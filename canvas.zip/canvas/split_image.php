<!DOCTYPE html>
<html>
<head>
  <title>Editable Frame & Preview</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  <style>
    body {
      background-color: #fff;
    }
    img {
      margin: 0px 10px;
    }
  </style>
</head>

<body>
  <div style="width:693px;" id="canvas_div">
    <img id="canvasimg" src="./image/rose-blue-flower-rose-blooms-67636.jpeg">
  </div>
  <button id="btn_preview" class="btn btn-success" tyle="button">Preview</button>
  <div id="test"></div>

  <div class="card" id="apend_div"></div>

    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="html2canvas.js"  ></script>
        <script src="html2canvas.min.js"  ></script>
        <script src="html2canvas.esm.js"  ></script>
        <script src="canvas2image.js"  ></script>

<script type="text/javascript">
            $(document).on('click', '#btn_preview', function(e) {
                var elm=$('#canvas_div').get(0);
                var lebar = '600';
                var tinggi  = '400';
                var type = 'png';
                var filename = 'htmltocanvas';
                alert();
                html2canvas(document.querySelector("#canvas_div")).then(canvas => {
                    // document.body.appendChild(canvas);

                    var canWidth=canvas.width;
                    var canHeight=canvas.height;
                    var img = Canvas2Image.convertToImage(canvas,canWidth,canHeight);
                    console.log(img.src);
                    alert(img.src);
                    // $('#preview').empty();
                    // alert(1);
                    // $('#preview').after(img);
                    get_preview(img);

                    // Canvas2Image.saveAsImage(canvas,lebar,tinggi,type,filename);
                })
            });
        </script>

<script type="text/javascript">
          
function get_preview(img){
    // alert('in');
        var canvas = document.createElement('canvas'),
        ctx = canvas.getContext('2d'),
        parts = [];
        // img = new Image();

    
    img.onload = split_4;
    function split_4() {
      
      var w2 = img.width / 3,
          h2 = img.height/1.8;
          // alert(w2);
      for(var i=0; i<3; i++) {
        var x = (-w2*i) % (w2*3),
            y = (h2*0)<=h2 ? 0 : -h2 ;
            console.log(x,y);
        canvas.width = w2;
        canvas.height = h2;
        ctx.drawImage(this, x, y, w2*3, h2*1);
        parts.push( canvas.toDataURL() );
        // for test div
        var slicedImage = document.createElement('img')
        slicedImage.src = parts[i];
        var div = document.getElementById('test');
        // div.appendChild( slicedImage );
      }
      console.log(parts);

          $.ajax({
                  type: "POST",
                  url: "./apend_image.php",
                  data: {data: parts},
                  cache: true,
                  async: false,
                  dataType:'html',
                  success: function(data){
                   // alert(data);
                  // result = data;
                  $('#apend_div').empty().append(data);
                  }
                  });
    }
    // img.src=document.getElementById("canvasimg").getAttribute('src');
             }
        </script>
<!--   <script type="text/javascript">
    $(document).on('click', '#btn_preview', function(e) {
    var canvas = document.createElement('canvas'),
        ctx = canvas.getContext('2d'),
        parts = [],
        img = new Image();

    
    img.onload = split_4;
    function split_4() {
      
      var w2 = img.width / 3,
          h2 = img.height/1.8;
          // alert(w2);
      for(var i=0; i<3; i++) {
        var x = (-w2*i) % (w2*3),
            y = (h2*0)<=h2 ? 0 : -h2 ;
            console.log(x,y);
        canvas.width = w2;
        canvas.height = h2;
        ctx.drawImage(this, x, y, w2*3, h2*1);
        parts.push( canvas.toDataURL() );
        // for test div
        var slicedImage = document.createElement('img')
        slicedImage.src = parts[i];
        var div = document.getElementById('test');
        // div.appendChild( slicedImage );
      }
      console.log(parts);

          $.ajax({
                  type: "POST",
                  url: "./apend_image.php",
                  data: {data: parts},
                  cache: true,
                  async: false,
                  dataType:'html',
                  success: function(data){
                   // alert(data);
                  // result = data;
                  $('#apend_div').empty().append(data);
                  }
                  });
    }
    img.src=document.getElementById("canvasimg").getAttribute('src');
    });
    


    // img.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQQAAABQCAYAAAD/YAtfAAAD6klEQVR4nO3c6Y0jIRCGYWdCKIRCKIRCKIRCKLU/dlxdzdDQF7ZHfkt6pB3uktbfzmqPhzxEAEAeIo93PwDA5yAQACgCAYAiEAAoAgGAIhAAKAIBgCIQACgCAYAiEAAoAgGAIhAAKAIBgCIQACgCAYAiEAAoAgGAIhAAKAIBgCIQACgCAYAiEAAoAgGAIhAAKAIBgCIQACgCAYAiEAAoAgGAIhAAKAJhJiciSUSK/K8iIuHA/vRzxrv7OMOLSJal8s/Yu9+FLgJhFidLENSVduxPZn0YrI2yDp345t7DRt+jXj6tjy9EIMxSZKki6w+4yPiDYfe6ztos7Spv6ttX70iN3v0f6ONLEQgzBFkq7xi3vKzLd+5JZl2R9W9PRPZ9J3I3+6ZoxmPnXZ/Yx5ciEGbwsvyEdtWcrdbebOZj5w5XneUG46/y7Lu+276r/IE+vhSBMJOvvnayrnp9MHN5cLZdm6q5ZObCi3vu9dea+9Q+vhSB8EpBliqN+WLm/eCsZNaGzj1px7tsZTOeq7k9Pdo9tge/ccedfeAyAuFVnKw/8LGaj2Yuyf8PkO+cZ89yjbueVXa8rS63Mb6nz2DW55+znKyDIkzqA5cRCK+SZV2umi9mzv44N9bW6+t5V501eluU3x/YUL0hHug1ynbV59zZBy4jEF4hyrpiNe+lX7lxpq3WnaP5mqvuS+Zrd7BfJ+0/RsyNs+7uA5cQCLN5WVdurInVmiTjv7dgq3XvaL6lvvP5lqM9l6rfbL4uL+gDpxEIsxVZl2usyWY+mfFkxnO1x1br3tF8i5Pf1XpvT9jRS5zcB04jEGaKsq6wsa6YNd6MezNeOntcNec6+0ay2ZtP9Gz3b/Viz53VB04hEGZxsq7UWWtr71wx465zd7nw5tbZI0d7mdEHTiMQZkmyVBmstbV3zp4fqrlg5tKBN0f5XfFg30d7mdEHTiMQZrHlB2vLxlpvxku1J5q5VM0lMxd3vteZPVnW3/q7A30f7eXuPnAJgTBDkKXyjvXJrE87xh9y/78BiGZPqHqIB3q352z1Ys+7uw9cQiDMkGWpLMsfI1rRrHeyrizjv8j0kPv+lWCs7nqO26rfvOVML3f1gcsIhBn2lt0TOuti566ysafI/l9VbSUzngZv3tLrJUzsA5cRCDMU2Vf1Pi/n/tuxaO4scvy/XrNl7/M73rzlTC9X+8BlBAIARSAAUAQCAEUgAFAEAgBFIABQBAIARSAAUAQCAEUgAFAEAgBFIABQBAIARSAAUAQCAEUgAFAEAgBFIABQBAIARSAAUAQCAEUgAFAEAgBFIABQBAIARSAAUAQCAEUgAFAEAgD1DxOuXDVQeFT8AAAAAElFTkSuQmCC";
  </script> -->
</body>

</html>