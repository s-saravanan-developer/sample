<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Earning extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Users_model');
        $this->load->model('earning/Earning_model');
    }

	public function index()
	{
        
		 $template['page']='earning/view_level_income';
         $template['level']       =  $this->Earning_model->get_all_level_types();
         $template['commission']  =  $this->Earning_model->get_all_commission_types();
         $template['topup']       =  $this->Earning_model->get_all_topups();
         $template['level']       =  $this->Earning_model->get_all_levels();
         $template['payout']      =  $this->Earning_model->get_earning();
        $this->load->view('template',$template);
        
		
	}

    
        public function get_contracts()
    {
        $topup             = $this->input->post("topup");
        $topops =  $this->Earning_model->get_contracts($topup);
        
        if(!empty($topops)){
                    echo '<option value>Select Contract</option>';            
                foreach ($topops as $value) {
                     echo '<option value="'.$value['Contract_ID'].'">'.$value['Contract_ref_no'].'</option>';
                 
                }}else{
                    echo '<option>Select Contract</option>';            
                }
        
    }

    public function binary_income()
    {
        
        $template['page']='earning/view_binary_income';
        $this->load->view('template',$template);
        
    }

    public function earning_summary()
    {
        
        $template['page']='earning/view_earning_summary';
        $this->load->view('template',$template);
        
    }

        public function get_earning1()
    {   extract($_POST);
        // var_dump($_POST);die();
        $mobile             = $this->input->post("mobile");
        $commission_type    = $this->input->post("commission_type");  
        $payment_status     = $this->input->post("payment_status");
        $topup              = $this->input->post("topup");
        $contract           = $this->input->post("contract");
        $level              = $this->input->post("level");
        $s_date             = date("Y-m-d", strtotime($this->input->post("s_date")));
        $e_date             = date("Y-m-d", strtotime($this->input->post("e_date")));
        $template['payout'] =  $this->Earning_model->get_earning1($commission_type,$payment_status,$s_date,$e_date,$mobile,$topup,$contract,$level);
// var_dump($template['payout']);die();
        $this->load->view('earning/ajax_earning',$template);
        
    }

}
    