<h3>You must login to access this page.</h3><br />
<a href='<?php echo base_url()."main/login" ?>'>Back to login</a>