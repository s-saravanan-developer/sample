<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Topup_model extends CI_Model { 

    function getall_bank() {

        $this->db->select('*');
        $this->db->where('Status',1);
        $this->db->order_by("ID", "DESC");
        $query = $this->db->get('gc_bank');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function process_withdraw_req($id)
{
        $data = array('Request_status' => 3, 'Withdrawn_status' => 6, 'Withdrawn_status_date' =>date('Y-m-d') );

        $this->db->where('Contract_ID',$id);
        $this->db->update('gc_member_franchisee_contract',$data);

}
public function cancel_withdraw_req($id,$date,$reason)
{
        $data = array('Request_status' => 4,'Rejecting_reason' => $reason );

        $this->db->where('Contract_ID',$id);
        $this->db->update('gc_member_franchisee_contract',$data);

}

function getall_members($status,$status1) {

        $this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');

        // $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
        $this->db->group_by("member.Membership_ID");
        if($status!=1){
        $this->db->where("member.Status",$status);}
        if($status1==10 || $status1==11){
            if($status1==10){
                $this->db->where("bank.Status",5);
            }elseif($status1==11){
                $this->db->where("documents.Status",5);
            }
        }
        $this->db->group_by("payments.Membership_ID");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


public function update_document_status($data,$Membership_ID) {
    $id=$data['Document_ID'];
    unset($data['Document_ID']);
        $this->db->where('Document_ID',$id);
        $this->db->update('gc_member_documents',$data);

        $data1['Status']=4;
        $this->db->where('Membership_ID',$Membership_ID);
        if($this->db->update('gc_membership',$data1)){
            return 1;
            }else{
                return 0;
            }
    }


}



