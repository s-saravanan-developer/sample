<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Offer_level_percentage extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
    }

    public function index()
    {
        $template['page']='master/offer_level_percentage/viewoffer_level_percentage';
        $template['offer'] =  $this->Master_model->getalloffer();
        $template['leveltype'] =  $this->Master_model->getall_leveltypes();
        $template['level'] =  $this->Master_model->getall_lts();
        $this->load->view('template',$template);
    }

    public function add_Offer_level_percentage()
    {
        extract($_POST);

        if ($Level_to == "")
        {
                $data = array(
                'Level_id' => $Level_from,
                'Level_type_id' => $Level_type_id,
                'Percentage' => $Percentage,
                'Description' => $Description,  
                'Status' => $Status
                );
                $this->db->insert('gc_offer_level_percentage',$data);

        }else{

         for ($i=$Level_from; $i <= $Level_to; $i++) 
         { 
                $data = array(
                'Level_id' => $i,
                'Level_type_id' => $Level_type_id,
                'Percentage' => $Percentage,
                'Description' => $Description,  
                'Status' => $Status
                );
            
                $this->db->insert('gc_offer_level_percentage',$data);
         }

        }      
        
        $this->session->set_flashdata('country_success', 'Added');
        redirect('master/Offer_level_percentage');
    }

    public function edit_Offer_level_percentage()
    {
        extract($_POST);

        $data = array(
                      'Level_id' => $Level_id,
                      'Level_type_id' => $Level_type_id,
                      'Percentage' => $Percentage,
                      'Description' => $Description,  
                      'Status' => $Status
                     );

        $this->db->where('ID',$id);
        $this->db->update('gc_offer_level_percentage',$data);
        $this->session->set_flashdata('country_success', 'Updated');
        redirect('master/Offer_level_percentage');
    }

    public function delete_offer_level_percentage($id)
    {

        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_offer_level_percentage',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Offer_level_percentage');
    }
}
