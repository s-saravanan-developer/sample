<div class="content-wrapper">
	 <div class="content">
			<header class="page-header">
				 <div class="d-flex align-items-center">
						<div class="mr-auto">
							 <h1 class="separator">Membership Downline Report</h1>
							 <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
									<ol class="breadcrumb">
										 <li class="breadcrumb-item"><a href="index.html"><i class="icon dripicons-home"></i></a></li>
										 <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
										 <li class="breadcrumb-item active" aria-current="page">Membership Downline Report</li>
									</ol>
							 </nav>
						</div>
						<ul class="actions top-right">
							 <li class="dropdown">
									<a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
									<i class="la la-ellipsis-h"></i>
									</a>
									<div class="dropdown-menu dropdown-icon-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(40px, 40px, 0px); top: 0px; left: 0px; will-change: transform;">
										 <div class="dropdown-header">
												Quick Actions
										 </div>
										 <a href="#" class="dropdown-item">
										 <i class="icon dripicons-clockwise"></i> Refresh
										 </a>
										 <a href="#" class="dropdown-item">
										 <i class="icon dripicons-gear"></i> Manage User Types
										 </a>
										 <a href="#" class="dropdown-item">
										 <i class="icon dripicons-help"></i> Support
										 </a>
									</div>
							 </li>
						</ul>
				 </div>
			</header>
			<section class="page-content container-fluid">
				 <div class="row">
						<div class="col">
							 <div class="card">
									<h5 class="card-header" style="display: inline-block;">Membership Downline Report  <a style="float:right;" href="<?php echo base_url();?>payout_money/Payout_money" class="btn btn-accent">Cancel</a></h5>
								 <!-- <form action="<?php echo base_url();?>master/users/user_add" method="POST"> -->
									
						<div class="card-body">
					 <div class="panel-body"><form>
				<input type="hidden" name="user_type_id" id="user_type_id" value="">
				<div class="row">
						<div class="col-md-12">
						<div class="form-group " style="float:right;">
								<div>
								
						</div>
						</div>
				</div>
				</div>
				<div class="card">
												<div class="card-body">
													 <div class="row">

																					 <div class="form-group col-md-4 enable_authorize_person" >
<label for="" required>Membership Code / Mobile <span style="color: #db3236">*</span></label>
<input type="text" class="form-control" name="payout[Date]" id="membership_code" placeholder="Mobile or Membership ID" required="" value="">
 <span id="referer_error_1" style="color:#db3236;"></span>
</div>
<!-- <div class="form-group col-md-4 enable_authorize_person" >
<label for="" required>Membership Code / Mobile <span style="color: #db3236">*</span></label>
<input type="text" class="form-control" name="payout[Mobile]" id="mobile_authorize" placeholder="Mobile or Membership ID" required="" value="<?php if(isset($Membership_code)){echo $Membership_code;}else{ echo "";

									} ?>">
									<input type="hidden"  name="">
 <span id="referer_error_1" style="color:#db3236;"></span>
</div> -->
<!--  <div class="form-group col-md-4 text-right" style="margin-top: 30px;">
												
												</div>
												 <div class="form-group col-md-4 text-right" style="margin-top: 30px;">
											 
												</div> -->
												 <div class="form-group col-md-4 text-right" style="margin-top: 30px;">
												<button type="button" class="btn btn-success  btn-floating get_levels"  id="get_levels" data-toggle="tooltip" data-placement="top" data-original-title="Search">
												Search 
												</button>
												</div>

												</div>


											 
									</div>
							 </div>
				<div class="card-footer bg-light">
										 <button class="btn btn-primary button_event export_payout"   type="button">Export Excel</button>
									</div>
				</form>
				
<?php //var_dump($payout); ?>
				<fieldset class="content-group">
						<div class="table-responsive" id="apend_new_div">
								<table id="bs4-table" class="table table-bordered table-striped table-bordered">

										<thead>
												<tr>
                            <th class="text-center">S.No</th>
                            <th class="text-center">Membership Code</th>
                            <th class="text-center">Membership Name</th>
                            <th class="text-center">Level</th>
                        </tr>
										</thead>
										
                  
                </table>
						</div>
				</fieldset>
				<div class="row">
						<!-- <div class="col-md-12">
								<button type="button" class="btn btn-danger" onclick="window.location = '<?php echo base_url('master/users'); ?>'" style="float:left;"><i class="icon-arrow-left13 position-left"></i> Cancel</button>
								<button type="submit" class="btn btn-success submit" >Submit <i class="icon-arrow-right14 position-right"></i></button>
						</div> -->
				</div>
			<!-- 	<div class="card-footer bg-light">                  
										 <button class="btn btn-success button_event process_payout" disabled  type="button">Process the Payment</button>
										 <button class="btn btn-accent button_event cancel_payout" disabled  type="button">Cancel Payout</button>
										 <button class="btn btn-primary button_event export_payout" disabled  type="button">Export Excel</button>
										 
									</div> -->
				</form>
		</div>
										 </div>

										 </div>





								 
								 <!--  <div class="card-footer bg-light">                  
										 <button class="btn btn-success" type="submit">Submit</button>
										 <a href="/medical_probook/master/users/user" class="btn btn-accent">Cancel</a>
									</div> -->
							 
									<!-- </form> -->
							 </div>
						</div>
				 </div>
	 </div>
	 </section>
</div>
</div>
</div>
<script type="text/javascript">
	$('#select_all').on('click',function(){
				if(this.checked){
						$('.checkbox').each(function(){
								this.checked = true;

						});
				}else{
						 $('.checkbox').each(function(){
								this.checked = false;
								
						});
				}
		});
$('.checkbox').on('click',function(){
				if($('.checkbox:checked').length == $('.checkbox').length){
						$('#select_all').prop('checked',true);
				}else{
						$('#select_all').prop('checked',false);
						//$('.button_event').prop('disabled',true);
				}
		});

$('.checkbox').change(function(){
		$('.button_event').prop('disabled', $('.checkbox:checked').length == 0);
});

				// $("#get_contract").click(function(e){
					$("#get_levels").click(function(e){
					// mobile=$("#mobile_authorize").val();
						membership_code=$("#membership_code").val();
						type='get_downline_details';
					
						$.ajax({
						type: "POST",
						url: "<?php echo base_url(); ?>Reports/get_downline_details",
						data: "type="+type+"&membership_code="+membership_code,
						cache: true,
						dataType:"html",
						// async: false,
						success: function(data){
							$('#apend_new_div').empty().append(data);
								
						}
						});
// });
});

		 $(document).ready(function() {
			$('#Payout_date').datepicker();


				$(".export_payout").click(function() {
						var favorite = [];
						membership_code=$('#membership_code').val();
						// $.each($("input[name='checkbox']:checked"), function() {
						// 		favorite.push($(this).val());
						// });


						swal({
							 title: 'Are you sure?',
							 text: "Are you Export to Excel this "+favorite.length+ " levels ?",
							 type: 'warning',
							 showCancelButton: true,
							 confirmButtonColor: '#3085d6',
							 cancelButtonColor: '#d33',
							 confirmButtonText: 'Yes, Export.!'
							 
						});
						$(".swal2-confirm").click(function(){
							 
							 window.location = "<?php echo base_url();?>Reports/excel_to_all_downline?membership_code="+membership_code;
						});
						$(".swal2-cancel").click(function(){
								 swal(
									'Canceled!',
									'Export Action Canceled.',
									'error'
							 );


						});
				});



		});


</script>

