<div class="content-wrapper">
  <div class="content">
    <header class="page-header">
      <div class="d-flex align-items-center">
        <div class="mr-auto">
          <h1 class="separator">Add New Lease </h1>
          <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i>
                </a>
              </li>
              <li class="breadcrumb-item active" aria-current="page">Lease Details / Add New Lease </li>
            </ol>
          </nav>
        </div>
        <ul class="actions top-right">
          <li class="dropdown">
            <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
              <i class="la la-ellipsis-h"></i>
            </a>
            <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
              <div class="dropdown-header">
                Quick Actions
              </div>
              <a href="#" class="dropdown-item">
                <i class="icon dripicons-clockwise"></i> Refresh
              </a>
              <a href="#" class="dropdown-item">
                <i class="icon dripicons-gear"></i> Manage Widgets
              </a>
              <a href="#" class="dropdown-item">
                <i class="icon dripicons-cloud-download"></i> Export
              </a>
              <a href="#" class="dropdown-item">
                <i class="icon dripicons-help"></i> Support
              </a>
            </div>
          </li>
        </ul>
      </div>
    </header>
    <section class="page-content container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <h5 class="card-header">Add Lease</h5>
            <div class="card-body">
              <form class="needs-validation" action="<?php echo base_url(); ?>lease/lease/add_lease" method="post" data-toggle="validator" role="form" enctype="multipart/form-data">
                <div class="form-row">

                  <div class="form-group col-md-4" style="padding-top: 5px;">
                   <label for="exampleFormControlSelect1">Tenant Origin<span style="color:red">*</span> </label>
                   <div class="input-group mb-3">
                     <div class="input-group-prepend">
                      <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                    </div>
                    <select class="form-control" name="lease[tenant_origin]" required>
                      <option value="">SELECT TENANT ORIGIN</option>
                      <option value="LOCAL NATIONAL">LOCAL NATIONAL</option>
                      <option value="INTERNATIONAL">INTERNATIONAL</option>
                      <option value="LOCAL TENANT">LOCAL TENANT</option>
                    </select>
                  </div>
                </div>

                <div class="form-group col-md-4" style="padding-top: 5px;">
                 <label for="exampleFormControlSelect1">Tenant Type <span style="color:red">*</span> </label>
                 <div class="input-group mb-3">
                   <div class="input-group-prepend">
                    <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                  </div>
                  <select class="form-control" name="lease[tenant_type]" required>
                    <option value="">SELECT TENANT TYPE</option>
                    <option value="CLOTHING">CLOTHING</option>
                    <option value="RETAILS">RETAILS</option>
                    <option value="FURNITURE">FURNITURE</option>
                    <option value="COMMUNICATION">COMMUNICATION</option>
                    <option value="RESTAURANT">RESTAURANT</option>
                  </select>
                </div>
              </div>
<!--                   <div class="form-group col-md-4" style="padding-top: 5px;">
                    <label for="exampleFormControlSelect1">Tenant <span style="color:red">*</span> </label>
                    <div class="input-group mb-3">
                     <div class="input-group-prepend">
                      <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                    </div>
                    <select class="form-control" name="lease[customer_id]" id="country_id" required>
                      <option value="">SELECT TENANT</option>
                      <?php if (!empty($customer)) {foreach ($customer as $value) {?>
                        <option value="<?php echo ucfirst($value['customer_id']); ?>" <?php echo ($value['customer_id'] == 0) ? 'selected' : ''; ?>><?php echo strtoupper($value['customer_name']); ?></option>
                      <?php } } ?>
                    </select>
                  </div>
                </div> -->

                <div class="form-group col-md-4">
                  <div class="form-group">
                    <label class="col-form-label-lg control-label" for="largeInput">Tenant Name <span style="color:red">*</span></label>
                    <div class="input-group mb-3">
                     <div class="input-group-prepend">
                      <span class="input-group-text "><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                    </div>
                    <input class="form-control" name="customer[customer_name]" placeholder="Enter Tenant Name" required="" type="text" maxlength="50">
                  </div>                                            
                </div>
              </div>

              <div class="form-group col-md-4" style="padding-top: 5px;">
               <label for="exampleFormControlSelect1">Lease Type <span style="color:red">*</span> </label>
               <div class="input-group mb-3">
                 <div class="input-group-prepend">
                  <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                </div>
                <select class="form-control" name="lease[lease_type]" required>
                  <option value="">SELECT LEASE TYPE</option>
                  <option value="AREA SQM">AREA SQM</option>
                  <option value="RENTAL">RENTAL</option>
                </select>
              </div>
            </div>

<!--             <div class="form-group col-md-4" style="padding-top: 5px;">
              <label for="exampleFormControlSelect1">Area <span style="color:red">*</span> </label>
              <div class="input-group mb-3">
               <div class="input-group-prepend">
                <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
              </div>
              <select class="form-control" name="lease[area_id]" id="area_id" required>
                <option value="">SELECT AREA</option>
                <?php if (!empty($area)) {foreach ($area as $value) {?>
                  <option value="<?php echo ucfirst($value['area_id']); ?>" <?php echo ($value['area_id'] == 0) ? 'selected' : ''; ?>><?php echo strtoupper($value['area_name']); ?></option>
                <?php } } ?>
              </select>
            </div>
          </div> -->

          <div class="form-group col-md-4">
            <div class="form-group">
              <label class="col-form-label-lg control-label" for="largeInput">Area Name <span style="color:red">*</span></label>
              <div class="input-group mb-3">
               <div class="input-group-prepend">
                <span class="input-group-text "><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
              </div>
              <input class="form-control" name="area[area_name]" placeholder="Enter Area Name" required="" type="text" maxlength="50">
            </div>                                            
          </div>
        </div>

        <div class="form-group col-md-4">
          <div class="form-group">
            <label class="col-form-label-lg control-label" for="largeInput">Area sqm <span style="color:red">*</span></label>
            <div class="input-group mb-3">
             <div class="input-group-prepend">
              <span class="input-group-text "><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
            </div>
            <input class="form-control" id="area_sqm" name="lease[area_sqm]" placeholder="Enter Area Sqm" required="" type="text" maxlength="50">
          </div>                                            
        </div>
      </div>

      <div class="form-group col-md-4">
        <div class="form-group">
          <label class="col-form-label-lg control-label" for="largeInput">Area Rent <span style="color:red">*</span></label>
          <div class="input-group mb-3">
           <div class="input-group-prepend">
            <span class="input-group-text "><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
          </div>
          <input class="form-control" id="area_rent" name="lease[area_rent]" placeholder="Enter Area Rent" required="" type="text" maxlength="50">
        </div>                                            
      </div>
    </div>

    <div class="form-group col-md-4">
      <div class="form-group">
        <label class="col-form-label-lg control-label" for="largeInput">Total Amount for Area Only <span style="color:red">*</span></label>
        <div class="input-group mb-3">
         <div class="input-group-prepend">
          <span class="input-group-text "><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
        </div>
        <input class="form-control" id="area_total" readonly name="lease[area_total]" placeholder="Enter Area Total" required="" type="text" maxlength="50">
      </div>                                            
    </div>
  </div>      
  <div class="form-group col-md-2">
    <div class="form-group">
      <label class="col-form-label-lg control-label" for="largeInput">Lease Duration (In Yrs) <span style="color:red">*</span></label>
      <div class="input-group mb-3">
       <div class="input-group-prepend">
        <span class="input-group-text "><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
      </div>
      <!-- <input class="form-control" id="lease_duration" name="lease[lease_tenure]" onkeypress="return isNumber(event,this.id)" placeholder="Enter Lease Duration" required="" type="text" maxlength="50"> -->
      <select class="form-control" name="lease[lease_tenure]" id="lease_duration" required>
                  <option value="">SELECT LEASE YEAR</option>
                  <?php for($i=0;$i<=99;$i++){ ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                  <?php } ?>
                </select>
    </div>                                            
  </div>
</div> 
 <div class="form-group col-md-2">
    <div class="form-group">
      <label class="col-form-label-lg control-label" for="largeInput">Lease Duration (In Mnths) <span style="color:red">*</span></label>
      <div class="input-group mb-3">
       <div class="input-group-prepend">
        <span class="input-group-text "><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
      </div>
      <!-- <input class="form-control" id="lease_duration" name="lease[lease_tenure]" onkeypress="return isNumber(event,this.id)" placeholder="Enter Lease Duration" required="" type="text" maxlength="50"> -->
       <select class="form-control" name="lease[lease_tenure_month]" id="lease_duration_month" required>
                  <option value="">SELECT LEASE Month</option>
                  <?php for($i=0;$i<=11;$i++){ ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                  <?php } ?>
                  
                </select>
    </div>                                            
  </div>
</div>        
<div class="form-group col-md-4">
  <div class="form-group">
    <label class="col-form-label-lg control-label" for="largeInput">  Start Date <span style="color:red">*</span></label>
    <div class="input-group mb-3">
     <div class="input-group-prepend">
      <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
    </div>
    <input class="form-control date" name="lease[start_date]" id="start_date" placeholder="Enter Lease Date" required="" value="<?php echo date('d-m-Y'); ?>" type="text" maxlength="50">
  </div>                                            
</div>
</div> 

<div class="form-group col-md-4">
  <div class="form-group">
    <label class="col-form-label-lg control-label" for="largeInput">  End Date <span style="color:red">*</span></label>
    <div class="input-group mb-3">
     <div class="input-group-prepend">
      <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
    </div>
    <input class="form-control" name="lease[end_date]" id="end_date" placeholder="Enter End Date" readonly required="" value="" type="text" maxlength="50">
  </div>                                            
</div>
</div> 
<script>

  $(document).ready(function(){
   $('#start_date').datepicker().on('change', function (ev) {
    date_change();

  });
   $('#lease_duration').on('change', function (ev) {
    date_change();

  });

  $('#lease_duration_month').on('change', function (ev) {
    // alert();
    date_change();

  });

   


 });




</script>

<!--   <div class="form-group col-md-4">
    <div class="form-group">
      <label class="col-form-label-lg control-label" for="largeInput">  End Date <span style="color:red">*</span></label>
      <div class="input-group mb-3">
       <div class="input-group-prepend">
        <span class="input-group-text"><i class="zmdi zmaintenancemdi-balance zmdi-hc-fw"></i></span>
      </div>
      <input class="form-control date" name="lease[end_date]" id="end_date" placeholder="Enter End Date" required="" value="<?php echo date('d-m-Y'); ?>" type="text" maxlength="50">
    </div>                                            
  </div>
</div>  -->
</div>
<br>
<div class="card">
  <div id="table_data">
    <table  class="table table-striped table-bordered dataTable no-footer" style="width:100%">
      <input type="hidden" id="full_value" value="">
      <thead>
        <tr style="background-color: #1e5598;color: #fff;">
          <th class="text-center" width="18%">Category</th>
          <th class="text-center" width="18%">Duration</th>
          <th class="text-center" width="18%">Percentage/Fixed</th>
          <th class="text-center" width="18%">SQRFT/TotalAmount</th>
          <th class="text-center">Value</th>
          <th class="text-center">Total Value</th>
          <th class="text-center">Action</th>
        </tr>
      </thead>
      <tbody id="dat_tbl">
        <tr id="1" class="root">
          <td class="text-center">
            <div class="form-group">
              <div class="input-group mb-3">
                <select class="form-control clear_input need custom-select" required=""  name="lease_data[0][category_type]" style="width: 100%;">
                  <option value="">SELECT CATEGORY</option>
                  <option value="MAINTENANCE">MAINTENANCE</option>
                  <option value="PARKING">PARKING</option>
                  <option value="ESCALATION">ESCALATION</option>
                  <option value="AIRCONDITION">AIRCONDITION</option>
                </select>
              </div>
            </div>
          </td>

          <td class="text-center">
            <div class="form-group">
              <div class="input-group mb-3">
                <select class="form-control clear_input need custom-select" required=""  name="lease_data[0][duration]" style="width: 100%;">
                  <option value="">SELECT DURATION</option>
                  <option value="YEAR">YEAR</option>
                  <option value="MONTH">MONTH</option>
                </select>
              </div>
            </div>
          </td>

          <td class="text-center">
            <div class="form-group">
              <div class="input-group mb-3">                              
                <select class="form-control clear_input" required style="width: 100%;" name="lease_data[0][category_amount_type]" id="increment_type1">
                  <option value="">SELECT PERCENTAGE / FIXED</option>
                  <option value="PERCENTAGE">PERCENTAGE</option>
                  <option value="FIXED">FIXED</option>
                </select>
              </div>
            </div>
          </td>
          <td class="text-center">
            <div class="form-group">
              <div class="input-group mb-3">                              
                <select class="form-control clear_input" onchange="return calculation_type(1);" required style="width: 100%;" name="lease_data[0][category_cal_type]" id="calculation_type1">
                  <option value="">SELECT SQRft / TOTALAMOUNT</option>
                  <option value="1">SQUARE FT</option>
                  <option value="2">TOTAL AMOUNT</option>
                  <option value="3">FLAT</option>
                </select>
              </div>
            </div>
          </td>
          <script>
            $('#increment_type').on('change', function() {
              $('#increment_type').val();
              if ($('#increment_type').val()=='PERCENTAGE') {
                //$('#amount_val').removeAttr('readonly');
                $('#amount_val').val('0');
                $('#percent_val').val('0');
                $('#percent_val').removeAttr('readonly');
              }else{
                $('#amount_val').val('0');
                $('#percent_val').val('0');
                $('#percent_val').removeAttr('readonly');
              }
            });
          </script> 
          <td class="text-center">
            <div class="form-group">
              <div class="input-group mb-3">                              
                <input type="text" onkeyup="return calculation(1);" id="percent_val1" name="lease_data[0][category_percentage]" placeholder="Percent" class="form-control clear_input">
              </div>
            </div>
          </td>
          <td class="text-center">
            <div class="form-group">
              <div class="input-group ">
                <input type="text" placeholder="Value" name="lease_data[0][category_value]" class="form-control clear_input" id="amount_val1" readonly="" value="0">
              </div>
            </td>

            <td class="text-center">
              <button class="btn btn-danger close_x" type="button" style="padding: 4px;" disabled><i class="zmdi zmdi-close" style="color: white;" ></i></button>
            </td>

          </tr>
          <tfoot>
            <tr>
              <td colspan="6">
                <button id="add_new_box" class="btn btn-info new_add" type="button"><i class="zmdi zmdi-plus" style="color: white;"></i> Add New </button>
              </td>
            </tr>
          </tfoot>
        </tbody>
      </table>
    </div>
    <div>
      <label for=""></label>
    </div>
    <div class="card-footer bg-light">
      <div style="float: right;">
        <button style="color: white;" class="btn btn-success" id="submit" type="submit">Save &amp; Continue</button>
        <a href="<?php echo base_url(); ?>lease/lease" class="btn btn-accent">Cancel</a>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>

            <!-- <div class="row">
         
            <h5 class="card-header">User Defined Feilds
             </h5>
          <div class="col-12">
             <div class="row">
                <div class="form-group col-md-4">
                    <div class="form-group">
                        <label class="col-form-label-lg control-label" for="largeInput">  UDF 1 <span style="color:red">*</span></label>
                        <div class="input-group mb-3">
                           <div class="input-group-prepend">
                              <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                           </div>
                           <input class="form-control" name="lease[udf_1]" placeholder="Enter UDF 1" required="" type="text" maxlength="50">
                        </div>                                            
                     </div>
                </div> 
                <div class="form-group col-md-4">
                    <div class="form-group">
                        <label class="col-form-label-lg control-label" for="largeInput">  UDF 2 <span style="color:red">*</span></label>
                        <div class="input-group mb-3">
                           <div class="input-group-prepend">
                              <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                           </div>
                           <input class="form-control" name="lease[udf_2]" placeholder="Enter UDF 2" required="" type="text" maxlength="50">
                        </div>                                            
                     </div>
                </div>
                <div class="form-group col-md-4">
                    <div class="form-group">
                        <label class="col-form-label-lg control-label" for="largeInput">  UDF 3 <span style="color:red">*</span></label>
                        <div class="input-group mb-3">
                           <div class="input-group-prepend">
                              <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                           </div>
                           <input class="form-control" name="lease[udf_3]" placeholder="Enter UDF 3" required="" type="text" maxlength="50">
                        </div>                                            
                     </div>
                </div>
             </div>
          </div>
        </div> -->
        <script>
          $(document).ready(function(){
           // $('.date').datepicker();
           $('.date').datepicker({ dateFormat: 'dd/mm/yy' }).val();
         });
       </script>
     </div>
   </form>
 </div>
</div>
</div>
</section>
</div>
</div>
</div>
<script src="<?php echo base_url(); ?>/assets/vendor/jquery/dist/jquery.min.js"></script>

<script type="text/javascript">

  $(document).ready(function() {
    $('.gstin').prop( "disabled", true );
  });
  $('select#gst_in').change(function() {
    var selectedText = $(this).find('option:selected').val();     
    if(selectedText == '1' || selectedText == '2' ){
      $('.gstin').prop( "disabled", false );
      $('.gstin').attr('required','required');        
    }
    else {
      $('.gstin').prop( "disabled", true );
      $('.gstin').removeAttr('required');
    }
  });
</script>


<script type="text/javascript">

 function isNumber(evt) {
  evt = (evt) ? evt : window.event;
  var charCode = (evt.which) ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

$('#area_id').on('change', function() {
  area=$('#area_id').val();             

  $.ajax({                    
    type: "POST",
    url: "<?php echo base_url(); ?>lease/lease/get_area_by_areaid",  
    data: {area: area},
    success: function(data){
      var result = JSON.parse(data);
      $('#area_sqm').empty();
      $('#area_sqm').val(result[0]['area_sqm']);
      $('#area_rent').empty();
      $('#area_rent').val(result[0]['area_rent']);
      $('#area_total').empty();
      $('#area_total').val(result[0]['area_rent']*result[0]['area_sqm']);
    }
  });
});

  function date_change(){
    date=$('#start_date').val();
    // alert(date);
    if(date.includes("/")){
      s_date=date.split('/');
      s='/';
    }else{
      s_date=date.split('-');
      s='-';
    }

    lease=$('#lease_duration').val();
    if(lease==''){
      lease=0;
    }
    lease_month=$('#lease_duration_month').val();
    // alert(lease_month);
    if(lease_month==''){
      lease_month=0;
    }

    // n_year=parseInt(s_date[2])+lease;
    // n_mnth=parseInt(s_date[1])+lease_month;
    // n_day=parseInt(s_date[0])-1;
    // e_date=s_date[0]+s+s_date[1]+s+n_year;
    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>lease/lease/date_change",
      data: {start_date: date,lease_year: lease,lease_month:lease_month},
      // cache: true,
      // async: false,
      success: function(data){
       // alert(data);
      $('#end_date').val(data);
      }
      });
      
      
  }

$(document).ready(function(){
  $('#area_id').on('change', function() {
    $('.root1').empty();
    $('.clear_input').val('');
  });
  $('#area_sqm').on('keyup', function() {
    $('.root1').empty();
    $('.clear_input').val('');
    $('#area_total').empty();
    $('#area_total').val($('#area_sqm').val()*$('#area_rent').val());
  });
  $('#area_rent').on('keyup', function() {
    $('.root1').empty();
    $('.clear_input').val('');
    $('#area_total').empty();
    $('#area_total').val($('#area_sqm').val()*$('#area_rent').val());
  });
});



// Add New Box
var count = 1;
$( "#add_new_box" ).click(function() {


  count = count+1;
  $("#dat_tbl").append(
    '<tr id='+count+' class="root1"> <td class="text-center"> <div class="form-group"> <div class="input-group mb-3"> <select class="form-control need custom-select" required=""  name="lease_data['+count+'][category_type]" style="width: 100%;"> <option value="">SELECT CATEGORY</option> <option value="MAINTENANCE">MAINTENANCE</option> <option value="PARKING">PARKING</option> <option value="ESCALATION">ESCALATION</option> <option value="AIRCONDITION">AIRCONDITION</option> </select> </div> </div>` </td><td class="text-center"> <div class="form-group"> <div class="input-group mb-3"> <select class="form-control clear_input need custom-select" required=""  name="lease_data['+count+'][duration]" style="width: 100%;"> <option value="">SELECT DURATION</option> <option value="YEAR">YEAR</option> <option value="MONTH">MONTH</option> </select> </div> </div> </td> <td class="text-center"> <div class="form-group"> <div class="input-group mb-3"> <select class="form-control"  required style="width: 100%;" name="lease_data['+count+'][category_amount_type]" id="increment_type'+count+'"> <option value="">SELECT AMOUNT TYPE</option> <option value="PERCENTAGE">PERCENTAGE</option> <option value="FIXED">FIXED</option> </select> </div> </div> </td><td class="text-center"> <div class="form-group"> <div class="input-group mb-3"> <select class="form-control clear_input" required style="width: 100%;" name="lease_data['+count+'][category_cal_type]"onchange="return calculation_type('+count+');" id="calculation_type'+count+'"> <option value="">SELECT SQRft / TOTALAMOUNT</option> <option value="1">SQUARE FT</option> <option value="2">TOTAL AMOUNT</option> <option value="3">FLAT</option> </select> </div> </div> </td> <td class="text-center"> <div class="form-group"> <div class="input-group mb-3"> <input type="text" onkeyup="return calculation('+count+');" id="percent_val'+count+'"  name="lease_data['+count+'][category_percentage]" placeholder="Percent" class="form-control"> </div> </div> </td> <td class="text-center"> <div class="form-group"> <div class="input-group mb-4"> <input type="text" placeholder="Value" name="lease_data['+count+'][category_value]" class="form-control" id="amount_val'+count+'" value=""> </div> </td> <td class="text-center"> <button class="btn btn-danger close_x" type="button" style="padding: 4px;" ><i class="zmdi zmdi-close" style="color: white;" ></i></button> </td> </tr>'
    );


  $('#increment_type'+count).on('change', function() {
    $('#increment_type'+count).val();
    if ($('#increment_type'+count).val()=='PERCENTAGE') {
      $('#percent_val'+count).val('0');
      $('#amount_val'+count).val('0');
      $('#percent_val'+count).removeAttr('readonly');
    }else{
      $('#percent_val'+count).val('0');
      $('#amount_val'+count).val('0');
      $('#percent_val'+count).removeAttr('readonly');
    }
  });
  $(document).ready(function(){

    $('#amount_val'+count).attr('readonly','readonly');
    $('#percent_val'+count).attr('readonly','readonly');

   //  $('#percent_val'+count).on('keyup', function() {
   //   $('#amount_val'+count).val(($('#area_total').val()/100)*$('#percent_val'+count).val());
   // });


   //  $('#percent_val'+count).on('keyup', function() {

   //    if ($('#increment_type'+count).val()=='PERCENTAGE') {
   //      $('#amount_val'+count).val(($('#area_total').val()/100)*$('#percent_val'+count).val());
   //    }else{
   //      $('#amount_val'+count).val($('#percent_val'+count).val());
   //    }
   // });


   //  $('#amount_val'+count).on('keyup', function() {
   //   let area_total=Number($('#area_total').val());
   //   let amount_val=Number($('#amount_val'+count).val());
   //   let find_per=Number((amount_val/area_total)*100);
   //   $('#percent_val'+count).val(find_per.toFixed(2));
   // });
  });
});

$(document).on('click', '.close_x', function(e) {
 var id = $(this).parents('tr:first').attr('id');
 $('#'+id+'').remove();
});
</script>
<script>
  
  function calculation(key){
    var area_square=Number($("#area_sqm").val());
    var area_total=Number($("#area_total").val());
    var per_val=Number($("#percent_val"+key).val());
    var increment_type= $('#increment_type'+key).val();
    var calculation_type= $('#calculation_type'+key).val();
    // alert('area_square='+area_square+',area_total='+area_total+',per_val='+per_val+',increment_type='+increment_type+',calculation_type='+calculation_type);

  if(area_square =='' || area_square=='0'){
    alert('Please Enter Squarefit value.....!');
    return false;
  }

   if(area_total =='' || area_total=='0'){
    alert('Please Enter Area Rent.....!');
    return false;
  }

  if(increment_type==''){
    alert('Please Select Percentage Or Fixed.....!');
    return false;
  }

   if(calculation_type==''){
    alert('Please Select SQRFIT or TotalAmount.....!');
    return false;
  }

    
     if ($('#increment_type'+key).val()=='PERCENTAGE') {

      if($('#calculation_type'+key).val()=='1'){//1 square
        var final=Number((area_square/100)*per_val);
        $('#amount_val'+key).val(final);

         }

     if($('#calculation_type'+key).val()=='2'){//2 total amt

        var final=Number((area_total/100)*per_val);
        $('#amount_val'+key).val(final);

     }


     if($('#calculation_type'+key).val()=='3'){//2 total amt

        var final=$('#percent_val'+key).val();
        $('#amount_val'+key).val(final);

     }


     }



       if ($('#increment_type'+key).val()=='FIXED') {

        if($('#calculation_type'+key).val()=='1'){//1 square

         var final=Number((area_square) * per_val);
        $('#amount_val'+key).val(final);

         }

         if($('#calculation_type'+key).val()=='2'){//2 total amt

        var final=Number((area_total)*per_val);
        $('#amount_val'+key).val(final);

         }

         if($('#calculation_type'+key).val()=='3'){//2 total amt

        var final=$('#percent_val'+key).val();
        $('#amount_val'+key).val(final);

         }

       } 
  }

  //END Calculations



  function calculation_type(key){
                      $('#percent_val'+key).val('0');
                $('#amount_val'+key).val('0');
  }
  $(document).ready(function(){

    $('#amount_val').attr('readonly','readonly');
    $('#percent_val').attr('readonly','readonly');

   //  $('#percent_val').on('keyup', function() {

   //    if ($('#increment_type').val()=='PERCENTAGE') {
   //      $('#amount_val').val(($('#area_total').val()/100)*$('#percent_val').val());
   //    }else{
   //      $('#amount_val').val($('#percent_val').val());
   //    }
   // });
    // $('#amount_val').on('keyup', function() {
    //   area_total=Number($('#area_total').val());
    //   amount_val=Number($('#amount_val').val());
    //   find_per=Number((amount_val/area_total)*100);
    //   $('#percent_val').val(find_per.toFixed(2));
    // });
  });
</script>