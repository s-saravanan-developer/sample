<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Commission extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
    }

	public function index()
	{
    	$template['page']='master/commission/viewcommission';
        $template['commission'] =  $this->Master_model->getall_commission();  
        $template['payout'] =  $this->Master_model->getallpayout();
        // var_dump( $template['payout']);die();
        $this->load->view('template',$template);
	}

    public function add_commission()
    {
        extract($_POST);

        $data = array('Commission' => $Commission,
                      'Alias_name' => $Alias_name,
                      //'Payout_type_id' => $Payout_type_id,
                      //'Percentage' => $Value,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->insert('gc_commission',$data);
        $this->session->set_flashdata('payout_success', 'Added');
        redirect('master/commission');
    }


    public function edit_commission()
    {
        extract($_POST);

        $data = array('Commission' => $Commission,
                      'Alias_name' => $Alias_name,
                      //'Payout_type_id' => $Payout_type_id,
                      //'Percentage' => $Value,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->where('ID',$ID);
        $this->db->update('gc_commission',$data);
        $this->session->set_flashdata('payout_success', 'Updated');
        redirect('master/commission');
    }


    public function delete_commission($id)
    {

        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_commission',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/commission');
    }

}
