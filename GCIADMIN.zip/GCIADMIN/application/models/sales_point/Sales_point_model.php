<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_point_model extends CI_Model { 

	function getall_sales_points() {

		$this->db->select('*');
		$this->db->where('status',1);
		$this->db->where('user_type_id',6);
		$this->db->order_by("firstname", "ASC");
		$query = $this->db->get('gc_users');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

	function get_sales_point_details($sales_point) {

		$this->db->select('user.*,country.country_name,city.city_name,state.state_name');
		$this->db->from('gc_users as user');
		$this->db->join('gc_countries as country','country.id = user.country_id','left');
		$this->db->join('gc_states as state','state.id = user.state_id','left');
		$this->db->join('gc_cities as city','city.id = user.city_id','left');
		$this->db->where('user.status',1);
		$this->db->where('user.user_type_id',6);
		$this->db->where('user.id',$sales_point);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

	function getall_service_entries() {

		$this->db->select('wallet.*,member.First_name,member.Last_name,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
		// $this->db->where('wallet.Status',1);

		if($this->session->userdata('UserTypeID')==6){
			// $this->db->where('wallet.Wallet_amount_from',1);
		// }elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',2);
			$this->db->where('wallet.Topup_for',1);
			$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));

		}

		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

	function getall_service_entries_credit() {

		$this->db->select('wallet.*,member.First_name,member.Last_name,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
		// $this->db->where('wallet.Status',1);

		if($this->session->userdata('UserTypeID')==1){
			$this->db->where('wallet.Wallet_amount_from',1);
		}elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',1);
			$this->db->where('wallet.Topup_for',2);
			$this->db->where('wallet.Service_point',$this->session->userdata('UserId'));

		}

		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

	function getall_service_entries_by_id($sales_point) {

		$this->db->select('wallet.*,member.First_name,member.Last_name,member.Membership_code,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
		// $this->db->where('wallet.Status',1);
		$this->db->where('wallet.Wallet_topup_ID',$sales_point);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}
	
		function getall_service_payments_by_id($sales_point) {

		$this->db->select('');
		$this->db->from('gc_wallet_payments as wallet');
		// $this->db->where('wallet.Status',1);
		$this->db->where('wallet.Service_point_ID',$sales_point);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

function getall_service_summary($mobile,$s_date,$e_date,$topup_for,$sales_point) {

		$this->db->select('wallet.*,member.First_name,member.Last_name,member.Membership_code,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
		$this->db->where('wallet.Status',6);
		if($topup_for==1){

			$this->db->where('wallet.Topup_for',$topup_for);
		if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
		}else{
			$this->db->where('wallet.Topup_for',$topup_for);
			if(!empty($sales_point)){
				$this->db->where('wallet.Service_point',$sales_point);
			}
			
		}
		if(!empty($s_date)){
        $this->db->where("wallet.Date >=",date('Y-m-d',strtotime($s_date)));
     }
     if(!empty($e_date)){
        $this->db->where("wallet.Date <=",date('Y-m-d',strtotime($e_date)));
     }

  //    if($this->session->userdata('UserTypeID')==6){
		// 	// $this->db->where('wallet.Wallet_amount_from',1);
		// // }elseif($this->session->userdata('UserTypeID')==6){
		// 	$this->db->where('wallet.Wallet_amount_from',2);
		// 	$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));

		// }
		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}
	
public function insert_service_point($data){
	if($this->db->insert('gc_wallet_topup',$data)){
		 $inserted_id=$this->db->insert_id();
	}else{
		$inserted_id='';
	}
	return $inserted_id;
}	

public function insert_service_point1($data)
{
	if($data['Wallet_amount_from']==2 && $data['Topup_for']==1){
						$query2 = $this->db->get_where('gc_service_wallet', array('Service_point_ID' => $data['Wallet_service_point']))->result_array();
					if(count($query2)>0){
						if($query2[0]['Wallet_balance']>=$data['Total_amount']){
							$wallet_data=array(
									  'Wallet_balance'=>$query2[0]['Wallet_balance']-$data['Total_amount'],
									  'Updated_date'=>date('Y-m-d'));
							$this->db->where('Service_point_ID',$data['Wallet_service_point']);
							$this->db->update('gc_service_wallet',$wallet_data);

							$query3 = $this->db->get_where('gc_users', array('id' => $data['Wallet_service_point']))->result_array();
						$user_data=array('Wallet_balance'=>$query3[0]['Wallet_balance']-$data['Total_amount']);
						$this->db->where('id',$data['Wallet_service_point']);
						$this->db->update('gc_users',$user_data);

						$query1 = $this->db->get_where('gc_membership', array('Membership_ID' => $data['Membership_ID']))->result_array();
							$member_data['Wallet_balance']=$query1[0]['Wallet_balance']+$data['Total_amount'];
							$this->db->where('Membership_ID',$data['Membership_ID']);
							$this->db->update('gc_membership',$member_data);

						$data['Status']=6;
						$data['Processed_date']=date('Y-m-d');
								if($this->db->insert('gc_wallet_topup',$data)){
									 $inserted_id=$this->db->insert_id();
								}else{
									$inserted_id='';
								}

						}
							
						}
					}else{
						if($data['Topup_for']==1){
							$query1 = $this->db->get_where('gc_membership', array('Membership_ID' => $data['Membership_ID']))->result_array();
							$member_data['Wallet_balance']=$query1[0]['Wallet_balance']+$data['Total_amount'];
							$this->db->where('Membership_ID',$data['Membership_ID']);
							$this->db->update('gc_membership',$member_data);

							$data['Status']=6;
							$data['Processed_date']=date('Y-m-d');
								if($this->db->insert('gc_wallet_topup',$data)){
									 $inserted_id=$this->db->insert_id();
								}else{
									$inserted_id='';
								}
					}else{
						$query2 = $this->db->get_where('gc_service_wallet', array('Service_point_ID' => $data['Service_point']))->result_array();
   			// if($data['Total_amount']>=5000){
   			// if($data['Total_amount']>=5000 && $data['Total_amount']<=5999){
      //                   $bin_com=5;
      //               }elseif($data['Total_amount']>=6000 && $data['Total_amount']<=6999){
      //                   $bin_com=7;
      //               }else{
      //                   $bin_com=10;
      //               }
      //               $final_Commission=$data['Total_amount']+($data['Total_amount'] * $bin_com) / 100;
      //           }else{
                	$final_Commission=$data['Total_amount'];
                //}

                  
						if(count($query2)>0){
							$wallet_data=array(
									  'Wallet_balance'=>$query2[0]['Wallet_balance']+$final_Commission,
									'Updated_date'=>date('Y-m-d'));
							$this->db->where('Service_point_ID',$data['Service_point']);
							$this->db->update('gc_service_wallet',$wallet_data);
						}else{
							$wallet_data=array(
									  'Company_id'=>$data['Company_id'],
									  'Branch_id'=>$data['Company_id'],
									  'Service_point_ID'=>$data['Service_point'],
									  'Wallet_balance'=>$final_Commission);

							$this->db->insert('gc_service_wallet',$wallet_data);
						}
						$query3 = $this->db->get_where('gc_users', array('id' => $data['Service_point']))->result_array();
						$user_data=array('Wallet_balance'=>$query3[0]['Wallet_balance']+$final_Commission);
						$this->db->where('id',$data['Service_point']);
						$this->db->update('gc_users',$user_data);

						$data['Status']=6;
						$data['Processed_date']=date('Y-m-d');
									if($this->db->insert('gc_wallet_topup',$data)){
										 $inserted_id=$this->db->insert_id();
									}else{
										$inserted_id='';
									}

					}
					}


					return $inserted_id;

}

public function insert_service_wallet($data){
	if($data['Topup_for']==2){
		   
   			$query = $this->db->get_where('gc_service_wallet', array('Service_point_ID' => $data['Service_point']))->result_array();
   			// if($data['Total_amount']>=3000){
   			// if($data['Total_amount']>=3000 && $data['Total_amount']<=3999){
      //                   $bin_com=5;
      //               }elseif($data['Total_amount']>=4000 && $data['Total_amount']<=4999){
      //                   $bin_com=8;
      //               }else{
      //                   $bin_com=10;
      //               }
      //               $final_Commission=$data['Total_amount']+($data['Total_amount'] * $bin_com) / 100;
      //           }else{
                	$final_Commission=$data['Total_amount'];
                //}

                    
		if($query->num_rows()>0){
			$wallet_data=array(
					  'Wallet_balance'=>$query[0]['Wallet_balance']+$final_Commission,
					'Updated_date'=>date('Y-m-d'));
			$this->db->where('Service_point_ID',$data['Service_point']);
			$this->db->update('gc_service_wallet',$wallet_data);
		}else{
			$wallet_data=array(
					  'Company_id'=>$data['Company_id'],
					  'Branch_id'=>$data['Company_id'],
					  'Service_point_ID'=>$data['Service_point'],
					  'Wallet_balance'=>$final_Commission);

			$this->db->insert('gc_service_wallet',$wallet_data);
		}
		$query3 = $this->db->get_where('gc_users', array('id' => $query[0]['Service_point']))->result_array();
						$user_data=array('Wallet_balance'=>$query3[0]['Wallet_balance']+$final_Commission);
						$this->db->where('id',$query[0]['Service_point']);
						$this->db->update('gc_users',$user_data);
	
	}else{
		$query = $this->db->get_where('gc_membership', array('Membership_ID' => $data['Membership_ID']))->result_array();
		if($query->num_rows()>0){
			$wallet_data=array(
					  'Wallet_balance'=>$query[0]['Wallet_balance']+$data['Total_amount']);
			$this->db->where('Membership_ID',$data['Membership_ID']);
			$this->db->update('gc_membership',$wallet_data);
		}
	}
}


public function insert_service_point_payment($data){
	if($this->db->insert('gc_wallet_payments',$data)){
		 $inserted_id=$this->db->insert_id();
	}else{
		$inserted_id='';
	}
	return $inserted_id;
}

public function process_withdraw_req($id)
{
		$data = array('Request_status' => 3, 'Withdrawn_status' => 6, 'Withdrawn_status_date' =>date('Y-m-d') );
		$this->db->where('Contract_ID',$id);
		$this->db->update('gc_member_franchisee_contract',$data);

}
public function cancel_withdraw_req($id,$date,$reason)
{
		$data = array('Request_status' => 4,'Rejecting_reason' => $reason );

		$this->db->where('Contract_ID',$id);
		$this->db->update('gc_member_franchisee_contract',$data);

}

function getall_members($status,$status1) {

		$this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name');
		$this->db->from('gc_membership as member');
		$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
		$this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
		$this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
		$this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');

		// $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
		$this->db->group_by("member.Membership_ID");
		if($status!=1){
		$this->db->where("member.Status",$status);}
		if($status1==10 || $status1==11){
			if($status1==10){
				$this->db->where("bank.Status",5);
			}elseif($status1==11){
				$this->db->where("documents.Status",5);
			}
		}
		$this->db->group_by("payments.Membership_ID");
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}


public function update_document_status($data,$Membership_ID) {
	$id=$data['Document_ID'];
	unset($data['Document_ID']);
		$this->db->where('Document_ID',$id);
		$this->db->update('gc_member_documents',$data);

		$data1['Status']=4;
		$this->db->where('Membership_ID',$Membership_ID);
		if($this->db->update('gc_membership',$data1)){
			return 1;
			}else{
				return 0;
			}
	}


}



