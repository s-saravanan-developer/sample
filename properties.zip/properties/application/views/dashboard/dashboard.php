<script>
 <?php
 if ($this->session->flashdata('success')) 
 {
  echo "var data = ' ".$this->session->flashdata('success')."';";
  echo "success(data);";
}
?>
</script>
<div class="content-wrapper">
  <div class="content">
    <header class="page-header">
     <div class="d-flex align-items-center">
      <div class="mr-auto">
       <h1 class="separator">Dashboard</h1>
     </div>
   </div>
 </header>
</div>
</div>
</div>  
