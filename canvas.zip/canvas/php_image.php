<div class="box" style="border: 4px solid #8FB3E7;
  padding: 20px;
  color: white;
  font-size: 100px;
  width: 800px;
  height: 400px;
  font-family: 'Roboto';
  background-color: #8BC6EC;
  background-image: linear-gradient(135deg, #8BC6EC 0%, #9599E2 100%);">
  <!-- <h3>Hi, Saravanan </h3> -->

            <div id="image" >
              <img src="./image/preview_img.png" id="result" style="width:318px;height:318px;" >
            </div>
</div>

<?php



    

  $html = <<<EOD
<div class="box" style="border: 4px solid #8FB3E7;
  padding: 20px;
  color: white;
  font-size: 100px;
  width: 800px;
  height: 400px;
  font-family: 'Roboto';
  background-color: #8BC6EC;
  background-image: linear-gradient(135deg, #8BC6EC 0%, #9599E2 100%);">
  <h3>Hi, Saravanan </h3>
</div>
EOD;

$css = <<<EOD
.box {
  border: 4px solid #8FB3E7;
  padding: 20px;
  color: white;
  font-size: 100px;
  width: 800px;
  height: 400px;
  font-family: 'Roboto';
  background-color: #8BC6EC;
  background-image: linear-gradient(135deg, #8BC6EC 0%, #9599E2 100%);
}
EOD;

$google_fonts = "Roboto";

$master_data = array('html'=>$html,
              'google_fonts'=>$google_fonts);
$user_id="426fea65-1888-41d7-befd-7bf9099133ed";
$api_key="6e2f24f0-ec58-4ee9-9cda-4693fa221bf2";



    $url = 'https://hcti.io/v1/image';
    // $master_data=array('code'=>$code,'platform'=>'web');

    $ch = curl_init($url);

    $postString1 = http_build_query($master_data, '', '&');

    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postString1);  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERPWD, "426fea65-1888-41d7-befd-7bf9099133ed" . ":" . "6e2f24f0-ec58-4ee9-9cda-4693fa221bf2");
    $headers = array();
	$headers[] = "Content-Type: application/x-www-form-urlencoded";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
  echo 'Error:' . curl_error($ch);
}
curl_close ($ch);
$res = json_decode($result,true);
echo $res['url'];


?>

			<?php 
                $path = $res['url'];
                $type = pathinfo($path, PATHINFO_EXTENSION);
                $data = file_get_contents($path);
                $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

              ?>
            <div id="image" >
              <img src="<?php echo $base64; ?>" id="result" style="width:800px;height:400px;" >
            </div>