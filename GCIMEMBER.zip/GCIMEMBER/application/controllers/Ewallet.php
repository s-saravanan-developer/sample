<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Ewallet extends CI_Controller {

	public function __construct() {

		parent::__construct();

		if ($this->session->userdata('is_logged_in') == '') {
			redirect('login');
			session_destroy();

		}
		// $this->load->model('master/Users_model');
		$this->load->model('Ewallet_model');
		$this->load->model('member/Membership_model');
	}

	public function index()
	{
		$template['id']        = $this->session->userdata('UserCode');
		$template['wallet']    =  $this->Ewallet_model->getall_service_entries_by_id($template['id']);
		// var_dump($template['wallet']);die();
		$template['page']      ='ewallet/ewallet_topup';
		$this->load->view('template',$template);
		
	}

	public function add_wallet()
	{
		$template['page']            ='ewallet/add_wallet';
		$template['id']              = $this->session->userdata('UserCode');
        $template['bank_to']         =  $this->Membership_model->getall_bank_to();
		$template['sales_point']     =  $this->Ewallet_model->getall_sales_points();
		$template['bank']            =  $this->Ewallet_model->getall_bank();
        $template['payment_mode']    =  $this->Ewallet_model->getall_payment_modes();
		$this->load->view('template',$template);

	}

	public function wallet_view()
	{
		$template['page']               ='ewallet/view_wallet';
		$service_point_id               = $this->input->get("id");
		$template['service_point']      =  $this->Ewallet_model->getall_service_entries_by_wallet($service_point_id);
		$template['service_payment']    =  $this->Ewallet_model->getall_service_payments_by_id($service_point_id);
		
		
		$template['sales_point']        =  $this->Ewallet_model->getall_sales_points();
		$template['bank']               =  $this->Ewallet_model->getall_bank();
        $template['payment_mode']       =  $this->Ewallet_model->getall_payment_modes();
		$this->load->view('template',$template);

	}

	

	public function get_sales_point_details()
    {
        $sales_point = $this->input->post("sales_point");
        $temp        =  $this->Ewallet_model->get_sales_point_details($sales_point);
        if(!empty($temp)){
        	$data    ="Name : ".$temp[0]['firstname']." , ".$temp[0]['city_name']." , ".$temp[0]['state_name']." , ".$temp[0]['country_name']." , ".$temp[0]['zipcode']."..,\n Wallet Balance - ".$temp[0]['Wallet_balance']; 
        }else{
        	$data    ='Name : - ';
        }
                 
        echo json_encode($data);
    }

public function wallet_add(){
	$sales_point                   = $this->input->post("sales_point");
	$unique_id                     = $this->input->post("unique_id");
	// var_dump($unique_id);
	// var_dump($sales_point);die();
		$sales_point['Wallet_flag']=$sales_point['Topup_for'];
		$sales_point['Date']       =date('Y-m-d');
		$sales_point['Company_id'] =$this->session->userdata('CompanyId');
		$sales_point['Branch_id']  =$this->session->userdata('CompanyId');
		$inserted_id               =  $this->Ewallet_model->insert_service_point($sales_point);
		// $inserted =  $this->Ewallet_model->insert_service_wallet($sales_point);

		$unique=explode(',',$unique_id);
        foreach($unique as $val1){
             $payment_data['payment_data_'.$val1] = $this->input->post('payment_data_'.$val1);
             $payment_data['payment_data_'.$val1]['Service_point_ID']   = $inserted_id;
             $payment_data['payment_data_'.$val1]['Topup_for']   = $sales_point['Topup_for'];

            if(isset($sales_point['Membership_ID'])){ $payment_data['payment_data_'.$val1]['Membership_ID']= $sales_point['Membership_ID'];}else{ $payment_data['payment_data_'.$val1]['Membership_ID']= '';}

              if(isset($sales_point['Service_point'])){ $payment_data['payment_data_'.$val1]['Service_point']   =$sales_point['Service_point'];}else{ $payment_data['payment_data_'.$val1]['Service_point']   ='';}

             $payment_data['payment_data_'.$val1]['Wallet_amount_from']   =$sales_point['Wallet_amount_from'];

             if(isset($sales_point['Wallet_service_point'])){ $payment_data['payment_data_'.$val1]['Wallet_service_point']   = $sales_point['Wallet_service_point'];}else{ $payment_data['payment_data_'.$val1]['Wallet_service_point']   = '';}

             $payment_data['payment_data_'.$val1]['Currency']   = $sales_point['Currency'];
             $payment_data['payment_data_'.$val1]['Company_id']   = $this->session->userdata('CompanyId');
             $payment_data['payment_data_'.$val1]['Branch_id']   = $this->session->userdata('CompanyId');
             $payment_data['payment_data_'.$val1]['Date']   = date('Y-m-d', strtotime(str_replace('/', '-', $payment_data['payment_data_'.$val1]['Date'])));

             $statement_name='state_ment_'.$val1;
             if(isset($sales_point['Membership_ID'])){
             	$data=$this->db->get_where('gc_membership',array('Membership_ID' => $sales_point['Membership_ID']))->result_array();
				if(!empty($data)){
					$Membership_code=$data[0]['Membership_code'];
				}
			}else{
				$Membership_code='';
			}

             $payment_data['payment_data_'.$val1]['Statement']   = $this->member_statement_attachment_1($Membership_code,$statement_name,'statement');

             $inserted_id1 =  $this->Ewallet_model->insert_service_point_payment($payment_data['payment_data_'.$val1]);
            }
            redirect('Ewallet');
}

    public function generatePIN($digits){
    $i = 0; //counter
    $pin = ""; //our default pin is blank.
    while($i < $digits){
        //generate a random number between 0 and 9.
        $pin .= mt_rand(0, 9);
        $i++;
    }
    return $pin;
}

    public function member_statement_attachment_1($ref_no,$profile_name,$name) {     
         // var_dump($profile_name);
         // var_dump($name);
    		if(!empty($ref_no)){


           if (!is_dir('./attachments/Members/'.$ref_no))
                  {
                      mkdir('./attachments/Members/'.$ref_no, 0777, true);
                  }
                  $dir_exist = true; // flag for checking the directory exist or not
                  if (!is_dir('./attachments/Members/'.$ref_no))
                  {
                      mkdir('./attachments/Members/'.$ref_no, 0777, true);
                      $dir_exist = false; // dir not exist
                  }

              

         $config['upload_path']          = './attachments/Members/'.$ref_no.'/';
         $config['allowed_types']        = 'gif|jpg|png';
         $new_name                       = $ref_no.'_'.$name;
     }else{
     	 $config['upload_path']          = './attachments/statements/';
         $config['allowed_types']        = 'gif|jpg|png';
         $new_name                       = $this->generatePIN(4).'_'.$name;
     }
         $config['file_name']            = $new_name;
         //var_dump($config['file_name']);
         
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ( ! $this->upload->do_upload($profile_name))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $file_name = '';
                        //print_r($error);
                         return $file_name;                 
                }
                else
                {   
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];
                        // die();
                        // return $file_name;
                        if(!empty($ref_no)){
                        	return "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$ref_no.'/'.$file_name;
                        }else{
                        	return "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/statements/'.$file_name;
                        }
                        
                }

    }

}
