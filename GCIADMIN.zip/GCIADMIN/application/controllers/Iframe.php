<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Iframe extends CI_Controller {

	public function __construct() {
        parent::__construct();
        $this->load->model('member/Membership_model');
    }


	public function get_method()
	{ 
        // echo '<b style="color:green;">User Successfully Added</b>';
        // echo ' <input type="hidden" class="done" value="1" /> ';
        // echo ' <input type="hidden" class="username" value="admin@gmail.com" /> ';
        // echo ' <input type="hidden" class="password" value="admin" /> ';
        // die();              
		$data 	 = $this->input->get('data');
		if(isset($data)){
			if($data = 'green_text'){
		        $this->load->model('member/Membership_model');		    	
		        $template['bank']            =  $this->Membership_model->getall_bank();
		        $template['payment_mode']    =  $this->Membership_model->getall_payment_modes();
		        $template['topup']           =  $this->Membership_model->getall_topups();
		        $template['payout']          =  $this->Membership_model->getall_payouts();
		        $template['membership_type'] =  $this->Membership_model->getall_membershiptype();        
		        $this->load->view('membership/ifram_member',$template);
			}
		}
	}

public function add()
    {
        
        $member = $this->input->post("member");
        $photo = $this->input->post("Photo");
        $upload1 = $this->input->post("upload1");
        $upload2 = $this->input->post("upload2");
        $upload3 = $this->input->post("upload3");
        $address_data = $this->input->post("address_data");
        $nominee_data = $this->input->post("nominee_data");
        $bank_data = $this->input->post("bank_data");
        $upload_rows = $this->input->post('upload_rows');
        $upload_rows=explode(',',$upload_rows);

        
        foreach($upload_rows as $val){
        $upload_data['upload_data_'.$val] = $this->input->post('upload_data_'.$val);

        $profile_name = 'upload'.$val;

        // Membership Code
        $pan=$upload_data["upload_data_1"]["Document_no"];

        if(!empty($pan)){
        $newpan = substr($pan, -5);
        }
        $newmob = substr($member['Mobile'], -5);
        $Membership_code=$newpan.$newmob;

        $docs_name = $this->Membership_model->member_profile_attachment_1($Membership_code,$profile_name,$upload_data['upload_data_'.$val]['Document_type']);

        $upload_data['upload_data_'.$val]['Folder_name']=$Membership_code;
        $upload_data['upload_data_'.$val]['Document_name']=$docs_name;
            }

        $contract_data  = null;
        $agreement_data = null;
        $payment_data   = null;

        $events1 = $this->Membership_model->add_membership($member,$address_data,$nominee_data,$bank_data,$upload_data,$contract_data,$payment_data,$agreement_data,$photo,$upload1,$upload2,$upload3);

        // // redirect('membership/Membership/members');
        //     $reg = array('firstname' => 'satheesh',
        //                  'lastname' => 'satheesh',
        //                  'customer_group_id' => '1',
        //                  'language_id' => '1',
        //                  'email' => 'sat@gmail.com',
        //                  'telephone' => '865132112',
        //                  'status' => '1',
        //                  'email' => 'sat@gmail.com',                         
        //                  'password' => '202cb962ac59075b964b07152d234b70',                         
        //                  'Member_id' => '2',                         
        //                 ); 
        //    $id  =  $this->customer_add_opencart($data);
        echo '<b style="color:green;">User Successfully Added</b>';
        echo ' <input type="hidden" class="done" value="1" /> ';
        echo ' <input type="hidden" class="username" value="'.$member['Email'].'" /> ';
        echo ' <input type="hidden" class="password" value="'.$member['Mobile'].'" /> ';
        //die();
        // var_dump($agreement_data);
    }

    public function get_referer_by_code()
        {
        $referer = $this->input->post("referer");
        
        $data['referer']         =  $this->Membership_model->get_referer_by_code($referer);
        $data['bank']            =  $this->Membership_model->getall_bank();
        $data['payment_mode']    =  $this->Membership_model->getall_payment_modes();
        $data['topup']           =  $this->Membership_model->getall_topups();
        $data['payout']          =  $this->Membership_model->getall_payouts();
        $data['membership_type'] =  $this->Membership_model->getall_membershiptype();
        if($data['referer']!=0){
        // var_dump($template['membership_type']);die();
        $temp['data'] = ['value'             => 'Success',
                        'referer'             => $data['referer'],
                         'bank'                => $data['bank'],
                         'payment_mode'        => $data['payment_mode'],
                         'topup'               => $data['topup'],
                         'payout'              => $data['payout'],
                         'membership_type'     => $data['membership_type']];
                     }else{
                        $temp['data'] = ['value'             => 'Failure',
                            'referer'             => $data['referer'],
                         'bank'                => $data['bank']="",
                         'payment_mode'        => $data['payment_mode']="",
                         'topup'               => $data['topup']="",
                         'payout'              => $data['payout']="",
                         'membership_type'     => $data['membership_type']=""];
                     }

        header('Content-Type: application/json');
        echo json_encode($temp);
    }

    public function get_pincode_details()
        {
            $pincode         = $this->input->post("pincode");

        $this->db->select('area.id as taluk_id,area.area_name as taluk_name,city.id as City_id,city.city_name as City_name,state.id as State_id,state.state_name as State_name,country.id as Country_id,country.country_name as Country_name');

        $this->db->from('gc_areas as area');
        $this->db->join('gc_cities as city', 'city.id = area.city_id', 'left');
        $this->db->join('gc_states as state', 'state.id = area.state_id', 'left');
        $this->db->join('gc_countries as country', 'country.id = area.country_id', 'left');
        $this->db->where("area.Pincode",$pincode);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $temp['pincode'] = $query->result_array();
            $temp['value']= "Success";
        }else{
        $temp['pincode']= "";
        $temp['value']= "Failure";

    }

            // $this->db->where('ID',$id);
            // $query          = $this->db->delete('gc_temp_user');
            // $temp['content']='OTP Expired!';
            // $temp['status'] =3;

            $data['data'] = ['pincode'             => $temp['pincode'],
                            'value'             => $temp['value']];
        header('Content-Type: application/json');
        echo json_encode($data);
    }	
  

}
