<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class API extends CI_Controller {

    public function __construct() {
        parent::__construct();

        // if ($this->session->userdata('is_logged_in') == '') {
            
        //     redirect('login');
        //     session_destroy();

        // }
        $this->load->model('member/Membership_model');
    }

    public function index($platform='web')
    {
        $platform = $this->input->post('platform');
        if(empty($platform)) {
            $platform = 'web';
        }
        $template['page']            ='membership/viewmembership';
        $template['bank']            =  $this->Membership_model->getall_bank();
        $template['payment_mode']    =  $this->Membership_model->getall_payment_modes();
        $template['topup']           =  $this->Membership_model->getall_topups();
        $template['payout']          =  $this->Membership_model->getall_payouts();
        $template['membership_type'] =  $this->Membership_model->getall_membershiptype();
        // var_dump($template['membership_type']);die();
        $data['data'] = ['bank'                => $template['bank'],
                             'payment_mode'    => $template['payment_mode'],
                             'topup'           => $template['topup'],
                             'payout'          => $template['payout'],
                             'membership_type' => $template['membership_type']];
        if(!empty($data) & $platform != 'web') {
            header('Content-Type: application/json');
            echo json_encode($data);
        } else {
        $this->load->view('template',$template);
        }
    }

public function members()
    {
        $this->load->model('member/Membership_model');
        $template['page']='membership/manage_members';
        $template['members'] =  $this->Membership_model->getall_members();
        $template['bank_status'] =  $this->Membership_model->getall_members();
        $template['document_status'] =  $this->Membership_model->getall_members();
        $template['payment_status'] =  $this->Membership_model->getall_members();

        // var_dump($template['membership_type']);die();
        $this->load->view('template',$template);
    }

    

    
public function get_referer_by_code()
        {
        $referer = $this->input->post("referer");
        
        $data['referer'] =  $this->Membership_model->get_referer_by_code($referer);
        $data['bank']            =  $this->Membership_model->getall_bank();
        $data['payment_mode']    =  $this->Membership_model->getall_payment_modes();
        $data['topup']           =  $this->Membership_model->getall_topups();
        $data['payout']          =  $this->Membership_model->getall_payouts();
        $data['membership_type'] =  $this->Membership_model->getall_membershiptype();
        if($data['referer']!=0){
        // var_dump($template['membership_type']);die();
        $temp['data'] = ['value'             => 'Success',
                        'referer'             => $data['referer'],
                         'bank'                => $data['bank'],
                         'payment_mode'        => $data['payment_mode'],
                         'topup'               => $data['topup'],
                         'payout'              => $data['payout'],
                         'membership_type'     => $data['membership_type']];
                     }else{
                        $temp['data'] = ['value'             => 'Failure',
                            'referer'             => $data['referer'],
                         'bank'                => $data['bank']="",
                         'payment_mode'        => $data['payment_mode']="",
                         'topup'               => $data['topup']="",
                         'payout'              => $data['payout']="",
                         'membership_type'     => $data['membership_type']=""];
                     }

        header('Content-Type: application/json');
        echo json_encode($temp);
    }

public function get_referer_detail()
        {
        $referer = $this->input->post("referer");
        
        $temp['referer'] =  $this->Membership_model->get_referer_by_code($referer);
         if($data['referer']!=0){
        $data['data'] = ['value'             => 'Success',
                        'referer'             => $temp['referer']];
    }else{
        $data['data'] = ['value'             => 'Failure',
                        'referer'             => $temp['referer']];
    }
        
        header('Content-Type: application/json');
        echo json_encode($data);
    }

public function mobile_verify()
        {
        $mobile = $this->input->post("mobile");
        // $temp['referer'] =  $this->Membership_model->mobile_verify($mobile);
        $this->db->select('Membership_ID,First_name,Last_name,Membership_code,Status');
        $this->db->where('Mobile',$mobile);
        $query = $this->db->get('gc_membership');
        if ($query->num_rows() > 0) {
            $verify['content'] =  'Member Already Exist!';
            $verify['status']  =  '1';
            $verify['value']  =  'Failiure';
            $verify['mobile']  =  "";
            $verify['temp_id']  =  "";

        }else{
            $temp['Mobile']=$mobile;
            $temp['OTP']=$this->generatePIN();
            if($this->db->insert('gc_temp_user',$temp)){
                $temp_id=$this->db->insert_id();
                $sms_content="Please Use This OTP : ".$temp['OTP'];

                // $sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=ZmQxNzA1OWEyZTE&mobiles='.$mobile.'&message='.$sms_content.'&sender=PKSEVA&type=1&route=2';
                $sms_url='http://bulksmscoimbatore.co.in/sendsms?uname=mequals&pwd=mequals@123&senderid=BUGFIX&to='.$mobile.'&msg='.urlencode($sms_content).'&route=SID';

                $ch = curl_init($sms_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
                $response=curl_exec($ch);
                // curl_close($ch);

                if (curl_errno($ch)) {
                    $error = curl_error($ch);
                }
                $curl_data = explode(',', $response);
                curl_close($ch);
                
            }
            $verify['content'] =  'Please Enter OTP';
            $verify['status']  ='0';
            $verify['mobile']  =  $mobile;
            $verify['temp_id']  =  $temp_id;
            $verify['value']  =  'Success';

        }
        $data['data'] = ['content'             => $verify['content'],
                         'status'             => $verify['status'],
                         'mobile'               =>$verify['mobile'],
                         'temp_id'               =>$verify['temp_id'],
                         'value'                => $verify['value']];
        header('Content-Type: application/json');
        echo json_encode($data);
    }
// Mobile Verity OTP End //


// Resend OTP Start //
public function resend_otp()
        {
            $mobile = $this->input->post("mobile");
            //$id = $this->input->post("temp_id");

            $temp['Mobile']=$mobile;
            $temp['OTP']=$this->generatePIN();
            $this->db->where('Mobile',$mobile);
            $this->db->delete('gc_temp_user');
            $this->db->where('Mobile',$mobile);
            if($this->db->insert('gc_temp_user',$temp)){
                $sms_content="Please Use This OTP : ".$temp['OTP'];

                // $sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=ZmQxNzA1OWEyZTE&mobiles='.$mobile.'&message='.$sms_content.'&sender=PKSEVA&type=1&route=2';
                $sms_url='http://bulksmscoimbatore.co.in/sendsms?uname=mequals&pwd=mequals@123&senderid=BUGFIX&to='.$mobile.'&msg='.urlencode($sms_content).'&route=SID';

                $ch = curl_init($sms_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
                $response=curl_exec($ch);
                // curl_close($ch);

                if (curl_errno($ch)) {
                    $error = curl_error($ch);
                }
                $curl_data = explode(',', $response);
                curl_close($ch);
                
            }

            $verify['content']  =  'Please Enter OTP';
            $verify['status']   =  '0';
            $verify['mobile']   =  $mobile;
            

             $data['data'] = ['Content'             => $verify['content'],
                         'status'                   => $verify['status'],
                         'mobile'                   => $verify['mobile'],
                         'value'                    => "Success" ];
        header('Content-Type: application/json');
        echo json_encode($data);

        
        }
// Resend OTP END //

// Expiry OTP Start //
public function expiry_otp()
        {
            $mobile         = $this->input->post("mobile");
            $this->db->where('Mobile',$mobile);
            $query          = $this->db->delete('gc_temp_user');
            $temp['content']='OTP Expired!';
            $temp['status'] =3;


            $data['data'] = ['content'             => $temp['content'],
                            'status'               => $temp['status'],
                            'value'               => "Success"];
        header('Content-Type: application/json');
        echo json_encode($data);
    }
// Expiry OTP End //

// Verity OTP Start //
public function verify_otp()
        {
            $mobile          = $this->input->post("mobile");
            $otp             = $this->input->post("otp");
            $this->db->select('*');
            $this->db->where('OTP',$otp);
            $this->db->where('Mobile',$mobile);
            $query          = $this->db->get('gc_temp_user');
            if ($query->num_rows() > 0) {
               $this->db->where('OTP',$otp);
               $this->db->where('Mobile',$mobile);
               $query          = $this->db->delete('gc_temp_user'); 
            $verify['content'] =  'OTP Verified!';
            $verify['status']  =  '1';
            $verify['mobile']  =  $mobile;
            $verify['value']  =  "Success";

        }else{
            $verify['content'] =  'Invalid OTP!';
            $verify['status']  =  '0';
            $verify['mobile']  =  $mobile;
            $verify['value']  =  "Failure";
        }

            $data['data'] = ['content'              => $verify['content'],
                             'status'               => $verify['status'],
                             'mobile'               => $verify['mobile'],
                            'value'               => $verify['value']];
        header('Content-Type: application/json');
        echo json_encode($data);
    }
// Verity OTP End //


public function get_pincode_details()
        {
            $pincode         = $this->input->post("pincode");

        $this->db->select('area.id as taluk_id,area.area_name as taluk_name,city.id as City_id,city.city_name as City_name,state.id as State_id,state.state_name as State_name,country.id as Country_id,country.country_name as Country_name');

        $this->db->from('gc_areas as area');
        $this->db->join('gc_cities as city', 'city.id = area.city_id', 'left');
        $this->db->join('gc_states as state', 'state.id = area.state_id', 'left');
        $this->db->join('gc_countries as country', 'country.id = area.country_id', 'left');
        $this->db->where("area.Pincode",$pincode);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $temp['pincode'] = $query->result_array();
            $temp['value']= "Success";
        }else{
        $temp['pincode']= "";
        $temp['value']= "Failure";

    }

            // $this->db->where('ID',$id);
            // $query          = $this->db->delete('gc_temp_user');
            // $temp['content']='OTP Expired!';
            // $temp['status'] =3;

            $data['data'] = ['pincode'             => $temp['pincode'],
                            'value'             => $temp['value']];
        header('Content-Type: application/json');
        echo json_encode($data);
    }

public function get_topup_details()
    {
        $topup = $this->input->post("topup");
        $temp['topup'] =  $this->Membership_model->get_topup_details($topup);
        if($temp['topup']!=0){

        header('Content-Type: application/json');
        $data['data'] = ['topup'              => $temp['topup'],
                            'value'    =>"Success"];
                        }else{
                            $data['data'] = ['topup'              => $temp['topup']="",
                            'value'    =>"Failure"];
                        }
          header('Content-Type: application/json');                   
        echo json_encode($data);
    }

    
public function member()
    {

$data['member']='';        
$data['address']='';
$data['nominee']='';
$data['profile']='';
$this->session->set_userdata($data);
extract($_POST);
if(!empty($_POST)){

$data['member']=array(
                      'Reference_ID'=>$Reference_ID,
                      'Prefix'=>$Prefix,
                      'First_name'=>$First_name,
                      'Last_name'=>$Last_name,
                      'F_prefix'=>$F_prefix,
                      'F_f_name'=>$F_f_name,
                      'F_l_name'=>$F_l_name,
                      'Gender'=>$Gender,
                      'DOB'=>$DOB,
                      'Mobile'=>$Mobile,
                      'Email'=>$Email
                      );

$data['address']=array(
              'Pincode'=> $Pincode,
              'Area'=> $Area,
              'City'=> $City,
              'State'=> $State,
              'Country'=> $Country,
              'Address_1'=> $Address_1,
              'Address_2'=> $Address_2,
              'Landmark'=> $Landmark,
              'Address_type'=> $Address_type
              );
$data['nominee']=array(
              'Nominee_name' => $Nominee_name,
              'Nominee_relationship' => $Nominee_relationship,
              'Nominee_mobile' => $Nominee_mobile
              );
$this->session->set_userdata($data);

    $temp['value']="success";
}else{
    $temp['value']="Empty";
}
    //     if(!empty($this->session->userdata($member))){

    //     $this->session->set_userdata($member);
    // }else{
    //     unset($this->session->userdata($member));
    //     $this->session->set_userdata($member);
    // }

//         $address_data = $this->input->post("address_data");
//         $nominee_data = $this->input->post("nominee_data");
//         $bank_data = $this->input->post("bank_data");
//         $upload_rows = $this->input->post('upload_rows');
//         $upload_rows=explode(',',$upload_rows);
//         foreach($upload_rows as $val){
//              $upload_data['upload_data_'.$val]                  = $this->input->post('upload_data_'.$val);
// }
        // $Upload_data = $this->input->post("Upload_data");
//         $contract_data = $this->input->post("contract_data");

//         $unique_id = $this->input->post('unique_id');
//         $unique=explode(',',$unique_id);
//         foreach($unique as $val1){
//              $payment_data['payment_data_'.$val1]                  = $this->input->post('payment_data_'.$val1);
// }
        // $payment_data = $this->input->post("payment_data");
        // $agreement_data = $this->input->post("agreement_data");

        // $events1 = $this->Membership_model->add_membership($member,$address_data,$nominee_data,$bank_data,$upload_data,$contract_data,$payment_data,$agreement_data);

     
$member['data'] = ['value'              => $temp['value']];
        header('Content-Type: application/json');                   
        echo json_encode($member);

        // var_dump($agreement_data);
    }

public function profile_upload(){

   // error_reporting(0);

extract($_POST);
$data['profile']='';
$this->session->set_userdata($data);
extract($_POST);
if(!empty($_POST)){

$data['profile']=array(
'mobile' => $mobile_upload,
'Photo' => base64_decode($Photo)
);
$this->session->set_userdata($data);


    $temp['value']="success";
}else{
    $temp['value']="Empty"; 
}

// $ref_no="sarvan";
// $name="profile";
// if (!is_dir('./attachments/Members/'.$ref_no))
//                   {
//                       mkdir('./attachments/Members/'.$ref_no, 0777, true);
//                   }
//                   $dir_exist = true; // flag for checking the directory exist or not
//                   if (!is_dir('./attachments/Members/'.$ref_no))
//                   {
//                       mkdir('./attachments/Members/'.$ref_no, 0777, true);
//                       $dir_exist = false; // dir not exist
//                   }
//     define('UPLOAD_DIR', './attachments/Members/'.$ref_no.'/');
//     $image_base64 = base64_decode($Photo);

//     $file = UPLOAD_DIR . $ref_no.'_'.$name . '.jpg';
//     $success=file_put_contents($file, $image_base64);
//     if($success){
//         $temp['value']='Success';
//     }else{
//         $temp['value']='Failed';
//     }

//var_dump($image);


$profile['data'] = ['value' => $temp['value']];
        header('Content-Type: application/json');                   
        echo json_encode($profile);

}   

public function member_bank(){

$data['bank']='';
$this->session->set_userdata($data);
extract($_POST);
if(!empty($_POST)){
    $data['bank']=array(
                        'Bank_ID' => $Bank_ID,
                        'Account_holder' => $Account_holder,
                        'Account_no' => $Account_no,
                        'Branch' => $Branch,
                        'IFSC' => $IFSC
                        );
$this->session->set_userdata($data);
    $temp['value']="success";
}else{
    $temp['value']="Empty";
}

$bank['data'] = ['value'              => $temp['value']];
        header('Content-Type: application/json');                   
        echo json_encode($bank);

} 

public function pan_upload(){
$data['pan']='';
$this->session->set_userdata($data);
extract($_POST);
if(!empty($_POST)){

$data['pan']=array(
'Document_type' => $Document_type_pan,
'mobile' => $mobile_upload,
'Document_no' => $Document_no_pan,
//'Document_name' => base64_decode($Document_image_pan)
);
$this->session->set_userdata($data);

    $temp['bank']=$this->session->userdata('0716');
    $temp['value']="success";
}else{
    $temp['value']="Empty"; 
}

// $ref_no="sarvan";
// $name="pan";
// if (!is_dir('./attachments/Members/'.$ref_no))
//                   {
//                       mkdir('./attachments/Members/'.$ref_no, 0777, true);
//                   }
//                   $dir_exist = true; // flag for checking the directory exist or not
//                   if (!is_dir('./attachments/Members/'.$ref_no))
//                   {
//                       mkdir('./attachments/Members/'.$ref_no, 0777, true);
//                       $dir_exist = false; // dir not exist
//                   }
//     define('UPLOAD_DIR', './attachments/Members/'.$ref_no.'/');
//     $image_base64 = base64_decode($_POST['Document_image_pan']);

//     $file = UPLOAD_DIR . $ref_no.'_'.$name . '.jpg';
//     $success=file_put_contents($file, $image_base64);
//     if($success){
//         $temp['value']='Success';
//     }else{
//         $temp['value']='Failed';
//     }

//var_dump($image);


$pan['data'] = ['value'              => $temp['value'],
                'bank'              => $temp['bank'] ];
        header('Content-Type: application/json');                   
        echo json_encode($pan);

}   

public function addhar_upload(){
$data['aadhar']="";
$this->session->set_userdata($data);
extract($_POST);
if(!empty($_POST)){

$data['aadhar']=array(
'Document_no_pan' => $Document_no_pan,
'mobile' => $mobile_upload,
'Document_type_' => $Document_type_addhar,
'Document_no' => $Document_no_addhar,
'Document_name' => base64_decode($Document_image_addhar)
);
$this->session->set_userdata($data);
    $temp['value']="success";
}else{
    $temp['value']="Empty";
}


// $ref_no="sarvan";
// $name="aadhar";
// if (!is_dir('./attachments/Members/'.$ref_no))
//                   {
//                       mkdir('./attachments/Members/'.$ref_no, 0777, true);
//                   }
//                   $dir_exist = true; // flag for checking the directory exist or not
//                   if (!is_dir('./attachments/Members/'.$ref_no))
//                   {
//                       mkdir('./attachments/Members/'.$ref_no, 0777, true);
//                       $dir_exist = false; // dir not exist
//                   }
//     define('UPLOAD_DIR', './attachments/Members/'.$ref_no.'/');
//     $image_base64 = base64_decode($Document_image_addhar);

//     $file = UPLOAD_DIR . $ref_no.'_'.$name . '.jpg';
//     $success=file_put_contents($file, $image_base64);
//     if($success){
//         $temp['value']='Success';
//     }else{
//         $temp['value']='Failed';
//     }

      $aadhar['data'] = ['value'              => $temp['value']];
        header('Content-Type: application/json');                   
        echo json_encode($aadhar);

}

public function check_upload(){
extract($_POST);
$data['cheque']="";
$this->session->set_userdata($data);
extract($_POST);
if(!empty($_POST)){

$data['cheque']=array(
'Document_no_pan' => $Document_no_pan,
'mobile' => $mobile_upload,
'Document_type_' => $Document_type_check,
'Document_no' => $Document_no_check,
'Document_name' => base64_decode($Document_image_check)
);
$this->session->set_userdata($data);
    $temp['value']="success";
}else{
    $temp['value']="Empty";
}
// $ref_no="sarvan";
// $name="cheque";
// if (!is_dir('./attachments/Members/'.$ref_no))
//                   {
//                       mkdir('./attachments/Members/'.$ref_no, 0777, true);
//                   }
//                   $dir_exist = true; // flag for checking the directory exist or not
//                   if (!is_dir('./attachments/Members/'.$ref_no))
//                   {
//                       mkdir('./attachments/Members/'.$ref_no, 0777, true);
//                       $dir_exist = false; // dir not exist
//                   }
//     define('UPLOAD_DIR', './attachments/Members/'.$ref_no.'/');
//     $image_base64 = base64_decode($Document_image_check);

//     $file = UPLOAD_DIR . $ref_no.'_'.$name . '.jpg';
//     $success=file_put_contents($file, $image_base64);
//     if($success){
//         $temp['value']='Success';
//     }else{
//         $temp['value']='Failed';
//     }


        $cheque['data'] = ['value'              => $temp['value']];
        header('Content-Type: application/json');                   
        echo json_encode($cheque);

}

public function add_payment(){

$randum_no=$this->generatePIN();
if(!$this->session->userdata('payment')){
$data['payment'][0]=[];
//$data[$randum_no]='';
$this->session->set_userdata($data);
}

extract($_POST);
if(!empty($_POST)){
    
    $randum_no=array(
        'Payment_type_ID' => $Payment_type_ID,
        'Bank_ID' => $Bank_ID,
        'Reference_no' => $Reference_no,
        'Date' => $Date,
        'Amount' => $Amount,
        'Remarks' => $Remarks 
    );
   $data['payment']= $this->session->userdata('payment');
array_push($data['payment'][0],$randum_no);
$this->session->set_userdata($data);    

$payment['payment']=$this->session->userdata('payment');
//$this->session->unset_userdata('payment');
    //$temp['temp_id']=count($payment['payment'])-1;
    $temp['value']="success";
}else{
    $temp['value']="Empty";
}

$payment['data'] = ['value'              => $temp['value']];
        header('Content-Type: application/json');                   
        echo json_encode($payment);

}

public function view_payment(){
    if($this->session->userdata('payment')){
$payment['payment']=$this->session->userdata('payment');
//$data[$randum_no]='';
}else{
  $payment['payment']=[];
}
extract($_POST);
if(!empty($_POST)){
    $temp['value']="success";
}else{
    $temp['value']="success";
}

$payment['data'] = ['value'              => $temp['value']];
        header('Content-Type: application/json');                   
        echo json_encode($payment);
}

public function delete_payment(){
  if($this->session->userdata('payment')){
$data['payment']=$this->session->userdata('payment');
}else{
  $data['payment']=[];
}

extract($_POST);
if(!empty($_POST)){
  //$removable_index=$temp_id;
if(count($data['payment'][0])>0){
  unset($data['payment'][0][$temp_id]);
  //$this->session->unset_userdata('payment');
}
$this->session->set_userdata($data); 
  //unset($this->session->userdata($temp_id));
  $payment['payment']=$this->session->userdata('payment');
    $temp['value']="success";
}else{
    $temp['value']="Empty";
}

$payment['data'] = ['value'              => $temp['value']];
        header('Content-Type: application/json');                   
        echo json_encode($payment);

}

public function final_url(){
extract($_POST);
if(!empty($_POST)){
    $temp['value']="success";
}else{
    $temp['value']="Empty";
}

$data['data'] = ['value'              => $temp['value']];
        header('Content-Type: application/json');                   
        echo json_encode($data);

}



public function generatePIN($digits = 4){
    $i = 0; //counter
    $pin = ""; //our default pin is blank.
    while($i < $digits){
        //generate a random number between 0 and 9.
        $pin .= mt_rand(0, 9);
        $i++;
    }
    return $pin;
}

    public function member_profile_attachment_1($ref_no,$profile_name,$name) {     
         // var_dump($profile_name);
         // var_dump($name);

           if (!is_dir('./attachments/Members/'.$ref_no))
                  {
                      mkdir('./attachments/Members/'.$ref_no, 0777, true);
                  }
                  $dir_exist = true; // flag for checking the directory exist or not
                  if (!is_dir('./attachments/Members/'.$ref_no))
                  {
                      mkdir('./attachments/Members/'.$ref_no, 0777, true);
                      $dir_exist = false; // dir not exist
                  }

         $config['upload_path']          = './attachments/Members/'.$ref_no.'/';
         $config['allowed_types']        = 'gif|jpg|png';
         $new_name                       = $ref_no.'_'.$name;
         $config['file_name']            = $new_name;
         var_dump($config['file_name']);
         
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ( ! $this->upload->do_upload($profile_name))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $file_name = '';
                        print_r($error);
                        // return $file_name;                 
                }
                else
                {   
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];
                        // die();
                        return $file_name;
                }

    }

}
