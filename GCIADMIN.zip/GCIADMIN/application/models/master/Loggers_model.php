<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Loggers_model extends CI_Model {

    private $gc_Log_history = 'login_history_table';
    private $gc_Log_attempts = 'gc_login_attempt';



    function get_all_loggers() {
        // $this->db->select($this->gc_Log_history . '.*');

        $this->db->select('
             history.*,company.CompanyName,branch.type_name,usertype.user_type_name
            ');
        $this->db->from('login_history_table as history');
        $this->db->join('gc_company_table as company', 'company.CompanyID = history.Company_id', 'left');
        $this->db->join('gc_hub_branch as branch', 'branch.id = history.Branch_id', 'left');
        $this->db->join('gc_user_types as usertype', 'usertype.id = history.UserTypeId', 'left');
        // $this->db->where('status!=', 3);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function get_all_users() {
         $this->db->select('
             users.*,company.CompanyName,branch.type_name,usertype.user_type_name
            ');
        $this->db->from('gc_users as users');
        $this->db->join('gc_company_table as company', 'company.companyID = users.Company_id', 'left');
        $this->db->join('gc_hub_branch as branch', 'branch.id = users.branch_id', 'left');
        $this->db->join('gc_user_types as usertype', 'usertype.id = users.user_type_id', 'left');
        $this->db->where('users.status!=', 3);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    
    function get_all_log_apptempts() {
        // $this->db->select($this->gc_Log_attempts . '.*');


        $this->db->select('
             attempt.*,company.CompanyName,branch.type_name,usertype.user_type_name
            ');
        $this->db->from('gc_login_attempt as attempt');
        $this->db->join('gc_company_table as company', 'company.CompanyID = attempt.Company_id', 'left');
        $this->db->join('gc_hub_branch as branch', 'branch.id = attempt.Branch_id', 'left');
        $this->db->join('gc_user_types as usertype', 'usertype.id = attempt.UserTypeId', 'left');
        // $this->db->where('city.status!=',3);
        // $this->db->where('status!=', 3);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

        function get_all_loggers_history($id) {
        // $this->db->select($this->gc_Log_history . '.*');

        $this->db->select('
             history.*,company.CompanyName,branch.type_name,usertype.user_type_name,users.firstname
            ');
        $this->db->from('login_history_table as history');
        $this->db->join('gc_company_table as company', 'company.CompanyID = history.Company_id', 'left');
        $this->db->join('gc_hub_branch as branch', 'branch.id = history.Branch_id', 'left');
        $this->db->join('gc_user_types as usertype', 'usertype.id = history.UserTypeId', 'left');
        $this->db->join('gc_users as users', 'users.id = history.UserId', 'left');
        $this->db->where('history.UserId=', $id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    
            function get_all_modifications() {
        // $this->db->select($this->gc_Log_history . '.*');

        $this->db->select('
             modification.*,users.firstname,company.CompanyName,branch.Branch_name
            ');
        $this->db->from('gc_modification_history as modification');
        $this->db->join('gc_users as users', 'users.id = modification.Created_by', 'left');
        $this->db->join('gc_company_table as company', 'company.CompanyID = users.company_id', 'left');
        $this->db->join('gc_hub_branch as branch', 'branch.id = users.branch_id', 'left');
        // $this->db->where('history.UserId=', $id);
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

        function get_all_error_logs() {

        $this->db->select('*');
        $this->db->from('logs');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
    

  
}