<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Reports extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Users_model');
        $this->load->model('payout_money/Payout_money_model');
        $this->load->model('Report_model');
        $this->load->model('member/Membership_model');
    }

	public function manage_payouts()
	{
        
		 $template['page']                           ='reports/view_payout_report';
         $template['level']                          =  $this->Report_model->get_all_level_types();
         $template['commission']                     =  $this->Report_model->get_all_commission_types();
         $template['payout_type']                    =  $this->Report_model->get_all_payout_types();
        $template['payout']                          =  $this->Report_model->get_today_payout_history();
        $this->load->view('template',$template);
		
	}

	public function payouts(){

		$template['page']='reports/payout_report';
        // $template['payout']    =  $this->Report_model->get_today_payouts();
   //         $this->output->enable_profiler(TRUE);

			// $sections = array(
			//         'config'  => TRUE,
			//         'queries' => TRUE
			// );

			// $this->output->set_profiler_sections($sections);
		// $template['pre_date']=$this->get_previous_date1(date('Y-m-d'));
        $this->load->view('template',$template);
	}

	public function downline_payout(){

		$template['page']='reports/member_downline_payout';
        // $template['payout']    =  $this->Report_model->get_today_payouts();


			// $this->output->set_profiler_sections($sections);
		// $template['pre_date']=$this->get_previous_date1(date('Y-m-d'));
        $this->load->view('template',$template);
	}

	public function membership(){

		$template['page']='reports/membership_report';
		$this->load->model('member/Membership_model');
        // $template['members']    =  $this->Report_model->get_today_membership(date('Y-m-d'),date('Y-m-d'),$membership_ID='');
		// $template['pre_date']=$this->get_previous_date1(date('Y-m-d'));
        $this->load->view('template',$template);
	}

	public function level(){

		$template['page']='reports/member_level_report';
        // $template['payout']    =  $this->Report_model->get_today_payouts();
   //         $this->output->enable_profiler(TRUE);

			// $sections = array(
			//         'config'  => TRUE,
			//         'queries' => TRUE
			// );

        $this->load->view('template',$template);
	}

		public function downline(){

		$template['page']='reports/member_downline_report';
        $this->load->view('template',$template);
	}

	public function payment(){

		$template['page']='reports/member_payment_report';
		$template['level'] = $this->Report_model->get_all_levels();
        // $template['payout']    =  $this->Report_model->get_today_payouts();
     $this->load->view('template',$template);
	}

	public function payout_summary(){

		$template['page']='reports/member_payout_summary';
		$template['level'] = $this->Report_model->get_all_levels();
        // $template['payout']    =  $this->Report_model->get_today_payouts();
     $this->load->view('template',$template);
	}

	public function investment(){

		$template['page']='reports/investment_report';
        // $template['payout']    =  $this->Report_model->get_today_payouts();
     $this->load->view('template',$template);
	}

	public function level_investment(){

		$template['page']='reports/level_investment_report';
        // $template['payout']    =  $this->Report_model->get_today_payouts();
     $this->load->view('template',$template);
	}

	

	public function gold(){

		$template['page']='reports/gold_member_report';
		// $template['level'] = $this->Report_model->get_all_levels();
        // $template['payout']    =  $this->Report_model->get_today_payouts();
     	$this->load->view('template',$template);
	}

	public function star(){

		$template['page']='reports/star_member_report';
     	$this->load->view('template',$template);
	}

	public function member_paid(){

		$template['page']='reports/member_paid_report';
		// $template['level'] = $this->Report_model->get_all_levels();
        // $template['payout']    =  $this->Report_model->get_today_payouts();
     	$this->load->view('template',$template);
	}


	public function member_list(){

		$template['page']='reports/investment_paid_report';
		// $template['level'] = $this->Report_model->get_all_levels();
        // $template['payout']    =  $this->Report_model->get_today_payouts();
     	$this->load->view('template',$template);
	}

	

	public function get_payment_details(){
		$mobile = $this->input->post("mobile");
		$from_date=date("Y-m-d", strtotime($this->input->post("from_date")));
		$to_date=date("Y-m-d", strtotime($this->input->post("to_date")));
		$template['level'] = $this->Report_model->get_all_levels();
		$template['payment'] =  $this->Report_model->get_payment_details($from_date,$to_date,$mobile);
		$this->load->view('reports/ajax_payout_history',$template);
	}

	public function get_payout_summary(){
		$mobile = $this->input->post("mobile");
		$where = '(Membership_code="'.$mobile.'" or Mobile = "'.$mobile.'")';
		$membership=$this->db->where($where)->get('gc_membership')->result_array();
		if(!empty($membership)){
			$template['member']=$membership;

		}else{
			$template['member']=Null;
		}
		$template['level'] = $this->Report_model->get_all_levels();
		$template['payment1']=$this->Report_model->get_downline_contract($mobile);
		$template['payment'] =  $this->Report_model->get_payout_summary($mobile);
		// $template['Membership_ID']=$this->db->get_where('');
		$this->load->view('reports/ajax_payout_history',$template);
	}

	public function get_investment_record(){
		$mobile = $this->input->post("mobile");
		$s_date=$this->input->post("s_date");
		$e_date=$this->input->post("e_date");
		// $where = '(Membership_code="'.$mobile.'" or Mobile = "'.$mobile.'")';
		// $this->db->where($where);
		// $this->db->where(array('DATE(Created_date)>='=>$s_date,'DATE(Created_date)<='=>$e_date));
		// $membership=$this->db->get('gc_membership')->result_array();
		// if(!empty($membership)){
		// 	$template['member']=$membership;

		// }else{
		// 	$template['member']=Null;
		// }
		// $template['payment1']=$this->Report_model->get_downline_contract($mobile);
		$template['payment'] =  $this->Report_model->get_investment_record1($mobile,$s_date,$e_date);
		// var_dump($template['payment']);die();
		// $template['Membership_ID']=$this->db->get_where('');
		$this->load->view('reports/ajax_payout_history',$template);
	}

	public function get_level_investment_record(){
		$mobile = $this->input->post("mobile");
		$s_date=$this->input->post("s_date");
		$e_date=$this->input->post("e_date");
		$template['payment'] =  $this->Report_model->get_level_investment_record($mobile,$s_date,$e_date);
		// var_dump($template['payment']);die();
		// $template['Membership_ID']=$this->db->get_where('');
		$this->load->view('reports/ajax_payout_history',$template);
	}	

	

	public function export_investment_record(){
		$mobile = $this->input->get("mobile");
		$s_date=$this->input->get("s_date");
		$e_date=$this->input->get("e_date");

		// $template['payment1']=$this->Report_model->get_downline_contract($mobile);
		$template['payment'] =  $this->Report_model->get_investment_record1($mobile,$s_date,$e_date);
		// var_dump($template['payment']);die();
		// $template['Membership_ID']=$this->db->get_where('');
		$this->load->view('reports/excel_investment_record',$template);
	}

		public function export_level_investment_record(){
		$mobile = $this->input->get("mobile");
		$s_date=$this->input->get("s_date");
		$e_date=$this->input->get("e_date");
		$template['level'] = $this->Report_model->get_all_levels();
		// $template['payment1']=$this->Report_model->get_downline_contract($mobile);
		$template['payment'] =  $this->Report_model->get_level_investment_record($mobile,$s_date,$e_date);
		// var_dump($template['payment']);die();
		// $template['Membership_ID']=$this->db->get_where('');
		$this->load->view('reports/excel_level_investment_record',$template);
	}

    public function export_payment_report(){
	    $mobile = $this->input->get("mobile");
		$from_date=date("Y-m-d", strtotime($this->input->get("from_date")));
		$to_date=date("Y-m-d", strtotime($this->input->get("to_date")));
		$template['level'] = $this->Report_model->get_all_levels();
		$template['payment'] =  $this->Report_model->get_payment_details($from_date,$to_date,$mobile);
		$this->load->view('reports/excel_payments',$template);
}

    public function export_payout_summary(){
	    $mobile = $this->input->get("mobile");
		$where = '(Membership_code="'.$mobile.'" or Mobile = "'.$mobile.'")';
		$membership=$this->db->where($where)->get('gc_membership')->result_array();
		if(!empty($membership)){
			$template['member']=$membership;

		}else{
			$template['member']=Null;
		}
		// $from_date=date("Y-m-d", strtotime($this->input->post("from_date")));
		// $to_date=date("Y-m-d", strtotime($this->input->post("to_date")));
		$template['level'] = $this->Report_model->get_all_levels();
		$template['payment1']=$this->Report_model->get_downline_contract($mobile);
		$template['payment'] =  $this->Report_model->get_payout_summary($mobile);
		$this->load->view('reports/excel_payout_summary',$template);
}

	public function get_membership_details(){
        $mobile = $this->input->post("mobile");
		$invest = $this->input->post("invest");
		$from_date=date("Y-m-d", strtotime($this->input->post("from_date")));
		$to_date=date("Y-m-d", strtotime($this->input->post("to_date")));
        // $this->load->model('payout_money/Payout_money_model');
		$template['members'] =  $this->Report_model->get_today_membership($from_date,$to_date,$mobile,$invest);
		// $template['pre_date']=$this->get_previous_date1($date);
		$this->load->view('reports/ajax_payout_history',$template);
	}

 public function get_level_details(){
 		$membership_code = $this->input->post("membership_code");
 		$template['levels'] =  $this->Report_model->get_level_details($membership_code);
 		// var_dump($template['levels']);die();
 		$this->load->view('reports/ajax_payout_history',$template);
 }	

  public function get_downline_details(){
 		$membership_code = $this->input->post("membership_code");
 		// $template['levels'] =  $this->Report_model->get_downline_contract($membership_code);
 		$template['levels'] =  $this->Report_model->get_downline_details($membership_code);
 		// var_dump($template['levels']);die();
 		$this->load->view('reports/ajax_payout_history',$template);
 }

	public function excel_all_members(){
		$mobile = $this->input->get("mobile");
        $invest = $this->input->get("invest");
        // var_dump($invest);die();
		$from_date=date("Y-m-d", strtotime($this->input->get("from_date")));
		$to_date=date("Y-m-d", strtotime($this->input->get("to_date")));
        // $this->load->model('payout_money/Payout_money_model');
		$template['members'] =  $this->Report_model->get_today_membership($from_date,$to_date,$mobile,$invest);
		$template['from_date']=$this->input->get("from_date");
		$template['to_date']=$this->input->get("to_date");
		// $template['pre_date']=$this->get_previous_date1($date);
		$this->load->view('reports/excel_membership',$template);
	}

	 public function excel_to_all_levels(){
 		$membership_code = $this->input->get("membership_code");
 		$template['levels'] =  $this->Report_model->get_level_details($membership_code);
 		$template['membership_code'] = $membership_code;
 		// var_dump($template['levels']);die();
 		$this->load->view('reports/excel_levels',$template);
 }

	 public function excel_to_all_downline(){
 		$membership_code = $this->input->get("membership_code");
 		$template['levels'] =  $this->Report_model->get_downline_details($membership_code);
 		$template['membership_code'] = $membership_code;
 		// var_dump($template['levels']);die();
 		$this->load->view('reports/excel_downline',$template);
 }

	

	public function get_payout_details(){
		// $mobile = $this->input->post("mobile");
		$date=date("Y-m-d", strtotime($this->input->post("date")));
        // $this->load->model('payout_money/Payout_money_model');
		$template['payout'] =  $this->Report_model->get_payout_details_condensed($date);
		// $template['pre_date']=$this->get_previous_date1($date);
		$this->load->view('reports/ajax_payout_history',$template);
	}

	public function get_down_payout_details(){
		$mobile = $this->input->post("mobile");
		$date=date("Y-m-d", strtotime($this->input->post("date")));
        $this->load->model('payout_money/Payout_money_model');
        $template['level'] = $this->Report_model->get_all_levels();
		$template['payout'] =  $this->Report_model->get_downline_payout_details($date,$mobile);
		// var_dump($template['payout']);die();
		$this->load->view('reports/ajax_payout_history',$template);
	}

	public function excel_downline_payout(){
		$mobile = $this->input->get("mobile");
		$date=date("Y-m-d", strtotime($this->input->get("date")));
        $this->load->model('payout_money/Payout_money_model');
        $template['level'] = $this->Report_model->get_all_levels();
		$template['payout'] =  $this->Report_model->get_downline_payout_details($date,$mobile);
		$template['Membership_code']=$mobile;
		// var_dump($template['payout']);die();
		$this->load->view('reports/excel_downline_payout',$template);
	}





        public function transaction_history()
    {
        
        $template['page']                            ='reports/view_transaction_history';
        $template['level']                           =  $this->Report_model->get_all_level_types();
        $template['commission']                      =  $this->Report_model->get_all_commission_types();
        $template['topup']                           =  $this->Report_model->get_all_topups();
        $template['transaction']                     =  $this->Report_model->get_transaction_history();
        $this->load->view('template',$template);
        
    }


    public function get_payout_history1()
    {
        
        $mobile                                      = $this->input->post("mobile");
        $date                                        =date("Y-m-d", strtotime($this->input->post("date")));
        $template['payout']                          =  $this->Report_model->get_payout_history1($mobile,$date);
        $this->load->view('reports/ajax_payout_history',$template);
        
    }
    public function get_payout_history2()
    {
        $mobile                                      = $this->input->post("mobile");
        $commission_type                             = $this->input->post("commission_type");  
        // $level_type                                  = $this->input->post("level_type");
        // $payout_list                                  = $this->input->post("payout_list");
        $payment_list                                  = $this->input->post("payment_list");

        $s_date                                      =date("Y-m-d", strtotime($this->input->post("s_date")));
        $e_date                                      =date("Y-m-d", strtotime($this->input->post("e_date")));
        $template['payout']                          =  $this->Report_model->get_payout_history2($commission_type,$s_date,$e_date,$mobile,$payment_list);
        $this->load->view('reports/ajax_payout_history',$template);
        
    }

    public function get_gold_members()
    {
        $mobile                                      = $this->input->post("mobile");
        $s_date                                      =date("Y-m-d", strtotime($this->input->post("s_date")));
        $e_date                                      =date("Y-m-d", strtotime($this->input->post("e_date")));
        $template['gold']                          =  $this->Report_model->get_gold_members($s_date,$e_date,$mobile);
        $this->load->view('reports/ajax_payout_history',$template);
        
    }

    public function get_star_members()
    {
        $mobile                                    = $this->input->post("mobile");
        $template['star']                          =  $this->Report_model->get_star_members($mobile);
        $this->load->view('reports/ajax_payout_history',$template);
        
    }    

    public function get_paid_mambers()
    {
        $mobile                                      = $this->input->post("mobile");
        $s_date                                      =$this->input->post("s_date");
        $e_date                                      =$this->input->post("e_date");
        $template['paid']                            =  $this->Report_model->get_paid_mambers($s_date,$e_date,$mobile);
        $this->load->view('reports/ajax_payout_history',$template);
        
    }

    public function get_investment_paid_mambers()
    {
        $mobile                                      = $this->input->post("mobile");
        $s_date                                      =$this->input->post("s_date");
        $e_date                                      =$this->input->post("e_date");
        $template['paid']                            =  $this->Report_model->get_investment_paid_mambers($s_date,$e_date,$mobile);
        $this->load->view('reports/ajax_payout_history',$template);
        
    }    


    public function export_paid_mamber()
    {
        $mobile                                      = $this->input->get("mobile");
        $s_date                                      =$this->input->get("s_date");
        $e_date                                      =$this->input->get("e_date");
        $template['paid']                          =  $this->Report_model->get_paid_mambers($s_date,$e_date,$mobile);
        $this->load->view('reports/excel_paid_member',$template);
        
    }
    

    public function export_investment_paid_mamber()
    {
        $mobile                                      = $this->input->get("mobile");
        $s_date                                      =$this->input->get("s_date");
        $e_date                                      =$this->input->get("e_date");
        $template['paid']                            =  $this->Report_model->get_investment_paid_mambers($s_date,$e_date,$mobile);
        $this->load->view('reports/excel_investment_paid_member',$template);
        
    }    

    


    public function export_payout_report()
    {      
        $this->load->model('Report_model');
        //$id = ( explode( ',', $this->input->get('id') ));

        $mobile                                      = $this->input->get("mobile");
        $commission_type                             = $this->input->get("commission_type");  
        // $level_type                                  = $this->input->get("level_type");
        // $payout_list                                  = $this->input->get("payout_list");
        $payment_list                                  = $this->input->get("payment_list");

        $s_date                                      =date("Y-m-d", strtotime($this->input->get("s_date")));
        $e_date                                      =date("Y-m-d", strtotime($this->input->get("e_date")));
		$template['payout']                          =  $this->Report_model->get_payout_history2($commission_type,$s_date,$e_date,$mobile,$payment_list);
        $this->load->view('reports/excel_processed_payout',$template);
        

    }


    public function export_gold_members()
    {      
        $this->load->model('Report_model');
        //$id = ( explode( ',', $this->input->get('id') ));

        $mobile                                      = $this->input->get("mobile");
        $s_date                                      =date("Y-m-d", strtotime($this->input->get("s_date")));
        $e_date                                      =date("Y-m-d", strtotime($this->input->get("e_date")));
		$template['gold']                          =  $this->Report_model->get_gold_members($s_date,$e_date,$mobile);
        $this->load->view('reports/excel_gold_member',$template);
        

    }
    public function get_transaction_history1()
    {
        
        $mobile                                      = $this->input->post("mobile");
        $date                                        =date("Y-m-d", strtotime($this->input->post("date")));
        $template['transaction']                     =  $this->Report_model->get_transaction_history1($mobile,$date);
        $this->load->view('reports/ajax_transaction_history',$template);
        
    }
    public function get_transaction_history2()
    {
        $mobile                                      = $this->input->post("mobile");
        $commission_type                             = $this->input->post("commission_type");  
        $topup_list                                  = $this->input->post("topup_list");  
        $transaction_type                            = $this->input->post("transaction_type");
        $contract                                    = $this->input->post("contract");
        $s_date                                      =date("Y-m-d", strtotime($this->input->post("s_date")));
        $e_date                                      =date("Y-m-d", strtotime($this->input->post("e_date")));
        $template['transaction']                     =  $this->Report_model->get_transaction_history2($commission_type,$topup_list,$transaction_type,$s_date,$e_date,$mobile,$contract);
        $this->load->view('reports/ajax_transaction_history',$template);
        
    }

    public function excel_to_all(){
	// extract($_POST);
	// echo $from;
	// exit;
	 // $from=$this->uri->segment(4);
	 $template['date'] = date('Y-m-d',strtotime($this->input->get('id')));
	 // $to=$this->uri->segment(5);
	 // $customer=$this->uri->segment(6);
	 // $explode_customer=explode('_', $customer);

	//  print_r($explode);
	// exit;


	 	$template['level'] = $this->Report_model->get_all_levels();
		$template['payout'] =  $this->Report_model->get_payout_details_condensed($template['date']);
		// $template['pre_date']=$this->get_previous_date1($date);
		$this->load->view('reports/excel_payout',$template);

}


public function export_payout()
    {      
        $date = date('Y-m-d',strtotime($this->input->get('id')));
        //$id = $this->input->get('url');
       //var_dump($id);die();
$name = 'Payout - '.$this->input->get('id');
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }
        // var_dump($id); die();
       // $this->load->model('reports/Payout_money_model');
        $empInfo = $this->Report_model->get_export_payouts($date);
        //var_dump($empInfo);die();
        $header =array(
                'Name',   
                'Membership Code',   
                'Mobile',   
                'Commission_type',
                'Generated_date',
                'Bank',        
                'Acc.Holder',        
                'Acc.Number',        
                'Branch',        
                'IFSC',        
                'Actual_amount',       
                'Final_amount'
                );
        $table_attrb = array(
                'First_name',   
                'Membership_code',   
                'Mobile',   
                'Commission_type_name',
                'Commision_date', 
                'Bank_name',       
                'Account_holder',       
                'Account_no',       
                'Branch',       
                'IFSC',       
                'Amount',    
                'Amount'  
                );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }


   public  function check007($Membership_ID,$cr_date){
    	$ctrt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->result_array();
    	if(!empty($ctrt)){
    		// $cr_date='2019-03-20';
    		$start=new DateTime(date('d-m-Y',strtotime($ctrt[0]['Start_date'])));$end=new DateTime(date('d-m-Y',strtotime($ctrt[0]['End_date'])));

          	$daterange = new DatePeriod($start, new DateInterval('P14D'), $end);
          	foreach($daterange as $key_1=> $date){ 
          		echo 'commission date : ';echo $k=date('d-m-Y', strtotime($date->format("d-m-Y"). ' + 14 days'));
          		if($key_1==0){
    								echo '    Payout date : '; echo $l=$this->Membership_model->get_excat_next_payout($k);echo '<br>';
    							}else{
    								echo '    Payout date : '; echo $l=$this->Membership_model->get_excat_next_payout(date('d-m-Y', strtotime($l. ' + 14 days')));echo '<br>';
    							}

    							if($l >= $cr_date){
    								echo 'new date : ';echo $n=$l;
    								break;
    							}

			}
			return $n;
    	}
    	
    }



}
