 <div class="card-body">  
            <!-- <form id="" class="needs-validation" method="POST"   data-toggle="validator" action="<?php echo base_url(); ?>Membership/" enctype="multipart/form-data">  -->
              <h5 class="card-title">Welcome <?php //$Userdetails[0]['First_name'] ?></h5>
              <div class="row">
              <div class="col-md-4">
                <label for="">Enter Your OTP</label>
                <input type="text" class="form-control" id="otp_no">
                <span class="text-center" id="otp_error" style="color:#db3236;"></span><span style="float: right"><a id="resend" style="display: none" href="<?php echo base_url(); ?>Login/mail_verify/<?php echo $userid; ?>">Resend OTP</a></span>
              </div>
               <div class="col-md-4">
              <button class="btn btn-success" style="margin-top: 30px;">Submit</button>
            </div>
            </div>
            <!-- </form> -->
        </div> 






<?php  
// $userid = $this->session->userdata('UserCode'); 
// $Userdetails  =  $this->Users_model->get_user_details($userid);
// var_dump($userid);die();
?>

        

<script>

 $(document).ready(function(){
     $("#otp_no").change(function(e){

   otp_val=$("#otp_no").val();
   userid=<?php echo $userid; ?>;

   var url='otp_val='+otp_val+'&userid='+userid;

    $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>Login/verified_otp",
    data: url,
    cache: true,
    async: false,
    success: function(data) {
     if (data==0) {
      $("#otp_no").focus().val("");
      $("#otp_error").text("Incorrect OTP");
      $("#resend").show();
    }else{

      window.location.href = "<?php echo base_url(); ?>Dashboard";
     } 
    }
  });
});
});

</script>