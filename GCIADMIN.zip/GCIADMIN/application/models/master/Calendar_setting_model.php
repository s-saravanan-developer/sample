<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Calendar_setting_model extends CI_Model {

    private $gc_company = 'gc_company_table';   

    public function get_holidays()
{

        $this->db->select("*");
        $this->db->where('Company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get("gc_weekly_calendar");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_weeks()
{

        $this->db->select("*");
        $this->db->where('Status',1);
        $query = $this->db->get("gc_weeks");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    
        public function get_calendar_export()
{

        $this->db->select("*");
        $this->db->where('Status',1);
        $query = $this->db->get("gc_individual_calendar");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
    

    public function get_all_company() {
        $this->db->select('company.*,country.country_name,state.state_name,city.city_name');
        $this->db->from('gc_company_table as company');
        $this->db->join('gc_cities as city', 'city.id = company.CityID', 'left');
        $this->db->join('gc_states as state', 'state.id = company.StateID', 'left');
        $this->db->join('gc_countries as country', 'country.id = company.Country', 'left');
        $this->db->where('company.CompanyStatus!=',3);
        $this->db->where('company.CompanyID', $this->session->userdata('CompanyId'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
                $company_base = $query->result_array(); 
                foreach ($company_base as $key => $value) {
                    $delete_status = $this->check_delete_status($value['CompanyID']);
                    if(isset($delete_status)){ 
                        $company_base[$key]['delete_status'] = 1; 
                    }
                    else{ 
                        $company_base[$key]['delete_status'] = 0;
                    }    
                }
            return $company_base;
        }
        return NULL;
    }

    public function get_events($start, $end)
{
    return $this->db->where("Date >=", $start)->where("Date <=", $end)->where("Status",1)->get("gc_individual_calendar");

}
    public function get_events1($year)
{
        // echo $year;
        // return $this->db->where("month(Date)", $year,FALSE)->get("gc_individual_calendar");
        $this->db->select("*");
        $this->db->where('Company_id', $this->session->userdata('CompanyId'));
        $this->db->where('Status', 1);
        // $this->db->where('month(Date)', $year,FALSE);
        $query = $this->db->get("gc_weekly_calendar");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    
}

public function insert_weekly_holidays($data,$id)
{

    $this->db->select("*");
        $this->db->where('Company_id', $data['Company_id']);
        $query = $this->db->get("gc_weekly_calendar");
        if ($query->num_rows() > 0) {
            $this->db->where("id", $id);
            $this->db->update("gc_weekly_calendar", $data);
        }else{
            $this->db->insert("gc_weekly_calendar", $data);
        }
        return NULL;
    }

    public function insert_weekly_holidays1($data,$id)
{   


        if ($this->db->insert('gc_individual_calendar', $data)) {
            $this->session->set_flashdata('Holiday_success', 'Added');
             return "1";
        }else{
            return "2";
        }
    }

public function add_monthly_setting($data)
    {
if ($this->db->insert('gc_individual_calendar', $data)) {
            $this->session->set_flashdata('Holiday_success', 'Added');
             echo "1";
        }else{
            echo "2";
        }       
    }
public function edit_monthly_setting($data,$id)
    {
        $this->db->where('Id', $id);
        if ($this->db->update('gc_individual_calendar', $data)) {
            echo "1";
        }else{
            echo "2";
        }
        
    }

public function delete_monthly_setting($id)
    {
        $this->db->where('Id', $id);
        if ($this->db->delete('gc_individual_calendar')) {
            echo "1";
        }else{
            echo "2";
        }
        
    }
    

}