<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Payout_money_model extends CI_Model { 

   public function get_today_payouts() {
        $pre_date=$this->get_previous_date1(date('Y-m-d')); 
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       
        // $this->db->where('commission.Commision_date',$pre_date);
        $this->db->where('commission.Payout_date',date('Y-m-d'));
        $this->db->where('commission.Status',1);
        // $this->db->where('commission.Payout_ID',1);
        $this->db->where('commission.Amount!=',0);
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            $result=$query->result_array();
            // return  $query->result_array();
            // var_dump($query->result_array());die();
            foreach ($result as $key => $value) {
            	$total_invest=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->row()->Amount;
            	// echo '<br>';

            	$total_earned=$this->db->select('sum(Amount) as Amount')->where(array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->get('gc_member_commission_details')->row()->Amount;

            	$pay_mode=$this->db->get_where('gc_member_payments',array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->row()->Payment_type_ID;
            	// die();
            	if($pay_mode==12){
            		if(($total_earned-$value['Amount'])<=$total_invest){
            		$result[$key]['Member_status']=1;
            	}else{
            		$result[$key]['Member_status']=0;
            	}
            	}else{
            		$result[$key]['Member_status']=0;
            	}
            	// if(($total_earned-$value['Amount'])<=$total_invest){
            	// 	$result[$key]['Member_status']=1;
            	// }else{
            	// 	$result[$key]['Member_status']=0;
            	// }
            }
            return $result;
        }
        return NULL;
    }

    public function get_week_payouts($mobile,$check_date) {
     //$pre_date=$this->get_previous_date1(date('Y-m-d')); 
       //$check_date;
        $type=$this->db->select('*')->from('gc_payout_type')->where('id',2)->where('status',1)->get()->row();
        $pay_d=$type->Days;
        // $pay_d=3;
        $days = array(
                    '1' => 'Monday',
                    '2' => 'Tuesday',
                    '3' => 'Wednesday',
                    '4' => 'Thursday',
                    '5' => 'Friday',
                    '6' => 'Saturday',
                    '7' => 'Sunday'
                        );
$pay_day=$days[$pay_d];
$cur_day=ucfirst(date('l',strtotime($check_date)));
// $cur_day='Wednesday';

if($pay_day===$cur_day){
     //echo '';
     $prev_date= date('Y-m-d', strtotime('previous '.$pay_day, strtotime($check_date)));
      $end_date=$this->get_previous_date1($check_date);
        $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no,pyt.payout_type');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');

        $this->db->join('gc_payout_type as pyt', 'pyt.id = commission.Payout_ID', 'left');
       

        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',2);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
           return NULL; 
        }


    }else{
        return NULL;
    }
    }

    public function get_week_payouts_condensed($mobile,$check_date) {
        $type=$this->db->select('*')->from('gc_payout_type')->where('id',2)->where('status',1)->get()->row();
        $pay_d=$type->Days;
        // $pay_d=3;
        $days = array(
                    '1' => 'Monday',
                    '2' => 'Tuesday',
                    '3' => 'Wednesday',
                    '4' => 'Thursday',
                    '5' => 'Friday',
                    '6' => 'Saturday',
                    '7' => 'Sunday'
                        );
$pay_day=$days[$pay_d];
$cur_day=ucfirst(date('l',strtotime($check_date)));
// $cur_day='Wednesday';

if($pay_day===$cur_day){
     //echo '';
     $prev_date= date('Y-m-d', strtotime('previous '.$pay_day, strtotime($check_date)));
      $end_date=$this->get_previous_date1($check_date);
        $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no,pyt.payout_type');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');

        $this->db->join('gc_payout_type as pyt', 'pyt.id = commission.Payout_ID', 'left');
       

        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Status',1);
        // $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',2);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            $wk=$query->result_array();
            
            for($i=0;$i<count($wk);$i++){
                $wk[$i]['Prev_date']=$prev_date;
                $wk[$i]['End_date']=$end_date;

            }
            return $wk;
        }else{
           return NULL; 
        }


    }else{
        return NULL;
    }
}    

    
public function get_binary_commission($mobile,$check_date) {
//echo $check_date;
        //$check_date=date('Y-m-d');
        $type=$this->db->select('*')->from('gc_payout_type')->where('id',3)->where('status',1)->get()->row();
        $pay_d=$type->Days;
        // $pay_d=3;

        $days = array(
                    '1' => 'Monday',
                    '2' => 'Tuesday',
                    '3' => 'Wednesday',
                    '4' => 'Thursday',
                    '5' => 'Friday',
                    '6' => 'Saturday',
                    '7' => 'Sunday'
                        );
$pay_day=$days[$pay_d];
$mnth_date=date("Y-m-d", strtotime("first ".$pay_day." of this month"));
$cur_day=ucfirst(date('l',strtotime($check_date)));

$mnth_date=date('Y-m-d');
//echo $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
//$sample_mnth="2019-04-01";

if(date('Y-m-d')==$mnth_date){
// if(date('Y-m-d')==date('Y-m-d')){
//echo "matched";echo '<br/>';die();
    $final_dates=[];
    $yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',2);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

        $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                
                $final_dates=array_values(array_diff($final_dates,$empt_leave));
                // print_r($final_dates);die();
                // echo $mnth_date;die();
        if(in_array($mnth_date, $final_dates)){
            
                //echo 'get values';
                $prev_date=date("Y-m-d", strtotime("first ".$pay_day." of previous month"));
                //echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
                $end_date=$this->get_previous_date1($mnth_date);
        $this->db->select('Commission_amount as Tot_binary_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Mobile');
        $this->db->from('gc_binary_commisions as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        // $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        // $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       

        $this->db->where('commission.Commission_date >=',"2019-03-01");
        // $this->db->where('commission.Commission_date >=',$prev_date);
        $this->db->where('commission.Commission_date <=',"2019-03-31");
        // $this->db->where('commission.Commission_date <=',$end_date);
        $this->db->where('commission.Status',1);
        $this->db->where('commission.Commission_amount!=',0);
        // $this->db->group_by('commission.Commision_type');
        // $this->db->group_by('commission.Membership_ID');
        // $this->db->where('commission.Payout_ID',3);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
           return NULL; 
        }
                //echo $prev_date=date('Y-m')
                
            
            
        }else{
            //echo 'today leave';
        }
    }
    
}else{
    $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
    //echo "not Match";
    if(date('Y-m-d')==$cms_start){
        //echo "Match Next Day";

        $prev_date=date("Y-m-d", strtotime("first ".$pay_day." of previous month"));
        //echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
        
                $end_date=$this->get_previous_date1($cms_start);
        $this->db->select('commission.Commission_amount as Tot_binary_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Mobile');
        $this->db->from('gc_binary_commisions as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        // $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        // $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       

        $this->db->where('commission.Commission_date >=',$prev_date);
        $this->db->where('commission.Commission_date <=',$end_date);
        $this->db->where('commission.Status',1);
        // $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        // $this->db->where('commission.Payout_ID',3);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
           return NULL; 
        }

    }else{
        return NULL;
        //echo "Not Match Next Day";
    }
}
// $cur_day='Wednesday';
//echo $cur_day;die();

}

public function get_month_payouts($mobile,$check_date) {
        //$check_date=date('Y-m-d');
        $type=$this->db->select('*')->from('gc_payout_type')->where('id',3)->where('status',1)->get()->row();
        $pay_d=$type->Days;
        // $pay_d=3;

        $days = array(
                    '1' => 'Monday',
                    '2' => 'Tuesday',
                    '3' => 'Wednesday',
                    '4' => 'Thursday',
                    '5' => 'Friday',
                    '6' => 'Saturday',
                    '7' => 'Sunday'
                        );
$pay_day=$days[$pay_d];
$mnth_date=date("Y-m-d", strtotime("first ".$pay_day." of this month"));
$cur_day=ucfirst(date('l',strtotime($check_date)));

//echo $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
if(date('Y-m-d')==$mnth_date){
//echo "matched";echo '<br/>';
    $final_dates=[];
    $yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

        $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));
        if(in_array($mnth_date, $final_dates)){
            
                //echo 'get values';
                $prev_date=date("Y-m-d", strtotime("first ".$pay_day." of previous month"));
                //echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
                $end_date=$this->get_previous_date1($mnth_date);
        $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       

        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',3);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
           return NULL; 
        }
                //echo $prev_date=date('Y-m')
                
            
            
        }else{
            //echo 'today leave';
        }
    }
    
}else{
    $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
    //echo "not Match";
    if(date('Y-m-d')==$cms_start){
        //echo "Match Next Day";

        $prev_date=date("Y-m-d", strtotime("first ".$pay_day." of previous month"));
        //echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
        
                $end_date=$this->get_previous_date1($cms_start);
        $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       

        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',3);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
           return NULL; 
        }

    }else{
        return NULL;
        //echo "Not Match Next Day";
    }
}
// $cur_day='Wednesday';
//echo $cur_day;die();
}

public function get_1st_monday_payouts($mobile,$check_date) {
        //$check_date=date('Y-m-d');
        $type=$this->db->select('*')->from('gc_payout_type')->where('id',5)->where('status',1)->get()->row();
        $pay_d=$type->Days;
        // $pay_d=3;

        $days = array(
                    '1' => 'Monday',
                    '2' => 'Tuesday',
                    '3' => 'Wednesday',
                    '4' => 'Thursday',
                    '5' => 'Friday',
                    '6' => 'Saturday',
                    '7' => 'Sunday'
                        );
$pay_day=$days[$pay_d];
$mnth_date=date("Y-m-d", strtotime("first ".$pay_day." of this month"));
$cur_day=ucfirst(date('l',strtotime($check_date)));

//echo $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
if(date('Y-m-d')==$mnth_date){
//echo "matched";echo '<br/>';
    $final_dates=[];
    $yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

        $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));
        if(in_array($mnth_date, $final_dates)){
            
                //echo 'get values';
                $prev_date=date("Y-m-d", strtotime("third ".$pay_day." of previous month"));
                //echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
                $end_date=$this->get_previous_date1($mnth_date);
        $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       

        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',5);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
           return NULL; 
        }
                //echo $prev_date=date('Y-m')
                
            
        }else{
            //echo 'today leave';
        }
    }
    
}else{
    $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
    //echo "not Match";
    if(date('Y-m-d')==$cms_start){
        //echo "Match Next Day";

        $prev_date=date("Y-m-d", strtotime("third ".$pay_day." of previous month"));
        //echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
        
                $end_date=$this->get_previous_date1($cms_start);
        $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       

        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',5);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
           return NULL; 
        }

    }else{
        return NULL;
        //echo "Not Match Next Day";
    }
}
// $cur_day='Wednesday';
//echo $cur_day;die();
}
     
public function get_3rd_monday_payouts($mobile,$check_date) {
        //$check_date=date('Y-m-d');
        $type=$this->db->select('*')->from('gc_payout_type')->where('id',5)->where('status',1)->get()->row();
        $pay_d=$type->Days;
        // $pay_d=3;

        $days = array(
                    '1' => 'Monday',
                    '2' => 'Tuesday',
                    '3' => 'Wednesday',
                    '4' => 'Thursday',
                    '5' => 'Friday',
                    '6' => 'Saturday',
                    '7' => 'Sunday'
                        );
$pay_day=$days[$pay_d];
$mnth_date=date("Y-m-d", strtotime("third ".$pay_day." of this month"));
$cur_day=ucfirst(date('l',strtotime($check_date)));

//echo $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
if(date('Y-m-d')==$mnth_date){
//echo "matched";echo '<br/>';
    $final_dates=[];
    $yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
        if(in_array($mnth_date, $final_dates)){
            $this->db->select('*');
            $this->db->where('Date',$mnth_date);
            $query = $this->db->get('gc_individual_calendar');
            if ($query->num_rows() > 0) {
                //echo 'leave';
            }else{
                //echo 'get values';
                $prev_date=date("Y-m-d", strtotime("first ".$pay_day." of previous month"));
                //echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
                $end_date=$this->get_previous_date1($mnth_date);
        $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       

        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',5);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
           return NULL; 
        }
                //echo $prev_date=date('Y-m')
                
            }
            
        }else{
            //echo 'today leave';
        }
    }
    
}else{
    $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
    //echo "not Match";
    if(date('Y-m-d')==$cms_start){
        //echo "Match Next Day";

        $prev_date=date("Y-m-d", strtotime("first ".$pay_day." of previous month"));
        //echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
        
                $end_date=$this->get_previous_date1($cms_start);
        $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       

        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',5);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
           return NULL; 
        }

    }else{
        return NULL;
        //echo "Not Match Next Day";
    }
}
// $cur_day='Wednesday';
//echo $cur_day;die();
}     
       public function get_payout_details($mobile,$date) {
        $pre_date=$this->get_previous_date1($date);
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
        // $this->db->where('commission.Commision_date',$pre_date);
        $this->db->where('commission.Payout_date',$date);
        $this->db->where('commission.Status',1);
        // $this->db->where('commission.Payout_ID',1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
        	$result=$query->result_array();
            // return  $query->result_array();
            // echo '<pre>';
            // print_r($query->result_array());die();
            // var_dump($query->result_array());die();
            foreach ($result as $key => $value) {
            	$total_invest=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->row()->Amount;
            	// echo '<br>';

            	$total_earned=$this->db->select('sum(Amount) as Amount')->where(array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->get('gc_member_commission_details')->row()->Amount;

            	$pay_mode=$this->db->get_where('gc_member_payments',array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->result_array();
            	// die();
            	if($pay_mode==12){
            		if(($total_earned-$value['Amount'])<=$total_invest){
            		$result[$key]['Member_status']=1;
            	}else{
            		$result[$key]['Member_status']=0;
            	}
            	}else{
            		$result[$key]['Member_status']=0;
            	}
            	// if(($total_earned-$value['Amount'])<=$total_invest){
            	// 	$result[$key]['Member_status']=1;
            	// }else{
            	// 	$result[$key]['Member_status']=0;
            	// }
            }
            return $result;
        }
        return NULL;
    }

public function get_payout_details_condensed($mobile,$date) {
        $pre_date=$this->get_previous_date1($date);
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
        $this->db->where('commission.Commision_date',$pre_date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_payout_topup($Membership_Id,$date,$Commision_type){
        $this->db->select('sum(Amount) as Amount');
        $this->db->from('gc_member_commission_details');
        $this->db->where('Membership_ID',$Membership_Id);
        $this->db->where('Commision_date',$date);
        $this->db->where('Commision_type',$Commision_type);
        $this->db->where('Payout_ID',1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
}

public function get_weekly_payout_topup($Membership_Id,$prev_date,$end_date,$Commision_type){
        $this->db->select('sum(Amount) as Amount');
        $this->db->from('gc_member_commission_details');
        $this->db->where('Membership_ID',$Membership_Id);
        $this->db->where('Commision_date >=',$prev_date);
        $this->db->where('Commision_date <=',$end_date);
        $this->db->where('Commision_type',$Commision_type);
        $this->db->where('Payout_ID',2);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
}
    

    

public function get_payout_processed_details($mobile,$date) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',$date);
        $this->db->where('commission.Payout_status',2);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


public function get_pay_later_details($mobile,$date) {
        $status=['3','4'];
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',$date);
        $this->db->where_in("commission.Payout_status",$status);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    public function get_payout_history_details($mobile,$date) {
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',$date);
        $this->db->where("commission.Payout_status",1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    

   public function get_export_payouts($id,$payout_mode) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Commision_date',date('Y-m-d'));
        $this->db->where('commission.Status',1);
        if($payout_mode==1){
        $this->db->where_in('commission.Commision_detail_ID',$id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }else{return NULL;}
        }else{

            $sample_array=[];
            foreach($id as $value){
            $value=explode('@',$value);
            $membership_id=$value[0];
            $prev_date=$value[1];
            $end_date=$value[2]; 
            $payout_id=$value[3];
        $this->db->where('commission.Membership_ID',$membership_id);
        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Payout_ID',$payout_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            //var_dump($query->result_array());
            $temp0=$query->result_array();
            foreach($temp0 as $temp){

                array_push($sample_array,$temp);
            }

            
        }else{
        //array_push($sample_array,NULL);
        }
        }
        return $sample_array;
        }
        
        
        
    }

   public function get_export_payouts_ready($id) {

         $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Commision_date',date('Y-m-d'));
        $this->db->where_in('commission.Commision_detail_ID',$id);
        // $this->db->where('commission.Status',1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


       public function get_today_processed_payouts() {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',2);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

       public function get_today_pay_later() {
        $status=['3','4'];
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where_in("commission.Payout_status",$status);
        // $this->db->where('commission.Payout_status',4);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

       public function get_today_payout_history() {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
    



    public function process_payout($id,$date,$payout_mode){
        $data_status['Status']=2;
        if($payout_mode==1){
          $id=explode('@',$id);
          // var_dump($id);die();
          $commission_id=$id[0];
          $table=$id[1];
          $ref_no=$id[2];
          if($table==1){
            $this->db->where('Commision_detail_ID',$commission_id);
            $this->db->update('gc_member_commission_details',$data_status);

            $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->where('commission.Commision_date',$date);
        $this->db->where('commission.Status',2);
        $this->db->where('commission.Commision_detail_ID',$commission_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                'Company_id'                  => $this->session->userdata('CompanyId'),
                'Branch_id'                   => $this->session->userdata('CompanyId'),
                'Commision_detail_ID'         => $commission[0]['Commision_detail_ID'],
                'Membership_ID'               => $commission[0]['Membership_ID'],
                'Contract_ID'                 => $commission[0]['Contract_ID'],
                'Commission_type'             => $commission[0]['Commision_type'],
                'Generated_date'              => $date,
                'Recieved_date  '             => '',
                'Payment_mode'                => 'Bank',
                'Bank_ID'                     => $commission[0]['Bank_ID'],
                'Actual_amount'               => $commission[0]['Amount'],
                'Charges'                     => 0,
                'Final_amount'                => $commission[0]['Amount'],
                'Reference_no'                => $ref_no,
                'Payout_status'               => 2,
                'Commission_mode'             => 1
                ); 
            //$this->db->insert('gc_member_payouts',$payout_data);
        }

          }else{
            $this->db->where('Commission_ID',$commission_id);
            $this->db->update('gc_binary_commisions',$data_status);

            $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Mobile');
        $this->db->from('gc_binary_commisions as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        // $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->where('commission.Commision_date',$date);
        $this->db->where('commission.Status',2);
        $this->db->where('commission.Commission_ID',$commission_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                'Company_id'                  => $this->session->userdata('CompanyId'),
                'Branch_id'                   => $this->session->userdata('CompanyId'),
                'Commision_detail_ID'         => $commission[0]['Commission_ID'],
                'Membership_ID'               => $commission[0]['Membership_ID'],
                'Contract_ID'                 => '',
                'Commission_type'             => '',
                'Generated_date'              => $date,
                'Recieved_date  '             => '',
                'Payment_mode'                => 'Bank',
                'Bank_ID'                     => $commission[0]['Bank_ID'],
                'Actual_amount'               => $commission[0]['Commission_amount'],
                'Charges'                     => 0,
                'Final_amount'                => $commission[0]['Commission_amount'],
                'Payout_status'               => 2,
                'Commission_mode'             => 2
                ); 
            //$this->db->insert('gc_member_payouts',$payout_data);
        }
          }
            
        

        }else{
        $id=explode('@',$id);
            $membership_id=$id[0];
            $prev_date=$id[1];
            $end_date=$id[2]; 
            $payout_id=$id[3];
            $table=$id[4];
            if($table==1){
                $this->db->where('Membership_ID',$membership_id);
                $this->db->where('Commision_date >=',$prev_date);
                $this->db->where('Commision_date <=',$end_date);
                $this->db->where('Payout_ID',$payout_id);
                $this->db->update('gc_member_commission_details',$data_status);
                $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->where('commission.Commision_date',$date);
        $this->db->where('commission.Status',2);
        $this->db->where('commission.Membership_ID',$membership_id);
        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Payout_ID',$payout_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                'Company_id'                  => $this->session->userdata('CompanyId'),
                'Branch_id'                   => $this->session->userdata('CompanyId'),
                'Commision_detail_ID'         => $commission[0]['Commision_detail_ID'],
                'Membership_ID'               => $commission[0]['Membership_ID'],
                'Contract_ID'                 => $commission[0]['Contract_ID'],
                'Commission_type'             => $commission[0]['Commision_type'],
                'Generated_date'              => $date,
                'Recieved_date  '             => '',
                'Payment_mode'                => 'Bank',
                'Bank_ID'                     => $commission[0]['Bank_ID'],
                'Actual_amount'               => $commission[0]['Amount'],
                'Charges'                     => 0,
                'Final_amount'                => $commission[0]['Amount'],
                'Payout_status'               => 2,
                'Commission_mode'             => 1
                ); 
            // $this->db->insert('gc_member_payouts',$payout_data);
        }
            }
            // else{

            // }
        

    }
    $this->db->insert('gc_member_payouts',$payout_data);


    }

public function cancel_payout($id,$date,$payout_mode){
        $data_status['Status']=4;
        if($payout_mode==1){
          $id=explode('@',$id);
          $commission_id=$id[0];
          $table=$id[1];
          if($table==1){
            $this->db->where('Commision_detail_ID',$commission_id);
            $this->db->update('gc_member_commission_details',$data_status);

            $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->where('commission.Commision_date',$date);
        $this->db->where('commission.Status',4);
        $this->db->where('commission.Commision_detail_ID',$commission_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                'Company_id'                  => $this->session->userdata('CompanyId'),
                'Branch_id'                   => $this->session->userdata('CompanyId'),
                'Commision_detail_ID'         => $commission[0]['Commision_detail_ID'],
                'Membership_ID'               => $commission[0]['Membership_ID'],
                'Contract_ID'                 => $commission[0]['Contract_ID'],
                'Commission_type'             => $commission[0]['Commision_type'],
                'Generated_date'              => $date,
                'Recieved_date  '             => $date,
                'Payment_mode'                => 'Bank',
                'Bank_ID'                     => $commission[0]['Bank_ID'],
                'Actual_amount'               => $commission[0]['Amount'],
                'Charges'                     => 0,
                'Final_amount'                => $commission[0]['Amount'],
                'Payout_status'               => 4,
                'Commission_mode'             => 1
                ); 
            //$this->db->insert('gc_member_payouts',$payout_data);
        }

          }else{
            $this->db->where('Commission_ID',$commission_id);
            $this->db->update('gc_binary_commisions',$data_status);

            $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Mobile');
        $this->db->from('gc_binary_commisions as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        // $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->where('commission.Commision_date',$date);
        $this->db->where('commission.Status',4);
        $this->db->where('commission.Commission_ID',$commission_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                'Company_id'                  => $this->session->userdata('CompanyId'),
                'Branch_id'                   => $this->session->userdata('CompanyId'),
                'Commision_detail_ID'         => $commission[0]['Commission_ID'],
                'Membership_ID'               => $commission[0]['Membership_ID'],
                'Contract_ID'                 => '',
                'Commission_type'             => '',
                'Generated_date'              => $date,
                'Recieved_date  '             => $date,
                'Payment_mode'                => 'Bank',
                'Bank_ID'                     => $commission[0]['Bank_ID'],
                'Actual_amount'               => $commission[0]['Commission_amount'],
                'Charges'                     => 0,
                'Final_amount'                => $commission[0]['Commission_amount'],
                'Payout_status'               => 4,
                'Commission_mode'             => 2
                ); 
            //$this->db->insert('gc_member_payouts',$payout_data);
        }
          }
            
        

        }else{
        $id=explode('@',$id);
            $membership_id=$id[0];
            $prev_date=$id[1];
            $end_date=$id[2]; 
            $payout_id=$id[3];
            $table=$id[4];
            if($table==1){
                $this->db->where('Membership_ID',$membership_id);
                $this->db->where('Commision_date >=',$prev_date);
                $this->db->where('Commision_date <=',$end_date);
                $this->db->where('Payout_ID',$payout_id);
                $this->db->update('gc_member_commission_details',$data_status);
                $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->where('commission.Commision_date',$date);
        $this->db->where('commission.Status',4);
        $this->db->where('commission.Membership_ID',$membership_id);
        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Payout_ID',$payout_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                'Company_id'                  => $this->session->userdata('CompanyId'),
                'Branch_id'                   => $this->session->userdata('CompanyId'),
                'Commision_detail_ID'         => $commission[0]['Commision_detail_ID'],
                'Membership_ID'               => $commission[0]['Membership_ID'],
                'Contract_ID'                 => $commission[0]['Contract_ID'],
                'Commission_type'             => $commission[0]['Commision_type'],
                'Generated_date'              => $date,
                'Recieved_date  '             => $date,
                'Payment_mode'                => 'Bank',
                'Bank_ID'                     => $commission[0]['Bank_ID'],
                'Actual_amount'               => $commission[0]['Amount'],
                'Charges'                     => 0,
                'Final_amount'                => $commission[0]['Amount'],
                'Payout_status'               => 4,
                'Commission_mode'             => 1
                ); 
            // $this->db->insert('gc_member_payouts',$payout_data);
        }
            }
            // else{

            // }
        

    }
    $this->db->insert('gc_member_payouts',$payout_data);


    }    



public function cancel_payout1($id,$date,$payout_mode){
        $data_status['Status']=4;
        if($payout_mode==1){
        $this->db->where('Commision_detail_ID',$id);
        }else{
        $id=explode('@',$id);
            $membership_id=$id[0];
            $prev_date=$id[1];
            $end_date=$id[2]; 
            $payout_id=$id[3];
        $this->db->where('Membership_ID',$membership_id);
        $this->db->where('Commision_date >=',$prev_date);
        $this->db->where('Commision_date <=',$end_date);
        $this->db->where('Payout_ID',$payout_id);
    }
        if($this->db->update('gc_member_commission_details',$data_status)){


        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->where('commission.Commision_date',$date);
        $this->db->where('commission.Status',4);
        if($payout_mode==1){
        
        $this->db->where('commission.Commision_detail_ID',$id);
        }else{
            $id=explode('@',$id);
            $membership_id=$id[0];
            $prev_date=$id[1];
            $end_date=$id[2]; 
            $payout_id=$id[3];
        $this->db->where('commission.Membership_ID',$membership_id);
        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Payout_ID',$payout_id);
        }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                'Company_id'                  => $this->session->userdata('CompanyId'),
                'Branch_id'                   => $this->session->userdata('CompanyId'),
                'Commision_detail_ID'         => $commission[0]['Commision_detail_ID'],
                'Membership_ID'               => $commission[0]['Membership_ID'],
                'Contract_ID'                 => $commission[0]['Contract_ID'],
                'Commission_type'             => $commission[0]['Commision_type'],
                'Generated_date'              => $date,
                'Recieved_date  '             => $date,
                'Payment_mode'                => 'Bank',
                'Bank_ID'                     => $commission[0]['Bank_ID'],
                'Actual_amount'               => $commission[0]['Amount'],
                'Charges'                     => 0,
                'Final_amount'                => $commission[0]['Amount'],
                'Payout_status'               => 4,
                );
            

            $this->db->insert('gc_member_payouts',$payout_data);

        }

    }

    }




    public function payout_later($id,$date){
        $data_status['Status']=3;
        $id=explode('@',$id);
        $Commision_detail_ID=$id[0];
        $Commission_mode=$id[1];
        if($Commission_mode==1){
            $this->db->where('Commision_detail_ID',$Commision_detail_ID);
            $this->db->update('gc_member_commission_details',$data_status);

            $payout_data=array(
                'Recieved_date  '          => $date,
                'Payout_status'               => 3
                );
            

            $this->db->where('Commision_detail_ID',$Commision_detail_ID);
            $this->db->where('Commission_mode',$Commission_mode);
           $this->db->update('gc_member_payouts',$payout_data);

           $mem_ID=$this->db->get_where('gc_member_commission_details',array('Commision_detail_ID' => $Commision_detail_ID))->result_array();
           	$this->db->where('Membership_ID',$mem_ID[0]['Membership_ID']);
            $this->db->where('Contract_ID',$mem_ID[0]['Contract_ID']);
            $this->db->where('Payout_date',date('Y-m-d',strtotime($date)));
            $this->db->update('gc_daily_member_commission_details',$data_status);

        
    }else{
            $this->db->where('Commission_ID',$Commision_detail_ID);
            $this->db->update('gc_binary_commisions',$data_status);

            $payout_data=array(
                
                'Recieved_date  '             => $date,
                
                'Payout_status'               => 3,
                );
            
        $this->db->where('Commision_detail_ID',$Commision_detail_ID);
        $this->db->where('Commission_mode',$Commission_mode);
        $this->db->update('gc_member_payouts',$payout_data);
    }

   

    }

public function mark_as_paid($id,$date){
        $data_status['Status']=6;
        $id=explode('@',$id);
        $Commision_detail_ID=$id[0];
        $Commission_mode=$id[1];
        if($Commission_mode==1){
            $this->db->where('Commision_detail_ID',$Commision_detail_ID);
            $this->db->update('gc_member_commission_details',$data_status);

           



            $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->where('commission.Commision_date',date('Y-m-d'));
        $this->db->where('commission.Status',6);
        $this->db->where('commission.Commision_detail_ID',$Commision_detail_ID);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                
                'Recieved_date  '             => $date,
                
                'Payout_status'               => 1,
                );
            
        $this->db->where('Commision_detail_ID',$Commision_detail_ID);
        $this->db->where('Commission_mode',$Commission_mode);
        $this->db->update('gc_member_payouts',$payout_data);

        $this->db->select('Payout_ID');
        $this->db->from('gc_member_payouts');
        $this->db->where('Commission_mode',$Commission_mode);
        $this->db->where('Commision_detail_ID',$Commision_detail_ID);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $pay=$query->result_array();
            $payout_id=$pay[0]['Payout_ID'];
        }



            $history_data=array(
                 'Company_id'                 => $this->session->userdata('CompanyId'),
                 'Branch_id'                  => $this->session->userdata('CompanyId'), 
                 'Membership_ID'              => $commission[0]['Membership_ID'],
                 'Contract_ID'                => $commission[0]['Contract_ID'],
                 'Payout'                     => $payout_id,
                 'Payout_ID'                  => $commission[0]['Payout_ID'],
                 'Date'                       => $date,
                 'History_for'                => 'Credited Commission Amount is '.$commission[0]['Amount'] ,
                 'Credit_amount'              => $commission[0]['Amount'],
                 'Type'                       => 1,
                 'Debit_amount'               => 0
                  );
            $this->db->insert('gc_transaction_history',$history_data);

            $this->db->where('Membership_ID',$commission[0]['Membership_ID']);
            $this->db->where('Contract_ID',$commission[0]['Contract_ID']);
            $this->db->where('Payout_date',date('Y-m-d',strtotime($date)));
            $this->db->update('gc_daily_member_commission_details',$data_status);

        }


        }else{
            $this->db->where('Commission_ID',$commission_id);
            $this->db->update('gc_binary_commisions',$data_status);

            $payout_data=array(
                
                'Recieved_date  '             => $date,
                
                'Payout_status'               => 1,
                );
            
        $this->db->where('Commision_detail_ID',$Commision_detail_ID);
        $this->db->where('Commission_mode',$Commission_mode);
        $this->db->update('gc_member_payouts',$payout_data);

        $this->db->select('Payout_ID,Final_amount,Membership_ID');
        $this->db->from('gc_member_payouts');
        $this->db->where('Commission_mode',$Commission_mode);
        $this->db->where('Commision_detail_ID',$Commision_detail_ID);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $pay=$query->result_array();
            $payout_id=$pay[0]['Payout_ID'];
            $amount=$pay[0]['Final_amount'];
            $Membership_ID=$pay[0]['Membership_ID'];
        }

        $history_data=array(
                 'Company_id'                 => $this->session->userdata('CompanyId'),
                 'Branch_id'                  => $this->session->userdata('CompanyId'), 
                 'Membership_ID'              => $Membership_ID,
                 'Contract_ID'                => '',
                 'Payout'                     => $payout_id,
                 'Payout_ID'                  => 4,
                 'Date'                       => $date,
                 'History_for'                => 'Credited Binary Commission Amount is '.$amount,
                 'Credit_amount'              => $amount,
                 'Type'                       => 1,
                 'Debit_amount'               => 0
                  );
            $this->db->insert('gc_binary_transaction_history',$history_data);

        }


    }


function getall_members($status,$status1) {

        $this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');

        // $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
        $this->db->group_by("member.Membership_ID");
        if($status!=1){
        $this->db->where("member.Status",$status);}
        if($status1==10 || $status1==11){
            if($status1==10){
                $this->db->where("bank.Status",5);
            }elseif($status1==11){
                $this->db->where("documents.Status",5);
            }
        }
        $this->db->group_by("payments.Membership_ID");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


public function update_document_status($data,$Membership_ID) {
    $id=$data['Document_ID'];
    unset($data['Document_ID']);
        $this->db->where('Document_ID',$id);
        $this->db->update('gc_member_documents',$data);

        $data1['Status']=4;
        $this->db->where('Membership_ID',$Membership_ID);
        if($this->db->update('gc_membership',$data1)){
            return 1;
            }else{
                return 0;
            }
    }

    public function get_previous_date($cur_date){

    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);
            //var_dump($week_days);
$date=new DateTime();
$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

    if($week_days[$i] == $search){
        $arr[$i] = $week_days[$i];
        $search = $week_days[$i] + 1;
    }else{
        $arr2[$i] = $week_days[$i];
    }
}

$action = array_merge($arr,$arr2);
$days = array(
     '1' => 'Monday',
     '2' => 'Tuesday',
     '3' => 'Wednesday',
     '4' => 'Thursday',
     '5' => 'Friday',
     '6' => 'Saturday',
     '7' => 'Sunday'
 );
$final_dt=[];

foreach($action as $da){
if (array_key_exists($da,$days))
  {
  array_push($final_dt,$days[$da]);
  }

}

//var_dump($final_dt);
$final_dates=[];
for($i=1; $i<=52; $i++){
        foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
        array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
        }
    }
   $cur_date=date("Y-m-d", strtotime($cur_date));
    
    //var_dump($final_dates);
    foreach($final_dates as $key=> $fin){
if($cur_date==$fin){
    $keyval= $key-1;
    return  $final_dates[$keyval];
}else{
    $keyval=$key;
    $final_dates[$keyval];
}
    }
    //echo $serch_date=$final_dates[$keyval];
}

    }

public function get_previous_date1($cur_date){
$final_dates=[];
$yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

                $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);    

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));

    foreach($final_dates as $key=> $fin){
if($cur_date==$fin){

    
    if($key>=1){
    $keyval= $key-1;
    return  $final_dates[$keyval];
}else{
    //$keyval= date("Y",strtotime("-1 year")).'-12-31';
    return  date("Y",strtotime("-2 year")).'-12-31';
}
    

}else{
    $keyval=$key;
    $final_dates[$keyval];
}
    }
}

    }

public function get_advance_date1($cur_date){
$final_dates=[];
$yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

        $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));

    foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
    
    $keyval= $key;
    if(isset($final_dates[$keyval])){
        return $final_dates[$keyval];
    }else{
        return date('Y-01-01');
    }
    
    break;
}else{
    $keyval=$key;
    return $final_dates[$keyval];
}
    }
}

    }

    public function get_three_yrs_holidays($year,$week_days){

//$week_days=['6','7'];
            //var_dump($week_days);
$date=new DateTime();
//$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

    if($week_days[$i] == $search){
        $arr[$i] = $week_days[$i];
        $search = $week_days[$i] + 1;
    }else{
        $arr2[$i] = $week_days[$i];
    }
}

$action = array_merge($arr,$arr2);
$days = array(
     '1' => 'Monday',
     '2' => 'Tuesday',
     '3' => 'Wednesday',
     '4' => 'Thursday',
     '5' => 'Friday',
     '6' => 'Saturday',
     '7' => 'Sunday'
 );
$final_dt=[];
//var_dump($action);
foreach($action as $da){
if (array_key_exists($da,$days))
  {
    //$sim=array('N' => $days[$da], 'A' => $da);
  array_push($final_dt,$days[$da]);
  }

}
//var_dump($final_dt);

$final_dates=[];
for($i=1; $i<=52; $i++){
        foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
        array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
        }
    }
    return $final_dates;
}


}



