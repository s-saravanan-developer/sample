
<script>
   <?php
         if ($this->session->flashdata('users_success')) 
         {
            echo "var data = ' ".$this->session->flashdata('users_success')."';";
            echo "success(data);";
         }
   ?>
</script>

<div class="content-wrapper">
   <div class="content">
      <header class="page-header">
         <div class="d-flex align-items-center">
            <div class="mr-auto">
               <h1 class="separator">Add New User</h1>
               <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="index.html"><i class="icon dripicons-home"></i></a></li>
                     <li class="breadcrumb-item"><a href="javascript:void(0)">Master</a></li>
                     <li class="breadcrumb-item active" aria-current="page">Manage User / Add New User</li>
                  </ol>
               </nav>
            </div>
            <ul class="actions top-right">
               <li class="dropdown">
                  <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                  <i class="la la-ellipsis-h"></i>
                  </a>
                  <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(40px, 40px, 0px); top: 0px; left: 0px; will-change: transform;">
                     <div class="dropdown-header">
                        Quick Actions
                     </div>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-clockwise"></i> Refresh
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-gear"></i> Manage User Types
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-help"></i> Support
                     </a>
                  </div>
               </li>
            </ul>
         </div>
      </header>
      <section class="page-content container-fluid">
         <div class="row">
            <div class="col">
               <div class="card" style="overflow-x: scroll;">
                  <h5 class="card-header">User Information</h5>
                 
                 <form class="needs-validation" action="<?php echo base_url();?>master/users/user_add" method="POST" data-toggle="validator" role="form" enctype="multipart/form-data">
                     <div class="card-body">
                        <div class="form-body">
                           <div class="row">

                              <!-- <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Region</label> <span class="text-danger">*</span>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="la la-building"></i></span>
                                       </div>
                                         <select class="form-control " id="s2_demo7" name="branch_id" required="">
                                          <option value="" selected>Select Region</option>
                                             <?php
                                          if (!empty($branch)) {
                                              foreach ($branch as $value) {
                                                  ?>
                                                  <option value="<?php echo $value['id']; ?>"><?php echo ucfirst($value['type_name']); ?></option>
                                                  <?php
                                              }
                                          }
                                          ?>
                                          </select>
                                 </div>
                                 </div>
                              </div>  -->
                              
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">User Code</label>
                                    <!-- <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-account zmdi-hc-fw"></i></span>
                                       </div> -->
                                
                                       <input type="text" class="form-control" placeholder="User Id" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="user_code" readonly="" value="<?php echo $Prefix[0]['user_prefix']; ?>-0000<?php echo $user_id; ?>">
                                 </div>
                              </div>

                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Company</label> <span class="text-danger">*</span>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control  multiselect" multiple="" id="company_id"  name="company_id[]" required="">
                                       <!-- <option value="">Select Company</option> -->
                                    <?php
                                    if (!empty($companies)) {
                                        foreach ($companies as $company) {
                                            ?>
                                            <option value="<?php echo $company['company_id']; ?>" <?php echo ($company['company_id'] == 0) ? 'selected' : ''; ?>><?php echo ucfirst($company['company_name']); ?>
                                            </option>
                                            <?php
                                        }
                                    }
                                    ?>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Name</label> <span class="text-danger">* </span>       
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-account zmdi-hc-fw"></i></span>
                                       </div>
                                       <input type="text" class="form-control " placeholder="Enter Name" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="firstname" required="" maxlength="50">
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label">DOB</label>
                                    <div class="input-group">
                                       <span class="input-group-addon action">
                                       <i class="icon dripicons-calendar"></i>
                                       </span>
                                       <input type="text" class="form-control helper-datepicker" placeholder="dd/mm/yyyy" name="dob" id="tbDate" >
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Email Address</label>
                                    <div class="input-group mb-3">
                                       <div class="input-group-append">
                                          <span class="input-group-text" id="basic-addon2"><i class="zmdi zmdi-email zmdi-hc-fw"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Enter Email Address" aria-label="Icon Left" aria-describedby="basic-addon2" name="email" minlength="10">
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Mobile Number</label> <span class="text-danger">*</span>
                                    <div class="input-group mb-3">
                                       <div class="input-group-append">
                                          <span class="input-group-text" id="basic-addon2"><i class="zmdi zmdi-smartphone-iphone zmdi-hc-fw"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Enter Mobile Number" aria-label="Icon Left" aria-describedby="basic-addon2" name="mobile" required="" pattern="[6-9]{1}[0-9]{9}" maxlength="10" onkeypress="return isNumber(event)" />
                                    </div>
                                 </div>
                              </div>
                              
                              
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Phone Number</label>
                                    <div class="input-group mb-3">
                                       <div class="input-group-append">
                                          <span class="input-group-text" id="basic-addon2"><i class="zmdi zmdi-phone zmdi-hc-fw"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Enter Phone Number" aria-label="Icon Left" aria-describedby="basic-addon2" name="phone" maxlength="11" onkeypress="return isNumber(event)">     
                                                            
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">

                                    <label class="col-form-label-lg control-label" for="largeInput">Address Line 1</label> <span class="text-danger">*</span>
                                     <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-card zmdi-hc-fw"></i></span>
                                       </div>
                                    <input type="text" class="form-control" id="exampleFormControlTextarea1" placeholder="Enter Address Line 1" name="address1" required="" />
                                    <div class="invalid-feedback">
                                       Please choose a Address Line.
                                    </div>
                                 </div>
                                 </div>

                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Address Line 2</label>
                                     <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-card zmdi-hc-fw"></i></span>
                                       </div>
                                    <input class="form-control" id="exampleFormControlTextarea1" placeholder="Enter Address Line 2" name="address2" required="" />
                                 </div>
                                 </div>
                              </div>
                              
                              
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Country</label> <span class="text-danger">*</span>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control company_country" id="country_id"  name="country_id" required="">
                                       <option value="">Select Country</option>
                                    <?php
                                    if (!empty($countries)) {
                                        foreach ($countries as $country) {
                                            ?>
                                            <option value="<?php echo $country['id']; ?>" <?php echo ($country['id'] == 0) ? 'selected' : ''; ?>><?php echo ucfirst($country['country_name']); ?>
                                            </option>
                                            <?php
                                        }
                                    }
                                    ?>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">State</label> <span class="text-danger">*</span>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control company_state"  id="state_id" name="state_id" required="">
                                       <option value="">Select State</option>

                                       <?php
                                    if (!empty($states)) {
                                        foreach ($states as $state) {
                                            ?>
                                            <option value="<?php echo $state['id']; ?>"><?php echo ucfirst($state['state_name']); ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">City</label> <span class="text-danger">*</span>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control company_city" id="city_id" name="city_id" required="">
                                     <option value="">Select City</option>

                                    </select>
                                 </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Pincode</label> <span class="text-danger">*</span>
                                    <div class="input-group mb-3" style="height: calc(2.25rem + -8px);">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text" id="basic-icon-addon1"><i class="icon dripicons-location"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Enter Pincode" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="pincode" required=""  maxlength="6" pattern="[1-9]{1}[0-9]{5}" onkeypress="return isNumber(event)" style="height: calc(2.25rem + -8px);">
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Profile Picture</label>
                                    <span class="">
                                       <input type="file" id="profile_image" class="form-control" name="profile" >
                                    </span>
                                 </div>
                              </div>
                              <div class="col-md-4" style="margin-top: 13px">
                                        <a href="javascript:void(0);" style="margin-left: -55px;"><img id="imagePreview" src="<?php echo base_url(); ?>attachments/users_image/default_profile_image.png" style="width: 60px; height: 60px; border: -2px #ccc solid;margin-top:10px;margin-left:55px;margin-top:6px; " alt="User profile picture" default_src="<?php echo base_url(); ?>attachments/users_image/default_profile_image.png"></a>
                                    </div>

                                   
                           </div>
                           <div class="row">
                             
                                <h5 class="card-header">User Credential
                                 </h5>
                              <div class="col-12">
                                 <div class="row">
                                    <div class="col-md-4">
                                       <div class="form-group">
                                          <label class="col-form-label-lg control-label" style="padding-left: 9px;" for="largeInput">User Name</label> <span class="text-danger">* <code class=" duplicate-occur no-display" style="font-size: 10px;"> [This Username Is Already Used ]</code></span>
                                          <div class="input-group mb-3"  style="padding-left: 9px;">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-account zmdi-hc-fw"></i></span>
                                             </div>
                                             <input type="text" class="form-control check_data" placeholder="User Name" aria-label="Icon Left" aria-describedby="basic-icon-addon1" onkeyup="duplicate_check()" name="username" required="">
                                          </div>
                                           
                                       </div>
                                    </div>
                                    <div class="col-md-4">
                                       <div class="form-group">
                                          <label class="col-form-label-lg control-label" for="largeInput">Password</label> <span class="text-danger">*</span>
                                          <div class="input-group mb-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-lock zmdi-hc-fw"></i></span>
                                             </div>
                                             
                                             <input type="password" data-minlength="6" class="form-control" id="inputPasswordform" placeholder="Password" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="password" required="">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-4">
                                       <div class="form-group">
                                          <label class="col-form-label-lg control-label" for="largeInput">Re-Password</label> <span class="text-danger">*</span>
                                          <div class="input-group mb-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-lock zmdi-hc-fw"></i></span>
                                             </div>
                                             
                                             <input type="password" class="form-control" id="inputPasswordConfirm" data-match="#inputPasswordform" data-match-error="Whoops, these don't match" placeholder="Re-Password" aria-describedby="basic-icon-addon1" required=""> <br>
                                          </div>
                                          
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                          <h5 class="card-header">User Role Information
                              </h5>
                           <div class="col-md-12">
                              <div class="row">
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">User Type</label> <span class="text-danger">*</span>
                                     <div class="input-group mb-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-account zmdi-hc-fw"></i></span>
                                             </div>
                                    <select class="form-control" id="user_type_id" name="user_type_id" onchange="view_desp()" required=""><option>Select User Type</option>
                                       <?php if (!empty($user_types)) {foreach ($user_types as $type) {
                                            ?>
                                       <option value="<?php echo $type['user_type_id']; ?>"><?php echo ucfirst($type['user_type_name']); ?></option>
                                            <?php } } ?>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                           <div class="col-md-8" id="description_view" style="display:none;">
                                 <div class="form-group">
                                    <label for="exampleFormControlTextarea1">Description <span style="color:red">*</span></label></label>
                                    <textarea class="form-control" style="background-color: yellow;" id="description" placeholder="Enter Description" required="" name="user_type[description]" rows="3" readonly=""></textarea>
                                 </div>
                           </div>
                           </div>
                           </div>
                        </div>
                     </div>
                     




                 
                  <div class="card-footer bg-light">                  
                     <button class="btn btn-success" id="useradd" type="submit">Submit</button>
                     <a href="<?php echo base_url();?>master/users/user" class="btn btn-accent">Cancel</a>
                  </div>
               
                  </form>
               </div>
            </div>
 
  
   </section>
</div>
</div>
</div>
<script type="text/javascript">

$(function() {
  var name = [];
  $.map(name, function (x) {
    return $('.multiselect').append("<option>" + x + "</option>");
  });
  
  $('.multiselect')
    .multiselect({
      allSelectedText: 'All',
      maxHeight: 200,
      includeSelectAllOption: true
    })
    .multiselect('deselectAll', false)
    .multiselect('updateButtonText');
});

   // $(document).ready(function(){
   //    $('.company_id').select2();
   // });
   function view_desp(){
      id = $('#user_type_id').val();
      var data_string="id="+id;
      console.log(data_string);
        $.ajax({   
          url: "<?php echo base_url(); ?>master/Users/get_desp",
          async: false,
          type: "POST",    
          data: data_string, 
          dataType: "json", 
          success: function(data) { 
                
         if(data!=null){
            $("#description_view").show();
            $("#description").val(data[0]['description']);
            }
            else{
                 $("#description_view").hide();
                 $("#description").val("");
               }
      
    }
    });
   }

         function duplicate_check() {
        // alert("hi");
      var check_data = $('.check_data').val();
      // alert(check_data);
      var result = '';
         $.ajax({
           type: "POST",
           url: "<?php echo base_url(); ?>master/location/duplicate_check",
           data: {data: check_data,table_name: 'gc_users',colum: 'username'},
           cache: true,
           async: false,
           success: function(data){
            // alert(data);
            result = data;
           }
         });
         if(result == 1){
            $('.duplicate-occur').removeClass('no-display');
            
            $('#useradd').attr( "disabled","disabled");
            return false;
        }else{
            $('.duplicate-occur').addClass('no-display');
            $('#useradd').removeAttr( "disabled", );
            return true;
        }
         
   }
</script>

<script type="text/javascript">
  
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}



</script>






               
