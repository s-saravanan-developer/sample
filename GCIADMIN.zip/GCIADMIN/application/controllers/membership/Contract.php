<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Contract extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('member/Membership_model');
        $this->load->model('member/Contract_model');
    }

	public function index()
	{
    	$template['page']            ='contract/contract';
        
        $this->load->view('template',$template);
	}

	public function manage_contract(){

		$template['page']            ='contract/manage_contract';
        // $template['contract']  = $this->Contract_model->get_today_contracts(date('Y-m-d'));
        $this->load->view('template',$template);
	}

public function get_contract_details()
        {
        $mobile = $this->input->post("mobile");  

        $this->load->model('member/Contract_model');
        $template['contract'] =  $this->Contract_model->get_contract_details($mobile);
        $this->load->view('contract/ajax_contract',$template);
    }

public function excel_to_all(){
	    $date = date('Y-m-d',strtotime($this->input->get('id')));
	 	$this->load->model('member/Contract_model');
        $template['contract'] =  $this->Contract_model->get_today_contracts($date);
       $template['date']=$this->input->get('id');
        $this->load->view('contract/excel_topup',$template);

}

    public function get_today_topup(){
    	 $date = date('Y-m-d',strtotime($this->input->post("date")));
    	$this->load->model('member/Contract_model');
        $template['contract'] =  $this->Contract_model->get_today_contracts($date);
       $template['date']=$this->input->post("date");
        $this->load->view('contract/ajax_contract',$template);
    }

    public function change_payment_status()
        {
        $Membership_ID = $this->input->post("Membership_ID");  
        $Member_payment_ID = $this->input->post("Member_payment_ID"); 
        $result =  $this->Contract_model->change_payment_status($Membership_ID,$Member_payment_ID);
        echo $result;
    }

        public function change_payment_status1()
        {
        $Membership_ID = $this->input->post("Membership_ID");  
        $Member_payment_ID = $this->input->post("Member_payment_ID"); 
        $result =  $this->Contract_model->change_payment_status1($Membership_ID,$Member_payment_ID);
        echo $result;
    }

    public function get_payments_details()
        {
        $Membership_ID = $this->input->post("Membership_ID");  
        $Contract_ID = $this->input->post("Contract_ID");  
        $this->load->model('member/Contract_model');
        $template['bank']            =  $this->Membership_model->getall_bank();
        $template['payment_mode']    =  $this->Membership_model->getall_payment_modes();
        $template['payments'] =  $this->Contract_model->get_payments_details($Membership_ID,$Contract_ID);
        $this->load->view('contract/ajax_contract',$template);
    }

    
public function get_documentation_details()
        {
        $Membership_ID = $this->input->post("Membership_ID");  
        $Contract_ID = $this->input->post("Contract_ID");  
        $this->load->model('member/Contract_model');
        $template['payments2'] =  $this->Contract_model->get_document_details($Membership_ID,$Contract_ID);
        // var_dump($template['payments2']);die();
        $this->load->view('contract/ajax_contract',$template);
    }
    
public function update_payment_status(){
extract($_POST);

if (isset($_POST['update']) || isset($_POST['unverified']) || isset($_POST['reupload'])) {
	
        foreach ($payment_data as $key => $value) {

			$name='Payment_'.$key;
			$file_name='upload'.$key;

			$photo_name = $this->payment_attachment($Membership_code,$file_name,$name);
			if (!empty($photo_name)) {
				
				$value['Statement'] = "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/'.$photo_name;
			}		

			$value['Date']=date('Y-m-d',strtotime($value['Date']));
			// var_dump($value);die();
			$this->db->where('Member_payment_ID',$value['Member_payment_ID']);
			$this->db->update('gc_member_payments',$value);
		}

		if (isset($_POST['update']) || isset($_POST['unverified'])) {
			$mbr_data['Payment_verify']=9; 
		}else{
			$mbr_data['Payment_verify']=5;
		}
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->update('gc_membership',$mbr_data);

		if(isset($_POST['update'])){
			redirect('membership/Membership/contract?id='.$Membership_code);
		}elseif(isset($_POST['unverified'])){
			redirect('membership/Membership/payment_members');
		}else{
			redirect('membership/Membership/payment_reupload_members');
		}

		
    }elseif(isset($_POST['verify_payment']) || isset($_POST['normal_verify_payment'])) {

    	foreach ($payment_data as $key => $value) {

			$name='Payment_'.$key;
			$file_name='upload'.$key;

			$photo_name = $this->payment_attachment($Membership_code,$file_name,$name);
			if (!empty($photo_name)) {
				$value['Statement'] = "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/'.$photo_name;
			}		

			$value['Date']=date('Y-m-d',strtotime($value['Date']));
			$value['Payment_status']=6;
			$this->db->where('Member_payment_ID',$value['Member_payment_ID']);
			$this->db->update('gc_member_payments',$value);
		}

		$mbr_dt['Status']=6;
		$mbr_dt['Payment_verify']=6;
		$this->db->where('Membership_ID',$Membership_ID)->update('gc_membership',$mbr_dt);

		$result=$this->Membership_model->Activate_member_contract($Membership_ID,$Contract_ID,$Commission_mode=1,$cmsn_per=0,$Memberhip_type=1,$Membership_payout=2);

		if(isset($_POST['normal_verify_payment'])){
			redirect('membership/Membership/contract?id='.$Membership_code);
		}else{
			redirect('membership/Membership/payment_members');
		}
    }

    // redirect('membership/Membership/contract?id='.$Membership_code);
    }
    

    public function payment_attachment($ref_no,$file_name,$name) {  

           if (!is_dir('./attachments/Members/'.$ref_no))
          {
              mkdir('./attachments/Members/'.$ref_no, 0777, true);
          }
          	$dir_exist = true; 
          if (!is_dir('./attachments/Members/'.$ref_no))
          {
              mkdir('./attachments/Members/'.$ref_no, 0777, true);
              $dir_exist = false; 
          }

         $config['upload_path']          = './attachments/Members/'.$ref_no.'/';
         $config['allowed_types']        = 'gif|jpg|png';
         $new_name                       = $ref_no.'_'.$name;
         $config['file_name']            = $new_name;

        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if ( ! $this->upload->do_upload($file_name))
        {
                $error = array('error' => $this->upload->display_errors());
                $file_name = '';
                 return $file_name;                 
        }
        else
        {   
                $data = array('upload_data' => $this->upload->data());
                $upload_data = $this->upload->data(); 
                $file_name =   $upload_data['file_name'];
                return $file_name;
        }

    }


}
