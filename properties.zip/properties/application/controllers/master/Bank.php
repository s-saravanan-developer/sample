<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Bank extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
    }

	public function index()
	{
    	$template['page']='master/bank/viewbank';
        $template['payout'] =  $this->Master_model->getall_bank();
        $this->load->view('template',$template);
	}

    public function add_bank()
    {
        extract($_POST);

        $data = array('Payment_mode' => $Payment_mode,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->insert('gc_payment_mode',$data);
        $this->session->set_flashdata('country_success', 'Added');
        redirect('master/bank');
    }


    public function edit_bank()
    {
        extract($_POST);

        $data = array('Payment_mode' => $Payment_mode,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->where('ID',$ID);
        $this->db->update('gc_payment_mode',$data);
        $this->session->set_flashdata('country_success', 'Updated');
        redirect('master/bank');
    }

    public function delete_bank($id)
    {

        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_payment_mode',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/bank');
    }

    public function bank()
    {
        $template['page']='master/bank/view_bank';
        $template['payout'] =  $this->Master_model->getall_banks();
        $this->load->view('template',$template);
    }

    public function addbank()
    {
        extract($_POST);

        $data = array('Bank_name' => $Bank_name,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->insert('gc_bank',$data);
        $this->session->set_flashdata('country_success', 'Added');
        redirect('master/bank/bank');
    }


    public function editbank()
    {
        extract($_POST);

        $data = array('Bank_name' => $Bank_name,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->where('ID',$ID);
        $this->db->update('gc_bank',$data);
        $this->session->set_flashdata('country_success', 'Updated');
        redirect('master/bank/bank');
    }

    public function deletebank($id)
    {
        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_bank',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/bank/bank');
    }

    public function payment_term()
    {
        $template['page']='master/bank/viewpaymentterm';
        $template['payout'] =  $this->Master_model->getall_paymentterm();
        $this->load->view('template',$template);
    }

    public function add_paymentterm()
    {
        extract($_POST);

        $data = array('Payment_term' => $Payment_term,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->insert('gc_payment_term',$data);
        $this->session->set_flashdata('country_success', 'Added');
        redirect('master/bank/payment_term');
    }

    public function edit_paymentterm()
    {
        extract($_POST);

        $data = array('Payment_term' => $Payment_term,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->where('ID',$ID);
        $this->db->update('gc_payment_term',$data);
        $this->session->set_flashdata('country_success', 'Updated');
        redirect('master/bank/payment_term');
    }

    public function delete_paymentterm($id)
    {

        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_payment_term',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/bank/payment_term');
    }

}
