                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                if(!window.__td){window.__MT=100;window.__ti=0;window.__td=[];window.__td.length=window.__MT;window.__noTrace=false;}



$.ns("vp.widget");














vp.widget.SelectableItems=function $vpfn_$HiXlqj3faUF4jNkOH7RCg20$28(
_oParentElement,
_fnCreateElement,
_options)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var me=this;






var options=
jQuery.extend({

selectOnMove:true,

percentCovered:0,

selectedClass:'selected',

disabledClass:'disabled',

selectables:"> :not(.disabled)",

draggingClass:'dragging',

itemsPerPage:8,

paginators:[],

clickToSelect:false,

dragToSelect:false,

notDraggables:false,

makeItemsDraggable:false,

draggableSelector:false,

previewSelector:false,

scope:"default"
},(_options||{}));





var _oParent=$(_oParentElement);





var _iCurrentPage=0;





var _aItems=[];





var _oCustomData={};




this.makeDraggable=function $vpfn_I1tRpw7U6gPxnhQomf0Vqw93$25(jElement,oItem)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var jDraggableElement=jElement.find(options.draggableSelector);
if(jDraggableElement.length===0)
{
jDraggableElement=jElement;
}

var jPreviewElement=jElement.find(options.previewSelector);
if(jPreviewElement.length===0)
{
jPreviewElement=jElement;
}

var oDraggableImage=new vp.studio.Draggable(jDraggableElement,{data:{oImage:oItem},scope:options.scope,distance:10});
oDraggableImage.setEnabled(!oItem.disabled);




jDraggableElement.mousedown(function $vpfn_QPPKnX$jkTtUMcOuqTwr8A113$36()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
if(oItem.disabled)
{
oDraggableImage.setEnabled(false);
return;
}

oDraggableImage.setEnabled(true);


var aImages=me.getSelectedItems();
if(!aImages.contains(oItem))
{
aImages.push(oItem);
}

var fnHelper=function $vpfn_ma0LAM1sEPTPohGV2GZX6w130$27(){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}return me.createDraggablePreviewElement(jPreviewElement,aImages).get(0);};

oDraggableImage.option("helper",fnHelper);
oDraggableImage.data("aImages",aImages);
for(var key in _oCustomData)
{
oDraggableImage.data(key,_oCustomData[key]);
}

});
};





this.createDraggablePreviewElement=function $vpfn_YAgIZK3W0aomG5Z5KPDcpg146$41(jPreview,aImages)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

var jImageTemplate=jPreview.clone();
var jImageElement=$("<div/>").append(jImageTemplate);
var jImageCount=$("<div/>").html(aImages.length);

var jDragElement=$("<div/>").attr("class","album-image-drag");
jDragElement.append(jImageElement);
jDragElement.append(jImageCount);
return jDragElement;
};




var buildPage=function $vpfn_TEI$kmN9LwxPFKLXeBuVWg162$20(iPageNumber,bForceRefresh)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

if(_iCurrentPage===iPageNumber&&!bForceRefresh)
{
return;
}


var iNumItems=_aItems.length;
var iNumPages=Math.ceil(iNumItems/options.itemsPerPage);


iPageNumber=Math.max(iPageNumber,1);
iPageNumber=Math.min(iPageNumber,iNumPages);


_iCurrentPage=iPageNumber;


var iFirstIndex=(_iCurrentPage-1)*options.itemsPerPage;
var iLastIndex=Math.min(iFirstIndex+options.itemsPerPage,iNumItems);
var aPageItems=iFirstIndex>iNumItems-1?[]:_aItems.slice(iFirstIndex,iLastIndex);


var oDragSelector=$(".jquery-drag-to-select",_oParent).detach();
_oParent.empty();
_oParent.prepend(oDragSelector);


for(var i=0;i<aPageItems.length;i++)
{
var oItem=aPageItems[i];


var jNewElement=$(_fnCreateElement(oItem));

jNewElement.data('item',oItem);

if(options.makeItemsDraggable)
{
me.makeDraggable(jNewElement,oItem);
}





if(oItem.disabled)
{
jNewElement.addClass(options.disabledClass);
}

else if(options.clickToSelect)
{
jNewElement.click(function $vpfn_QPPKnX$jkTtUMcOuqTwr8A217$34()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

if($(this).hasClass(options.disabledClass))
{
return;
}


if($(this).hasClass(options.selectedClass))
{
$(this).removeClass(options.selectedClass);
}
else
{
$(this).addClass(options.selectedClass);
}
});
}




var currWin;
try
{
currWin=vp.dialog.getCurrent();
}
catch(ex)
{
}

if(currWin)
{
jNewElement.click(function $vpfn_QPPKnX$jkTtUMcOuqTwr8A251$34()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
$(document).trigger("mouseup");
});
}


_oParent.append(jNewElement);
}


for(var j=0;j<options.paginators.length;j++)
{
var oPaginator=options.paginators[j];
oPaginator.selectedPageNumber=iPageNumber;
oPaginator.render();
}
};




this.getAllItems=function $vpfn_2WR9XomeCeKpvJchu8iKGQ273$23()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
return vp.core.filterListByProperties(_aItems,{});
};




this.getSelectedItems=function $vpfn_OkU245KWq0hfBiCsOdv_$w281$28()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var aItems=[];


_oParent.children().each(
function $vpfn_QPPKnX$jkTtUMcOuqTwr8A287$12(i)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var oItem=$(this).data('item');
if(!oItem)
{
return;
}

if($(this).hasClass(options.selectedClass))
{
aItems.push(oItem);
}
});
return aItems;
};

this.getItemsOnPage=function $vpfn_KhyeXE4IReUAG5AQCM9Y6Q303$26()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var iNumItems=_aItems.length;
var iNumPages=Math.ceil(iNumItems/options.itemsPerPage);

var iFirstIndex=(_iCurrentPage-1)*options.itemsPerPage;
var iLastIndex=Math.min(iFirstIndex+options.itemsPerPage,iNumItems);

return(iFirstIndex>iNumItems-1)?[]:_aItems.slice(iFirstIndex,iLastIndex);
};




this.updateItems=function $vpfn_Fziaw3ktKqoX1Jrw_8oZnA317$23(aItems,bPreservePage,oCustomData)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

_aItems=aItems;


_oCustomData=oCustomData||{};


var iNumItems=_aItems.length;
var iNumPages=Math.ceil(iNumItems/options.itemsPerPage);
for(var i=0,l=options.paginators.length;i<l;i++)
{
options.paginators[i].numberOfPages=iNumPages;
}


buildPage(bPreservePage?_iCurrentPage:1,true);
};





this.refreshItems=function $vpfn_v4uEG$I8on6NWZ2kpWhqgw341$24()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

_oParent.children().each(
function $vpfn_QPPKnX$jkTtUMcOuqTwr8A345$12(i)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var oItem=$(this).data('item');
if(!oItem)
{
return;
}


$(this).removeClass(options.selectedClass);


if(oItem.disabled)
{
$(this).addClass(options.disabledClass);
}
else
{
$(this).removeClass(options.disabledClass);
}




if(options.makeItemsDraggable)
{
var jDraggableElement=$(this).find(options.draggableSelector);
if(jDraggableElement.length===0)
{
jDraggableElement=$(this);
}
jDraggableElement.draggable(oItem.disabled?'disable':'enable');
}
});
};

var startDrag=function $vpfn_46atVM9nTs4xy4dFQjR6lw381$20(){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}_oParent.addClass(options.draggingClass);};
var stopDrag=function $vpfn_g3tlTQUcdRKDQ51HbL68Bw382$19(){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}_oParent.removeClass(options.draggingClass);};




var init=function $vpfn_aeE8uG7LDg1OnsRteMBNvQ387$15()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

for(var i=0,l=options.paginators.length;i<l;i++)
{

options.paginators[i]=new vp.widget.PaginatorOld(options.paginators[i],1,buildPage);
}


if(options.dragToSelect)
{

options.onShow=startDrag;
options.onHide=stopDrag;


_oParent.dragToSelect(options);
}
};


init();
};