<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Ewallet_model extends CI_Model { 

public function __construct() {
$this->load->model('Report_model');
}


   public function get_today_requests($date,$mobile) {

		$this->db->select('wallet.*,member.First_name,member.Last_name,user.firstname,user1.firstname as firstname1,member.Membership_code');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
	   	
		$this->db->where('wallet.Date',$date);
		$this->db->where('wallet.Status',1);
		if($this->session->userdata('UserTypeID')==1){
			$this->db->where('wallet.Wallet_amount_from',1);
		}elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',2);
			$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));

		}
		if(!empty($mobile)){
	   		$where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
		$this->db->where($where);
	   	}
		
		$query = $this->db->get();  
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}


public function get_wallet_details($mobile,$date,$sales_point,$payment_mode) {
	
		$this->db->select('wallet.*,member.First_name,member.Last_name,user.firstname,user1.firstname as firstname1,member.Membership_code');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
		$this->db->join('gc_wallet_payments as payment','payment.Service_point_ID = wallet.Wallet_topup_ID','left');
		// $this->db->join('gc_payment_mode as mode','mode.ID = payment.Payment_type_ID','left');
	   	if(!empty($date)){
	   		$this->db->where('wallet.Date',date('Y-m-d',strtotime($date)));
	   	}

	   	if(!empty($sales_point) && !empty($mobile)){
	   		$where = '(member.Membership_code="'.$mobile.'" or wallet.Service_point = "'.$sales_point.'")';
		$this->db->where($where);
	   	}elseif(!empty($sales_point) && empty($mobile)){
	   		$this->db->where('wallet.Service_point',$sales_point);
	   	}elseif(empty($sales_point) && !empty($mobile)){
	   		$where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
		$this->db->where($where);
	   	}

	   	if(!empty($payment_mode)){
	   		$payment_mode=explode(',', $payment_mode);
	   		$this->db->where_in('payment.Payment_type_ID',$payment_mode);
	   		$this->db->group_by('wallet.Wallet_topup_ID');

	   	}


		$this->db->where('wallet.Status',1);
		if($this->session->userdata('UserTypeID')==1){
			$this->db->where('wallet.Wallet_amount_from',1);
		}elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',2);
			$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));
			
		}


		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}




	

public function get_wallet_processed_details($mobile,$date,$sales_point) {

		$this->db->select('wallet.*,member.First_name,member.Last_name,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
	   	if(!empty($date)){
	   		$this->db->where('wallet.Processed_date',date('Y-m-d',strtotime($date)));
	   	}
		if(!empty($sales_point) && !empty($mobile)){
	   		$where = '(member.Membership_code="'.$mobile.'" or wallet.Service_point = "'.$sales_point.'")';
		$this->db->where($where);
	   	}elseif(!empty($sales_point) && empty($mobile)){
	   		$this->db->where('wallet.Service_point',$sales_point);
	   	}elseif(empty($sales_point) && !empty($mobile)){
	   		$where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
		$this->db->where($where);
	   	}
		$this->db->where('wallet.Status',2);
		if($this->session->userdata('UserTypeID')==1){
			$this->db->where('wallet.Wallet_amount_from',1);
		}elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',2);
			$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));
			
		}

		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}


public function get_pay_later_details($mobile,$date,$sales_point) {
		$status=['3','4'];
		$this->db->select('wallet.*,member.First_name,member.Last_name,member.Membership_code,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
	   	if(!empty($date)){
	   		$this->db->where('wallet.Processed_date',date('Y-m-d',strtotime($date)));
	   	}
		if(!empty($sales_point) && !empty($mobile)){
	   		$where = '(member.Membership_code="'.$mobile.'" or wallet.Service_point = "'.$sales_point.'")';
		$this->db->where($where);
	   	}elseif(!empty($sales_point) && empty($mobile)){
	   		$this->db->where('wallet.Service_point',$sales_point);
	   	}elseif(empty($sales_point) && !empty($mobile)){
	   		$where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
		$this->db->where($where);
	   	}
		$this->db->where_in('wallet.Status',$status);
		if($this->session->userdata('UserTypeID')==1){
			$this->db->where('wallet.Wallet_amount_from',1);
		}elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',2);
			$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));
			
		}

		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

	public function get_wallets_history_details($mobile,$date,$sales_point) {
		$this->db->select('wallet.*,member.First_name,member.Membership_code,member.Last_name,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
	   	if(!empty($date)){
	   		$this->db->where('wallet.Processed_date',date('Y-m-d',strtotime($date)));
	   	}
		if(!empty($sales_point) && !empty($mobile)){
	   		$where = '(member.Membership_code="'.$mobile.'" or wallet.Service_point = "'.$sales_point.'")';
		$this->db->where($where);
	   	}elseif(!empty($sales_point) && empty($mobile)){
	   		$this->db->where('wallet.Service_point',$sales_point);
	   	}elseif(empty($sales_point) && !empty($mobile)){
	   		$where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
		$this->db->where($where);
	   	}
		$this->db->where_in('wallet.Status',6);
		if($this->session->userdata('UserTypeID')==1){
			$this->db->where('wallet.Wallet_amount_from',1);
		}elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',2);
			$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));
			
		}

		
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}


	

   public function get_export_payouts($id,$payout_mode) {

		$this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
		$this->db->from('gc_member_commission_details as commission');
		
		$this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
		$this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
		$this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
		$this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
		//$this->db->where('commission.Commision_date',date('Y-m-d'));
		$this->db->where('commission.Status',1);
		if($payout_mode==1){
		$this->db->where_in('commission.Commision_detail_ID',$id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}else{return NULL;}
		}else{

			$sample_array=[];
			foreach($id as $value){
			$value=explode('@',$value);
			$membership_id=$value[0];
			$prev_date=$value[1];
			$end_date=$value[2]; 
			$payout_id=$value[3];
		$this->db->where('commission.Membership_ID',$membership_id);
		$this->db->where('commission.Commision_date >=',$prev_date);
		$this->db->where('commission.Commision_date <=',$end_date);
		$this->db->where('commission.Payout_ID',$payout_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			//var_dump($query->result_array());
			$temp0=$query->result_array();
			foreach($temp0 as $temp){

				array_push($sample_array,$temp);
			}

			
		}else{
		//array_push($sample_array,NULL);
		}
		}
		return $sample_array;
		}
		
		
		
	}

   public function get_export_payouts_ready($id) {

		 $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
		$this->db->from('gc_member_payouts as commission');
		
		$this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
		$this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
		$this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
		$this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
		//$this->db->where('commission.Commision_date',date('Y-m-d'));
		$this->db->where_in('commission.Commision_detail_ID',$id);
		// $this->db->where('commission.Status',1);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}


	   public function get_today_processed_requests() {

		$this->db->select('wallet.*,member.First_name,member.Last_name,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
	   	
		$this->db->where('wallet.Processed_date',date('Y-m-d'));
		$this->db->where('wallet.Status',2);
		if($this->session->userdata('UserTypeID')==1){
			$this->db->where('wallet.Wallet_amount_from',1);
		}elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',2);
			$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));
			
		}
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

	   public function get_today_pay_later() {
		$status=['3','4'];
		$this->db->select('wallet.*,member.First_name,member.Last_name,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
	   	
		$this->db->where('wallet.Processed_date',date('Y-m-d'));
		$this->db->where_in('wallet.Status',$status);
		if($this->session->userdata('UserTypeID')==1){
			$this->db->where('wallet.Wallet_amount_from',1);
		}elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',2);
			$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));
			
		}
		// $this->db->where('commission.Payout_status',4);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

public function get_today_pay_later1($date,$membership_ID,$topup_ID) {
		$status=['3','4'];
		$this->db->select('wallet.*,member.First_name,member.Last_name,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
	   	
		$this->db->where('wallet.Processed_date',$date);
		$this->db->where('wallet.Membership_ID',$membership_ID);
		$this->db->where('wallet.Wallet_topup_ID',$topup_ID);
		$this->db->where_in('wallet.Status',$status);
		if($this->session->userdata('UserTypeID')==1){
			$this->db->where('wallet.Wallet_amount_from',1);
		}elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',2);
			$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));
			
		}
		// $this->db->where('commission.Payout_status',4);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			// var_dump($query->result_array());die();
			return  $query->result_array();
		}
		return NULL;
	}

	   public function get_today_wallet_history() {

		$this->db->select('wallet.*,member.First_name,member.Last_name,member.Membership_code,user.firstname,user1.firstname as firstname1');
		$this->db->from('gc_wallet_topup as wallet');
		$this->db->join('gc_membership as member','member.Membership_ID = wallet.Membership_ID','left');
		$this->db->join('gc_users as user','user.id = wallet.Service_point','left');
		$this->db->join('gc_users as user1','user1.id = wallet.Wallet_service_point','left');
	   	
		$this->db->where('wallet.Processed_date',date('Y-m-d'));
		$this->db->where('wallet.Status',6);
		if($this->session->userdata('UserTypeID')==1){
			$this->db->where('wallet.Wallet_amount_from',1);
		}elseif($this->session->userdata('UserTypeID')==6){
			$this->db->where('wallet.Wallet_amount_from',2);
			$this->db->where('wallet.Wallet_service_point',$this->session->userdata('UserId'));
			
		}
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}
	
	



public function process_payout($id){
		$data_status['Status']=2;
		$data_status['Processed_date']=date('Y-m-d');
			$this->db->where('Wallet_topup_ID',$id);
			$this->db->update('gc_wallet_topup',$data_status);
	}

public function cancel_payout($id,$date,$payout_mode){
		$data_status['Status']=4;
		$data_status['Processed_date']=date('Y-m-d');
			$this->db->where('Wallet_topup_ID',$id);
			$this->db->update('gc_wallet_topup',$data_status);
}    

public function payout_later($id,$date){
		$data_status['Status']=3;
		$data_status['Processed_date']=date('Y-m-d');
			$this->db->where('Wallet_topup_ID',$id);
			$this->db->update('gc_wallet_topup',$data_status);
}


	public function get_pay_mode($id){
		$this->db->select('mode.Payment_mode');
		$this->db->from('gc_wallet_payments as payment');
		$this->db->join('gc_payment_mode as mode','mode.ID=payment.Payment_type_ID','left');
		$this->db->where('payment.Service_point_ID',$id);
		$query = $this->db->get();
		$py_mode=[];
		if ($query->num_rows() > 0) {
			$data=$query->result_array();
			foreach ($data as $key => $value) {
				array_push($py_mode,$value['Payment_mode']);
			}
			return implode(',',$py_mode);
			//return  $query->result_array();
		}
		return NULL;
	}

public function get_investtype($membership_ID){
	$count=$this->db->where('Membership_ID',$membership_ID)->count_all_results('gc_member_franchisee_contract');
}
public function mark_as_paid($id){

		
				$query = $this->db->get_where('gc_wallet_topup', array('Wallet_topup_ID' => $id))->result_array();
				// var_dump($query);
				if(!empty($query)){	

				if($query[0]['Wallet_amount_from']==2){
						$query2 = $this->db->get_where('gc_service_wallet', array('Service_point_ID' => $query[0]['Wallet_service_point']))->result_array();
					if(count($query2)>0){
						if($query2[0]['Wallet_balance']>=$query[0]['Total_amount']){
							$wallet_data=array(
									  'Wallet_balance'=>$query2[0]['Wallet_balance']-$query[0]['Total_amount'],
									  'Updated_date'=>date('Y-m-d'));
							$this->db->where('Service_point_ID',$query[0]['Wallet_service_point']);
							$this->db->update('gc_service_wallet',$wallet_data);

							$query3 = $this->db->get_where('gc_users', array('id' => $query[0]['Wallet_service_point']))->result_array();
						$user_data=array('Wallet_balance'=>$query3[0]['Wallet_balance']-$query[0]['Total_amount']);
						$this->db->where('id',$query[0]['Wallet_service_point']);
						$this->db->update('gc_users',$user_data);

						$query1 = $this->db->get_where('gc_membership', array('Membership_ID' => $query[0]['Membership_ID']))->result_array();
							$member_data['Wallet_balance']=$query1[0]['Wallet_balance']+$query[0]['Total_amount'];
							$this->db->where('Membership_ID',$query[0]['Membership_ID']);
							$this->db->update('gc_membership',$member_data);

							

						$data_status['Status']=6;
						$data_status['Processed_date']=date('Y-m-d');
						$this->db->where('Wallet_topup_ID',$id);
						$this->db->update('gc_wallet_topup',$data_status);

						}
							
						}
					}else{
						if($query[0]['Topup_for']==1){

							// $query1 = $this->db->get_where('gc_membership', array('Membership_ID' => $query[0]['Membership_ID']))->result_array();
							// $member_data['Wallet_balance']=$query1[0]['Wallet_balance']+$query[0]['Total_amount'];
							// $this->db->where('Membership_ID',$query[0]['Membership_ID']);
							// $this->db->update('gc_membership',$member_data);
							$payment_data['Payment_status']=6;
							$this->db->where('Service_point_ID',$query[0]['Wallet_topup_ID']);
							$this->db->update('gc_wallet_payments',$payment_data);


							$reg_date=date('Y-m-d',strtotime($query[0]['Date']));
							// $payment_mode=$payment_data[0]['Payment_type_ID'];
							$payment_mode=$this->db->get_where('gc_wallet_payments',array('Service_point_ID' => $query[0]['Wallet_topup_ID']))->result_array()[0]['Payment_type_ID'];

							$Wallet_topup_ID=$query[0]['Wallet_topup_ID'];

							$data_status['Status']=6;
							$data_status['Processed_date']=date('Y-m-d');
							$this->db->where('Wallet_topup_ID',$id);
							$this->db->update('gc_wallet_topup',$data_status);

							$tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();

            			$payout_id=2;
            			if(!empty($tp)){
            				$cmsn_percentage=$tp[0]['Return'];
            				$month=$tp[0]['Validity'];
            			}else{
            				$cmsn_percentage=20;
            				$month=10;
            			}

            			$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();
       					 
       					 if(!empty($py_qry)){
       					     $pay_flag=$py_qry[0]['Pay_flag'];
       					     $py_days=$py_qry[0]['Days']-1;
       					 }else{
       					     $pay_flag=2;
       					     $py_days=15-1;
       					 }
       					 


       					$cmsn_per=$cmsn_percentage/$pay_flag;
            			$membership_ID=$query[0]['Membership_ID'];
            			
            			// $increment_code1 = $this->db->count_all_results('gc_member_franchisee_contract')+1;
            			// $contract_data['Contract_ref_no']   ="GRNC-CNT-0000".$increment_code1;
            			$increment_code1=(substr($this->db->select('Contract_ref_no')->order_by('Contract_ID','desc')->limit(1)->get('gc_member_franchisee_contract')->row('Contract_ref_no'),9))+1;
						$contract_data['Contract_ref_no'] ='GRNC-CNT-'.sprintf("%'.06d", $increment_code1);
						
            			$contract_data['Company_id']        = $this->session->userdata('CompanyId');
            			$contract_data['Branch_id']         = $this->session->userdata('CompanyId');
            			$contract_data['Payout_ID']         = $payout_id;
            			$count=$this->db->where('Membership_ID',$membership_ID)->count_all_results('			gc_member_franchisee_contract');
            			if ($count > 0) {
            			   $contract_data['Invest_type']                      = 2;
            			   $contract_data['Pay_status']      				  = 5;
            			}else{
            			    $contract_data['Invest_type']                     = 1;
            			    $contract_data['Pay_status']      				  = 6;

            			    // Memberhsip Update end
        				$mbr_data['Status']=6;
        				$mbr_data['Commission_mode']=1;
        				$mbr_data['Final_commission_per']=$cmsn_per;
        				$mbr_data['Payout_ID']=$payout_id;
     					$mbr_data['Commission_per']=0;  
     					$mbr_data['Payment_verify']=6;  
     					$mbr_data['Activated_date']=date('Y-m-d',strtotime($reg_date));
        				$mbr_data['End_date']=date('Y-m-d', strtotime($reg_date. ' + '.$month.' months'));
     					 
 						$this->db->where('Membership_ID',$membership_ID);
     					$this->db->update('gc_membership',$mbr_data);

     						date_default_timezone_set('Asia/Kolkata');
							$remark='-[Payment_verify_activation2@'.date('Y-m-d H:i:s').']';
							$this->db->where('Membership_ID',$membership_ID);
							$this->db->set('Update_history', "CONCAT(Update_history,'$remark')", FALSE);   
							$this->db->update('gc_membership');

            			}
            			
            			$contract_data['Topup_id']               = 1;
            			$contract_data['Membership_type']        = 1;
            			$contract_data['Membership_ID']          = $membership_ID;
            			$contract_data['Final_commission_per']   = $cmsn_per;
            			$contract_data['Amount']                 = $query[0]['Total_amount'];
            			$contract_data['Payment_mode']           = $payment_mode;
            			$contract_data['Date']                   = date('Y-m-d',strtotime($reg_date));
            			$contract_data['Payment_status_date']    = date('Y-m-d',strtotime($reg_date));
            			$contract_data['Payment_status']         = 6;
            			$contract_data['Aggreement_mode']   	 = 1;
            			$contract_data['Surety_mode']       	 = 1;
            			$contract_data['Created_date']      	 = date('Y-m-d');
            			//var_dump($contract_data);
            			if($this->db->insert('gc_member_franchisee_contract', $contract_data)){
            			    $Contract_ID=$this->db->insert_id();
            			}

            			

            			$activate=$this->topup_activate($membership_ID,$Contract_ID,$Commission_mode=1,$cmsn_per,$Memberhip_type=1,$payout_id,$contract_data['Amount'],$reg_date,$contract_data['Invest_type']);	
					}else{
						$query2 = $this->db->get_where('gc_service_wallet', array('Service_point_ID' => $query[0]['Service_point']))->result_array();
   			// if($query[0]['Total_amount']>=5000){
   			// if($query[0]['Total_amount']>=5000 && $query[0]['Total_amount']<=5999){
      //                   $bin_com=5;
      //               }elseif($query[0]['Total_amount']>=6000 && $query[0]['Total_amount']<=6999){
      //                   $bin_com=7;
      //               }else{
      //                   $bin_com=10;
      //               }
      //               $final_Commission=$query[0]['Total_amount']+($query[0]['Total_amount'] * $bin_com) / 100;
      //           }else{
                	$final_Commission=$query[0]['Total_amount'];
                // }

                  
						if(count($query2)>0){
							$wallet_data=array(
									  'Wallet_balance'=>$query2[0]['Wallet_balance']+$final_Commission,
									'Updated_date'=>date('Y-m-d'));
							$this->db->where('Service_point_ID',$query[0]['Service_point']);
							$this->db->update('gc_service_wallet',$wallet_data);
						}else{
							$wallet_data=array(
									  'Company_id'=>$query[0]['Company_id'],
									  'Branch_id'=>$query[0]['Company_id'],
									  'Service_point_ID'=>$query[0]['Service_point'],
									  'Wallet_balance'=>$final_Commission);

							$this->db->insert('gc_service_wallet',$wallet_data);
						}
						$query3 = $this->db->get_where('gc_users', array('id' => $query[0]['Service_point']))->result_array();
						$user_data=array('Wallet_balance'=>$query3[0]['Wallet_balance']+$final_Commission);
						$this->db->where('id',$query[0]['Service_point']);
						$this->db->update('gc_users',$user_data);

						$data_status['Status']=6;
						$data_status['Processed_date']=date('Y-m-d');
						$this->db->where('Wallet_topup_ID',$id);
						$this->db->update('gc_wallet_topup',$data_status);

					}
					}
					

					


				}
			

}


public function topup_activate($Membership_ID,$Contract_ID,$Commission_mode,$cmsn_per,$Memberhip_type,$Membership_payout,$contract_amount,$reg_date,$invest_Type){

	$up_data['Membership_type']=$Memberhip_type;
	$this->db->where('Membership_ID',$Membership_ID);
	$this->db->update('gc_membership',$up_data);

	

	// $this->db->select('topup.Validity,topup.Value,topup.Return,contract.Multiples,contract.Amount');
 //        $this->db->from('gc_member_topup as topup');
        

 //        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');
 //        // $this->db->join('gc_membership as member', 'member.Payout_ID = topup.ID', 'left');

 //        $this->db->where('contract.Contract_ID',$Contract_ID);
 //        $this->db->where('contract.Membership_ID',$Membership_ID);
 //        $query = $this->db->get();
 //        $contract=$query->result_array();

        $tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();
        $contract=$this->db->get_where('gc_member_franchisee_contract',array('Contract_ID' => $Contract_ID,'Membership_ID' => $Membership_ID))->result_array();
// var_dump($contract);die();
        if(!empty($tp)){
            $month=$tp[0]['Validity'];
            // $Amount=$contract[0]['Value']*$contract[0]['Multiples'];
            
            // $Return=$tp[0]['Return'];
            // $pay_flag=$contract[0]['Pay_flag'];

            // if($contract[0]['Payout_status']==2){
            //     $payout_id=$contract[0]['New_payout_ID'];
            // }else{
            //     $payout_id=$contract[0]['Old_payout_ID'];
            // }
        }else{
            $month=0;
            
            // $Return=0;
            // $pay_flag=1;
        }

        // if(!empty($contract)){
        // 	$Amount=$contract[0]['Amount'];
        // }else{
        // 	$Amount=0;
        // }

        $Return=$cmsn_per;
        $Amount=$contract_amount;
        $new_pay=$Return;
        // $mem_qry = $this->db->select('Membership_ID,Payout_ID,Membership_type')->get_where('gc_membership', array('Membership_ID' => $Membership_ID))->result_array();
        // if(!empty($mem_qry[0]['Payout_ID'])){
        //     $payout_id=$mem_qry[0]['Payout_ID'];
        // }else{
            $payout_id=$Membership_payout;
        //}

        $py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();
        if(!empty($py_qry)){
            $pay_flag=$py_qry[0]['Pay_flag'];
            $py_days=$py_qry[0]['Days']-1;
        }else{
            $pay_flag=2;
            $py_days=15-1;
        }

        // if($Commission_mode==2){
        //     $new_pay=$Return+($cmsn_per/$pay_flag);
        // }else{
        //     $new_pay=$Return;
        // }

        // $new_pay=$cmsn_per/$pay_flag;
// Memberhsip Update end
        $data['Status']=6;
        $data['Commission_mode']=$Commission_mode;
        $data['Final_commission_per']=$new_pay;
        $data['Payout_ID']=$payout_id;
        
      //   if($Commission_mode==2){
      //     $data['Commission_per']=$cmsn_per;  
      // }else{
      //       $data['Commission_per']=0;
      // }
      // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
      $Pay_date=date('Y-m-d', strtotime($reg_date. ' + '.$py_days.' days'));
      $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
      $lvl_py_days=15-1;
      // $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$lvl_py_days.' days')));
      $Lvl_pay_date=date('Y-m-d', strtotime($reg_date. ' + '.$lvl_py_days.' days'));
      $data['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));

      $next_exact_payout=$this->get_excat_next_payout($Pay_date);
      // if($pay_flag==1){
      //   $py_days=30;
      //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
      //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
      // }else{
      //   $py_days=15;
      //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
      //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
      // }
        
      // var_dump($data);die();
        // $data['Activated_date']=date('Y-m-d H:i:s');
        // $this->db->where('Membership_ID',$Membership_ID);
        // $this->db->update('gc_membership',$data);


// Membership Update end 
// Transaction Insert Start        
        $transaction=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $Membership_ID, 
                            'Contract_ID' => $Contract_ID, 
                            'Transaction_type' => 1,
                            'Transaction_date' => date('Y-m-d',strtotime($reg_date)), 
                            'Remarks' => '', 
                            'Created_by' => $this->session->userdata('UserId') 
                        );
        $this->db->insert('gc_transaction',$transaction);
        $transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
        $Comission_amount=$Amount*$new_pay/100;
        $transaction_detail=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $Membership_ID, 
                            'Contract_ID' => $Contract_ID,
                            'Member_level_detail_ID' => NULL, 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 1, 
                            'Payout_ID' => $payout_id,
                            'Amount' => $Comission_amount, 
                            'Commision' => $new_pay,
                            'New_pay_percent' => $new_pay,
                            'Remarks' => '' 
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail);
// Transaction Detail (Top-up) Insert End   

// Transaction History (Debit) Insert start 
		$history_data=array(
                 			'Company_id'               => $this->session->userdata('CompanyId'),
                 			'Branch_id'                => $this->session->userdata('CompanyId'), 
                 			'Membership_ID' => $Membership_ID,
                 			'Contract_ID'   => $Contract_ID,
                 			'Payout_ID' => $payout_id,
                 			'Date'  => date('Y-m-d',strtotime($reg_date)), 
                 			'History_for'   => ' Topup Amount of  '.$Amount,
                 			'Credit_amount' => 0,
                 			'Debit_amount' => $Amount,
                 			 );
        $this->db->insert('gc_transaction_history',$history_data);  

// Transaction History (Debit) Insert End  

// Transaction Details (Direct&Push-up) Insert Start
        $this->db->select('Reference_ID');
        $this->db->from('gc_membership');
        $this->db->where('Membership_ID',$Membership_ID);
        $query = $this->db->get();
        $membership=$query->result_array();

if($Commission_mode==1){ // Level Commission OR Self Commission is Start
    $ref_ID="";$level_insert_id="";
        for($i=1;$i<=9;$i++){ 
            if($i==1){
            $this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$membership[0]['Reference_ID']);
            $this->db->where('member.Commission_mode',1);
            $this->db->where('member.Membership_type',1);
            $this->db->where('contract.Contract_ID IS NOT NULL');
            //$this->db->where('contract.Contract_status',6);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            if($binary[0]['Commission_mode']==1){
            $crnt_lvl=$binary[0]['Current_level'];
            //if($crnt_lvl<=$i){
            $level['Level_ID']=$i;
            //}
            //else{
               //$level['Level_ID']=$crnt_lvl;
            //}
            $ref_ID=$binary[0]['Reference_ID'];

            $this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
            $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
            //$this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();
            if(!empty($level_details)){

            $Comission_amount1=$Amount*$level_details[0]['Return']/100;
            $this->db->select('Payout_type');
            $this->db->from('gc_level');
            $this->db->where('ID',$level['Level_ID']);
            $query_lvl= $this->db->get();
            if($query_lvl->num_rows() > 0) {
            $level_payout=$query_lvl->result_array();
            $payout_id1=$level_payout[0]['Payout_type'];
            }else{
                if($level_details[0]['Payout_status']==2){
                $payout_id1=$level_details[0]['New_payout_ID'];
                }else{
                $payout_id1=$level_details[0]['Old_payout_ID'];
                        }
                    }
// Transaction Details Insert start 
$transaction_detail1=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $binary[0]['Membership_ID'], 
                            'Contract_ID' => $binary[0]['Contract_ID'],
                            'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 2,
                            'Payout_ID' => $payout_id1, 
                            'Amount' => $Comission_amount1, 
                            'Commision' => $level_details[0]['Return'],
                            'Remarks' => '' 
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
        		}
            }
        }
    }
    else{
            $this->db->select('*');
            $this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$ref_ID);
            $this->db->where('member.Commission_mode',1);
            $this->db->where('member.Membership_type',1);
            $this->db->where('contract.Contract_ID IS NOT NULL');
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            if($binary[0]['Commission_mode']==1){

            $crnt_lvl=$binary[0]['Current_level'];
            $level['Level_ID']=$i;
           //  if($crnt_lvl<=$i){
            
           //  }
           //  else{
           //     $level['Level_ID']=$crnt_lvl;
           // }
            $ref_ID=$binary[0]['Reference_ID'];

            $this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount,contract.Payout_ID');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
            $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
            //$this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();
            if(!empty($level_details)){
                        $Comission_amount1=$level_details[0]['Value']*$level_details[0]['Return']/100;
            $this->db->select('Payout_type');
            $this->db->from('gc_level');
            $this->db->where('ID',$level['Level_ID']);
            $query_lvl= $this->db->get();
            if($query_lvl->num_rows() > 0) {
            $level_payout=$query_lvl->result_array();
            $payout_id1=$level_payout[0]['Payout_type'];
            }else{
                        if($level_details[0]['Payout_status']==2){
                        $payout_id1=$level_details[0]['New_payout_ID'];
                        }else{
                        $payout_id1=$level_details[0]['Old_payout_ID'];
                        $payout_id1=$level_payout[0]['Payout_type'];
                        }
                    }
// Transaction Details Insert start 
$transaction_detail1=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $binary[0]['Membership_ID'], 
                            'Contract_ID' => $binary[0]['Contract_ID'],
                            'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 3,
                            'Payout_ID' => $payout_id1, 
                            'Amount' => $Comission_amount1, 
                            'Commision' => $level_details[0]['Return'],
                            'Remarks' => ''  
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
// Transaction Details (Direct&Push-up) Insert End    
						}    
                    }
                }

            }
        }
} // Level Commission OR Self Commission is End
        // $user_data = array('status' => 1 );
        // $this->db->where('user_id',$Membership_ID);
        // $this->db->update('gc_users',$user_data);

        $data1['Start_date']=date('Y-m-d',strtotime($reg_date));

        // $data1['End_date']=date('Y-m-d', strtotime('+'.$month.'months'));
        $data1['End_date']=date('Y-m-d', strtotime($reg_date. ' + '.$month.' months'));
        $data1['Contract_status']=6;
        $data1['Commission_mode']=$Commission_mode;
        $data1['Final_commission_per']=$new_pay;
        $data1['Pay_date']=$Pay_date;
        $data1['Lvl_pay_date']=$Lvl_pay_date;
        $data1['Created_date']=date('Y-m-d');

        if($invest_Type==2){
			$cur_pay_dt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->result_array();
			// var_dump($cur_pay_dt);die();
			// if(!empty($cur_pay_dt)){
			// 	$re_date=$cur_pay_dt[0]['Payout_date'];
			// 	if($re_date <= $data1['Start_date']){
			// 			$mth=date('m',strtotime($Pay_date));
			// 			$re_date1=explode('-',$re_date);
			// 			$re_date2=$this->get_excat_next_payout(date('Y-m-d',strtotime($re_date1[0].'-'.$mth.'-'.$re_date1[2])));
			// 		if($re_date2<=$Pay_date){
			// 			$data1['Payout_date']=$re_date2;
			// 		}else{
			// 			$py_days=14;
			// 			$cur_payout=date('Y-m-d', strtotime($re_date2. ' - '.$py_days.' days'));
			// 			$data1['Payout_date']=$this->get_excat_next_payout1($cur_payout);
			// 		}
					
			// 	}else{
			// 		if($re_date<=$Pay_date){
			// 			$data1['Payout_date']=$re_date;
			// 		}else{
			// 			$py_days=14;
			// 			$cur_payout=date('Y-m-d', strtotime($re_date. ' - '.$py_days.' days'));
			// 			$data1['Payout_date']=$this->get_excat_next_payout1($cur_payout);
			// 		}
			// 	}
			// }else{
			// 	$data1['Payout_date']=$next_exact_payout;
			// 	$data1['Invest_type']=1;
			// }

			
			$data_payout_date=$this->Report_model->get_curent_payout_date($Membership_ID,$data1['Pay_date']);
			$py_days=14;
			$data_payout_date=date('Y-m-d', strtotime($data_payout_date. ' - '.$py_days.' days'));

			$data1['Payout_date']=$this->get_excat_next_payout1($data_payout_date);

		}else{
			$data1['Payout_date']=$next_exact_payout;
		}

		$star['Payout_date']=$data1['Payout_date'];

		$this->db->where('Membership_ID',$Membership_ID)->update('gc_green_star',$star);
      //   if($Commission_mode==2){
      //     $data1['Commission_per']=$cmsn_per;  
      // }else{
      //       $data1['Commission_per']=0;
      // }
        $data1['Contract_status_date']=date('Y-m-d',strtotime($reg_date));
        $data1['Created_by']=$this->session->userdata('UserId');
        // var_dump($data1);die();
        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->where('Contract_ID',$Contract_ID);
        $this->db->update('gc_member_franchisee_contract',$data1);
        

}

public function get_excat_next_payout($cl_dt){
	//$cl_dt='2019-05-08';
	$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
                	if(!empty($com_pay_date)){
                		$commission_pay_date=$com_pay_date[0]['Pay_dates'];
                	}else{
                		$commission_pay_date='7,14,21,28';
                	}
                	$commission_pay_date=explode(',',$commission_pay_date);

                      	//$cl_dt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $tran['Membership_ID'],'Contract_ID' => $tran['Contract_ID']))->row()->Pay_date;
					$per_date=date('d',strtotime($cl_dt));
                      	$temp_date=date('Y-m',strtotime($cl_dt));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							// return $payout_date=$this->fet_exact_payout_date($final_payout_date);
							return $payout_date=date('Y-m-d',strtotime($final_payout_date));
}

public function get_excat_next_payout1($cl_dt){
    // $cl_dt='2019-05-08';
    $com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
    if(!empty($com_pay_date)){
        $commission_pay_date=$com_pay_date[0]['Pay_dates'];
    }else{
        $commission_pay_date='7,14,21,28';
    }
    $commission_pay_date=explode(',',$commission_pay_date);


        $per_date=date('d',strtotime($cl_dt));
        $temp_date=date('Y-m',strtotime($cl_dt));

            foreach($commission_pay_date as $key => $val){
                if($per_date < $val){
                if($key != 0){
                    $exct_day= $commission_pay_date[$key-1];
                    break;
                }elseif($per_date==7){
                    $exct_day=$val;
                    break;
                }else{
                    $exct_day=$commission_pay_date[3];
                    break;
                }
            }

                if($per_date == 28){
                    $exct_day=28;
                    break;
                }elseif($per_date >= 28){
                    $exct_day=28;
                    break;
                }
            }

            if($per_date>=$exct_day){

                    $final_payout_date=date($temp_date.'-'.$exct_day);

                }else{

                    $samp_dy=date($temp_date.'-'.$exct_day);
                    $final_payout_date=date('Y-m-d', strtotime($samp_dy. ' -1 months'));
                    
                }

            return $payout_date=date('Y-m-d',strtotime($final_payout_date));
}

public function fet_exact_payout_date($final_payout_date)
{
	$Cal_date=date('Y-m-d',strtotime($final_payout_date));
$final_dates=[];
$yrl_dates_0=[];
		$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
		    $days=$query->result_array();
		    $week_days=explode(',',$days[0]['Weeks']);
		    $final_days=[];
		    $final_days1=[];


		$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
		

		        $this->db->select('Date');
		        $query = $this->db->get('gc_individual_calendar');
		        if ($query->num_rows() > 0) {
		            $db_leave=$query->result_array();
		        }else{
		            $db_leave=[];
		        }

		        $empt_leave=[];
		        foreach($db_leave as $lv){
		            array_push($empt_leave,$lv['Date']);

		        }
		        $final_dates=array_values(array_diff($final_dates,$empt_leave));
		    if(in_array($Cal_date, $final_dates)){

		    	return $Cal_date;
		    }else{
		    	return $this->get_next_pay_date($Cal_date);
		    }
		}
}




public function get_next_pay_date($cur_date){
$final_dates=[];
$yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

         $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));

    foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
    
    $keyval= $key;
    if(isset($final_dates[$keyval])){
        return $final_dates[$keyval];
    }
    
    break;
}else{
    $keyval=$key;
    $final_dates[$keyval];
}
    }
}

    }

	public function get_previous_date($cur_date){

	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);
			//var_dump($week_days);
$date=new DateTime();
$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

	if($week_days[$i] == $search){
		$arr[$i] = $week_days[$i];
		$search = $week_days[$i] + 1;
	}else{
		$arr2[$i] = $week_days[$i];
	}
}

$action = array_merge($arr,$arr2);
$days = array(
	 '1' => 'Monday',
	 '2' => 'Tuesday',
	 '3' => 'Wednesday',
	 '4' => 'Thursday',
	 '5' => 'Friday',
	 '6' => 'Saturday',
	 '7' => 'Sunday'
 );
$final_dt=[];

foreach($action as $da){
if (array_key_exists($da,$days))
  {
  array_push($final_dt,$days[$da]);
  }

}

//var_dump($final_dt);
$final_dates=[];
for($i=1; $i<=52; $i++){
		foreach($final_dt as $newval){
		//date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
		array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
		}
	}
   $cur_date=date("Y-m-d", strtotime($cur_date));
	
	//var_dump($final_dates);
	foreach($final_dates as $key=> $fin){
if($cur_date==$fin){
	$keyval= $key-1;
	return  $final_dates[$keyval];
}else{
	$keyval=$key;
	$final_dates[$keyval];
}
	}
	//echo $serch_date=$final_dates[$keyval];
}

	}

public function get_previous_date1($cur_date){
$final_dates=[];
$yrl_dates_0=[];
	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);

			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
	
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

				$this->db->select('Date');
				$query = $this->db->get('gc_individual_calendar');
				if ($query->num_rows() > 0) {
					$db_leave=$query->result_array();
				}else{
					$db_leave=[];
				}
				$empt_leave=[];
				foreach($db_leave as $lv){
					array_push($empt_leave,$lv['Date']);    

				}
				
				//print_r($db_leave);die();
				$final_dates=array_values(array_diff($final_dates,$empt_leave));

	foreach($final_dates as $key=> $fin){
if($cur_date==$fin){

	
	if($key>=1){
	$keyval= $key-1;
	return  $final_dates[$keyval];
}else{
	//$keyval= date("Y",strtotime("-1 year")).'-12-31';
	return  date("Y",strtotime("-2 year")).'-12-31';
}
	

}else{
	$keyval=$key;
	$final_dates[$keyval];
}
	}
}

	}

public function get_advance_date1($cur_date){
$final_dates=[];
$yrl_dates_0=[];
	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);

			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
	
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

		$this->db->select('Date');
				$query = $this->db->get('gc_individual_calendar');
				if ($query->num_rows() > 0) {
					$db_leave=$query->result_array();
				}else{
					$db_leave=[];
				}
				$empt_leave=[];
				foreach($db_leave as $lv){
					array_push($empt_leave,$lv['Date']);

				}
				
				//print_r($db_leave);die();
				$final_dates=array_values(array_diff($final_dates,$empt_leave));

	foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
	
	$keyval= $key;
	if(isset($final_dates[$keyval])){
		return $final_dates[$keyval];
	}else{
		return date('Y-01-01');
	}
	
	break;
}else{
	$keyval=$key;
	return $final_dates[$keyval];
}
	}
}

	}

	public function get_three_yrs_holidays($year,$week_days){

//$week_days=['6','7'];
			//var_dump($week_days);
$date=new DateTime();
//$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

	if($week_days[$i] == $search){
		$arr[$i] = $week_days[$i];
		$search = $week_days[$i] + 1;
	}else{
		$arr2[$i] = $week_days[$i];
	}
}

$action = array_merge($arr,$arr2);
$days = array(
	 '1' => 'Monday',
	 '2' => 'Tuesday',
	 '3' => 'Wednesday',
	 '4' => 'Thursday',
	 '5' => 'Friday',
	 '6' => 'Saturday',
	 '7' => 'Sunday'
 );
$final_dt=[];
//var_dump($action);
foreach($action as $da){
if (array_key_exists($da,$days))
  {
	//$sim=array('N' => $days[$da], 'A' => $da);
  array_push($final_dt,$days[$da]);
  }

}
//var_dump($final_dt);

$final_dates=[];
for($i=1; $i<=52; $i++){
		foreach($final_dt as $newval){
		//date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
		array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
		}
	}
	return $final_dates;
}


}



