<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Lease extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
    }

	public function index()
	{
    	$template['page']='master/lease_types/viewlease_types';
      $template['lease_types'] =  $this->Master_model->getall_lease_types();
      // $template['weeks']  =  $this->Master_model->get_weeks();
      $this->load->view('template',$template);
	}


    public function add()
    {
        extract($_POST);

        
        $lease_data = $this->input->post('lease_type');
        $lease_data['created_by']=$this->session->userdata('id');
        $lease_data['company_id']=$this->session->userdata('company_id');
        $this->db->insert('prop_lease_types',$lease_data);
        $this->session->set_flashdata('country_success', 'Added');
        redirect('master/Lease');
    }


    public function edit()
    {
        
        $id=decrypt($this->input->post('lease_type_id'));
        $lease_data = $this->input->post('lease_type');
        $lease_data['updated_by']=$this->session->userdata('id');
        
        
        $this->db->where('lease_type_id',$id);
        $this->db->update('prop_lease_types',$lease_data);
        $this->session->set_flashdata('country_success', 'Updated');
        redirect('master/Lease');
    }


    public function delete($id)
    {
        $id=decrypt($this->input->post('delete_id'));
        $data = array('Status' => 3);
        
        $this->db->where('lease_type_id',$id);
        $this->db->update('prop_lease_types',$data);

        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Lease');
    }

        public function checkbox_action(){
                 $id = ( explode( ',', $this->input->get_post('id') ));             
                 $status = $this->input->get_post('status');             
                 foreach ($id as  $value) {
                                  // $this->Users_model->delete_checkbox($value);
                                  $data['updated_date'] = date('Y-m-d H:i:s');
                                  $data['status']         = $status;    
                              // var_dump($data);die();
                                  $this->db->where('lease_type_id', $value);

                        if ($this->db->update('prop_lease_types', $data)) {
                            $this->session->set_flashdata('user_success', 'Deleted');
                            return TRUE;
                  }
                 }
        }



}
