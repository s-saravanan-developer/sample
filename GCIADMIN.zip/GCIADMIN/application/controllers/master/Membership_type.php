<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Membershiptype extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
        // Load form helper
        $this->load->helper('form');
        // Load encryption library
        $this->load->library('encrypt');
        
    }

	public function Membershiptype()
	{
    	$template['page']='master/membershiptype/viewmembershiptype';
        $template['type'] =  $this->Master_model->getall_membershiptype();
        $this->load->view('template',$template);
	}

    public function add_payout()
    {
        extract($_POST);

        $data = array('payout_type' => $payout_type,
                      'alias_name' => $alias_name,
                      'Description' => $Description,
                      'status' => $status
                     );
        $this->db->insert('gc_payout_type',$data);
        $this->session->set_flashdata('payout_success', 'Added');
        redirect('master/Payout');
    }

    public function edit_payout()
    {
        extract($_POST);

        $data = array('payout_type' => $payout_type,
                      'alias_name' => $alias_name,
                      'Description' => $Description,
                      'status' => $status
                     );
        $this->db->where('id',$id);
        $this->db->update('gc_payout_type',$data);
        $this->session->set_flashdata('payout_success', 'Updated');
        redirect('master/Payout');
    }

    public function delete_payout($id)
    {

        $data = array('status' => 3);
        
        $this->db->where('id',$id);
        $this->db->update('gc_payout_type',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Payout');
    }



public function edit() {
    $this->load->view('master/payout/edit');
}

// Encode message
public function key_encoder() 
{

    // Check for validation
    $this->form_validation->set_rules('key', 'Message', 'trim|required|xss_clean');
    if ($this->form_validation->run() == TRUE) {
    $this->load->view('master/payout/edit');
    } else {
    $key = $this->input->post('key');
    // Encoding message
    $data['encrypt_value'] = $this->encrypt->encode($key);
    $this->load->view('master/payout/edit', $data);
    }
}

// Decode encrypted message
public function key_decoder() 
    {
        $encrypt_key = $this->input->post('encrypt_key');
        $data['decrypt_value'] = $this->encrypt->decode($encrypt_key);
        $this->load->view('master/payout/edit', $data);
    }

}
