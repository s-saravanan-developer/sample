<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Earning_model extends CI_Model { 



       public function get_earning($id) {
        // var_dump($id);
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level.Level,commission.Status as Commission_status');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Commision_date',date('Y-m-d'));
       $where = '(member.Membership_code="'.$id.'" or member.Mobile = "'.$id.'")';
        $this->db->where($where);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

       public function get_earning1($commission_type,$payment_status,$s_date,$e_date,$mobile,$contract,$level) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level.Level,commission.Status as Commission_status,contract.Contract_ref_no,level_det.Child_ID');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');

        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');

        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');

        $this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Commision_date',date('Y-m-d'));
        //$this->db->where('commission.Status',1);

        if(!empty($commission_type)){
        $this->db->where("commission.Commision_type",$commission_type);
     }
     if(!empty($payment_status)){
        $payment_status=explode(',',$payment_status);
        $this->db->where_in("commission.Status",$payment_status);
     }
    
     if(!empty($s_date)){
        $this->db->where("commission.Commision_date >=",$s_date);
     }
     if(!empty($e_date)){
        $this->db->where("commission.Commision_date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

     //    if(!empty($topup)){
     //    $this->db->where("topup.ID",$topup);
     // }
     if(!empty($contract)){
        $this->db->where("contract.Contract_ID",$contract);
     }
     if(!empty($level)){
        $this->db->where("level.ID",$level);
     }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    

public function get_payout_history1($mobile,$date) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
     if(!empty($date)){
        $this->db->where("commission.Recieved_date",$date);
     }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_payout_history2($commission_type,$level_type,$s_date,$e_date,$mobile) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',1);

        if(!empty($commission_type)){
        $this->db->where("commission.Commission_type",$commission_type);
     }
     // if(!empty($level_type)){
     //    $this->db->where("contract.Topup_id",$level_type);
     // }
    
     if(!empty($s_date)){
        $this->db->where("commission.Recieved_date >=",$s_date);
     }
     if(!empty($e_date)){
        $this->db->where("commission.Recieved_date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    public function get_all_level_types() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    public function get_child($child){
    	return $this->db->get_where('gc_membership',array('Membership_ID' => $child))->row('First_name');
    }

public function get_all_commission_types() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_commission');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_all_topups() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_member_topup');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_all_levels() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_level');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
public function get_contract($id) {
    $this->db->select('Contract_ID,Contract_ref_no');
    $this->db->where("Contract_status",6);
    $this->db->where("Membership_ID",$id);
    $query = $this->db->get('gc_member_franchisee_contract');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


public function get_contracts($topup) {
    $this->db->select('*');
    $this->db->where("Contract_status",6);
    $this->db->where("Topup_id",$topup);
    $query = $this->db->get('gc_member_franchisee_contract');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    

    

public function get_transaction_history() {
    $this->db->select('history.*,member.First_name,member.Last_name,member.Mobile,member.Membership_code,payout.payout_type as Payout_type');
    $this->db->from('gc_transaction_history as history');
        $this->db->join('gc_membership as member', 'member.Membership_ID = history.Membership_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = history.Payout_ID', 'left');
     $this->db->where("history.Status",1);
     $this->db->where("history.Date",date('Y-m-d'));
    $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_transaction_history1($mobile,$date) {
    $this->db->select('history.*,member.First_name,member.Last_name,member.Mobile,member.Membership_code,payout.payout_type as Payout_type');
    $this->db->from('gc_transaction_history as history');
        $this->db->join('gc_membership as member', 'member.Membership_ID = history.Membership_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = history.Payout_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = history.Contract_ID', 'left');
     $this->db->where("history.Status",1);
     //$this->db->where("history.Date",date('Y-m-d'));
     // if(!empty($commission_type)){
     //    $this->db->where("history.Date",date('Y-m-d'))
     // }
    if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
     if(!empty($date)){
        $this->db->where("history.Date",$date);
     }
    $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
public function get_transaction_history2($commission_type,$topup_list,$transaction_type,$s_date,$e_date,$mobile) {
    $this->db->select('history.*,member.First_name,member.Last_name,member.Mobile,member.Membership_code,payout.payout_type as Payout_type');
    $this->db->from('gc_transaction_history as history');
        $this->db->join('gc_membership as member', 'member.Membership_ID = history.Membership_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = history.Payout_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = history.Contract_ID', 'left');
     $this->db->where("history.Status",1);
     $this->db->where("history.Date",date('Y-m-d'));
     // if(!empty($commission_type)){
     //    $this->db->where("history.Date",date('Y-m-d'))
     // }
     if(!empty($topup_list)){
        $this->db->where("contract.Topup_id",$topup_list);
     }
     if(!empty($transaction_type)){
        $transaction_type=explode(',',$transaction_type);
        $this->db->where_in("history.Type",$transaction_type);
     }
     if(!empty($s_date)){
        $this->db->where("history.Date >=",$s_date);
     }
     if(!empty($e_date)){
        $this->db->where("history.Date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
    $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
    



    


}



