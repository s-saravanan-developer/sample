<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Help_model extends CI_Model { 

    function getallrequest() {

        $this->db->select('*');
        $this->db->where('Status',1);
        $query = $this->db->get('gc_membership_reqtype');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function getallticket() {

        $member_id = $this->session->userdata('UserCode');

        $this->db->select('tab.*,tab2.Membership_reqtype');
        $this->db->from('gc_ticket as tab');  
        $this->db->join('gc_membership_reqtype as tab2', 'tab2.ID = tab.Member_request', 'left'); 
        $this->db->where('tab.Membership_ID', $member_id);
        $this->db->where('tab.Status', 1);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function getallfeedback() {

        $member_id = $this->session->userdata('UserCode');

        $this->db->select('tab.*');
        $this->db->from('gc_feedback as tab');  
        $this->db->where('tab.Membership_ID', $member_id);
        $this->db->where('tab.Status', 1);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function getallticket_dashboard() {

        $member_id = $this->session->userdata('UserCode');

        $this->db->select('tab.*,tab2.Membership_reqtype');
        $this->db->from('gc_ticket as tab');  
        $this->db->join('gc_membership_reqtype as tab2', 'tab2.ID = tab.Member_request', 'left'); 
        $this->db->where('tab.Membership_ID', $member_id);
        $this->db->where('tab.Status', 1);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

      public function uploads($ref_no,$member_id,$name,$common) {     

         mkdir('./uploads/'.$common, 0777, true);   
         mkdir('./uploads/'.$common.'/'.$ref_no, 0777, true);   
         $config['upload_path']          = './uploads/'.$common.'/'.$ref_no.'/';
         $config['allowed_types']        = 'gif|pdf|png|jpg';
         $new_name                       = 'TKT'.$ref_no.'_'.$member_id;
         $config['file_name']            = $new_name;
         
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ( ! $this->upload->do_upload($name))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $file_name = '';
                        // print_r($error);
                        // return $file_name;                 
                }
                else
                {   
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];

                        return $file_name;
                }

    }
}



