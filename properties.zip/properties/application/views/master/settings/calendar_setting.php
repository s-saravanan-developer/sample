<script>
   <?php
         if ($this->session->flashdata('company_success')) 
         {
            echo "var data = ' ".$this->session->flashdata('company_success')."';";
            echo "success(data);";
         }
   ?>
</script>
<div class="content-wrapper">
   <div class="content">
      <header class="page-header">
         <div class="d-flex align-items-center">
            <div class="mr-auto">
               <h1 class="separator">Calendar Settings </h1>
               <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i></a></li>
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard">Master</a></li>
                     <li class="breadcrumb-item active" aria-current="page">Calendar Settings</li>
                  </ol>
               </nav>
            </div>
            <ul class="actions top-right">
               <li class="dropdown">
                  <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                  <i class="la la-ellipsis-h"></i>
                  </a>
                  <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
                     <div class="dropdown-header">
                        Quick Actions
                     </div>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-clockwise"></i> Refresh
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-gear"></i> Manage Widgets
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-cloud-download"></i> Export
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-help"></i> Support
                     </a>
                  </div>
               </li>
            </ul>
         </div>
      </header>


      <section class="page-content container-fluid">
         <div class="row">
            <div class="col-12"> 
                     <div class="card">
                        <h5 class="card-header">
                     <div style="float: left;">
                        Yearly Holidays Setting    
                     </div></h5>
                     <div class="card-body">
                        <form action="<?php echo base_url(''); ?>/master/Calendar_setting/update_yearly_holiday" data-toggle='validator' method="post" >
                        <div class="form-body">
                           <div class="card">
                                 <div class="card-body">

                           <div class="row">
                              
                              <div class="col-md-12">
                                 <div class="row">
                                 <div class="col-md-5">
                                 <div class="form-group">
                                    <label class="col-form-label-lg" for="largeInput">Days  <span style="color:red">*</span></label>
                                                               <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control company_country weekly_holiday" disabled name="Week_holiday[]" id="s2_demo1" multiple required="" style="width: 93%">
                                       <?php if(!empty($weeks)){foreach($weeks as $wks){ ?>
                                          <option value="<?php echo $wks["Id"] ?>"><?php echo $wks["Week"] ?></option>
                                       <?php } } ?>
                                    
                                    </select>
                                    <input type="hidden" name="Id" value="<?php echo $holiday[0]['Id'] ?>">
                                    <input type="hidden" name="Selected_days" value="<?php echo $holiday[0]['Days'] ?>">
                                 </div>
                                 </div>
                              </div>
                              <div class="col-md-5">
                             <div class="form-group">
                              <label class="col-form-label-lg" for="largeInput">Color  <span style="color:red">*</span></label>
                                                               <div class="input-group mb-3">
                             <div class="input-group-prepend">
                           <!-- <div class="m-t-5"> -->
                              <div class="event-tag event-tag-edit-yearly" >
                                 <span class="brand-primary">
                                    <input type="radio" value="6610f2" <?php if($holiday[0]['Color']=="6610f2"){echo "checked";} ?> class ="yearly_event_color" disabled id="Y_6610f2" name="Color"  >
                                    <i></i>
                                 </span>
                                 <span class="brand-accent">
                                    <input type="radio" value="e83e8c" <?php if($holiday[0]['Color']=="e83e8c"){echo "checked";} ?> class ="yearly_event_color" disabled id="Y_e83e8c"  name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-warning">
                                    <input type="radio" value="ffc107" <?php if($holiday[0]['Color']=="ffc107"){echo "checked";} ?> class ="yearly_event_color" disabled id="Y_ffc107" name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-info">
                                    <input type="radio" value="17a2b8" <?php if($holiday[0]['Color']=="17a2b8"){echo "checked";} ?> class ="yearly_event_color" disabled id="Y_17a2b8" name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-success">
                                    <input type="radio" value="28a745" <?php if($holiday[0]['Color']=="28a745"){echo "checked";} ?> class ="yearly_event_color" disabled id="Y_28a745" name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-danger">
                                    <input type="radio" value="dc3545" <?php if($holiday[0]['Color']=="dc3545"){echo "checked";} ?> class ="yearly_event_color" disabled id="Y_dc3545" name="Color">
                                    <i></i>
                                 </span>
                              </div>
                           <!-- </div> -->
                        </div>
                        </div>
                     </div>

                              </div>
                              <div class="col-md-2">
                                 <div class="form-group" style="margin-top: 38px;">
                              <div class="input-group mb-3">
                        <div id="edit_fun">
                         <button  href="#" id="common_prefix" type="button" class="btn btn-info btn-sm editusertype"><i class="zmdi zmdi-edit zmdi-hc-fw" style="color:  white;" data-toggle="tooltip" data-placement="top" data-original-title="Edit"></i>
                           </button>
                        </div> 
                           <div id="function_btn" class="no-display">
                              <button onclick="update_common_prefix()" type="submit" class="btn btn-success  btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Update">
                                 Update
                              </button>
                              <button id="Cancel_btn" type="button" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Cancel">
                                 Cancel
                              </button>
                           </div>
                        </div>
                     </div>
                                 
                              </div>
                              
                           </div>

                              </div>
                           </div>
                        </div>
                     </div>
                        </div>
                     </form>

                     </div>
                     </div>    
               <div class="card">
                  <h5 class="card-header">
                     <div style="float: left;">
                        Monthly Holidays Setting 	
                     </div>
                     <div style="float: right;">
                        
                        <button type="button" class="btn btn-success  btn-floating" data-toggle="tooltip" data-placement="top" title="" data-original-title="Add Multiple Holidays" >
                        <p class="text-white" data-toggle="modal" data-target="#modal_multiple_event">Add Multiple Holidays</p>
                        </button>
                        <button class="btn btn-primary region_input " data-toggle="modal" data-target="#multiexport">Export Excel</button>
                        


                     </div>
                     
                  </h5>
                  <div class="card-body">
                              <div id="calendar"></div>
                           </div>
               </div>
            </div>
         </div>
      </section>
   </div>
</div>
</div>	


<!-- export Modal start-->
<div class="modal fade" id="multiexport" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Export</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <a 
               type="submit" class="btn btn-primary multi_export" data-dismiss="modal">Yes, Export it!</a>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
      </div>
   </div>
</div>
<!-- export Modal End -->
<!-- Model Execution -->

<div class="modal fade" id="modal_new_event" tabindex="-1" role="dialog" aria-hidden="true">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel1">Add Holiday</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <form class="form-event">
                     <div class="form-group row">
                        <label for="editTitle" class="col-md-2 control-label">Title</label>
                        <div class="col-md-10">
                           <input type="text" class="form-control new_event_title" name="Event" id="add_event_title" placeholder="Event Name">
                        </div>
                     </div>
                     <div class="form-group row">
                        <label class="col-md-2 control-label">Date</label>
                        <div class="col-md-10">
                           <div class="row">
                              <div class="col p-0">
                                 <div class="form-group m-0">
                                    <div class="input-group">
                                       <div class="input-group-prepend">
                                          <span class="input-group-addon"><i class="icon dripicons-calendar"></i></span>
                                       </div>
                                       <input type="text" readonly class="form-control datepicker" id="add_event_date" name="Date" placeholder="Start Date">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="form-group row">
                       <label  class="col-md-2 control-label">Tag Color</label>
                        <div class="col-md-10">
                           <div class="form-group m-t-5">
                              <div class="event-tag">
                                 <span class="brand-primary">
                                    <input type="radio" value="6610f2" class ="add_event_color" id="6610f2" name="Color" >
                                    <i></i>
                                 </span>
                                 <span class="brand-accent">
                                    <input type="radio" value="e83e8c" class ="add_event_color" id="e83e8c"  name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-warning">
                                    <input type="radio" value="ffc107" class ="add_event_color" id="ffc107" name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-info">
                                    <input type="radio" value="17a2b8" class ="add_event_color" id="17a2b8" name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-success">
                                    <input type="radio" value="28a745" class ="add_event_color" id="28a745" name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-danger">
                                    <input type="radio" value="dc3545" checked class ="add_event_color" id="dc3545" name="Color">
                                    <i></i>
                                 </span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="textArea" class="col-md-2 control-label">Desctiption</label>
                        <div class="col-md-10">
                           <textarea class="form-control edit-event-description" name="Description" rows="3" id="add_event_description" placeholder="Event Desctiption"></textarea>
                        </div>
                     </div>

                     
                  </form>
                  <div class="modal-footer">
                     <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                     <button type="submit" class="btn btn-primary" id="event_add">Set Holiday</button>
                  </div>
               </div>
            </div>
         </div>
      </div>
<!-- LOCATION RIGHT SIDE -->




<div class="modal fade bd-example-modal-lg" id="modal_multiple_event" tabindex="-1" role="dialog" aria-hidden="true">
         <div class="modal-dialog modal-lg">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel1">Add Holiday</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <form id "multiple_holiday_form" action="<?php echo base_url(''); ?>/master/Calendar_setting/insert_multiple_holiday" data-toggle='validator' method="post" >
                     <div class="row">
                        <input type="hidden"  class="unique_id" name="unique_id" value="1" >
   <div class="col-md-3"><label for="editTitle" class="col-md-2 control-label">Title</label></div>
   <div class="col-md-2"><label for="editTitle" class="col-md-2 control-label">Date</label></div>
   <div class="col-md-3"><label for="editTitle" class="col-md-2 control-label">Color</label></div>
   <div class="col-md-3"><label for="editTitle" class="col-md-2 control-label">Description</label></div>
   <div class="col-md-1"></div>
</div>
<div class="card">
   <div class="card-body">
<div class="row root" id="1">
   <div class="col-md-3">
          <input type="text" class="form-control new_event_title" id="add_event_title" id="add_event_title" placeholder="Event Name" name="multiple_1[Event]">
   </div>
   <div class="col-md-2">
         <input type="text" class="form-control" id="multiple_event_date_1" placeholder="Start Date" name="multiple_1[Date]">
   </div>
   <div class="col-md-3">
                           <div class="form-group m-t-5">
                              <div class="event-tag">
                                 <span class="brand-primary" style="width:26px;height:26px;">
                                    <input type="radio" value="6610f2" class ="add_event_color" id="6610f2" name="multiple_1[Color]" >
                                    <i></i>
                                 </span>
                                 <span class="brand-accent" style="width:26px;height:26px;">
                                    <input type="radio" value="e83e8c" class ="add_event_color" id="e83e8c"  name="multiple_1[Color]">
                                    <i></i>
                                 </span>
                                 <span class="brand-warning" style="width:26px;height:26px;">
                                    <input type="radio" value="ffc107" class ="add_event_color" id="ffc107" name="multiple_1[Color]">
                                    <i></i>
                                 </span>
                                 <span class="brand-info" style="width:26px;height:26px;">
                                    <input type="radio" value="17a2b8" class ="add_event_color" id="17a2b8" name="multiple_1[Color]">
                                    <i></i>
                                 </span>
                                 <span class="brand-success" style="width:26px;height:26px;">
                                    <input type="radio" value="28a745" class ="add_event_color" id="28a745" name="multiple_1[Color]">
                                    <i></i>
                                 </span>
                                 <span class="brand-danger" style="width:26px;height:26px;">
                                    <input type="radio" value="dc3545" checked class ="add_event_color" id="dc3545" name="multiple_1[Color]">
                                    <i></i>
                                 </span>
                              </div>
                           </div>
   </div>
   <div class="col-md-3">
           <textarea class="form-control edit-event-description" name="multiple_1[Description]" rows="2" id="add_event_description" placeholder="Event Desctiption"></textarea>
   </div>
      <div class="col-md-1">
          <button class="btn btn-info add_new_row" type="button" style="padding: 4px;"><i class="zmdi zmdi-plus zmdi-hc-fw" style="color: white;"></i></button>
   </div>
</div>
<div id="new_row_div"></div>
          </div>
</div>           

                     
                  
                  <div class="modal-footer">
                     <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                     <button type="submit" class="btn btn-primary">Set Holiday</button>
                  </div>
                  </form>
               </div>
            </div>
         </div>
      </div>

<input type="hidden" name="details_count" value="1" class="details_count">


<!-- End View Company Modal -->
      <!-- Edit event modal-->
      <div class="modal fade" id="modal_edit_event">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel2">Edit Holiday</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <form class="edit-event__form">
                     <div class="form-group row">
                        <label for="editTitle" class="col-md-2 control-label">Title</label>
                        <div class="col-md-10">
                           <input type="text" class="form-control edit_event_title" name="Event" id="edit_event_title" placeholder="Event Title">
                        </div>
                     </div>
                     <div class="form-group row">
                        <label class="col-md-2 control-label">Date</label>
                        <div class="col-md-10">
                           <div class="row">
                              <div class="col p-0">
                                 <div class="form-group m-0">
                                    <div class="input-group">
                                       <div class="input-group-prepend">
                                          <span class="input-group-addon"><i class="icon dripicons-calendar"></i></span>
                                       </div>
                                       <input type="text" readonly class="form-control datepicker" id="edit_event_date" placeholder="Start Date">
                                    </div>
                                 </div>
                              </div>
                              
                           </div>
                        </div>
                     </div>
                    
                     <div class="form-group row">
                        <label  class="col-md-2 control-label">Tag Color</label>
                        <div class="col-md-10">
                           <div class="form-group m-t-5">
                              <div class="event-tag event-tag-edit">
                                 <span class="brand-primary">
                                    <input type="radio" value="6610f2" class ="edit_event_color" id="6610f2" name="Color"  >
                                    <i></i>
                                 </span>
                                 <span class="brand-accent">
                                    <input type="radio" value="e83e8c" class ="edit_event_color" id="e83e8c"  name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-warning">
                                    <input type="radio" value="ffc107" class ="edit_event_color" id="ffc107" name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-info">
                                    <input type="radio" value="17a2b8" class ="edit_event_color" id="17a2b8" name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-success">
                                    <input type="radio" value="28a745" class ="edit_event_color" id="28a745" name="Color">
                                    <i></i>
                                 </span>
                                 <span class="brand-danger">
                                    <input type="radio" value="dc3545" class ="edit_event_color" id="dc3545" name="Color">
                                    <i></i>
                                 </span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="textArea" class="col-md-2 control-label">Desctiption</label>
                        <div class="col-md-10">
                           <textarea class="form-control edit-event-description" rows="3" id="edit_event_description" placeholder="Event Desctiption"></textarea>
                        </div>
                     </div>
                     
                     <input type="hidden" class="edit_event_id" id="edit_event_id">
                  </form>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-danger btn-flat" id="event_delete" data-calendar="delete">Delete</button>
                  <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Cancel</button>
                  <button type="button" class="btn btn-primary" id="event_edit">Update</button>
               </div>
            </div>

<!-- BASIC MODAL DEMO -->
<div class="modal fade" id="deletemodel" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Delete</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <form action="<?php echo base_url();?>master/Company/delete" method="POST">
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
               <input type="hidden" name="url" value="Company">
               <input class="delete_id" type="hidden" name="CompanyID">
               <input class="table_name" type="hidden" name="table_name">						
            </div>
            <div class="delete-footer">
               <button type="submit" class="btn btn-primary">Yes, delete it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>						
            </div>
         </form>
      </div>
   </div>
</div>
<script type="text/javascript">
   $(function() { 
    $('#multiple_event_date_1').datepicker();
  });

        $('#common_prefix').click(function(){ 
            // $(".weekly_holiday").val($("#Selected_days").val());
           $(".weekly_holiday").prop('disabled', false);
           $(".yearly_event_color").prop('disabled', false);

           
           
           $('#edit_fun').addClass('no-display');
           $('#function_btn').removeClass('no-display');
      });

      $('#Cancel_btn').click(function(){
            $(".weekly_holiday").prop('disabled', true);
           $(".yearly_event_color").prop('disabled', true);
            $('#edit_fun').removeClass('no-display');
            $('#function_btn').addClass('no-display');
      });

$(document).ready(function() {
   // dayvalue=$("#Selected_days").val();
   dayvalue='<?php echo $holiday[0]['Days']; ?>';
   weekly_holiday = JSON.parse("[" + dayvalue + "]");
      $('.weekly_holiday').select2().val(weekly_holiday).trigger('change');
    $('#calendar').fullCalendar({
      header: {
            left: 'prev,next,today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
         },
         theme: false,
         selectable: true,
         selectHelper: true,
         editable: true,
         navLinks: true,
         eventLimit: true,
         
     eventSources: [
         {
                  // color: '#4885ed',   
                  // textColor: '#fff',

             events: function(start, end, timezone, callback) {
                 $.ajax({
                 url: '<?php echo base_url() ?>master/Calendar_setting/get_events',
                 dataType: 'json',
                 data: {
                 // our hypothetical feed requires UNIX timestamps
                 start: start.unix(),
                 end: end.unix()
                 },
                 success: function(msg) {
                     var events = msg.events;
                     callback(events);
                     console.log(events);
                     
                 }
                 });
                 
             }
         },
     ],
     dayClick: function(date, jsEvent, view) {
        date_last_clicked = $(this);
        // $(this).css('background-color', '#bed7f3');
        $('#modal_new_event #add_event_date').val(moment(date).format("YYYY-MM-DD"));
        $('#modal_new_event').modal();
    },
    eventClick: function(event, jsEvent, view) {
      if(event.status==1){
          $('#edit_event_title').val(event.title);
          $('#edit_event_description').text(event.description);
          $('#edit_event_date').val(moment(event.start).format('YYYY-MM-DD'));
          $('.'+event.clr).attr('checked','checked');
          $('#modal_edit_event input[id=' + event.clr + ']').prop('checked', true);
          $('#edit_event_id').val(event.id);
          $('#modal_edit_event').modal();
       }else{
         // alert("Unable To Edit Here");
         swal({
        type: 'error',
        title: 'Oops...',
        text: 'Unable to Edit here!',
        allowOutsideClick: false
      })
       }
},
  eventDrop: function(event, delta,revertFunc) {
if(event.status==1){
    date       =event.start.format();
    id         =event.id;
    // if (!confirm("Are you sure about this change?")) {
      setTimeout(function() {
            swal({
               title: 'Are you sure?',
               text: "Are you sure about this change?",
               type: 'warning',
               showCancelButton: true,
               confirmButtonColor: '#3085d6',
               cancelButtonColor: '#d33',
               confirmButtonText: 'Yes, Change it!',
               allowOutsideClick: false
            }),
            $(".swal2-confirm").click(function(){
               var result1=dragevent(date,id);
               if(result1==1){
               swal(
                  'Changed!',
                  'Your event has been Changed.',
                  'success'
               );
           }
            });
            $(".swal2-cancel").click(function(){
               revertFunc();
                 swal(
                  'Canceled!',
                  'Drag Action Canceled.',
                  'error'
               );


            })
         }, 250);
   }else{
      revertFunc();
      swal({
        type: 'error',
        title: 'Oops...',
        text: 'Unable to change here!',
        allowOutsideClick: false
      })
   }

      
    

  },
   

 });
    });

$("#event_add").click(function(){
event=$("#add_event_title").val();
date=$("#add_event_date").val();
description=$("#add_event_description").val();
color=$('.add_event_color:checked').val();
$.ajax({
type: "POST",
url: "<?php echo base_url(); ?>master/Calendar_setting/add_monthly_setting",
data: {event: event,date: date,description:description,color:color},
cache: true,
async: false,
success: function(data){
 if(data==1){
   location.reload();
 }else{
   alert
   ("Something Went Wrong");
   $('#modal_new_event').modal("hide");

 }
result = data;
}
});

});

$("#event_edit").click(function(){
event=$("#edit_event_title").val();
date=$("#edit_event_date").val();
description=$("#edit_event_description").val();

color=$('.edit_event_color:checked').val();
// alert(color);
id=$("#edit_event_id").val();
$.ajax({
type: "POST",
url: "<?php echo base_url(); ?>master/Calendar_setting/edit_monthly_setting",
data: {event: event,date: date,description:description,color:color,id:id},
cache: true,
async: false,
success: function(data){
if(data==1){
   location.reload();
 }else{
   alert
   ("Something Went Wrong");
   $('#modal_new_event').modal("hide");

 }
}
});

});

function dragevent(date,id){
   var Results1;
   $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>master/Calendar_setting/edit_monthly_setting1",
      data: {date: date,id:id},
      cache: true,
      async: false,
      success: function(data){
      Results1=data;
      }
      });
   return Results1;

}

function newsam1(currentId){
   var results;
   $.ajax({
                  type: "POST",
                  url: "<?php echo base_url(); ?>master/Calendar_setting/delete_monthly_setting",
                  data: {id:currentId},
                  cache: true,
                  async: false,
                  success: function(data){
                     results=data;
                  }
                  });
   return results;
   // return data;
}

var count = 1;
$( ".add_new_row" ).click(function() {

  // Increment the count
  $('.details_count').val( function(i, oldval) {
      return parseInt( oldval, 10) + 1;
  });

   count = count+1;
  $("#new_row_div").append(
   ''
   +'<div class="row root" id='+count+' >'
+'<div class="col-md-3">'
+'<input type="text" class="form-control new_event_title" id="add_event_title" id="add_event_title" placeholder="Event Name" name="multiple_'+count+'[Event]">'
+'</div>'
+'<div class="col-md-2">'
+'<input type="text" class="form-control" id="multiple_event_date_'+count+'" placeholder="Start Date" name="multiple_'+count+'[Date]">'
+'</div>'
+'<div class="col-md-3">'
+'<div class="form-group m-t-5">'
+'<div class="event-tag">'
+'<span class="brand-primary" style="width:26px;height:26px;margin-left:4px;">'
+'<input type="radio" value="6610f2" class ="add_event_color" id="6610f2" name="multiple_'+count+'[Color]" >'
+'<i></i>'
+'</span>'
+'<span class="brand-accent" style="width:26px;height:26px;margin-left:4px;">'
+'<input type="radio" value="e83e8c" class ="add_event_color" id="e83e8c"  name="multiple_'+count+'[Color]">'
+'<i></i>'
+'</span>'
+'<span class="brand-warning" style="width:26px;height:26px;margin-left:4px;">'
+'<input type="radio" value="ffc107" class ="add_event_color" id="ffc107" name="multiple_'+count+'[Color]">'
+'<i></i>'
+'</span>'
+'<span class="brand-info" style="width:26px;height:26px;margin-left:4px;">'
+'<input type="radio" value="17a2b8" class ="add_event_color" id="17a2b8" name="multiple_'+count+'[Color]">'
+'<i></i>'
+'</span>'
+'<span class="brand-success" style="width:26px;height:26px;margin-left:4px;">'
+'<input type="radio" value="28a745" class ="add_event_color" id="28a745" name="multiple_'+count+'[Color]">'
+'<i></i>'
+'</span>'
+'<span class="brand-danger" style="width:26px;height:26px;margin-left:4px;">'
+'<input type="radio" value="dc3545" checked class ="add_event_color" id="dc3545" name="multiple_'+count+'[Color]">'
+'<i></i>'
+'</span>'
+'</div>'
+'</div>'
+'</div>'
+'<div class="col-md-3">'
+'<textarea class="form-control edit-event-description" name="multiple_'+count+'[Description]" rows="2" id="add_event_description" placeholder="Event Desctiption"></textarea>'
+'</div>'
+'<div class="col-md-1">'
+'<button class="btn btn-danger close_x" type="button" style="padding: 4px;"><i class="zmdi zmdi-close zmdi-hc-fw" style="color: white;"></i></button>'
+'</div>'
+'</div>'

);

$("#multiple_event_date_"+count).datepicker();
  var id_v = new Array();
    $(".root").each(function() {
                var value = $(this).attr('id');
                  id_v.push(value);
                 // $(".unique_id").text(value);

            });

$(".unique_id").val(id_v);

});

$(document).on('click', '.close_x', function(e) {

   var id = $(this).parents('.root').attr('id');
   $('#'+id+'').remove();
     // dEcrement the count
      $('.details_count').val( function(i, oldval) {
          return parseInt( oldval, 10) - 1;
      });

        var id_v = new Array();
    $(".root").each(function() {
                var value = $(this).attr('id');
                  id_v.push(value);
                 // $(".unique_id").text(value);

            });
    $(".unique_id").val(id_v);
            });

            

$('.multi_export').click(function(){
    window.location = "<?php echo base_url();?>Export/export_calendar";

});
</script>