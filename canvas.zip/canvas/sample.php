<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Title Page</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<h1 class="text-center">Hello World</h1>
		<div class="card" id="canvas_div">
			<div class="card-header">Image Canvas</div>
			<div class="card-body">
			<?php 
			// $path = './preview.jpg';
			// $type = pathinfo($path, PATHINFO_EXTENSION);
			// $data = file_get_contents($path);
			// $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

 			?>
				<!-- <img src="<?php echo $base64; ?>"> -->
				 <!-- <span><img src="./rose-blue-flower-rose-blooms-67636.jpeg" style="width: 244px; margin-left: -346px; height: 148px; margin-top: 9px;"></span> -->
				 	<img src="./rose-blue-flower-rose-blooms-67636.jpeg"> 
				</div> <div class="card-footer"> sample
			</div>
		</div>

		
		
	<button class="btn-btn-success" type="button" id="click_canas">click</button>
	<p id="preview">pre</p>
		<!-- jQuery -->
		<script src="https://code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"  ></script>
		<script src="html2canvas.js"  ></script>
		<script src="html2canvas.min.js"  ></script>
		<script src="html2canvas.esm.js"  ></script>
		<script src="canvas2image.js"  ></script>

		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>

 		<script type="text/javascript">
 			$(document).on('click', '#click_canas', function(e) {
 				var elm=$('#canvas_div').get(0);
 				var lebar = '600';
 				var tinggi	= '400';
 				var type = 'png';
 				var filename = 'htmltocanvas';
 				alert();
 				html2canvas(document.querySelector("#canvas_div")).then(canvas => {
    				// document.body.appendChild(canvas);

    				var canWidth=canvas.width;
    				var canHeight=canvas.height;
    				var img = Canvas2Image.convertToImage(canvas,canWidth,canHeight);
    				console.log(img.src);
    				alert(img.src);
    				$('#preview').empty();
    				alert(1);
    				$('#preview').after(img);

    				Canvas2Image.saveAsImage(canvas,lebar,tinggi,type,filename);
				})
 			});
 		</script>

 		<script type="text/javascript">
 			

 		</script>
	</body>
</html>