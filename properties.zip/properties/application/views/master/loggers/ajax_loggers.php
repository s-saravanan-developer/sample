<?php 
if($_POST['type']=='get_historys'){ 

?>
<div class="modal-dialog modal-lg">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title text-danger" id="ModalTitle2">Logg History <?php //var_dump($history); ?></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true" class="zmdi zmdi-close"></span>
                  </button>
               </div>
              <form action="#" method="POST">
               <div class="modal-body" style="overflow-y: scroll;">

<table id="bs4-table-1" class="table table-striped table-bordered responsive dataTable no-footer dtr-inline">
    	 	<thead>
            <th style="width: 20%">Name</th>
            <th style="width: 20%">Browser</th>
            <th style="width: 20%">Ip</th>
            <th style="width: 20%">Date & Time</th>
            <th style="width: 20%">Log Status</th>     
            <!-- <th>Action</th> -->
            </thead>

            <tbody><?php
                              if (!empty($history)) {
                                  $s = 1;
                                  foreach ($history as $list) {
                                      ?>
                <tr>
                    
                               <td class="s_no"><?php echo ucfirst($list['firstname']); ?></td>
                               <td class="s_no"><?php echo ucfirst($list['User_browser']); ?></td>
                               <td class="s_no"><?php echo ucfirst($list['User_ip']); ?></td>
                               <td class="s_no"><?php echo ucfirst($list['DateTime']); ?></td>
                              <td><span class="badge badge-<?php echo ($list['Login'] == 'Login') ? 'success' : 'danger'; ?>"><?php echo ($list['Login'] == 'Login') ? 'Login' : 'Logout'; ?></span></td>
                    
                    

                </tr>
            <?php $s++; }  }?>
            </tbody>
        </table>
        </div>
               <div class="modal-footer">
            
              <div class="form-group">
               <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
                
              </div>  
         </div>
            </form>
            </div>
         </div>


<?php  }?>
<script type="text/javascript">
  $('#bs4-table-1').DataTable();
</script>