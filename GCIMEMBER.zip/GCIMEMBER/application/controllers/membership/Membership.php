<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Membership extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('member/Membership_model');
        $this->load->model('member/Contract_model');
    }

	public function index($platform='web')
	{
        $platform = $this->input->post('platform');
        if(empty($platform)) {
            $platform = 'web';
        }
    	$template['page']            ='membership/viewmembership';
        $template['bank']            =  $this->Membership_model->getall_bank();
        $template['payment_mode']    =  $this->Membership_model->getall_payment_modes();
        $template['topup']           =  $this->Membership_model->getall_topups();
        $template['payout']          =  $this->Membership_model->getall_payouts();
        $template['membership_type'] =  $this->Membership_model->getall_membershiptype();
        // var_dump($template['membership_type']);die();
        $data['data'] = ['bank'                => $template['bank'],
                             'payment_mode'    => $template['payment_mode'],
                             'topup'           => $template['topup'],
                             'payout'          => $template['payout'],
                             'membership_type' => $template['membership_type']];
        if(!empty($data) & $platform != 'web') {
            header('Content-Type: application/json');
            echo json_encode($data);
        } else {
        $this->load->view('template',$template);
        }
	}

public function members()
    {
        $this->load->model('member/Membership_model');
        $template['page']='membership/manage_members';
        $status=5;
        $status1=10;
        $template['increment_code'] = $this->db->count_all_results('gc_membership');
        $template['members'] =  $this->Membership_model->getall_members($status,$status1);
        $this->db->where('Status',6);
        $template['bank_status'] =  $this->db->count_all_results('gc_member_banks');

        $this->db->where('Status',6);
        $this->db->group_by('Membership_ID');
        $template['document_status'] =  $this->db->count_all_results('gc_member_documents');

        $this->db->where('Payment_status',6);
        $this->db->group_by('Membership_ID');
        $template['payment_status'] =  $this->db->count_all_results('gc_member_payments');
        // $template['document_status'] =  $this->Membership_model->getall_members();
        // $template['payment_status'] =  $this->Membership_model->getall_members();

        // var_dump($template['membership_type']);die();
        $this->load->view('template',$template);
    }


public function profile(){
   $member=$this->session->userdata('UserCode');
   $template['bank']            =  $this->Membership_model->getall_bank();
    $template['members'] =  $this->Membership_model->getall_members_by_id($member);
    $this->load->model('member/Contract_model');
    $template['contract'] =  $this->Contract_model->get_contract_details($template['members'][0]['Membership_ID']);
    // var_dump($template['contract']);die();
   $this->load->model('member/Membership_model');
   $template['page']='membership/profile_view';
   $this->load->view('template',$template);

}
   
   public function update_user_details()
    {
        extract($_POST);

        $user_data['Updated_by']        =$this->session->userdata('UserId');
        $user_data['Updated_date']      =date('Y-m-d H:i:s');
        $user_data['DOB']               =date('Y-m-d',strtotime($user_data['DOB']));

        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->update('gc_membership',$user_data);

        // $nominee_data['Updated_by']     =$this->session->userdata('UserId');
        // $nominee_data['updated_date']   =date('Y-m-d H:i:s');

        // $this->db->where('Membership_ID',$Membership_ID);
        // $this->db->update('gc_member_nominees',$nominee_data);

        $user_table_data['email_address'] = $user_data['Email'];
        $user_table_data['mobile_number'] = $user_data['Mobile'];
        $user_table_data['DOB']           = $user_data['DOB'];
        $user_table_data['Updated_by']    =$this->session->userdata('UserId');
        $user_table_data['updated_date']  =date('Y-m-d H:i:s');

        $this->db->where('user_id',$Membership_ID);
        $this->db->update('gc_users',$user_table_data);

        redirect('membership/Membership/profile');
    } 

   public function update_bank_details()
    {
        extract($_POST);

        $bank_data['Updated_by']=$this->session->userdata('UserId');
        $bank_data['Updated_date']=date('Y-m-d');
        $bank_data['Status']=5;
        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->update('gc_member_banks',$bank_data);
        redirect('membership/Membership/profile');
    } 
    public function tree_view1()
    {
        $this->load->model('member/Membership_model');
        $this->load->model('master/Users_model');
        $Membership_ID = $this->input->get("id");
        $template['Membership_code']            =$Membership_ID;
        $template['page']            ='membership/tree_view';
        $this->load->view('template',$template);
    }
    
public function get_referer_by_code()
        {
        $referer = $this->input->post("referer");
        
        $data['referer'] =  $this->Membership_model->get_referer_by_code($referer);
        $data['bank']            =  $this->Membership_model->getall_bank();
        $data['payment_mode']    =  $this->Membership_model->getall_payment_modes();
        $data['topup']           =  $this->Membership_model->getall_topups();
        $data['payout']          =  $this->Membership_model->getall_payouts();
        $data['membership_type'] =  $this->Membership_model->getall_membershiptype();
        if($data['referer']!=0){

        $temp['data'] = ['value'             => 'Success',
                        'referer'             => $data['referer'],
                         'bank'                => $data['bank'],
                         'payment_mode'        => $data['payment_mode'],
                         'topup'               => $data['topup'],
                         'payout'              => $data['payout'],
                         'membership_type'     => $data['membership_type']];
                     }else{
                        $temp['data'] = ['value'             => 'Failure',
                            'referer'             => $data['referer'],
                         'bank'                => $data['bank']="",
                         'payment_mode'        => $data['payment_mode']="",
                         'topup'               => $data['topup']="",
                         'payout'              => $data['payout']="",
                         'membership_type'     => $data['membership_type']=""];
                     }

        header('Content-Type: application/json');
        echo json_encode($temp);
    }

public function get_referer_detail()
        {
        $referer = $this->input->post("referer");
        
        $temp['referer'] =  $this->Membership_model->get_referer_by_code($referer);
         if($data['referer']!=0){
        $data['data'] = ['value'             => 'Success',
                        'referer'             => $temp['referer']];
    }else{
        $data['data'] = ['value'             => 'Failure',
                        'referer'             => $temp['referer']];
    }
        
        header('Content-Type: application/json');
        echo json_encode($data);
    }

public function status_wise_members()
        {
        $status = $this->input->post("status");  
        $status1 = $this->input->post("status1");  
        $this->load->model('member/Membership_model');
        //$template['page']='membership/manage_members';
        $template['members'] =  $this->Membership_model->getall_members($status,$status1);
        $this->load->view('membership/ajax_members',$template);
    }

public function calculate_commission()
        {
        $status = $this->input->post("status");
        //$template['page']='membership/manage_members';
        $template['members'] =  $this->Membership_model->calculate_commission();
        //$this->load->view('membership/ajax_members',$template);
    }

    

public function mobile_verify()
        {
        $mobile = $this->input->post("mobile");
        // $temp['referer'] =  $this->Membership_model->mobile_verify($mobile);
        $this->db->select('Membership_ID,First_name,Last_name,Membership_code,Status');
        $this->db->where('Mobile',$mobile);
        $query = $this->db->get('gc_membership');
        if ($query->num_rows() > 0) {
            $verify['content'] =  'Member Already Exist!';
            $verify['status']  =  '1';
            $verify['value']  =  'Failiure';
            $verify['mobile']  =  "";

        }else{
            $temp['Mobile']=$mobile;
            $temp['OTP']=$this->generatePIN();
            if($this->db->insert('gc_temp_user',$temp)){
                $temp_id=$this->db->insert_id();
                $sms_content="Please Use This OTP : ".$temp['OTP'];

                // $sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=ZmQxNzA1OWEyZTE&mobiles='.$mobile.'&message='.$sms_content.'&sender=PKSEVA&type=1&route=2';
                $sms_url='http://bulksmscoimbatore.co.in/sendsms?uname=mequals&pwd=mequals@123&senderid=BUGFIX&to='.$mobile.'&msg='.urlencode($sms_content).'&route=SID';

                $ch = curl_init($sms_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
                $response=curl_exec($ch);
                // curl_close($ch);

                if (curl_errno($ch)) {
                    $error = curl_error($ch);
                }
                $curl_data = explode(',', $response);
                curl_close($ch);
                
            }
            $verify['content'] =  'Please Enter OTP';
            $verify['status']  ='0';
            $verify['mobile']  =  $mobile;
            $verify['value']  =  'Success';

        }
        $data['data'] = ['content'             => $verify['content'],
                         'status'             => $verify['status'],
                         'mobile'               =>$verify['mobile'],
                         'value'                => $verify['value']];
        header('Content-Type: application/json');
        echo json_encode($data);
    }
// Mobile Verity OTP End //


// Resend OTP Start //
public function resend_otp()
        {
            $mobile = $this->input->post("mobile");
            //$id = $this->input->post("temp_id");

            $temp['Mobile']=$mobile;
            $temp['OTP']=$this->generatePIN();
            $this->db->where('Mobile',$mobile);
            $this->db->delete('gc_temp_user');
            $this->db->where('Mobile',$mobile);
            if($this->db->insert('gc_temp_user',$temp)){
                $sms_content="Please Use This OTP : ".$temp['OTP'];

                // $sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=ZmQxNzA1OWEyZTE&mobiles='.$mobile.'&message='.$sms_content.'&sender=PKSEVA&type=1&route=2';
                $sms_url='http://bulksmscoimbatore.co.in/sendsms?uname=mequals&pwd=mequals@123&senderid=BUGFIX&to='.$mobile.'&msg='.urlencode($sms_content).'&route=SID';

                $ch = curl_init($sms_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
                $response=curl_exec($ch);
                // curl_close($ch);

                if (curl_errno($ch)) {
                    $error = curl_error($ch);
                }
                $curl_data = explode(',', $response);
                curl_close($ch);
                
            }

            $verify['content']  =  'Please Enter OTP';
            $verify['status']   =  '0';
            $verify['mobile']   =  $mobile;
            

             $data['data'] = ['Content'             => $verify['content'],
                         'status'                   => $verify['status'],
                         'mobile'                   => $verify['mobile'],
                         'value'                    => "Success" ];
        header('Content-Type: application/json');
        echo json_encode($data);

        
        }
// Resend OTP END //

// Expiry OTP Start //
public function expiry_otp()
        {
            $mobile         = $this->input->post("mobile");
            $this->db->where('Mobile',$mobile);
            $query          = $this->db->delete('gc_temp_user');
            $temp['content']='OTP Expired!';
            $temp['status'] =3;


            $data['data'] = ['content'             => $temp['content'],
                            'status'               => $temp['status'],
                            'value'               => "Success"];
        header('Content-Type: application/json');
        echo json_encode($data);
    }
// Expiry OTP End //

// Verity OTP Start //
// public function verify_otp1()
//         {
//             $mobile          = $this->input->post("mobile");
//             $otp             = $this->input->post("otp");
//             $this->db->select('*');
//             $this->db->where('OTP',$otp);
//             $this->db->where('Mobile',$mobile);
//             $query           = $this->db->get('gc_temp_user');
//             if ($query->num_rows() > 0) {
//                $this->db->where('OTP',$otp);
//                $this->db->where('Mobile',$mobile);
//                $query          = $this->db->delete('gc_temp_user'); 
//             $verify['content'] =  'OTP Verified!';
//             $verify['status']  =  '1';
//             $verify['mobile']  =  $mobile;
//             $verify['value']   =  "Success";

//         }else{
//             $verify['content'] =  'Invalid OTP!';
//             $verify['status']  =  '0';
//             $verify['mobile']  =  $mobile;
//             $verify['value']   =  "Failure";
//         }

//             $data['data'] = ['content'              => $verify['content'],
//                              'status'               => $verify['status'],
//                              'mobile'               => $verify['mobile'],
//                             'value'                 => $verify['value']];
//         header('Content-Type: application/json');
//         echo json_encode($data);
//     }
// Verity OTP End //


public function get_pincode_details()
        {
            $pincode         = $this->input->post("pincode");

        $this->db->select('area.id as taluk_id,area.area_name as taluk_name,city.id as City_id,city.city_name as City_name,state.id as State_id,state.state_name as State_name,country.id as Country_id,country.country_name as Country_name');

        $this->db->from('gc_areas as area');
        $this->db->join('gc_cities as city', 'city.id = area.city_id', 'left');
        $this->db->join('gc_states as state', 'state.id = area.state_id', 'left');
        $this->db->join('gc_countries as country', 'country.id = area.country_id', 'left');
        $this->db->where("area.Pincode",$pincode);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $temp['pincode'] = $query->result_array();
            $temp['value']= "Success";
        }else{
        $temp['pincode']= "";
        $temp['value']= "Failure";

    }

            // $this->db->where('ID',$id);
            // $query          = $this->db->delete('gc_temp_user');
            // $temp['content']='OTP Expired!';
            // $temp['status'] =3;

            $data['data'] = ['pincode'             => $temp['pincode'],
                            'value'             => $temp['value']];
        header('Content-Type: application/json');
        echo json_encode($data);
    }

public function get_topup_details()
    {
        $topup = $this->input->post("topup");
        $temp['topup'] =  $this->Membership_model->get_topup_details($topup);
        if($temp['topup']!=0){

        header('Content-Type: application/json');
        $data['data'] = ['topup'              => $temp['topup'],
                            'value'    =>"Success"];
                        }else{
                            $data['data'] = ['topup'              => $temp['topup']="",
                            'value'    =>"Failure"];
                        }
          header('Content-Type: application/json');                   
        echo json_encode($data);
    }

    
public function add()
    {
        $member = $this->input->post("member");
        $photo = $this->input->post("Photo");
        $upload1 = $this->input->post("upload1");
        $upload2 = $this->input->post("upload2");
        $upload3 = $this->input->post("upload3");
        $address_data = $this->input->post("address_data");
        $nominee_data = $this->input->post("nominee_data");
        $bank_data = $this->input->post("bank_data");
        $upload_rows = $this->input->post('upload_rows');
        $upload_rows=explode(',',$upload_rows);

        foreach($upload_rows as $val){
        $upload_data['upload_data_'.$val] = $this->input->post('upload_data_'.$val);

        $profile_name = 'upload'.$val;

        // Membership Code
        $pan=$upload_data["upload_data_1"]["Document_no"];

        if(!empty($pan)){
        $newpan = substr($pan, -5);
        }
        $newmob = substr($member['Mobile'], -5);
        $Membership_code=$newpan.$newmob;

        $docs_name = $this->Membership_model->member_profile_attachment_1($Membership_code,$profile_name,$upload_data['upload_data_'.$val]['Document_type']);

        $upload_data['upload_data_'.$val]['Folder_name']=$Membership_code;
        $upload_data['upload_data_'.$val]['Document_name']=$docs_name;
            }
        // $Upload_data = $this->input->post("Upload_data");
        $contract_data = $this->input->post("contract_data");

        $unique_id = $this->input->post('unique_id');
        $unique=explode(',',$unique_id);
        foreach($unique as $val1){
             $payment_data['payment_data_'.$val1] = $this->input->post('payment_data_'.$val1);
            }
        // $payment_data = $this->input->post("payment_data");
        $agreement_data = $this->input->post("agreement_data");

        $events1 = $this->Membership_model->add_membership($member,$address_data,$nominee_data,$bank_data,$upload_data,$contract_data,$payment_data,$agreement_data,$photo,$upload1,$upload2,$upload3);

        redirect('membership/Membership/members');

        // var_dump($agreement_data);
    }



public function tree_view()
    {
        $this->load->model('member/Membership_model');
        $id=$this->input->get('id');
        $template['page']            ='membership/tree_view';
        $template['member']          =  $this->Membership_model->get_parent_detail($id);
        // var_dump($template['member']);die();
        $template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
        $template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
        // var_dump($template['child_parent_binary']);
        $this->load->view('template',$template);
        
}

public function tree()
{
$template['page']            ='membership/search_tree_view';
$this->load->view('template',$template);
}

// public function get_tree_details()
//     {   
//         $id = $this->input->post("mobile"); 

//         $this->load->model('member/Membership_model');
//         $template['member_id']   =  $this->Membership_model->get_member_detailbyid($id);
//         $template['member']   =  $this->Membership_model->get_parent_detail($template['member_id'][0]['Membership_ID']);
        
       
//         $template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
//         $template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
//        // var_dump($template['child_parent_binary']);die();
//         $this->load->view('membership/ajax_tree',$template);
//     }


public function get_tree_details()
    {   
        $id = $this->input->post("mobile"); 
        
        $this->load->model('member/Membership_model');
        $template['member_id']   =  $this->Membership_model->get_member_detailbyid($id);
        $template['member']   =  $this->Membership_model->get_parent_detail($template['member_id'][0]['Membership_ID']);
        if(!empty($template['member'] )){
        $member_refer= $template['member'][0]['Reference_ID'];
        $template['member_refer1']  =  $this->Membership_model->get_parent_referer($member_refer);
        if(!empty($template['member_refer1'])){
        $template['member_refer'] =$template['member_refer1'][0]['Membership_code'];
    }else{
         $template['member_refer'] =0;
    }
    }else{
        $template['member_refer']=0;
    }
      // echo ($template['member'][0]['Membership_code']);
        $template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
        $template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
       // var_dump($template['member']);die();
        $this->load->view('membership/ajax_tree',$template);
    }

public function update_bank_status()
    {
        $bank_verify = $this->input->post("bank_verify");
        $Membership_ID = $this->input->post("Membership_ID");
        $temp['banks'] =  $this->Membership_model->update_bank_status($bank_verify,$Membership_ID);
        echo  $temp['banks'];
    }
        
    public function update_document_status()
    {
        $upload_rows = $this->input->post('upload_rows');
        $Membership_ID = $this->input->post('Membership_ID');

        $upload_rows=explode(',',$upload_rows);
        foreach($upload_rows as $val){
             $upload_data['doc_verify_'.$val]                  = $this->input->post('doc_verify_'.$val);
             $temp['docs'] =  $this->Membership_model->update_document_status($upload_data['doc_verify_'.$val],$Membership_ID);
         }
            
        echo 1;
}

public function contract()
    {
        $Membership_ID = $this->input->get("id");  

        $template['page']            ='contract/contract';
        $template['Membership_code']            =$Membership_ID;
        
        $this->load->view('template',$template);
    }


public function Activate_member()
        {
        $Membership_ID = $this->input->post("Membership_ID");  
        $Contract_ID = $this->input->post("Contract_ID");
        $result =  $this->Membership_model->Activate_member_contract($Membership_ID,$Contract_ID);
        echo $result;
    }

 public function sms()
        {
            $mobile="8122325955";
        $sms_content="Hi Satheesh I Love U...";
        $sms_url='http://bulksmscoimbatore.co.in/sendsms?uname=mequals&pwd=mequals@123&senderid=BUGFIX&to='.$mobile.'&msg='.urlencode($sms_content).'&route=SID';

                $ch = curl_init($sms_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
                $response=curl_exec($ch);
                // curl_close($ch);

                if (curl_errno($ch)) {
                    $error = curl_error($ch);
                }
                $curl_data = explode(',', $response);
                curl_close($ch);
    }   

public function check()
    {   
        $Membership_ID=17;
        $membership[0]['Reference_ID']=6;
        $level['Level_ID']=1;
        $Contract_ID=16;
            $this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$Contract_ID, 'left');
            $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
            $this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();
            var_dump($level_details);
}

public function generatePIN($digits = 4){
    $i = 0; //counter
    $pin = ""; //our default pin is blank.
    while($i < $digits){
        //generate a random number between 0 and 9.
        $pin .= mt_rand(0, 9);
        $i++;
    }
    return $pin;
}

public function check1() {
        $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',2);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);
            $final_days=[];
            $final_days1=[];
            foreach($week_days as $value){
                $new = [];
                for($i = 1;$i<=12;$i++){
                    $days = $this->getDays(date('Y'),$i,$value);
                    $final[] = $days;
                    foreach($days as $val){
                        //$final_days1=array('Date' => $val);
                        array_push($final_days,$val);
                        // array_push($final_days,$value);
                    // array_push($final_days1,$final_days);

                    }
                    
                }
                    
                // array_push($final_days)
            }
            if(in_array(date('Y-m-d'), $final_days)){
            $this->db->where('Date',date('Y-m-d'));
            $query = $this->db->get('gc_individual_calendar');
            if ($query->num_rows() > 0) {
                //echo "not insert";
            }else{
                // Get Transaction Table
                $this->db->select('transaction.*');
                $this->db->from('gc_transaction as transaction');
                $this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
                $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');

                $this->db->where('transaction.Transaction_status',1);
                $this->db->where('member.Status',6);
                $this->db->where('contract.Withdrawn_status',5);
                $query1 = $this->db->get();
                if ($query1->num_rows() > 0) {
                    $transaction=$query1->result_array();
                    foreach($transaction as $tran){

                    $commision_data=array(
                            'Company_id'       => $this->session->userdata('CompanyId'),
                            'Branch_id'        => $this->session->userdata('CompanyId'),
                            'Transaction_ID'   => $tran['Transaction_ID'],
                            'Membership_ID'    => $tran['Membership_ID'], 
                            'Contract_ID'      => $tran['Contract_ID'], 
                            'Transaction_type' => $tran['Transaction_ID'],
                            'Commision_date'  => date('Y-m-d'), 
                            'Remarks'          => '', 
                            'Created_by'       => $this->session->userdata('UserId')
                            );
                    $this->db->insert('gc_member_commission',$commision_data);
                    $commision_id=$this->db->insert_id();

                    // Get Transaction detail Table
                    $this->db->select('*');
                    $this->db->where('Status',1);
                    $this->db->where('Transaction_ID',$tran['Transaction_ID']);
                    $query2 = $this->db->get('gc_transaction_details');
                      if ($query2->num_rows() > 0) {
                        $transaction_detail=$query2->result_array();
                        foreach($transaction_detail as $tran_det){
                            $commision_detail_data=array(
                            'Company_id'               => $this->session->userdata('CompanyId'),
                            'Branch_id'                => $this->session->userdata('CompanyId'),
                            'Commission_ID'            => $commision_id,
                            'Transaction_ID'           => $tran_det['Transaction_ID'],
                            'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
                            'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
                            'Membership_ID'            => $tran_det['Membership_ID'], 
                            'Contract_ID'              => $tran_det['Contract_ID'], 
                            'Commision_type'           => $tran_det['Commision_type'],
                            'Commision_date'          => date('Y-m-d'), 
                            'Amount'                   => $tran_det['Amount'], 
                            'Commision'                => $tran_det['Commision'],
                            'Remarks'                  => '', 
                            'Created_by'               => $this->session->userdata('UserId')
                            );
                            $this->db->insert('gc_member_commission_details',$commision_detail_data);

                        }

                      }
            }

          }
        }

        }
    }
}

    public function getDays($y,$m,$d){ 
    $date = "$y-$m-01";
    $first_day = date('N',strtotime($date));
    $first_day = $d - $first_day + 1;
    $last_day =  date('t',strtotime($date));
    $days = array();
    for($i=$first_day; $i<=$last_day; $i=$i+7 ){
        $days[] = $y.'-'.$m.'-'.$i;
        //$days[] = implode(',',$days);
    }
    return $days;
}



}
