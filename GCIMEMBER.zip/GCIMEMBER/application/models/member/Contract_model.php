<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Contract_model extends CI_Model { 

    function getall_bank() {

        $this->db->select('*');
        $this->db->where('Status',1);
        $this->db->order_by("ID", "DESC");
        $query = $this->db->get('gc_bank');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function get_all_contract_id($id) {

        $this->db->select('*');
        $this->db->where('Membership_ID',$id);
        $this->db->where('Contract_status',6);
        $this->db->where('Request_status!=',2);
        $query = $this->db->get('gc_member_franchisee_contract');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

   function get_contract_by($id) {

    $this->db->select('member.*,topup.Franchise');
    $this->db->from('gc_member_franchisee_contract as member');
    $this->db->join('gc_member_topup as topup', 'topup.ID = member.Topup_ID', 'left');
    $this->db->where('member.Contract_ID',$id);

    $query = $this->db->get();
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    function change_payment_status($Membership_ID,$Member_payment_ID) {
    $data['Payment_status']=6;

        $this->db->where('Member_payment_ID',$Member_payment_ID);
        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->update('gc_member_payments',$data);

        $data1['Status']=4;
        $this->db->where('Membership_ID',$Membership_ID);
        if($this->db->update('gc_membership',$data1)){
            return 1;}else{
                return 0;
            }
        }
   

    function get_contract_details($mobile) {

        $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Photo,member.Mobile,contract.*,type.Membership_type as Membership_name,banks.Status as bank_status,contract.Start_date,contract.End_date,aggrement.Delivery_mode,aggrement.Referer_name,contract.Request_status,pay.payout_type as Payout_type,contract.Amount as Contract_amount');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        // $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_ID', 'left');
        // $this->db->join('gc_payout_type as payout', 'payout.id = contract.Old_payout_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
        $this->db->join('gc_member_banks as banks', 'banks.Member_bank_ID = member.Membership_ID', 'left');
        $this->db->join('gc_payout_type as pay', 'pay.id = member.Payout_ID', 'left');

        $this->db->join('gc_member_agreement as aggrement', 'aggrement.Membership_ID = member.Membership_ID', 'left');
        $this->db->group_by('contract.Contract_ID');
        // $this->db->where('contract.Request_status!=',2);
        
        $this->db->where('contract.Membership_ID',$mobile);
        // $this->db->where('member.Membership_ID',$mobile);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function get_contract_details_withdraw($mobile,$by) {

        $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Photo,member.Mobile,contract.*,type.Membership_type as Membership_name,topup.Franchise,payout.Payout_type,topup.Value,topup.Validity,topup.Return,banks.Status as bank_status,contract.Start_date,contract.End_date,aggrement.Delivery_mode,aggrement.Referer_name,contract.Request_status');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = contract.Old_payout_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
        $this->db->join('gc_member_banks as banks', 'banks.Member_bank_ID = member.Membership_ID', 'left');

        $this->db->join('gc_member_agreement as aggrement', 'aggrement.Membership_ID = member.Membership_ID', 'left');
        $this->db->group_by('contract.Contract_ID');
        $this->db->where('contract.Request_status',2);
        
        $this->db->where('member.Membership_ID',$mobile);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function get_payments_details($Membership_ID,$Contract_ID) {

         $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Membership_code,payments.*,contract.Contract_ref_no,mode.Payment_mode,bank.Bank_name,topup.Franchise');
        $this->db->from('gc_member_payments as payments');
        $this->db->join('gc_membership as member', 'member.Membership_ID = payments.Membership_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = payments.Contract_ID', 'left');
        $this->db->join('gc_payment_mode as mode', 'mode.ID = payments.Payment_type_ID', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_ID', 'left');

        $this->db->join('gc_bank as bank', 'bank.ID = payments.Bank_ID', 'left');
        $this->db->where('payments.Membership_ID',$Membership_ID);
        $this->db->where('payments.Contract_ID',$Contract_ID);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    // function get_document_details($Membership_ID,$Contract_ID) {
    //     // var_dump($Membership_ID);
    //     $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Photo,member.Mobile,contract.*,type.Membership_type as Membership_name,topup.Franchise,payout.Payout_type,topup.Value,topup.Validity,topup.Return,banks.Status as bank_status,contract.Start_date,contract.End_date,aggrement.Delivery_mode,aggrement.Referer_name,aggrement.Agreement_ID,aggrement.Status as agreementstatus,aggrement.Courier_name');
    //     $this->db->from('gc_membership as member');
    //     $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
    //     $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_ID', 'left');
    //     $this->db->join('gc_payout_type as payout', 'payout.id = contract.Old_payout_ID', 'left');
    //     $this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
    //     $this->db->join('gc_member_banks as banks', 'banks.Member_bank_ID = member.Membership_ID', 'left');

    //     $this->db->join('gc_member_agreement as aggrement', 'aggrement.Membership_ID = member.Membership_ID', 'left');
        
    //     // $this->db->where('member.Membership_ID',$Membership_ID);
    //     $this->db->where('aggrement.Agreement_ID',$Contract_ID);
    //     $query = $this->db->get();
    //     if ($query->num_rows() > 0) {
    //         return  $query->result_array();
    //     }
    //     return NULL;
    // }



    function get_document_details($Membership_ID,$Contract_ID) {
        // var_dump($Membership_ID);
        $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Photo,member.Mobile,aggrement.Delivery_mode,aggrement.Referer_name,aggrement.Agreement_ID,aggrement.Status as agreementstatus,aggrement.Courier_name,contract.Contract_ref_no,aggrement.Created_date,aggrement.Updated_date');
        $this->db->from('gc_membership as member');

        $this->db->join('gc_member_agreement as aggrement', 'aggrement.Membership_ID = member.Membership_ID', 'left');

       $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');

        $this->db->where('contract.Contract_ID',$Contract_ID);
        $this->db->group_by('contract.Contract_ID');

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    public function get_all_withdraw()
    {
        $this->db->select('*');
        $this->db->where('Status',1);
        $query = $this->db->get('gc_withdraw');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


}




   
