<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Packages extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
        $this->load->model('master/Packages_model');
    }

    public function index()
    {
        $template['page']='master/packages/view_packages';
        $template['packages'] =  $this->Packages_model->getallpackages();
        $template['level'] =  $this->Packages_model->getall_levels();
        $template['grade'] =  $this->Packages_model->getall_grades1();
        $this->load->view('template',$template);
    }

    public function add_package()
    {

        $data = $this->input->post('package');
        $data['Company_id']=$this->session->userdata('CompanyId');
        $data['Branch_id']=$this->session->userdata('CompanyId');
      // var_dump($data);die();
        $this->db->insert('gc_packages',$data);
        $this->session->set_flashdata('country_success', 'Added');
        redirect('master/Packages');
    }

    public function edit_package()
    {
        $data = $this->input->post('package');
        $id = $this->input->post('ID');
        // var_dump($data);die();
        $this->db->where('ID',$id);
        $this->db->update('gc_packages',$data);
        $this->session->set_flashdata('country_success', 'Updated');
        redirect('master/Packages');
    }

    public function delete_package($id)
    {

        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_packages',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Packages');
    }

            public function get_grades()
    {
      $id = $this->input->post('level');

      $data = $this->Packages_model->get_all_grades($id);
    if(isset($data)){

            echo '<option value="">Select Grade</option>';      
           
            
            foreach ($data as $value)  {

            echo '<option value="'.$value['ID'].'">'.$value['Grade_name'].'</option>';
                
            }}else{

            echo '<option value="">Select Grade</option>';            
          }
    }



    
}
