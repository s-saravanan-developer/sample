<script>
   <?php
         if ($this->session->flashdata('tenant_success')) 
         {
            echo "var data = ' ".$this->session->flashdata('tenant_success')."';";
            echo "success(data);";
         }
         if ($this->session->flashdata('tenant_error')) 
         {
            echo "var data = ' ".$this->session->flashdata('tenant_error')."';";
            echo "duplicate(data);";
         }
   ?>
</script>
<div class="content-wrapper">
   <div class="content">
      <header class="page-header">
         <div class="d-flex align-items-center">
            <div class="mr-auto">
               <h1 class="separator">Tenant Groups  </h1>
               <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i></a></li>
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard">Tenant Management</a></li>
                     <li class="breadcrumb-item active" aria-current="page">Tenant Groups</li>
                  </ol>
               </nav>
            </div>
            <ul class="actions top-right">
               <li class="dropdown">
                  <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                  <i class="la la-ellipsis-h"></i>
                  </a>
                  <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
                     <div class="dropdown-header">
                        Quick Actions
                     </div>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-clockwise"></i> Refresh
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-gear"></i> Manage Widgets
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-cloud-download"></i> Export
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-help"></i> Support
                     </a>
                  </div>
               </li>
            </ul>
         </div>
      </header>
      <section class="page-content container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="card">
                  <h5 class="card-header">
                     <div style="float: left;">
                        Manage Tenant Groups	
                     </div>
                     <div style="float: right;">
                       <?php //if($this->Common_model->add_permission(Tenant_Group_global) != 0){ ?>
                        <button type="button" class="btn btn-success  btn-floating" data-toggle="tooltip" data-placement="top" data-original-title="Add New Tenant Group">
                           <p class="text-white" data-toggle="modal" data-target="#addusertype">
                        Add New Tenant Group</p>
                        </button>
                         <?php //} ?>
                     </div>
                  </h5>
                  <div class="card-body">
                     <table id="bs4-table" class="table table-striped table-bordered table-responsive" style="width:100%">
                        <thead>
                           <tr>

                              
                               <th class="text-center" style="width: 2%">
                                                                 <input type="checkbox" name="checkbox" class="checkbox" id="select_all" /> 
                                                             </th>
                              
                              
                              <th style="width: 2%">S.No</th>
                             
                              <th style="width: 12%">Action</th>
                              <th style="width: 66%">Tenant group Name</th>
                              <th style="width: 20%">Status</th>                              
                           </tr>
                        </thead>
                        <tbody>
                           <?php 
                              if (!empty($tenant_group)) {
                                  $s = 1;
                                  foreach ($tenant_group as $list) {
                                      ?>
                           <tr>

                              
                               <td><input type="checkbox" name="checkbox" class="checkbox boxischecked" value="<?php echo ucfirst($list['id']); ?>"  /></td>
                              
                              
                              <td ><?php echo $s; ?></td>
                              <td>    
                               <?php //if($this->Common_model->edit_permission(tenant_group_global) != 0){ ?>                     
                                 <a href="#" onclick="edit_customer('<?php echo ucfirst($list['id']); ?>','<?php echo ucfirst($list['tenant_group_name']); ?>','<?php echo ucfirst($list['status']); ?>','<?php echo ucfirst($list['description']); ?>')" id="usertypeedit" class="btn btn-info btn-sm editusertype" data-toggle="modal" data-target="#editusertype"><i class="zmdi zmdi-edit zmdi-hc-fw"   style="
                                    font-size: 17px;
                                    color:  white;
                                    "data-toggle="tooltip" data-placement="top" data-original-title="Edit"></i></a> 
                                     <?php //} ?>
                                      <?php //if($this->Common_model->delete_permission(tenant_group_global) != 0){ ?>
                                 <a href="" onclick="delete_customer('<?php echo ucfirst($list['id']); ?>','<?php echo ucfirst($table_name); ?>')" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deletemodel"><i class="zmdi zmdi-delete zmdi-hc-fw" style="
                                    font-size: 17px;
                                    color:  white;
                                    "data-toggle="tooltip" data-placement="top" data-original-title="Delete"></i></a>   
                                     <?php //} ?>                                   
                              </td>
                              <td class="s_no"><?php echo ucfirst($list['tenant_group_name']); ?></td>
                              <td><span class="badge badge-<?php echo ($list['status'] == 1) ? 'success' : 'danger'; ?>"><?php echo ($list['status'] == 1) ? 'Active' : 'In-Active'; ?></span></td>
                              
                           </tr>
                           <?php
                              $s++;
                              }
                              }
                              ?>
                        </tbody>
                     </table>
                  </div>

                <div class="card-footer bg-light">
                   <?php //if($this->Common_model->delete_permission(tenant_group_global) != 0){ ?>
                               <button type="button" class="btn btn-danger delbtn"  data-toggle="modal" data-target="#deletemodel1">Delete</button>
                                <?php //} ?>
                                 <?php //if($this->Common_model->others_permission(tenant_group_global) != 0){ ?>
                               <button type="" class="btn btn btn-success   delbtn"  data-toggle="modal" data-target="#active_all_model">Active</button>
                               <button type="" class="btn btn btn-info delbtn" data-toggle="modal" data-target="#deactive_all_model">In-Active
                               </button>
                               <button class="btn btn-primary region_input no-display" data-toggle="modal" data-target="#multiexport">Export Excel</button>
                                <button class="btn btn-primary region_input1" data-toggle="modal" data-target="#Export">Export Excel</button>
                                 <?php //} ?>
                               </div>
                  
                  
               </div>
            </div>
         </div>
      </section>
   </div>
</div>
</div>	
<!-- Model Execution -->
<!-- LOCATION RIGHT SIDE -->
<div id="addusertype" class="modal modal-right-side fade" data-backdrop="static" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content" >
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel6">Customer Groups</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <div class="modal-body">
            <div class="row">
               <div class="col">
                  <div class="card">
                     <h5 class="card-header">Add Customer Group</h5>
                     <?php
                        $attributes = array('id' => 'login_form','data-toggle' => 'validator');
                        echo form_open('tenant/Tenant/tenant_group_add', $attributes);
                        ?> 
                     <div class="card-body">
                        <div class="form-body">
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Tenant Group Name <span style="color:red">*</span></label>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-accounts zmdi-hc-fw"></i></span>
                                       </div>
                                    <input type="text" class="form-control check_data" onkeyup="duplicate_check()" name="tenantgroup[tenant_group_name]" id="inputName" placeholder="Tenant Group Name" required>
                                    
                                 </div>
                                 <div class="text-center duplicate-occur no-display">
                                           <code>This Tenant Group Name Is Already Used</code>
                                        </div>
                              </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="col-form-label-lg" for="largeInput">Status</label>
                                     <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-equalizer zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control" name="tenantgroup[status]" id="defaultSelect" required="">
                                       <option value="1">Active</option>
                                       <option value="2">In-Active</option>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                                   <div class="form-group">
                                       <label for="exampleFormControlTextarea1">Description</label>
                                       <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Enter Description" name="tenantgroup[description]" rows="3"></textarea>
                                    </div>
                                                </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success  submit" id="addcustomergroup">Save changes</button>
         </div>
         </form>
      </div>
   </div>
</div>
<!-- Editing -->
<!-- LOCATION RIGHT SIDE -->
<div class="modal modal-right-side fade" id="editusertype" data-backdrop="static" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content" >
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel6">Tenant Group</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <div class="modal-body">
            <div class="row">
               <div class="col">
                  <div class="card">
                     <h5 class="card-header">Edit Tenant Group</h5>
                     <?php
                        $attributes = array('id' => 'login_form','data-toggle' => 'validator');
                        echo form_open('tenant/Tenant/tenant_group_edit', $attributes);
                        ?>
                     <div class="card-body">
                        <div class="form-body">
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Tenant Group Name <span style="color:red">*</span></label>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-accounts zmdi-hc-fw"></i></span>
                                       </div>
                                    <input type="hidden" class="tenant_id" name="tenant_group_id" >
                                    <input type="text" class="form-control tenant_name check_dataedit" onkeyup="duplicate_checkedit()" name="tenantgroup[tenant_group_name]" id="inputName" placeholder="Tenant Group Name" required >
                                 </div>
                                 <div class="text-center duplicate-occuredit no-display">
                                           <code>This Tenant Group Name Is Already Used</code>
                                        </div>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="col-form-label-lg" for="largeInput">Status</label>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-equalizer zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control status" name="tenantgroup[status]" id="defaultSelect" required="">
                                       <option value="1">Active</option>
                                       <option value="2">In-Active</option>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                                   <div class="form-group">
                                       <label for="exampleFormControlTextarea1">Description</label>
                                       <textarea class="form-control description"  placeholder="Enter Description" id="exampleFormControlTextarea1" name="tenantgroup[description]" rows="3"></textarea>
                                    </div>
                             </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success  submit" id="edittenantgroup">Update</button>
         </div>
         </form>	
      </div>
   </div>
</div>
<!-- BASIC MODAL DEMO -->
<div class="modal fade" id="deletemodel" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Delete</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <form action="<?php echo base_url();?>tenant/Tenant/delete" method="POST">
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
               <input type="hidden" name="url" value="Tenant">
               <input class="delete_id" type="hidden" name="tenant_id">
               <input class="table_name" type="hidden" name="table_name">						
            </div>
            <div class="delete-footer">
               <button type="submit" class="btn btn-primary">Yes, delete it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>						
            </div>
         </form>
      </div>
   </div>
</div>



<div class="modal fade" id="deletemodel1" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Delete</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <button type="submit" id="del_all" class="btn btn-primary">Yes, delete it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
        
      </div>
   </div>
</div>


<div class="modal fade" id="deactive_all_model" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">In-Active</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <button type="submit" id="deactive_all" class="btn btn-primary">Yes, In-Active it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
        
      </div>
   </div>
</div>


<div class="modal fade" id="active_all_model" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Active</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <button type="submit" id="active_all" class="btn btn-primary">Yes, Active it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
        
      </div>
   </div>
</div>



<div class="modal fade" id="Export" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Export</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <a 
              id="active_all" class="btn btn-primary export_link" data-dismiss="modal">Yes, Export it!</a>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
      </div>
   </div>
</div>

<div class="modal fade" id="multiexport" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Excel Export</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <button  type="submit" id="active_all" class="btn btn-primary multi_export" data-dismiss="modal">Yes, Export it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
        
      </div>
   </div>
</div>



<script type="text/javascript">
   function edit_customer(val,val1,val2,val3){
      $('.duplicate-occuredit').addClass('no-display');
      $('#edittenantgroup').removeAttr( "disabled", );
   	$('.tenant_id').val(val);
   	$('.tenant_name').val(val1);		
      $('.status').val(val2);
   	$('.description').val(val3);
   
   }
   
   function delete_customer(val,val1){
   	$('.delete_id').val(val);
   	$('.table_name').val(val1);
   	//alert($('.delete_id').val(val));
   }

      function duplicate_check() {
        // alert("hi");
      var check_data = $('.check_data').val();
      // alert(check_data);
      var result = '';
         $.ajax({
           type: "POST",
           url: "<?php echo base_url(); ?>master/location/duplicate_check",
           data: {data: check_data,table_name: 'prop_tenant_group',colum: 'tenant_group_name'},
           cache: true,
           async: false,
           success: function(data){
            // alert(data);
            result = data;
           }
         });
         if(result == 1){
            $('.duplicate-occur').removeClass('no-display');
            
            $('#addcustomergroup').attr( "disabled","disabled");
            return false;
        }else{
            $('.duplicate-occur').addClass('no-display');
            $('#addcustomergroup').removeAttr( "disabled", );
            return true;
        }
         
   }

      function duplicate_checkedit() {
        // alert("hi");
      var id = $('.tenant_id').val();
      var check_data = $('.check_dataedit').val();
      // alert(check_data);
      var result = '';
         $.ajax({
           type: "POST",
           url: "<?php echo base_url(); ?>master/location/duplicate_checkedit",
           data: {data: check_data,table_name: 'prop_tenant_group',colum: 'tenant_group_name',id:id},
           cache: true,
           async: false,
           success: function(data){
            
            result = data;
           }
         });
         if(result == 1){
            $('.duplicate-occuredit').removeClass('no-display');
            
            $('#edittenantgroup').attr( "disabled","disabled");
            return false;
        }else{
            $('.duplicate-occuredit').addClass('no-display');
            $('#edittenantgroup').removeAttr( "disabled", );
            return true;
        }
         
   }
</script>



<script type="text/javascript">

   // To check all the boxes

$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
});

// To pass the value to the Controller

   $(document).ready(function() {
        $("#del_all").click(function(){
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function(){            
                favorite.push($(this).val());
            });
            //alert("Selected Countries are: " + favorite.join(","));
             $.ajax({
                        url: '<?php echo base_url() ?>tenant/Tenant/delete_checkbox',
                        type: 'post',
                        data: {id:favorite.join(",")},
                    }).done(function(data) {
                 
                       location.reload();



                    });
        });
    });

    $(document).ready(function() {
        $("#active_all").click(function(){
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function(){            
                favorite.push($(this).val());
            });
            //alert("Selected Countries are: " + favorite.join(","));
             $.ajax({
                        url: '<?php echo base_url() ?>tenant/Tenant/active_all_checkbox',
                        type: 'post',
                        data: {id:favorite.join(",")},
                    }).done(function(data) {
                       location.reload();



                    });
        });
    });

     $(document).ready(function() {
        $("#deactive_all").click(function(){
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function(){            
                favorite.push($(this).val());
            });
            //alert("Selected Countries are: " + favorite.join(","));
             $.ajax({
                        url: '<?php echo base_url() ?>tenant/Tenant/deactivate_all_checkbox',
                        type: 'post',
                        data: {id:favorite.join(",")},
                    }).done(function(data) {
                       location.reload();



                    });
        });
    });


$('.delbtn').prop('disabled', true);

$('.checkbox').change(function(){
    $('.delbtn').prop('disabled', $('.checkbox:checked').length == 0);
})


$('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;

            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
                
            });
        }
    });
$('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
             $('.region_input1').addClass('no-display');
             $('.region_input').removeClass('no-display');
        }else{
            $('#select_all').prop('checked',false);
             $('.region_input1').removeClass('no-display');
             $('.region_input').addClass('no-display');
        }
    });
$('.boxischecked').on('click',function(){

     if ($(this).prop('checked') == true) {
                $('.region_input1').addClass('no-display');
                $('.region_input').removeClass('no-display');
            } else {
                $('.region_input1').removeClass('no-display');
                $('.region_input').addClass('no-display');
            }

            
            checked_checkbox = Number($('input[type=checkbox].boxischecked:checked').length);
            // alert(checked_checkbox);
            if (checked_checkbox!=0) {
                $('.region_input1').addClass('no-display');
                $('.region_input').removeClass('no-display');
            } else {
                $('.region_input1').removeClass('no-display');
                $('.region_input').addClass('no-display');
            }
  });
$('.multi_export').click(function(){

             var favorite = [];
             $.each($("input[name='checkbox']:checked"), function(){            
                 favorite.push($(this).val());
             });

    window.location = "<?php echo base_url();?>export/multi_export_tenant_group_multi?url="+favorite;

});

$('.export_link').click(function(){
            // alert();
             window.location ="<?php echo base_url();?>export/export_tenant_group";
});
</script>

