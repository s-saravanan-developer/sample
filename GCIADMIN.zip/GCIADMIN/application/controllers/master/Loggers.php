<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Loggers extends CI_Controller {

	public function __construct() {
        parent::__construct();
        if ($this->session->userdata('is_logged_in') == '') {            
            redirect('login');
            session_destroy();
        }
        $this->load->model('master/Loggers_model');
        $this->load->model('master/Users_model');
    }

    /**
     * [Units Page]
     * @return [countty] Main Page
     * 
     */
	public function index()
	{		
		$template['users'] 			= $this->Loggers_model->get_all_users();
		$template['table_name'] 	=	"login_history_table";
		$template['page']			=	'master/loggers/log_history';
        $this->load->view('template',$template);

	}

	public function log_attempts()
	{
		$template['table_name'] 	=	"mpro_login_attempt";
		$template['attempts'] 			=	$this->Loggers_model->get_all_log_apptempts();
		$template['page']			=	'master/loggers/log_attempt';
        $this->load->view('template',$template);
	}

	public function get_history()
	{
		// $template['table_name'] 	=	"mpro_login_attempt";
		$id = $this->input->post('id');
		
		$template['history'] =	$this->Loggers_model->get_all_loggers_history($id);
		
		$this->load->view('master/loggers/ajax_loggers',$template);
}	

	public function modification()
	{
		$template['modification'] =	$this->Loggers_model->get_all_modifications();
		$template['page']			=	'master/loggers/modification';
        $this->load->view('template',$template);
}

	public function error_logs()
	{
		$template['error_logs'] =	$this->Loggers_model->get_all_error_logs();
		$template['page']			=	'master/loggers/error_logs';
        $this->load->view('template',$template);
	}

	public function clear_log_list()
	{
        $this->db->empty_table('logs');
        redirect('master/Loggers/error_logs');
	}


}



?>