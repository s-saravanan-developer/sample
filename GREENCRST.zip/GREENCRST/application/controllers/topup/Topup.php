<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Topup extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();
        }
        $this->load->model('member/Membership_model');
        $this->load->model('topup/Topup_model');
    }
	public function index()
	{
        
		$template['page']='topup/view_member_upgrade'; 
        $template['payment_mode']    =  $this->Membership_model->getall_payment_modes();
        $template['bank']            =  $this->Membership_model->getall_bank();
        $template['topup']           =  $this->Membership_model->getall_topups();
        $template['payout']          =  $this->Membership_model->getall_payouts_franchasie();
        $template['membership_type'] =  $this->Membership_model->getall_membershiptype();
        $template['invest_type']     =  $this->Membership_model->getall_invest_type();
        $this->load->view('template',$template);
		
	}

    public function topup()
    {
        
        $template['page']='topup/view_member_topup';
        $template['payout']    =  $this->Membership_model->getall_payment_modes();
        $this->load->view('template',$template);
        
    }

    public function withdraw_request()
    {
        
        $template['page']='topup/view_member_history';
        // $template['contract']='1';
        $this->load->view('template',$template);
        
    }

    public function withdraw()
    {
        
        $template['page']='topup/view_member_withdraw';
        $this->load->view('template',$template);
        
    }

     public function cancelled_withdraw()
    {
        
        $template['page']='topup/view_member_canceled_withdraw';
        $this->load->view('template',$template);
        
    }

    public function add_member_upgrade()
    {
        // extract($_POST);
        // var_dump($_POST);die();

        $agreement_data = $this->input->post("agreement_data");

        $contract_data = $this->input->post("contract_data");

        $unique_id = $this->input->post('unique_id');
        $unique=explode(',',$unique_id);
        foreach($unique as $val1){
             $payment_data['payment_data_'.$val1] = $this->input->post('payment_data_'.$val1);
            }

        $inserted = $this->Membership_model->add_membership_upgrade($contract_data,$payment_data,$agreement_data);

        redirect('topup/Topup');
    }

    public function get_withdraw_details()
    {
        extract($_POST);
        
        $template['member_id'] =  $this->Membership_model->get_member_by_details($mobile);

        $dates=date("Y-m-d", strtotime($date));

         $template['contract'] =  $this->Membership_model->get_contract_by($mobile,$dates);

        $this->load->view('contract/ajax_contract',$template);
    }

    public function get_withdraw_approved_details()
    {
        extract($_POST);

        $template['member_id'] =  $this->Membership_model->get_member_by_details($mobile);

        $dates=date("Y-m-d", strtotime($date));
        $template['contract'] =  $this->Membership_model->get_contract_by_success($mobile,$dates);

        $this->load->view('contract/ajax_contract',$template);
    }

        public function get_withdraw_canceled_details()
    {
        extract($_POST);

        $template['member_id'] =  $this->Membership_model->get_member_by_details($mobile);

        $dates=date("Y-m-d", strtotime($date));
        $template['contract'] =  $this->Membership_model->get_contract_by_failed($mobile,$dates);

        $this->load->view('contract/ajax_contract',$template);
    }

    public function withdraw_req_approve($value='')
    {
        $id = ( explode( ',', $this->input->post('id') ));
        $date =  $this->input->post('date');

        foreach ($id as  $value) {
                $this->Topup_model->process_withdraw_req($value,$date);
             }
    }

public function cancel_withdraw_req(){
        $id = ( explode( ',', $this->input->post('id') ));
        $date =  $this->input->post('date');
        $reason =  $this->input->post('reason');
        //var_dump($id);die();
        foreach ($id as  $value) {
                $this->Topup_model->cancel_withdraw_req($value,$date,$reason);
             }
    }
}


