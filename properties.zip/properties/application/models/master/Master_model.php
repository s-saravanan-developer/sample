<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Master_model extends CI_Model { 

    function getallpayout() {

    $this->db->select('*');
    $this->db->where('status!=',3);
    $query = $this->db->get('gc_payout_type');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    function getalloffer() {

    $this->db->select('table.*,table1.Level,table2.Level_type');
    $this->db->where('table.status!=',3);
    $this->db->join('gc_level as table1','table1.ID = table.Level_id');
    $this->db->join('gc_leveltype as table2','table2.ID = table.Level_type_id');
    $query = $this->db->get('gc_offer_level_percentage as table');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    function getallgrade() 
    {
    $this->db->select('table.*,table1.Level_type');
    $this->db->where('table.status!=',3);
    $this->db->join('gc_leveltype as table1','table1.ID = table.Level_type_id');
    $query = $this->db->get('gc_grade as table');
    if ($query->num_rows() > 0) {
        $country_base = $query->result_array(); 
        foreach ($country_base as $key => $value) {
            $delete_status = $this->check_delete_status_grade($value['ID']);
            if(isset($delete_status)){ 
                $country_base[$key]['delete_status'] = 1; 
            }
            else{ 
                $country_base[$key]['delete_status'] = 0;
            }    
        }
        return $country_base;
    }
    return NULL;
    }

    public function check_delete_status_grade($ID)
    {   
    $this->db->select('table.id');
    $this->db->from('gc_grade as table');        
    $this->db->join('gc_packages as table1','table1.Grade_id = table.ID','left');
    $this->db->where('table1.status!=',3);
    $this->db->where('table1.Grade_id',$ID.'' );
    $query = $this->db->get();        
    if ($query->num_rows() > 0) {
        return $query->result_array();
    }
    return NULL;
    }

    
    public function getall_properties_types() {

    $this->db->select('*');
    $this->db->where('status!=',3);
    $query = $this->db->get('prop_properties_types');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    public function getall_lease_types() {

    $this->db->select('*');
    $this->db->where('status!=',3);
    $query = $this->db->get('prop_lease_types');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    public function getall_tenant_types() {

    $this->db->select('*');
    $this->db->where('status!=',3);
    $query = $this->db->get('prop_tenant_types');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }
    function getallgradeby($id) {

    $this->db->select('table.*,table1.Level_type');
    $this->db->where('table.status!=',3);
    $id = explode(",", $id);
    $this->db->where_in('table.ID',$id);
    $this->db->join('gc_leveltype as table1','table1.ID = table.Level_type_id');
    $query = $this->db->get('gc_grade as table');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    public function get_weeks()
    {
    $this->db->select("*");
    $query = $this->db->get("gc_weeks");
    if ($query->num_rows() > 0) {
        return $query->result_array();
    }
    return NULL;
    }
    
    function getall_membershiptype() 
    {
    $this->db->select('*');
    $this->db->where('status!=',3);
    $this->db->order_by("ID", "DESC");
    $query = $this->db->get('gc_membershiptype');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }


    function getall_membershiptypeby($id) 
    {
    $this->db->select('*');
    $this->db->where('status!=',3);
    $id = explode(",", $id);
    $this->db->where_in('table.ID',$id);
    $query = $this->db->get('gc_membershiptype');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    public function getall_leveltypes()
    {
    $this->db->select('*');
    $this->db->where('status!=',3);
    $this->db->order_by("ID", "DESC");
    $query = $this->db->get('gc_level');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    public function getall_lts()
    {
    $this->db->select('*');
    $this->db->where('status',1);
    $query = $this->db->get('gc_leveltype');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    function get_all_investbyleveltype($id) 
    {
    $this->db->select('*');
    $this->db->where('Level_type_id',$id);             
    $this->db->where('status',1);
    $query = $this->db->get('gc_invest_type');          
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    function getallinvestype() {

    $this->db->select('*');          
    $this->db->where('status',1);
    $query = $this->db->get('gc_invest_type');          
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    function get_allinvest() {

    $this->db->select('invest.*');
    $this->db->select('type.Level_type,type.ID as Leveltype_id');
    $this->db->where('invest.status!=',3);
    $this->db->order_by("invest.ID", "DESC");   
    $this->db->join('gc_leveltype as type','type.ID = invest.Level_type_id','left');
    $query = $this->db->get('gc_invest_type as invest');
    if ($query->num_rows() > 0) {
        $country_base = $query->result_array(); 
        foreach ($country_base as $key => $value) {
            $delete_status = $this->check_delete_status_invest($value['ID']);
            if(isset($delete_status)){ 
                $country_base[$key]['delete_status'] = 1; 
            }
            else{ 
                $country_base[$key]['delete_status'] = 0;
            }    
        }
        return $country_base;
    }
    return NULL;
    }

    public function check_delete_status_invest($ID)
    {   
    $this->db->select('tab.id');
    $this->db->from('gc_invest_type as tab');        
    $this->db->join('gc_level as tab1','tab1.Invest_type_id = tab.ID','left');
    $this->db->join('gc_member_topup as tab2','tab2.Invest_type_id = tab.ID','left');
    $this->db->where('tab1.Invest_type_id',$ID.'' );
    $query = $this->db->get();        
    if ($query->num_rows() > 0) {
        return $query->result_array();
    }
    return NULL;
    }

    function getall_leveltype() {

    $this->db->select('*');
    $this->db->where('status!=',3);
    $this->db->order_by("ID", "DESC");
    $query = $this->db->get('gc_leveltype');
    if ($query->num_rows() > 0) {
    	$country_base = $query->result_array(); 
        foreach ($country_base as $key => $value) {
            $delete_status = $this->check_delete_status_level_type($value['ID']);
            if(isset($delete_status)){ 
                $country_base[$key]['delete_status'] = 1; 
            }
            else{ 
                $country_base[$key]['delete_status'] = 0;
            }    
        }
        return $country_base;
    }
    return NULL;
	}

	public function check_delete_status_level_type($ID)
	{	
    $this->db->select('country.id');
    $this->db->from('gc_leveltype as country');        
    $this->db->join('gc_level as state','state.Level_type_id = country.ID','left');
    $this->db->join('gc_payout_type as table','table.Level_type_id = country.ID','left');
    $this->db->where('state.Level_type_id',$ID.'' );
    $query = $this->db->get();        
    if ($query->num_rows() > 0) {
        return $query->result_array();
    }
    return NULL;
	}
    
    function getall_level() {

    $this->db->select('table.*,table1.Level_type,table2.payout_type,table3.Invest_name,table3.ID as Invest_id');
    $this->db->where('table.status!=',3);
    $this->db->order_by("ID", "DESC");
    $this->db->from('gc_level as table');
    $this->db->join('gc_leveltype as table1','table1.ID = table.Level_type_id');
    $this->db->join('gc_payout_type as table2','table2.ID = table.Payout_type');
    $this->db->join('gc_invest_type as table3','table3.ID = table.Invest_type_id');
    $query = $this->db->get();        
    if ($query->num_rows() > 0) {
        return $query->result_array();
    }
    return NULL;
    }

    function getall_commission() {

    $this->db->select('table.*,table1.payout_type');
    $this->db->where('table.status!=',3);
    $this->db->order_by("ID", "DESC");
    $this->db->from('gc_commission as table');
    $this->db->join('gc_payout_type as table1','table1.ID = table.Payout_type_id');
    $query = $this->db->get();        
    if ($query->num_rows() > 0) {
        return $query->result_array();
    }
    return NULL;
    }

   function getall_bank() {

    $this->db->select('table.*');
    $this->db->where('table.status!=',3);
    $this->db->order_by("ID", "DESC");
    $this->db->from('gc_payment_mode as table');
    $query = $this->db->get();        
    if ($query->num_rows() > 0) {
        return $query->result_array();
    }
    return NULL;
    }


   function getall_banks() {

    $this->db->select('table.*');
    $this->db->where('table.status!=',3);
    $this->db->order_by("ID", "DESC");
    $this->db->from('gc_bank as table');
    // $this->db->join('gc_payout_type as table1','table1.ID = table.Payout_type_id');
    $query = $this->db->get();        
    if ($query->num_rows() > 0) {
        return $query->result_array();
    }
    return NULL;
    }

   function getall_paymentterm() {

    $this->db->select('table.*');
    $this->db->where('table.status!=',3);
    $this->db->order_by("ID", "DESC");
    $this->db->from('gc_payment_term as table');
    // $this->db->join('gc_payout_type as table1','table1.ID = table.Payout_type_id');
    $query = $this->db->get();        
    if ($query->num_rows() > 0) {
        return $query->result_array();
    }
    return NULL;
    }
    function getall_membership_reqtype() {

    $this->db->select('*');
    $this->db->where('status!=',3);
    $this->db->order_by("ID", "DESC");
    $query = $this->db->get('gc_membership_reqtype');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    function getall_membership_reqtypeby($id) {

    $this->db->select('*');
    $this->db->where('status!=',3);
    $id = explode(",", $id);
    $this->db->where_in('table.ID',$id);
    $this->db->order_by("ID", "DESC");
    $query = $this->db->get('gc_membership_reqtype');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    function getall_withdraw() {

    $this->db->select('*');
    $this->db->where('status!=',3);
    $this->db->order_by("ID", "DESC");
    $query = $this->db->get('gc_withdraw');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    function getall_franchise() {

    $this->db->select('table.*,table1.Level_type,table2.payout_type');
    $this->db->select('table3.ID as Investtype_id,table3.Invest_name');
    $this->db->order_by("ID", "DESC");
    $this->db->where('table.status!=',3);
    $this->db->join('gc_leveltype as table1','table1.ID = table.Level_type_id');
    $this->db->join('gc_payout_type as table2','table2.ID = table.Payout_type');
    $this->db->join('gc_invest_type as table3','table3.ID = table.Invest_type_id');
    $query = $this->db->get('gc_member_topup as table');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }



 function delete_checkbox($id,$table,$success){
      
    $data['Updated_date'] = date('Y-m-d H:i:s');
            $data['status']         = 3;    

        $this->db->where('id', $id);
        if ($this->db->update($table, $data)) {
            $this->session->set_flashdata($success, 'Deleted');
            return TRUE;
       }
        
        return FALSE;               
     }

function active_all_checkbox($id){
      
            $data['updated_date'] = date('Y-m-d H:i:s');
            $data['status']         = 1;    

        $this->db->where('id', $id);
        if ($this->db->update('gc_countries', $data)) {
            $this->session->set_flashdata('country_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}

function deactivate_all_checkbox($id){

      $data['updated_date'] = date('Y-m-d H:i:s');
      $data['status']       = 2;

        $this->db->where('id', $id);
        if ($this->db->update('gc_countries', $data)) {
            $this->session->set_flashdata('country_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}

    function get_all_payouttyp($id) {

    $this->db->select('*');
    $this->db->where('Level_type_id',$id);             // Feild name
    $this->db->where('status',1);
    $query = $this->db->get('gc_payout_type');          // Table name
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    function get_leveltype_level($id) {

    $this->db->select('*');
    $this->db->where('Level_type_id',$id);             // Feild name
    $this->db->where('status',1);
    $query = $this->db->get('gc_level');          // Table name
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

}

