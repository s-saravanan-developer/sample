<div class="header">
<a href="http://localhost/new/Ranjit/index.php/user/registration" style=" float:right; text-decoration:none; margin-right:110px; color:#FFFFFF; font-weight:bold;">Sign up</a>
<a href="http://localhost/new/Ranjit/main/" style=" float:right; text-decoration:none; margin-right:10px; color:#FFFFFF; font-weight:bold;">Login</a>
<a href="http://www.sourcecodester.com/php/7238/addedit-and-delete-using-codeigniter.html" target="_blank" style=" float:right; text-decoration:none; margin-right:10px; color:#FFFFFF; font-weight:bold;">My Tuts</a>

<a href="http://facebook.com/Ranjit.karki.140" target="_blank" style=" float:right; text-decoration:none; margin-right:10px; color:#FFFFFF; font-weight:bold;">Follow Me</a>


</div>

<style>
body{
width:80%;
height:75%;
border:1px solid #000000;
}
.header{
width:100%;
height:35px;
margin-left:0px;
background: #990000;
text-decoration:none;
}
</style>