<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Help extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();

        }
        $this->load->helper(array('form', 'url'));
        $this->load->model('master/Help_model');
        $this->load->model('master/Calendar_setting_model');
        $this->load->model('master/Users_model');
        $this->load->model('member/Membership_model');
    }

	public function index()
	{
        
		$template['page']='help/view_ticket';
        $template['request'] = $this->Help_model->getallrequest();
        $template['ticket'] = $this->Help_model->getallticket();
        $this->load->view('template',$template);
		
	}

    public function feedback()
    {
        
        $template['page']='help/view_feedback';
        $template['feedback'] = $this->Help_model->getallfeedback();
        $this->load->view('template',$template);
        
    }

    public function calendar()
    {
        
        $template['page']='help/view_calendar';
        $template['table_name']  =   "gc_company_table";
        $template['weeks']        =   $this->Calendar_setting_model->get_weeks();
        $template['holiday']      =   $this->Calendar_setting_model->get_holidays();
        $this->load->view('template',$template);
        
    }

public function add_ticket()
{
    extract($_POST);

    $Ref_no = ($this->db->count_all_results('gc_ticket')+1);
    $member_id = $this->session->userdata('UserCode');

    $name = "ticket_image";
    $common = "Service";
    // $ticket_image = $this->Help_model->uploads($Ref_no,$member_id,$name,$common);

    $data = array('Ref_no' => 'GC-TKT-'.$Ref_no, 
                  'Membership_ID' => $member_id,
                  // 'Ticket_image' => $ticket_image,
                  'Member_request' => $member_request,
                  'Created_on' => date('Y-m-d'),
                  'Desc' => $desc
                );
    $this->db->insert('gc_ticket',$data);
    $this->session->set_flashdata('message',  array('message' => 'Added Successfully','class' => 'success'));
    redirect('Help');
}

public function add_feedback()
{
    extract($_POST);

    $Ref_no = 'FBR-0'.($this->db->count_all_results('gc_feedback')+1);
    $member_id = $this->session->userdata('UserCode');

    $data = array('Membership_ID' => $member_id,
                  'Desc' => $Desc,
                  'Ref_no' => $Ref_no,
                  'Created_on' => date('Y-m-d')
                );
    $this->db->insert('gc_feedback',$data);
    $this->session->set_flashdata('message',  array('message' => 'Added Successfully','class' => 'success'));
    redirect('Help/feedback');
}

}



        