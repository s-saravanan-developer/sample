<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Ecart extends CI_Controller {
	public function __construct() {
        parent::__construct();
        
        $this->load->helper(array('form', 'url'));
        // $this->load->model('master/Company_model');
        // $this->load->model('master/Location_model');
        // $this->load->model('master/Calendar_setting_model');

    }

	public function index()
	{
        echo $this->session->userdata('UserId');
        $id = $this->session->userdata('UserId');
        $this->db->select('*');
        $this->db->from('gc_users');
        $this->db->where('gc_users.id', $id);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            $user_details =  $query->result_array();
        }
        var_dump($user_details);
        var_dump($user_details[0]['email_address']);
        var_dump($user_details[0]['og_password']);
  //       $template['table_name']     =   "gc_company_table";
  //       $template['weeks']        =   $this->Calendar_setting_model->get_weeks();
  //       $template['holiday']        =   $this->Calendar_setting_model->get_holidays();
		// $template['page']='dashboard/dashboard';
  //       $this->load->view('template',$template);
		
	}

}

?>