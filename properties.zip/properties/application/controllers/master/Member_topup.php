<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Member_topup extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
    }

    public function index()
    {
        $template['page']='master/member_topup/viewmember_topup';
        $template['franchise'] =  $this->Master_model->getall_franchise();
        $template['level'] =  $this->Master_model->getall_leveltype();
        $template['payout'] =  $this->Master_model->getallpayout();
        $template['invest'] =  $this->Master_model->getallinvestype();
        // var_dump($template['franchise']);die();
        $this->load->view('template',$template);
    }

    public function add_member_topup()
    {
        extract($_POST);
        // var_dump($_POST);die();
        $data = array('Franchise' => $Franchise,
                      'Alias_name' => $Alias_name,
                      'Level_type_id' => $Level_type_id,  
                      'Invest_type_id' => $Invest_type_id,  
                      'Value' => $Value,  
                      'Validity' => $Validity,  
                      'Payout_type' => $Payout_type,  
                      'Return' => $Return,  
                      'Description' => $Description,  
                      //'Status' => $Status
                     );
        $this->db->insert('gc_member_topup',$data);
        $this->session->set_flashdata('payout_success', 'Added');
        redirect('master/Member_topup');
    }

    public function edit_member_topup()
    {
        extract($_POST);
        // var_dump($_POST);die();
       $data = array(//'Franchise' => $Franchise,
                      'Alias_name' => $Alias_name,
                      //'Level_type_id' => $Level_type_id,  
                      'Value' => $Value,  
                      'Validity' => $Validity,  
                      'Payout_type' => $Payout_type,  
                      'Return' => $Return,  
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->where('ID',$ID);
        $this->db->update('gc_member_topup',$data);
        $this->session->set_flashdata('payout_success', 'Updated');
        redirect('master/Member_topup');
    }

    public function delete_member_topup($id)
    {

        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_member_topup',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Member_topup');
    }
}
