<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard extends CI_Controller {
	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            //$this->session->set_flashdata('msg', 'Please Login to Continue');
            redirect('login');
            session_destroy();

        }
        $this->load->helper(array('form', 'url'));
        $this->load->model('master/Company_model');
        $this->load->model('master/Location_model');
        $this->load->model('member/Membership_model');
        $this->load->model('master/Calendar_setting_model');
        $this->load->model('master/Users_model');
        $this->load->model('master/Help_model');
        $this->load->model('Report_model');
    }

	public function index()
	{
        $this->load->model('master/Users_model');
        $template['table_name']   =   "gc_company_table";
        $template['wallet_balance']  =  $this->Membership_model->get_wallet_balance();
        $template['payout']     =  $this->Membership_model->get_payout_date();
        // var_dump($template['payout']);die();
        $template['weeks']        =   $this->Calendar_setting_model->get_weeks();
        $template['holiday']      =   $this->Calendar_setting_model->get_holidays();
        $template['ticket'] = $this->Help_model->getallticket_dashboard();
        $template['investment'] = $this->Membership_model->gettotal_investment($this->session->userdata('UserCode'));
        $template['return'] = $this->Membership_model->get_return_investment($this->session->userdata('UserCode'));
        $template['self'] = $this->Membership_model->get_return_investment_chart($this->session->userdata('UserCode'));

        // $template['self'] = $this->Membership_model->get_self_investment($this->session->userdata('UserCode'));
        $template['level'] = $this->Membership_model->get_level_investment_level2t09($this->session->userdata('UserCode'));
        $template['direct_invest'] = $this->Membership_model->get_level_investment($this->session->userdata('UserCode'));
        // $template['direct_invest'] = $this->Membership_model->get_direct_investment($this->session->userdata('UserCode'));
        // $template['payout'] = $this->Membership_model->get_next_payout($this->session->userdata('UserCode'));

        $this->db->where('Membership_ID',$this->session->userdata('UserCode'));
         $template['downline']  =  $this->db->count_all_results('gc_member_level_details');
        // echo "hidfhglsdhfg";die();
		$template['page']='dashboard/dashboard';
        $this->load->view('template',$template);
		
	}


    public function profile()
    {
        
        $template['page']='dashboard/viewprofile';
        $this->load->view('template',$template);
        
    }

    public function down_doc()
    {
        
        $template['page']='dashboard/view_down_doc';
        $this->load->view('template',$template);
        
    }

    public function payout()
    {   
        $mobile = $this->session->userdata('UserCode');
        $template['level']       =  $this->Report_model->get_all_level_types();
        $template['commission']  =  $this->Report_model->get_all_commission_types();
        $template['payout_type'] =  $this->Report_model->get_all_payout_types();
        $template['payout']      =  $this->Report_model->get_today_payout_history($mobile);
        $template['page']='dashboard/view_payout';
        $this->load->view('template',$template);
        
    }

    public function member_upgrade()
    {
        
        $template['page']='dashboard/view_member_upgrade';
        $template['wallet_balance']  =  $this->Membership_model->get_wallet_balance();
        // var_dump($template['wallet_balance']);die();
        $template['payment_mode']    =  $this->Membership_model->getall_payment_modes();
        $template['bank']            =  $this->Membership_model->getall_bank();
        $template['topup']           =  $this->Membership_model->getall_topups();
        $template['payout']          =  $this->Membership_model->getall_payouts_franchasie();
        $template['membership_type'] =  $this->Membership_model->getall_membershiptype();
        $this->load->view('template',$template);
        
    }

    public function member_topup()
    {   

        $mem_id = $this->session->userdata('UserCode');  
        // $mobile = 2;  
        // var_dump($mobile);die();
        $this->load->model('member/Contract_model');
        $template['contract'] =  $this->Contract_model->get_contract_details($mem_id);
        // var_dump($template['contract']);die();
        $template['page']='dashboard/view_member_topup';
        
        $this->load->view('template',$template);
        
    }
    public function member_history()
    {
        $mobile = $this->session->userdata('UserCode');  
        $template['level']       =  $this->Report_model->get_all_level_types();
        $template['commission']  =  $this->Report_model->get_all_commission_types();
        $template['topup']       =  $this->Report_model->get_all_topups();
        $template['transaction'] =  $this->Report_model->get_transaction_history($mobile);
        $template['page']='dashboard/view_member_history';
        $this->load->view('template',$template);
        
    }
    public function withdraw()
    {   
        $contract_id = $this->session->userdata('UserCode');  
        $this->load->model('member/Contract_model');
        $template['contract'] =  $this->Contract_model->get_all_contract_id($contract_id);
        $template['withdraw'] =  $this->Contract_model->get_all_withdraw($contract_id);
        $template['contract_withdraw'] =  $this->Contract_model->get_contract_details_withdraw($contract_id,1);
        $template['withdraw']       =  $this->Report_model->get_all_withdraw_req();

        $template['page']='dashboard/view_withdraw';
        $this->load->view('template',$template);
        
    }
    
    public function go()
    {
        // var_dump($_GET['rt']);
        $txtdcp = rawurldecode($this->encrypt->decode($_GET['rt']));
        // echo $txtdcp;die();
        $template['page']=$txtdcp;
        $this->load->view('template',$template);
        // redirect($this->encrypt->decode($_GET['rt']));
        
    }


    public function add_member_upgrade()
    {
        extract($_POST);
        // print_r($_POST);die();
        // $agreement_data = $this->input->post("agreement_data");

        $contract_data = $this->input->post("contract_data");

        // $unique_id = $this->input->post('unique_id');
        // // var_dump($unique_id);die();
        // $unique=explode(',',$unique_id);
        // foreach($unique as $val1){
        //      $payment_data['payment_data_'.$val1] = $this->input->post('payment_data_'.$val1);
        //     }

        
        $wallet_balance  =  $this->Membership_model->get_wallet_balance();
        if($wallet_balance[0]['Wallet_balance']!=0 && $contract_data['Amount']<=$wallet_balance[0]['Wallet_balance']){
        	$inserted = $this->Membership_model->add_membership_upgrade($contract_data,$Membership_ID);
        }

        redirect('Dashboard/member_upgrade');
    }

    public function update_agreement()
    {
        extract($_POST);

        $data = array('Status' => '6');

        $this->db->where('Agreement_ID',$ID);
        $this->db->update('gc_member_agreement',$data);
    }

  public function get_payout_history1()
    {
        
        $mobile             = $this->session->userdata('UserCode');
        $date               =date("Y-m-d", strtotime($this->input->post("date")));
        $template['payout'] =  $this->Report_model->get_payout_history1($mobile,$date);
        $this->load->view('reports/ajax_payout_history',$template);
        
    }
    public function get_payout_history2()
    {
        $member_id             = $this->session->userdata('UserCode');
        $template['mobile'] =  $this->Membership_model->get_parent_detail($member_id);
        $commission_type    = $this->input->post("commission_type");  
        $level_type         = $this->input->post("level_type");
        $payout_list        = $this->input->post("payout_list");
        $payment_list       = $this->input->post("payment_list");
        $s_date = date("Y-m-d", strtotime($this->input->post("s_date")));
        $e_date = date("Y-m-d", strtotime($this->input->post("e_date")));
        // var_dump($template['mobile'][0]['Membership_code']);die();
        $template['payout'] =  $this->Report_model->get_payout_history2($commission_type,$level_type,$s_date,$e_date,$template['mobile'][0]['Membership_code'],$payout_list,$payment_list);
        $this->load->view('reports/ajax_payout_history',$template);
        
    }

    
    public function get_transaction_history1()
    {
        
        $mobile           = $this->input->post("mobile");
        $date             =date("Y-m-d", strtotime($this->input->post("date")));
        $template['transaction'] =  $this->Report_model->get_transaction_history1($mobile,$date);
        $template['withdraw']       =  $this->Report_model->get_all_withdraw_req();

        $this->load->view('reports/ajax_transaction_history',$template);
        
    }
    public function get_transaction_history2()
    {
        $mobile           = $this->input->post("mobile");
        $commission_type  = $this->input->post("commission_type");  
        $topup_list       = $this->input->post("topup_list");  
        $transaction_type = $this->input->post("transaction_type");
        $contract         = $this->input->post("contract");
        $s_date           =date("Y-m-d", strtotime($this->input->post("s_date")));
        $e_date           =date("Y-m-d", strtotime($this->input->post("e_date")));
        $template['transaction'] =  $this->Report_model->get_transaction_history2($commission_type,$topup_list,$transaction_type,$s_date,$e_date,$mobile,$contract);
        $this->load->view('reports/ajax_transaction_history',$template);
        
    }

    public function get_contract_history()
    {
        $this->load->model('member/Contract_model');
        $contract_id           = $this->input->post("mobile");
        $template['contract'] =  $this->Contract_model->get_contract_by($contract_id);
        $template['withdraw'] =  $this->Contract_model->get_all_withdraw();
        $this->load->view('contract/ajax_contract',$template);
        
    }

public function update_withdraw()
{
        $contract_id   = $this->input->post("ID");

        $this->load->view('contract/ajax_contract',$template);

}

public function update_withdraw_req()
{
        $contract_id     = $this->input->post("ID");
        $withdraw_text   = $this->input->post("text");
        $withdraw_type   = $this->input->post("mobile");

        $date = date('Y-m-d');
        $data = array('Request_status' => 2,
                      'Request_type' => $withdraw_type,
                      'Request_text' => $withdraw_text,
                      'Request_date' => $date
                             );

        $this->db->where('Contract_ID',$contract_id);
        $this->db->update('gc_member_franchisee_contract',$data);

        // redirect('Dashboard/withdraw');
        

}

public function random($userid)
{
    $permitted_chars = 'wdfwtr_ywert#@43%^*&f_ghW#$%^eftg$%^@!$%#T345g1_346w7n3gdFqwfDe723#$_%v23SDFGSADF';
     
    function generate_string($input, $strength = 16) {
        $input_length = strlen($input);
        $random_string = '';
        for($i = 0; $i < $strength; $i++) {
            $random_character = $input[mt_rand(0, $input_length - 1)];
            $random_string .= $random_character;
        }
     
        return $random_string;
    }
    $pwd = generate_string($permitted_chars, 9);

        $user_data = array('password' => md5($pwd),'og_password' => $pwd);
        $this->db->where('user_id',$userid);
        $this->db->update('gc_users',$user_data);
        redirect('');

}


}


