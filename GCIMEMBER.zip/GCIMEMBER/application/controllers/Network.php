<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Network extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();

        }
        $this->load->helper(array('form', 'url'));
        $this->load->model('master/Company_model');
        $this->load->model('master/Users_model');
        $this->load->model('master/Location_model');
        $this->load->model('member/Membership_model');
        $this->load->model('master/Calendar_setting_model');
    }

	public function index()
	{
        $template['table_name']   =   "gc_company_table";
        $template['weeks']        =   $this->Calendar_setting_model->get_weeks();
        $template['holiday']      =   $this->Calendar_setting_model->get_holidays();
		$template['page']='network/view_genealogy';
        $this->load->view('template',$template);
		
	}

public function level_list()
    {
        // $this->load->model('member/Membership_model');
        $template['page']        = 'network/view_level_list';
        // $this->load->view('template',$template);
        //         $this->load->model('member/Membership_model');
        // $Membership_ID = $this->input->get("id");
        // $template['Membership_code']            =$Membership_ID;
        // $template['page']            ='membership/tabular_tree_view';
        // $this->load->view('template',$template);
        // 
        $this->load->model('member/Membership_model');
        $this->load->model('master/Users_model');
        $template['member_id'] =  $this->Membership_model->get_memcode_detail($this->session->userdata('UserCode'));
        $template['Membership_code'] =$template['member_id'][0]['Membership_Code'];
        // $template['page']            ='membership/tabular_tree_view';

        $this->load->view('template',$template);
    }

    public function tabular_view123()
    {
        $this->load->model('member/Membership_model');
        $Membership_ID = $this->input->get("id");
        $template['Membership_code']            =$Membership_ID;
        $template['page']            ='membership/tabular_tree_view';
        $this->load->view('template',$template);
    }

public function get_tabular_tree_details()
    {   
        ini_set('display_errors', 0);
        $id = $this->input->post("mobile"); 

        $this->load->model('member/Membership_model');
        $template['member_id']   =  $this->Membership_model->get_member_detailbyid($id);
        $template['member']   =  $this->Membership_model->get_parent_detail($template['member_id'][0]['Membership_ID']);
        if(!empty($template['member'] )){
        $member_refer= $template['member'][0]['Reference_ID'];
        $template['member_refer1']  =  $this->Membership_model->get_parent_referer($member_refer);
        if(!empty($template['member_refer1'])){
        $template['member_refer'] =$template['member_refer1'][0]['Membership_code'];
    }else{
         $template['member_refer'] =0;
    }
    }else{
        $template['member_refer']=0;
    }
      // echo ($template['member'][0]['Membership_code']);
        $template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
        $template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
       // var_dump($template['child_parent_binary']);die();
        $this->load->view('membership/ajax_tree',$template);
    }


public function tree_view()
    {
        $this->load->model('member/Membership_model');
        $id=$this->input->get('id');
        $template['page']            ='membership/tree_view';
        $template['member']          =  $this->Membership_model->get_parent_detail($id);
        // var_dump($template['member']);die();
        $template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
        $template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
        // var_dump($template['child_parent_binary']);
        $this->load->view('template',$template);
        
}

public function tree()
{
$template['page']            ='membership/search_tree_view';
$this->load->view('template',$template);
}

// public function get_tree_details()
//     {   
//         $id = $this->input->post("mobile"); 

//         $this->load->model('member/Membership_model');
//         $template['member_id']   =  $this->Membership_model->get_member_detailbyid($id);
//         $template['member']   =  $this->Membership_model->get_parent_detail($template['member_id'][0]['Membership_ID']);
        
       
//         $template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
//         $template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
//        // var_dump($template['child_parent_binary']);die();
//         $this->load->view('membership/ajax_tree',$template);
//     }

public function get_tree_details()
    {   
        $id = $this->input->post("mobile"); 

        $this->load->model('member/Membership_model');
        $template['member_id']   =  $this->Membership_model->get_member_detailbyid($id);
        $template['member']   =  $this->Membership_model->get_parent_detail($template['member_id'][0]['Membership_ID']);
        if(!empty($template['member'] )){
        $member_refer= $template['member'][0]['Reference_ID'];
        $template['member_refer1']  =  $this->Membership_model->get_parent_referer($member_refer);
        if(!empty($template['member_refer1'])){
        $template['member_refer'] =$template['member_refer1'][0]['Membership_code'];
    }else{
         $template['member_refer'] =0;
    }
    }else{
        $template['member_refer']=0;
    }

        $template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
        $template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);

        $this->load->view('membership/ajax_tree',$template);
    }

    public function referred_member()
    {
        
        $template['page']='network/view_referredmember';
        $this->load->view('template',$template);
        
    }

    public function explorer()
    {
        
        $template['page']='network/view_networkexplorer';
        $this->load->view('template',$template);
        
    }

        public function tree_view_search()
    {
        $this->load->model('member/Membership_model');
        $this->load->model('master/Users_model');
        $Membership_ID = $this->input->get("id");
        $template['member_id'] =  $this->Membership_model->get_memcode_detail($Membership_ID);
        $template['Membership_code'] =$template['member_id'][0]['Membership_Code'];
        $template['page']            ='network/view_genealogy';

        $this->load->view('template',$template);
        
}

        public function tree_view_details()
    {
        $encode = $this->session->userdata('UserCode');
        $this->load->model('member/Membership_model');
        $this->load->model('master/Users_model');

        $template['member_id'] =  $this->Membership_model->get_memcode_detail($encode);
        $template['Membership_code'] =$template['member_id'][0]['Membership_Code'];
        $template['page']            ='membership/tree_view';

        $this->load->view('template',$template);
        
}


        public function tabular_tree_view()
    {
        $encode = $this->session->userdata('UserCode');
        $this->load->model('member/Membership_model');
        $this->load->model('master/Users_model');
        $template['member_id'] =  $this->Membership_model->get_memcode_detail($encode);
        $template['Membership_code'] =$template['member_id'][0]['Membership_Code'];
        $template['page']            ='membership/tabular_tree_view';

        $this->load->view('template',$template);
        
}


}
