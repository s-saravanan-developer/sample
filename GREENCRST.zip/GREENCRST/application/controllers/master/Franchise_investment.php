<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Franchise extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
    }

    public function index()
    {
        $template['page']='master/franchise/viewfranchise';
        $template['franchise'] =  $this->Master_model->getall_franchise();
        $template['level'] =  $this->Master_model->getall_leveltype();
        $this->load->view('template',$template);
    }

    public function add_franchise()
    {
        extract($_POST);

        $data = array('franchise_type_id' => $franchise_type,
                      'Alias_name' => $Alias_name,
                      'franchise' => $franchise,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->insert('gc_franchise',$data);
        $this->session->set_flashdata('payout_success', 'Added');
        redirect('master/franchise');
    }

    public function edit_franchise()
    {
        extract($_POST);

        $data = array('franchise_type_id' => $franchise_type,
                      'Alias_name' => $Alias_name,
                      'franchise' => $franchise,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->where('ID',$ID);
        $this->db->update('gc_franchise',$data);
        $this->session->set_flashdata('payout_success', 'Updated');
        redirect('master/franchise');
    }

    public function delete_franchise($id)
    {

        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_franchise',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/franchise');
    }
}
