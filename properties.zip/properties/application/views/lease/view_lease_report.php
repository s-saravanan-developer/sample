<script>
 <?php
 if ($this->session->flashdata('company_success')) 
 {
  echo "var data = ' ".$this->session->flashdata('company_success')."';";
  echo "success(data);";
}
?>
</script>
<div class="content-wrapper">
 <div class="content">
  <header class="page-header">
   <div class="d-flex align-items-center">
    <div class="mr-auto">
     <h1 class="separator">Lease</h1>
     <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
      <ol class="breadcrumb">
       <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i></a></li>
       <li class="breadcrumb-item " aria-current="page">Lease</li>
       <li class="breadcrumb-item active" aria-current="page">Lease Report </li>
     </ol>
   </nav>
 </div>
 <ul class="actions top-right">
   <li class="dropdown">
    <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
      <i class="la la-ellipsis-h"></i>
    </a>
    <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
     <div class="dropdown-header">
      Quick Actions
    </div>
    <a href="#" class="dropdown-item">
     <i class="icon dripicons-clockwise"></i> Refresh
   </a>
   <a href="#" class="dropdown-item">
     <i class="icon dripicons-gear"></i> Manage Widgets
   </a>
   <a href="#" class="dropdown-item">
     <i class="icon dripicons-cloud-download"></i> Export
   </a>
   <a href="#" class="dropdown-item">
     <i class="icon dripicons-help"></i> Support
   </a>
 </div>
</li>
</ul>
</div>
</header>
<section class="page-content container-fluid">
 <div class="row">
  <div class="col-12">              
   <div class="card">
    <h5 class="card-header">
     <div style="float: left;font-weight: bold"> Manage Lease</div>
   </h5>
   <div class="card">
    <div class="card-body">
     <div class="row">
      <div class="form-group col-md-4" style="padding-top: 5px;">
                   <label for="exampleFormControlSelect1">Tenant Origin<span style="color:red">*</span> </label>
                   <div class="input-group mb-3">
                     <div class="input-group-prepend">
                      <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                    </div>
                    <select class="form-control" name="lease[tenant_origin]" id="tenant_origin" required>
                      <option value="">SELECT TENANT ORIGIN</option>
                      <option value="LOCAL NATIONAL">LOCAL NATIONAL</option>
                      <option value="INTERNATIONAL">INTERNATIONAL</option>
                      <option value="LOCAL TENANT">LOCAL TENANT</option>
                    </select>
                  </div>
                </div>

       <div class="form-group col-md-4 enable_authorize_person" >
        <label for="" required> From Date <span style="color: #db3236">*</span></label>
        <input type="text" class="form-control" id="start_date" value="<?php if(isset($Date)){echo $Date;}else{ echo date('d-m-Y');} ?>">
      </div>

      <div class="form-group col-md-4 enable_authorize_person" >
        <label for="" required>End Date <span style="color: #db3236">*</span></label>
        <input type="text" class="form-control" id="end_date" value="<?php if(isset($Date)){echo $Date;}else{ echo date('d-m-Y');
      } ?>">
    </div>

    <div class="form-group col-md-4">
      <label for="exampleFormControlSelect1">Customer  </label>
      <div class="input-group mb-3">
       <div class="input-group-prepend">
        <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
      </div>
      <select class="form-control" id="customer_id" required>
        <option value="">Select Customer</option>
        <?php if (!empty($customer)) {foreach ($customer as $value) {?>
          <option value="<?php echo ucfirst($value['customer_id']); ?>" <?php echo ($value['customer_id'] == 0) ? 'selected' : ''; ?>><?php echo ucfirst($value['customer_name']); ?></option>
        <?php } } ?>
      </select>
    </div>
  </div>
  <div class="form-group col-md-4">
    <label for="exampleFormControlSelect1">Area  </label>
    <div class="input-group mb-3">
     <div class="input-group-prepend">
      <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
    </div>
    <select class="form-control" id="area_id" required>
      <option value="">Select Area</option>
      <?php if (!empty($area)) {foreach ($area as $value) {?>
        <option value="<?php echo ucfirst($value['area_id']); ?>" <?php echo ($value['area_id'] == 0) ? 'selected' : ''; ?>><?php echo ucfirst($value['area_name']); ?></option>
      <?php } } ?>
    </select>
  </div>
</div>  

<div class="form-group col-md-4 " style="margin-top: 30px;">
  <button type="button" class="btn btn-success  btn-floating " id="get_lease" data-toggle="tooltip" data-placement="top" data-original-title="Search Report">
    Search Report 
  </button>
  <button class="btn btn-primary" id="report_excel" type="button">Export Excel</button>
</div>
</div>

</div>
</div>
<div class="card-body" style="overflow-x: scroll;max-width: 1090px;">
  <div class="append"> 
   <table class="table table-striped table-bordered table table-responsive tablescript" >
    <thead>
     <tr>
      <th class="text-center" style="width: 2%">S.No</th>
      <th class="text-center" style="width: 20%">Tenant.Name</th>
      <th class="text-center" style="width: 20%">Tenant.Origin</th>
      <th class="text-center" style="width: 20%">Tenant.Type</th>
      <th class="text-center" style="width: 20%">Lease.Type</th>
      <th class="text-center" style="width: 10%">Area</th>
      <th class="text-center" style="width: 10%">Current.Area.Sqm</th>
      <th class="text-center" style="width: 10%">Rate.per.Sqm</th>
      <th class="text-center" style="width: 10%">Total.Area.Rent</th>
      <th class="text-center" style="width: 10%">Lease.Period</th>
      <th class="text-center" style="width: 10%">Management.Fees</th>
      <th class="text-center" style="width: 10%">Parking.Fees</th>
      <th class="text-center" style="width: 10%">Air.Condition.Fees</th>
      <th class="text-center" style="width: 10%">Escalation.Fees</th>
      <th class="text-center" style="width: 10%">Initail.Lease.Commencement</th>
      <th class="text-center" style="width: 10%">Final.Lease.Commencement</th>
      <th class="text-center" style="width: 10%">Total.Lease.Amount</th>
      <th class="text-center" style="width: 5%">Status</th>                            
    </tr>
  </thead>
  <tbody>
   <?php if (!empty($lease)) {$s = 1; foreach ($lease as $list) {?>
     <tr>
      <td ><?php echo $s; ?></td>

      <td class="text-center"> 

       <a href="<?php echo base_url(); ?>lease/lease/editlease?id=<?php echo ucfirst($list['lease_id']); ?> " id="usertypeedit" class="btn btn-info btn-sm "><i class="zmdi zmdi-edit zmdi-hc-fw" style="color:  white; " data-toggle="tooltip" data-placement="top" data-original-title="Edit"></i></a>

       <a href="" onclick="delete_lease('<?php echo ucfirst($list['lease_id']); ?>')" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deletemodel" ><i class="zmdi zmdi-delete zmdi-hc-fw" style="color:  white;" data-toggle="tooltip" data-placement="top" data-original-title="Delete"></i></a>  

     </td>

     <td class="text-center"><?php echo ucfirst($list['customer_name']); ?></td>
     <td class="text-center"><?php echo ucfirst($list['area_name']); ?></td>
     <td class="text-center"><?php echo ucfirst($list['area_sqm']); ?></td>
     <td class="text-right"><i class="la la-rupee"></i> <?php echo ucfirst($list['area_rent']); ?></td>
     <td class="text-right"><i class="la la-rupee"></i> <?php echo ucfirst($list['area_total']); ?></td>
     <?php 
     $datetime1 = new DateTime('01 JAN 2018');
     $datetime2 = new DateTime('01 JAN 2019');
     $interval = $datetime1->diff($datetime2);
     $interval->format('%y yr %m mn and %d days');
     ?>
     <td class="text-center"><?php echo ucfirst($list['customer_id']); ?></td>
     <td class="text-center"><?php echo date('d-m-Y',strtotime($list['start_date'])); ?></td>

     <td><span class="badge badge-<?php echo ($list['status'] == 1) ? 'success' : 'danger'; ?>"><?php echo ($list['status'] == 1) ? 'Active' : 'In-Active'; ?></span></td>

   </tr>
   <?php $s++; } } ?>
 </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>	
<script>
  $("#get_lease").click(function(e)
  {
    start   = $("#start_date").val();
    end     = $("#end_date").val();
    area    = $("#area_id").val();
    customer= $("#customer_id").val();
    tenant_origin= $("#tenant_origin").val();
    

    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>lease/lease/get_lease_report",
      data: "type=get_lease_report&start="+start+"&end="+end+"&area="+area+"&customer="+customer+"&tenant_origin="+tenant_origin,
      cache: true,
      dataType:"html",
      async: false,
      success: function(data)
      {
        $('.append').empty().append(data);
        $('.scroll_card').css('overflow-x','scroll');
      }
    });

  });


  $("#report_excel").click(function(e)
  {
    start   = $("#start_date").val();
    end     = $("#end_date").val();
    area    = $("#area_id").val();
    customer= $("#customer_id").val();


    $.ajax({
      type: "POST",
      url: "<?php echo base_url(); ?>lease/lease/get_lease_report_excel",
      data: "type=get_lease_report&start="+start+"&end="+end+"&area="+area+"&customer="+customer,
      cache: true,
      dataType:"html",
      async: false,
      success: function(data)
      {
        if (data==1) {
         var url="<?php echo base_url(); ?>lease/lease/get_lease_excel_report/"+start+"/"+end+"/"+area+"/"+customer;
         window.location.href = url;
       }else{
        swal('No Data to Export..!');
      }
    }
  });
  });

  $(document).ready(function(){
   $('.tablescript').dataTable();
   $('#start_date').datepicker();
   $('#end_date').datepicker();

 });


</script>