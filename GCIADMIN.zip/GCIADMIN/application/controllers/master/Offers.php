<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Offers extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
        $this->load->model('master/Offers_model');
    }

    public function index()
    {
        $template['page']='master/offers/view_offers';
        $template['offers'] =  $this->Offers_model->getalloffers();
        $template['leveltype'] =  $this->Offers_model->getall_leveltype();
        $template['package'] =  $this->Offers_model->getall_packages();
        $this->load->view('template',$template);
    }

    public function add_offer()
    {

        $data = $this->input->post('offer');
        $data['Company_id']=$this->session->userdata('CompanyId');
        $data['Branch_id']=$this->session->userdata('CompanyId');
        $data['From_date']=date("Y-m-d", strtotime($data['From_date']));
        $data['To_date']=date("Y-m-d", strtotime($data['To_date']));
        $this->db->insert('gc_offers',$data);
        $this->session->set_flashdata('payout_success', 'Added');
        redirect('master/Offers');
    }

    public function edit_offer()
    {
        $data = $this->input->post('offer');
        $id = $this->input->post('ID');

        $data['From_date']=date("Y-m-d", strtotime($data['From_date']));
        $data['To_date']=date("Y-m-d", strtotime($data['To_date']));
        $this->db->where('ID',$id);
        $this->db->update('gc_offers',$data);
        $this->session->set_flashdata('payout_success', 'Updated');
        redirect('master/Offers');
    }

    public function delete_offer($id)
    {
        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_offers',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Offers');
    }

  public function get_grades()
    {
      $id = $this->input->post('level');

      $data = $this->Offers_model->get_all_grades($id);
    if(isset($data)){

            echo '<option value="">Select Grade</option>';      
           
            
            foreach ($data as $value)  {

            echo '<option value="'.$value['ID'].'">'.$value['Grade_name'].'</option>';
                
            }}else{

            echo '<option value="">Select Grade</option>';            
          }
    }

  public function get_packages_grade()
    {
      $id = $this->input->post('level');

      $data = $this->Offers_model->get_all_pack($id);

    if(isset($data)){
            echo '<option value="">Select Package</option>';      
            foreach ($data as $value)  {
            echo '<option value="'.$value['ID'].'">'.$value['Package'].'</option>'; 
            }}else{
            echo '<option value="">Select Package</option>';            
          }
    }

    
}
