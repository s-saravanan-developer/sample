<div class="content-wrapper">
    <div class="content">
        <header class="page-header">
            <div class="d-flex align-items-center">
                <div class="mr-auto">
                    <h1 class="separator">Edit Lease </h1>
                    <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Lease Details / Edit Lease </li>
                        </ol>
                    </nav>
                </div>
                <ul class="actions top-right">
                    <li class="dropdown">
                        <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                        <i class="la la-ellipsis-h"></i>
                        </a>
                        <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
                            <div class="dropdown-header">
                                Quick Actions
                            </div>
                            <a href="#" class="dropdown-item">
                            <i class="icon dripicons-clockwise"></i> Refresh
                            </a>
                            <a href="#" class="dropdown-item">
                            <i class="icon dripicons-gear"></i> Manage Widgets
                            </a>
                            <a href="#" class="dropdown-item">
                            <i class="icon dripicons-cloud-download"></i> Export
                            </a>
                            <a href="#" class="dropdown-item">
                            <i class="icon dripicons-help"></i> Support
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </header>
        <section class="page-content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <h5 class="card-header">Edit Lease </h5>
                        <div class="card-body">
                            <form class="needs-validation" action="<?php echo base_url(); ?>lease/lease/edit_lease" method="post" data-toggle="validator" role="form" enctype="multipart/form-data">
                                <div class="form-row">

                                    <div class="form-group col-md-4" style="padding-top: 5px;">
                                        <label for="exampleFormControlSelect1">Customer <span style="color:red">*</span> </label>
                                        <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                        <select class="form-control" name="lease[customer_id]" id="country_id" required>
                                          <option value="">Select Customer</option>
                                            <?php if (!empty($customer)) {foreach ($customer as $value) {?>
                                            <option value="<?php echo ucfirst($value['customer_id']); ?>" <?php echo ($value['customer_id'] == $lease[0]['customer_id']) ? 'selected' : ''; ?>><?php echo ucfirst($value['customer_name']); ?></option>
                                            <?php } } ?>
                                        </select>
                                      </div>
                                    </div>
                                    <div class="form-group col-md-4" style="padding-top: 5px;">
                                        <label for="exampleFormControlSelect1">Area <span style="color:red">*</span> </label>
                                        <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                        <select class="form-control" name="lease[area_id]" id="area_id" required>
                                          <option value="">Select Area</option>
                                            <?php if (!empty($area)) {foreach ($area as $value) {?>
                                            <option value="<?php echo ucfirst($value['area_id']); ?>" <?php echo ($value['area_id'] == $lease[0]['area_id']) ? 'selected' : ''; ?>><?php echo ucfirst($value['area_name']); ?></option>
                                            <?php } } ?>
                                        </select>
                                      </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Area sqm <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text "><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control" value="<?php echo $lease[0]['area_sqm'] ?>" id="area_sqm" name="lease[area_sqm]" placeholder="Enter Area Sqm" required="" type="text" maxlength="50">
                                               <input name="lease_id" type="hidden" value="<?php echo encrypt($lease[0]['lease_id']); ?>">
                                            </div>                                            
                                         </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Area Rent <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text "><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control" value="<?php echo $lease[0]['area_rent'] ?>" id="area_rent" name="lease[area_rent]" placeholder="Enter Area Rent" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Area Total <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text "><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control" value="<?php echo $lease[0]['area_total'] ?>" id="area_total" readonly name="lease[area_total]" placeholder="Enter Area Total" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div>  
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput"> Management Fees <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control" name="lease[management_fees]" placeholder="Enter Management Fees" value="<?php echo $lease[0]['management_fees'] ?>" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div>      
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput"> Parking Fees <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control" name="lease[parking]" value="<?php echo $lease[0]['parking'] ?>" placeholder="Enter Parking Fees" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div>        
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput"> Aircondition Fees <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control" name="lease[aircondition]" placeholder="Enter Aircondition Fees" value="<?php echo $lease[0]['aircondition'] ?>" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div>    
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">  Start Date <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control date" name="lease[start_date]" placeholder="Enter Start Date" required="" value="<?php echo date('d-m-Y',strtotime($lease[0]['start_date'])); ?>" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">  End Date <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control date" name="lease[end_date]" placeholder="Enter End Date" required="" value="<?php echo date('d-m-Y',strtotime($lease[0]['end_date'])); ?>" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">  Escalation Rate <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control" name="lease[escalation]" value="<?php echo $lease[0]['escalation'] ?>" placeholder="Enter Escalation Rate" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div> 
                                    <div class="form-group col-md-4" style="padding-top: 5px;">
                                        <label for="exampleFormControlSelect1">Status <span style="color:red">*</span> </label>
                                        <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text "><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                        <select class="form-control" name="lease[status]" required>
                                          <?php if ($lease[0]['status']==1) { ?>
                                            <option value="1">Active</option>
                                            <option value="2">In-Active</option>
                                          <?php }else{ ?>
                                            <option value="2">In-Active</option>
                                            <option value="1">Active</option>
                                          <?php } ?>
                                        </select>
                                      </div>
                                    </div> 
                                </div>
                                <div class="row">
                             
                                <h5 class="card-header">User Defined Feilds
                                 </h5>
                              <div class="col-12">
                                 <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">  UDF 1 <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control" value="<?php echo $lease[0]['udf_1'] ?>" name="lease[udf_1]" placeholder="Enter UDF 1" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">  UDF 2 <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control" value="<?php echo $lease[0]['udf_2'] ?>" name="lease[udf_2]" placeholder="Enter UDF 2" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">  UDF 3 <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control" value="<?php echo $lease[0]['udf_3'] ?>" name="lease[udf_3]" placeholder="Enter UDF 3" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                                <script>
                                    $(document).ready(function(){
                                     $('.date').datepicker();
                                    });
                                </script>
                        </div>
                        <div class="card-footer bg-light ">
                            <button class="btn btn-success" type="submit">Submit</button>
                            <a href="<?php echo base_url(); ?>lease/lease" class="btn btn-accent">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
</div>
<script src="<?php echo base_url(); ?>/assets/vendor/jquery/dist/jquery.min.js"></script>

<script type="text/javascript">
  
  $(document).ready(function() {
    $('.gstin').prop( "disabled", true );
    });
      $('select#gst_in').change(function() {
        var selectedText = $(this).find('option:selected').val();     
        if(selectedText == '1' || selectedText == '2' ){
        $('.gstin').prop( "disabled", false );
        $('.gstin').attr('required','required');        
        }
        else {
          $('.gstin').prop( "disabled", true );
        $('.gstin').removeAttr('required');
        }
      });
</script>


<script type="text/javascript">
 
 function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

  $('#area_id').on('change', function() {
    area=$('#area_id').val();             

    $.ajax({                    
      type: "POST",
      url: "<?php echo base_url(); ?>lease/lease/get_area_by_areaid",  
      data: {area: area},
      success: function(data){
        var result = JSON.parse(data);
            $('#area_sqm').empty();
            $('#area_sqm').val(result[0]['area_sqm']);
            $('#area_rent').empty();
            $('#area_rent').val(result[0]['area_rent']);
            $('#area_total').empty();
            $('#area_total').val(result[0]['area_rent']*result[0]['area_sqm']);
      }
    });
  });

  $(document).ready(function(){
    $('#area_sqm').on('keyup', function() {
      $('#area_total').empty();
      $('#area_total').val($('#area_sqm').val()*$('#area_rent').val());
    });
    $('#area_rent').on('keyup', function() {
      $('#area_total').empty();
      $('#area_total').val($('#area_sqm').val()*$('#area_rent').val());
    });
  });
</script>