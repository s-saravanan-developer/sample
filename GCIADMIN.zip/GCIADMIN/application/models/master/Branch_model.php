<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Branch_model extends CI_Model {

    private $gc_gst_table = 'gc_hub_branch';



   public function get_all_branch() {
        $this->db->select('*');
        $this->db->from('gc_hub_branch');        
        $this->db->where('gc_hub_branch.Status', 1);
        $this->db->where('gc_hub_branch.branch_code!=', "");
        $this->db->where('gc_hub_branch.company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            
            return $query->result_array();
        }
        return NULL;
    }

    public function get_all_branch_for_front_view() {
        $this->db->select('*');
        $this->db->from('gc_hub_branch');        
        $this->db->where('gc_hub_branch.Status', 1);
        $this->db->where('gc_hub_branch.branch_code!=', "");
        $this->db->where('gc_hub_branch.company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            $branch_base = $query->result_array(); 
            foreach ($branch_base as $key => $value) {
                $delete_status = $this->check_delete_status($value['id']);
                if(isset($delete_status)){ 
                    $branch_base[$key]['delete_status'] = 1; 
                }
                else{ 
                    $branch_base[$key]['delete_status'] = 0;
                }    
            }
            return $branch_base;
        }
        return NULL;
    }

    public function check_delete_status($region){
        $this->db->select('region.id');
        $this->db->from('gc_hub_branch as region');        
        $this->db->join('gc_products as product','region.id = product.Division','left');
        $this->db->join('gc_team as team','team.region_id = region.id','left');
        $this->db->join('gc_customers as customer','customer.Division_id = region.id','left');
        $this->db->where('team.region_id ='.$region.' or customer.Division_id = '.$region.' or find_in_set("'.$region.'", product.Division)' );
        $this->db->where('region.company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_all_region() {
        $this->db->select('*');
        $this->db->from('gc_hub_branch');        
        $this->db->where('gc_hub_branch.Status', 1);
        $this->db->where('gc_hub_branch.branch_code!=', "");
        $this->db->where('gc_hub_branch.company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

       public function get_all_branch_active() {
        $this->db->select('*');
        $this->db->from('gc_hub_branch');        
        $this->db->where('gc_hub_branch.Status', 1);
        $this->db->where('gc_hub_branch.company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

        public function get_prefix()
    {
        $this->db->select('branch_prefix,hub_prefix');
        $query = $this->db->get("gc_prefix_setting");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_all_branch_specific($id) {
        $this->db->select('*');
        $this->db->from('gc_hub_branch'); 
        $this->db->where('company_id', $this->session->userdata('CompanyId'));
        //$this->db->where('gc_hub_branch.Status!=', 3);
        $this->db->where('id', $id);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_all_drug_type() {
        $this->db->select('*');
        $this->db->from('gc_super_categories'); 
        $this->db->where('company_id', $this->session->userdata('CompanyId'));
        $this->db->where('status', 1);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_state_code_data($id) {
        $this->db->select('*,branch.id as b_id');
        $this->db->from('gc_hub_branch as branch');  
        $this->db->join('gc_states as state', 'state.id = branch.state_id', 'left'); 
        $this->db->where('branch.company_id', $this->session->userdata('CompanyId'));
        $this->db->where('branch.id', $id);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }


     public function get_all_branch_specific_export($id) {
        $this->db->select('*');
        $this->db->from('gc_hub_branch');        
        //$this->db->where('gc_hub_branch.Status!=', 3);
        $this->db->where('company_id', $this->session->userdata('CompanyId'));

         $id = explode(",", $id); 
         
        $this->db->where_in('id', $id);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_hub_increment_code() {
         $query = $this->db->query("SELECT count(hub_code) as hub_code FROM gc_hub_branch");
         $entry_number=$query->row()->hub_code+1;
         return $entry_number;
    }

    public function get_branch_increment_code() {

        $query = $this->db->query('SELECT count(branch_code) as branch_code FROM gc_hub_branch');
        $entry_number=$query->row()->branch_code+1;
        return $entry_number;
    }

    public function get_all_regions_by_id($id) {

        $this->db->select('*');
        $this->db->where('Division', $id);
        $this->db->where('company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get("gc_product_rate_setting");
        return $query->num_rows(); 
            // $query->result_array();
          
    }

    public function get_all_Products()
    {
        $this->db->select('*');
        $this->db->where_not_in('status',3);
        $this->db->where('company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get('gc_products');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

   /**
     * Branch Data Add 
     */
    public function inserting_branch($branch_data)
    {
        $modify['Module_name'] = "City";
        $modify['Data'] = $branch_data['type_name'];
        $modify['Action'] = "1";
        $modify['Created_by'] = $this->session->userdata('UserId');
        $this->db->insert('gc_modification_history', $modify);
        $branch_data['company_id'] = $this->session->userdata('CompanyId');
        $branch_data['financial_yr_id'] = $this->session->userdata('Financial_yr_id');
        $branch_data['Created_by'] = $this->session->userdata('UserId');
        $branch_data['created_date'] = date('Y-m-d H:i:s');
        $this->db->insert('gc_hub_branch', $branch_data); 
        $this->session->set_flashdata('branch_success', 'Added');
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }

    public function get_state_code($id) {
        $this->db->select("gc_states" . '.state_code');
        $this->db->where('id', $id);
        $query = $this->db->get("gc_states");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;       
    }


    public function update_prefix_transaction($id,$data) {        
           // $data['updated_date'] = date();
           $data['Updated_by'] = $this->session->userdata('UserId');
           $this->db->where('id', $id);
        if ($this->db->update('gc_transaction_prefix_region', $data)) {
            return TRUE;
        }
        return FALSE;  
    }

    public function update_prefix_transaction_common($id,$data) {
           // $data['updated_date'] = date();
           $data['Updated_by'] = $this->session->userdata('UserId');
           $this->db->where('id', $id);
        if ($this->db->update('gc_transaction_prefix_region', $data)) {
            return TRUE;
        }
        return FALSE;  
    }

    public function update_prefix_transaction_advice($id,$data) {
            // print_r($data);
           // $data['updated_date'] = date();
           $data['Updated_by'] = $this->session->userdata('UserId');
           $this->db->where('id', $id);
        if ($this->db->update('gc_transaction_prefix_region', $data)) {
            return TRUE;
        }
        return FALSE;  
    }


    public function update_prefix_sales_order($id,$sales_order)
    {
        $sales_order['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', $id);
        $this->db->where('common_based_prefix_status',1);
        if ($this->db->update('gc_transaction_prefix_region', $sales_order)) {
            $this->session->set_flashdata('success', 'Updated');
            return TRUE;
        }
        return FALSE;       
    }

    public function update_prefix_direct_sale($id,$direct_sale)
    {
        $sales_order['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', $id);
        $this->db->where('common_based_prefix_status',1);
        if ($this->db->update('gc_transaction_prefix_region', $direct_sale)) {
            $this->session->set_flashdata('success', 'Updated');
            return TRUE;
        }
        return FALSE;       
    }

    /**
     * Branch Data Update 
     */
    public function updating_branch($branch_data,$id)
    {
        $modify['Module_name']="Branch";
                $modify['Data']=$branch_data['type_name'];
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);
         $branch_data['Updated_by']=$this->session->userdata('UserId');       
        $branch_data['update_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', $id);
        if ($this->db->update('gc_hub_branch', $branch_data)) {
            $this->session->set_flashdata('branch_success', 'Updated');
            return TRUE;
        }
        return FALSE;       
    }

    /**
     * Gst Data Edit 
     */
    public function editing_gst($gst_data_edit,$id)
    {
        $gst_data_edit['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', $id);
        if ($this->db->update('gc_gst', $gst_data_edit)) {
            return TRUE;
        }
        return FALSE;       
    }


    /**
     * Comman Model To Delete or update the Data
     * @param  [type] $table_name [description]
     * @param  [type] $id         [description]
     * @return [type]             [description]
     */
    public function delete($table_name,$id)
    {
        $this->db->where('id', $id);
            $query = $this->db->get('gc_hub_branch');
            $get['data']=$query->result_array();
                $modify['Module_name']="Branch";
                $modify['Data']=$get['data'][0]['type_name'];
                $modify['Action']="3";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);
                $data['Deleted_by']=$this->session->userdata('UserId');
        $data['status'] ="3";
        $this->db->where('id', $id);
        if ($this->db->update($table_name, $data)) {
            $this->session->set_flashdata('branch_success', 'Deleted');
            return TRUE;           
        }
        return FALSE;          
    }




    // Adding Branch Prefix Setting    
    public function adding_branch_prefix($id)
    {
        $prefix_data['company_id']=$this->session->userdata('CompanyId');
        $prefix_data['financial_yr_id']=$this->session->userdata('Financial_yr_id');
        $prefix_data['branch_id'] = $id;
        $this->db->insert('gc_prefix_setting', $prefix_data); 
    }

    // Adding Branch Prefix Setting    
    public function adding_transaction_prefix($id,$prefix_transaction_data)
    {
        $prefix_transaction_data['region_id'] = $id;
        $prefix_transaction_data['company_id'] = $this->session->userdata('CompanyId');
        $prefix_transaction_data['financial_yr_id'] = $this->session->userdata('Financial_yr_id');
        $prefix_transaction_data['common_based_prefix_status'] = 1;
        $this->db->insert('gc_transaction_prefix_region', $prefix_transaction_data); 
    }
    
    // Adding Branch Prefix Setting    
    public function adding_branch_details_user($id,$branch_data)
    {
       if($branch_data['hub_code'] != NULL){ 
        $branch_user_data['user_id']         = $branch_data['hub_code']; }
       else{
        $branch_user_data['user_id']        = $branch_data['branch_code']; }
       $branch_user_data['company_id']      = $branch_data['company_id'];
       $branch_user_data['branch_id']       = $id;
       $branch_user_data['firstname']       = $branch_data['type_name'];
       $branch_user_data['username']        = 'mybranch_'.$id;
       $branch_user_data['password']        = md5('welcome123');
       $branch_user_data['og_password']     = 'welcome123';
       $branch_user_data['email_address']   = $branch_data['email'];
       $branch_user_data['mobile_number']   = $branch_data['mobile'];
       $branch_user_data['address_line_1']  = $branch_data['address'];
       $branch_user_data['address_line_2']  = $branch_data['address2'];
       $branch_user_data['zipcode']         = $branch_data['pincode'];
       $branch_user_data['country_id']         = $branch_data['country_id'];
       $branch_user_data['state_id']         = $branch_data['state_id'];
       $branch_user_data['city_id']         = $branch_data['city_id'];
       $branch_user_data['user_type_id']    = 3;
       $this->db->insert('gc_users', $branch_user_data); 
      


    }



    
    function delete_checkbox($id){
    $data['update_date'] = date('Y-m-d H:i:s');
                  $data['status']         = 3;    
    
            $this->db->where('id', $id);
            if ($this->db->update('gc_hub_branch', $data)) {
                $this->session->set_flashdata('branch_success', 'Deleted');
                return TRUE;
           }
        
            return FALSE;                
         }
    
    
    function active_all_checkbox($id){
          
                 $data['update_date'] = date('Y-m-d H:i:s');
                  $data['status']         = 1;    
    
            $this->db->where('id', $id);
            if ($this->db->update('gc_hub_branch', $data)) {
                $this->session->set_flashdata('branch_success', 'Updated');
                return TRUE;
            }
            return FALSE;  
    }
    
    function deactivate_all_checkbox($id){
    
          $data['update_date'] = date('Y-m-d H:i:s');
          $data['status']         = 2;
    
            $this->db->where('id', $id);
            if ($this->db->update('gc_hub_branch', $data)) {
                $this->session->set_flashdata('branch_success', 'Updated');
                return TRUE;
            }
            return FALSE;  
    }


    // Supplier ADD in Region Inserting
    public function adding_ventors_for_branch($adding_ventors_data)
    {               
       // var_dump($adding_ventors_data);
        // $adding_ventors_data['Created_by']=$this->session->userdata('UserId');
        if ($this->db->insert('gc_ventors_table', $adding_ventors_data)) {
            $Supplier_id=$this->db->insert_id();
         return $Supplier_id;
            $this->session->set_flashdata('vendor_su', 'Added');
            return TRUE;
        }
        return FALSE;       
    }


     // Check region Based Customer
    public function teambased_customer($region_id,$id) {
        $this->db->select('customer.Customer_id as id,customer.Customer_name');
        $this->db->from('gc_customers as customer');
        $this->db->where('customer.Status!=', 3);
        $this->db->where('customer.Team_id', $id);
        $this->db->where('customer.Division_id', $region_id);
        $this->db->where('customer.company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }


    // Sales_direct Details Table
    public function inserting_sales_direct_data($data)
    {
        if ($this->db->insert('gc_transaction_prefix_region_direct_sale_details', $data)) {
            $this->session->set_flashdata('success', 'Added');
            return $this->db->insert_id();
        }
        return FALSE; 
    }

    public function updating_sales_direct_data($id,$data)
    {
         $this->db->where('Ds_id', $id);
        if ($this->db->update('gc_transaction_prefix_region_direct_sale_details', $data)) {
            $this->session->set_flashdata('success', 'Updated');
            return TRUE;
        }
        return FALSE;    
    }

    public function get_ds_existing_data($region_id,$team_id)
    {
        $this->db->select('details.*,details.Product_id as d_pro,customer.Customer_id,customer.Customer_name');
        $this->db->from('gc_transaction_prefix_region_direct_sale_details as details');
        $this->db->join('gc_customers as customer', 'customer.Customer_id = details.Customer_id', 'left');
        $this->db->where('details.Region_id', $region_id);
        $this->db->where('details.Team_id', $team_id);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
  
    

}