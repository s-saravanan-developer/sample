<script src="<?php echo base_url(); ?>/assets/vendor/jquery/dist/jquery.min.js"></script>
<div class="content-wrapper">
    <div class="content">
        <header class="page-header">
            <div class="d-flex align-items-center">
                <div class="mr-auto">
                    <h1 class="separator">Edit Company</h1>
                    <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard">Master</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Manage Company / Edit Company </li>
                        </ol>
                    </nav>
                </div>
                <ul class="actions top-right">
                    <li class="dropdown">
                        <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                        <i class="la la-ellipsis-h"></i>
                        </a>
                        <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
                            <div class="dropdown-header">
                                Quick Actions
                            </div>
                            <a href="#" class="dropdown-item">
                            <i class="icon dripicons-clockwise"></i> Refresh
                            </a>
                            <a href="#" class="dropdown-item">
                            <i class="icon dripicons-gear"></i> Manage Widgets
                            </a>
                            <a href="#" class="dropdown-item">
                            <i class="icon dripicons-cloud-download"></i> Export
                            </a>
                            <a href="#" class="dropdown-item">
                            <i class="icon dripicons-help"></i> Support
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </header>
        <section class="page-content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <h5 class="card-header">Edit Company</h5>
                        <div class="card-body">
                            <form class="needs-validation" action="<?php echo base_url(); ?>master/company/editing_company" method="post" data-toggle="validator" role="form" enctype="multipart/form-data">
                                <div class="form-row">
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Company Name <span style="color:red">*</span><code class="error_state" style="display: none"> [ Name Already Used ]</code></label>
                                            <input type="hidden" name="id" value="<?php echo $edit_company[0]['company_id']; ?>">
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control company_name company_name_validate" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="company[company_name]" placeholder="Enter Company Name" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Contact Person <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-account zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control contact_person" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="company[contact_person]" placeholder="Enter Contact Person" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                    </div>
                                    <div id="branch_input" class="form-group col-md-4 ">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Mobile Number <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-smartphone-iphone zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control mobile_number" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="company[mobile_number]" placeholder="Enter Mobile Number" required="" type="text" pattern="[6-9]{1}[0-9]{9}" maxlength="10" onkeypress="return isNumber(event)">
                                            </div>                                            
                                         </div>
                                    </div>
                                     <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Email <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-email zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control email" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="company[email]" placeholder="Enter Email" required="" type="email">
                                            </div>                                            
                                         </div>
                                    </div>
                                     <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Phone Number</label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-phone zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control phone_number" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="company[phone_number]" placeholder="Enter Phone Number" type="text" maxlength="11" onkeypress="return isNumber(event)">
                                            </div>                                            
                                         </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="row">
                                        <div class="col-md-8">
                                            <div class="form-group">
                                                <label class="col-form-label-lg control-label" for="largeInput">Company Logo</label>
                                                <span class="">
                                                <input type="file" id="profile_image" class="form-control" name="company_logo" >
                                                <input type="hidden" value="<?php echo $edit_company[0]['company_logo']; ?>" name="old_file_name">
                                                </span>                                            
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                            <a href="javascript:void(0);">
                                              <?php 
                                              if($edit_company[0]['company_logo'] != NULL){
                                                $img = $edit_company[0]['company_logo'];}
                                              else{ 
                                                $img = "default_profile_image.png";} 
                                                ?>
                                                <img id="imagePreview" src="<?php echo base_url(); ?>attachments/company_logo/<?php echo $img; ?>" style="width: 60px; height: 60px; margin-top: 7px; border: 2px #ccc solid; " alt="Company Logo" default_src="<?php echo base_url(); ?>attachments/users_image/default_profile_image.png">
                                                <?php
                                                  
                                                 ?>
                                            </a>
                                        </div>
                                        </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="exampleFormControlTextarea1">address 1</label> <span style="color:red">*</span>
                                            <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-card zmdi-hc-fw"></i></span>
                                       </div>
                                            <input type="text" class="form-control" id="exampleFormControlTextarea1" name="company[address1]" rows="3" placeholder="Enter address 1" required="" value="<?php echo $edit_company[0]['address1']; ?>" />
                                        </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="exampleFormControlTextarea1">address 2</label>
                                            <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-card zmdi-hc-fw"></i></span>
                                       </div>
                                            <input type="text" class="form-control" id="exampleFormControlTextarea2" name="company[address2]" placeholder="Enter address 2" value="<?php echo $edit_company[0]['address2']; ?>" />
                                        </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Pincode <span style="color:red">*</span></label>
                                            <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin zmdi-hc-fw"></i></span>
                                       </div>
                                               <input class="form-control zip_code " aria-label="Icon Left" aria-describedby="basic-icon-addon1" maxlength="6" pattern="[1-9]{1}[0-9]{5}" name="company[zip_code]" placeholder="Enter the PinCode" required="" type="text" onkeypress="return isNumber(event)">
                                            </div>                                            
                                         </div>
                                    </div>
                                    
                                    <div class="form-group col-md-4" style="padding-top: 7px;">
                                        <label for="exampleFormControlSelect1">country <span style="color:red">*</span></label>
                                        <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                        <select class="form-control country custom-select company_country" name="company[country]" id="country_id">
                                          <option>Select country</option>
                                            <?php
                                                if (!empty($countries)) {
                                                    foreach ($countries as $country) {
                                                        ?>
                                            <option value="<?php echo ucfirst($country['id']); ?>" <?php echo ($country['id'] == 1) ? 'selected' : ''; ?>><?php echo ucfirst($country['country_name']); ?></option>
                                            <?php
                                                }
                                                }
                                                ?>
                                        </select>
                                    </div>
                                    </div>
                                    <div class="form-group col-md-4" style="padding-top: 7px;">
                                        <label for="exampleFormControlSelect1">State <span style="color:red">*</span></label>
                                        <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                        <select class="form-control state company_state" name="company[state_id]" id="state_id"><option>Select State</option>
                                            <?php
                                                if (!empty($states)) {
                                                    foreach ($states as $state) {
                                                        ?>
                                            <option value="<?php echo $state['id']; ?>"><?php echo ucfirst($state['state_name']); ?></option>
                                            <?php
                                                }
                                                }
                                                ?>
                                        </select>
                                    </div>
                                    </div>
                                    
                                    <div class="form-group col-md-4" style="padding-top: 7px;">
                                        <label for="exampleFormControlSelect1">City <span style="color:red">*</span></label>
                                        <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                        <select class="form-control city_id company_city" name="company[city_id]" id="city_id"><option>Select City</option>
                                           <?php
                                                if (!empty($city)) {
                                                    foreach ($city as $values) {
                                                        ?>
                                            <option value="<?php echo $values['id']; ?>"><?php echo ucfirst($values['city_name']); ?></option>
                                            <?php
                                                }
                                                }
                                                ?>
                                        </select>
                                    </div>
                                    </div>


                                    <?php 

                                      // if($edit_company[0]['tax_no1'] != NULL){ ?>
                                        
                                        <!-- <div class="form-group col-md-4" style="padding-top: 8px;">
                                        <label for="exampleFormControlSelect1">Tax No 1</label> <span class="text-danger">*</span>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-trending-up zmdi-hc-fw"></i></span>
                                               </div>
                                        <select class="form-control tax_no2" id="gst_in" name="company[tax_no2]" style="height: calc(2.25rem + -8px);">
                                            <option class="gstn_disable" value="0">Select GST Type</option>
                                            <option class="gstn_enable" value="1">GST Registered - Regular</option>
                                            <option id="enable" class="gstn_enable" value="2">GST Registered - Composition</option>
                                            <option class="gstn_disable" value="3">GST Unregistered</option>
                                            <option class="gstn_disable" value="4">Consumer</option>
                                        </select>
                                      </div>
                                    </div> -->

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Tax No 1 </label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-trending-up zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control gstin tax_no1 validate_only_char_num" aria-label="Icon Left" aria-describedby="basic-icon-addon1"   type="text" name="company[tax_no1]" style="text-transform: uppercase;" placeholder="ENTER Tax No 1"> 
                                               
                                            </div>                                          
                                         </div>
                                    </div>
                                    
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Tax No 2 </label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-trending-up zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control gstin tax_no2 validate_only_char_num" aria-label="Icon Left" aria-describedby="basic-icon-addon1"   type="text" name="company[tax_no2]" style="text-transform: uppercase;" placeholder="ENTER Tax No 2"> 
                                               
                                            </div>                                          
                                         </div>
                                    </div>

<?php //if($edit_company[0]['tax_no1'] != 0){ ?>
<!-- <script>
  alert();
  $(document).ready(function() {
  // $('.gstin').prop( "disabled", true );
    // $('select#gst_in').change(function() 
    {
      var selectedText = $(this).find('option:selected').val();     
      if(selectedText == '1' || selectedText == '2' ){
      $('.gstin').prop( "disabled", false );
      $('.gstin').attr('required','required');   
      $('.tax_no1').val('<?php //echo $edit_company[0]['tax_no1']; ?>');
      }
      else {
        $('.gstin').prop( "disabled", true );
        $('.gstin').removeAttr('required');
        $('.gstin').val('');
      }
    // });
    $('select#gst_in').ready(function() {
      var selectedText = $(this).find('option:selected').val();     
      if(selectedText == '1' || selectedText == '2' ){
      $('.gstin').prop( "disabled", false );
      $('.gstin').attr('required','required');   
      $('.tax_no1').val('<?php //echo $edit_company[0]['tax_no1']; ?>');
      }
      else {
        $('.gstin').prop( "disabled", true );
        $('.gstin').removeAttr('required');
        $('.gstin').val('');
      }
    });
});
</script> -->
<?php //}else{ ?>
<!-- <script>
  $(document).ready(function() {
    $('.gstin').prop( "disabled", true );
    });
      $('select#gst_in').change(function() {
        var selectedText = $(this).find('option:selected').val();     
        if(selectedText == '1' || selectedText == '2' ){
        $('.gstin').prop( "disabled", false );
        $('.gstin').attr('required','required');        
        }
        else {
          $('.gstin').prop( "disabled", true );
        $('.gstin').removeAttr('required');
        }
      });
</script> -->

<?php //} ?>
                                    <?php  

                                  // }else{

                                      // }

                                     ?>
                                    



                                     <div class="form-group col-md-4">
                                        <div class="form-group">
                                            <label class="col-form-label-lg control-label" for="largeInput">Website Link</label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-link zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control website_link validate_website" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="company[website_link]" placeholder="Enter Website Link" type="text">
                                            </div>                                            
                                         </div>
                                     </div>    
                                    <div class="form-group col-md-4 " >
                                        <label for="exampleFormControlSelect1">Status</label>
                                        <div class="input-group mb-3">
                                 <div class="input-group-prepend">
                                    <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-equalizer zmdi-hc-fw"></i></span>
                                 </div>
                                        <select class="form-control" name="company[status]" id="exampleFormControlSelect1" style="height: calc(2.25rem + -8px);">
                                            <option value="1">Active</option>
                                            <option value="2">Inactive</option>
                                        </select>
                                    </div>
                                    </div>
                                </div>
                        </div>
                        <div class="card-footer bg-light ">
                            <button class="btn btn-success" type="submit">Update</button>
                            <a href="<?php echo base_url(); ?>master/company/" class="btn btn-accent">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
</div>




<script type="text/javascript">
            $('.company_id').val('<?php echo $edit_company[0]['company_id']; ?>');
            $('.company_type').val('<?php echo $edit_company[0]['company_type']; ?>');
            $('.company_name').val('<?php echo $edit_company[0]['company_name']; ?>');
            // $('.company_logo').val('<?php //echo $edit_company[0]['company_logo']; ?>');
            $('.contact_person').val('<?php echo $edit_company[0]['contact_person']; ?>');
            $('.mobile_number').val('<?php echo $edit_company[0]['mobile_number']; ?>');
            $('.phone_number').val('<?php echo $edit_company[0]['phone_number']; ?>');
            $('.email').val('<?php echo $edit_company[0]['email']; ?>');
            $('.country').val('<?php echo $edit_company[0]['country']; ?>');
            $('.state').val('<?php echo $edit_company[0]['state_id']; ?>');
            $('.city_id').val('<?php echo $edit_company[0]['city_id']; ?>');
            $('.tax_no1').val('<?php echo $edit_company[0]['tax_no1']; ?>');
            $('.tax_no2').val('<?php echo $edit_company[0]['tax_no2']; ?>');
            $('.credit_days').val('<?php echo $edit_company[0]['credit_days']; ?>');
            $('.website_link').val('<?php echo $edit_company[0]['website_link']; ?>');
            $('.notes').val('<?php echo $edit_company[0]['notes']; ?>');
            $('.status').val('<?php echo $edit_company[0]['status']; ?>');
            $('.created_on').val('<?php echo $edit_company[0]['created_on']; ?>');
            $('.updated_on').val('<?php echo $edit_company[0]['updated_on']; ?>');
            $('.zip_code').val('<?php echo $edit_company[0]['zip_code']; ?>');
</script>


<script type="text/javascript">
  
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

$('.company_name_validate').change(function(){
     $.ajax({
               type: "POST",
               url: "<?php echo base_url(); ?>master/Company/check_duplicate_company_name",
               data: {company_name: $('.company_name_validate').val()},
               cache: true,
               async: false,
               success: function(data){
                if(data == 1){
                  $('.error_state').show();
                  $('.company_name_validate').focus();
                  $('.company_name_validate').select();
                }else{
                  $('.error_state').hide();                 
                }
               }
             });
});
</script>