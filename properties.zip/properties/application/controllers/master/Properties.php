<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Properties extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
    }

	public function index()
	{
    	$template['page']='master/properties_types/viewproperties_types';
      $template['properties_types'] =  $this->Master_model->getall_properties_types();
      // $template['weeks']  =  $this->Master_model->get_weeks();
      $this->load->view('template',$template);
	}


    public function add()
    {
        
        $prop_data = $this->input->post('prop_type');
        $prop_data['created_by']=$this->session->userdata('id');
        $prop_data['company_id']=$this->session->userdata('company_id');
        $this->db->insert('prop_properties_types',$prop_data);
        $this->session->set_flashdata('country_success', 'Added');
        redirect('master/Properties');
    }


    public function edit()
    {
        $id=decrypt($this->input->post('prop_type_id'));
        $prop_data = $this->input->post('prop_type');
        $prop_data['updated_by']=$this->session->userdata('id');
        $this->db->where('prop_type_id',$id);
        $this->db->update('prop_properties_types',$prop_data);
        $this->session->set_flashdata('country_success', 'Updated');
        redirect('master/Properties');
    }


    public function delete($id)
    {
        $id=decrypt($this->input->post('delete_id'));
        $data = array('Status' => 3);
        
        $this->db->where('prop_type_id',$id);
        $this->db->update('prop_properties_types',$data);

        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Properties');
    }

                public function check1() {
        $data['page'] = 'import';
        $data['title'] = 'Import XLSX | TechArise';
        $this->load->view('sampleselect', $data);
    }

       public function check() {
        $data['page'] = 'import';
        $data['title'] = 'Import XLSX | TechArise';
        $this->load->view('import/index', $data);
    }



    
    public function checkbox_action(){
                 $id = ( explode( ',', $this->input->get_post('id') ));             
                 $status = $this->input->get_post('status');             
                 foreach ($id as  $value) {
                                  // $this->Users_model->delete_checkbox($value);
                                  $data['updated_date'] = date('Y-m-d H:i:s');
                                  $data['status']         = $status;    
                              // var_dump($data);die();
                                  $this->db->where('prop_type_id', $value);

                        if ($this->db->update('prop_properties_types', $data)) {
                            $this->session->set_flashdata('user_success', 'Deleted');
                            return TRUE;
                  }
                 }
        }
    
        // public function active_all_checkbox(){
        //          $id = ( explode( ',', $this->input->get_post('id') ));             
        //          foreach ($id as  $value) {
        //              $this->Users_model->active_all_checkbox($value);
        //          }
        // }
    
        // public function deactivate_all_checkbox(){
        //          $id = ( explode( ',', $this->input->get_post('id') ));             
        //          foreach ($id as  $value) {
        //              $this->Users_model->deactivate_all_checkbox($value);
        //          }
        // }
    


    
        // public function delete_checkbox1(){
        //          $id = ( explode( ',', $this->input->get_post('id') ));        

        //          foreach ($id as  $value) {
        //              $this->Users_model->delete_checkbox1($value);
        //          }
        // }
    
        // public function active_all_checkbox1(){
        //          $id = ( explode( ',', $this->input->get_post('id') ));             
        //          foreach ($id as  $value) {
        //              $this->Users_model->active_all_checkbox1($value);
        //          }
        // }
    
        //  public function active_all_checkbox11(){
        //          $id = ( explode( ',', $this->input->get_post('id') ));  
                            
        //          foreach ($id as  $value) {
        //              $this->Users_model->active_all_checkbox11($value);
        //          }
        // }
    


   
   
   function active_all_checkbox($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 1;    
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_users', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
   function deactivate_all_checkbox($id){
   
         $data['updated_date'] = date('Y-m-d H:i:s');
         $data['status']         = 2;
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_users', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
   
   
   function delete_checkbox1($id){
   // $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status'] = 3;    
   
           $this->db->where('user_id', $id);
           $this->db->where('user_mode', 2);
           if ($this->db->update('prop_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Deleted');
               return TRUE;
          }
       
           return FALSE;                
        }
   
   
   function active_all_checkbox1($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 1;    
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
    function active_all_checkbox11($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 2;    
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }



}
