<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Membership_model extends CI_Model { 

	function getall_bank() {

		$this->db->select('*');
		$this->db->where('Status',1);
		$this->db->order_by("ID", "DESC");
		$query = $this->db->get('gc_bank');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

	function get_member_by_details($id) {

		$this->db->select('gc_membership.Membership_ID');

		if(!empty($id)){
		$where = '(Membership_code="'.$id.'" or Mobile = "'.$id.'")';
		$this->db->where($where);}

		$query = $this->db->get('gc_membership');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}
 // function get_contract_by($id) {
 //    var_dump($id);
 //    $this->db->select('member.*,topup.Franchise');
 //    $this->db->from('gc_member_franchisee_contract as member');
 //    $this->db->join('gc_member_topup as topup', 'topup.ID = member.Topup_ID', 'left');

 //    $this->db->where('member.Contract_ID',$id);

 //    $query = $this->db->get();
 //    if ($query->num_rows() > 0) {
 //        return  $query->result_array();
 //    }
 //    return NULL;
 //    }

	function get_wallet_balance($Membership_ID) {

		$this->db->select('Wallet_balance,Pay_date');
		$this->db->where('Membership_ID',$Membership_ID);
		$query = $this->db->get('gc_membership');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}
 function get_contract_by($id,$date) {
// var_dump($id);
	$this->db->select('member.*,topup.Franchise,membership.First_name,membership.Last_name,withdraw.Withdraw_type');
	$this->db->from('gc_membership as membership');
	$this->db->join('gc_member_franchisee_contract as member','member.Membership_ID = membership.Membership_ID', 'left');
	$this->db->join('gc_member_topup as topup', 'topup.ID = member.Topup_ID', 'left');
	$this->db->join('gc_withdraw as withdraw', 'withdraw.ID = member.Request_type', 'left');

	$this->db->where('member.Request_status',2);
	// $this->db->where('membership.Membership_code',$id);

	if ($id != "") {
		$this->db->where('membership.Membership_code',$id);
	}

	//  if ($date != "") {
	//     $this->db->where('member.Request_date',$date);
	// }

	$query = $this->db->get();
	if ($query->num_rows() > 0) {
		return  $query->result_array();
	}
	return NULL;
	}

 function get_contract_by_success($id,$date) {
// var_dump($date);
	$this->db->select('member.*,topup.Franchise,membership.First_name,membership.Last_name,withdraw.Withdraw_type');
	$this->db->from('gc_membership as membership');
	$this->db->join('gc_member_franchisee_contract as member','member.Membership_ID = membership.Membership_ID', 'left');
	$this->db->join('gc_member_topup as topup', 'topup.ID = member.Topup_ID', 'left');
	$this->db->join('gc_withdraw as withdraw', 'withdraw.ID = member.Request_type', 'left');

	$this->db->where('member.Request_status',3);

	if ($id != "") {
		$this->db->where('membership.Membership_code',$id);
	}

	 if ($date != "") {
		$this->db->where('member.Request_date',$date);
	}

	$query = $this->db->get();
	if ($query->num_rows() > 0) {
		return  $query->result_array();
	}
	return NULL;
	}

	 function get_contract_by_failed($id,$date) {
// var_dump($date);
	$this->db->select('member.*,topup.Franchise,membership.First_name,membership.Last_name,withdraw.Withdraw_type');
	$this->db->from('gc_membership as membership');
	$this->db->join('gc_member_franchisee_contract as member','member.Membership_ID = membership.Membership_ID', 'left');
	$this->db->join('gc_member_topup as topup', 'topup.ID = member.Topup_ID', 'left');
	$this->db->join('gc_withdraw as withdraw', 'withdraw.ID = member.Request_type', 'left');

	$this->db->where('member.Request_status',4);

	if ($id != "") {
		$this->db->where('membership.Membership_code',$id);
	}

	 if ($date != "") {
		$this->db->where('member.Request_date',$date);
	}

	$query = $this->db->get();
	if ($query->num_rows() > 0) {
		return  $query->result_array();
	}
	return NULL;
	}


	public function get_child_by_parent_contract_initial($id) { 
	// var_dump($id);die();    
		 $this->db->select('sum(table2.Amount) as contract_initial');
		 $this->db->from('gc_franchisee_member_relation as tree');
		 $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
		 $this->db->join('gc_membership as members', 'members.Membership_ID = tree.Parent_ID', 'left');
		 $this->db->join('gc_member_franchisee_contract as table2', 'table2.Membership_ID = member.Membership_ID', 'left');

		$this->db->where('table2.Invest_type',1);
		$this->db->where('member.Membership_ID',$id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
	}

	function get_member_detailbyid($id) {

		$this->db->select('gc_membership.Membership_ID');
		$where = '(Membership_code="'.$id.'" or Mobile = "'.$id.'")';
		$this->db->where($where);
		$query = $this->db->get('gc_membership');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}
	function getall_payment_modes() {

		$this->db->select('*');
		$this->db->where('Status',1);
		$query = $this->db->get('gc_payment_mode');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

function get_doc_records($id) {

		$this->db->select('*');
		$this->db->where('Membership_ID',$id);
		$query = $this->db->get('gc_member_documents');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

function get_bank_records($id) {

		$this->db->select('bank.*,gc_bank.Bank_name');
		$this->db->from('gc_member_banks as bank');
		$this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');

		$this->db->where('Membership_ID',$id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

	

function get_pays_records($id,$contract_id) {

		$this->db->select('payment.*,mode.Payment_mode,gc_bank.Bank_name');
		$this->db->from('gc_member_payments as payment');
		$this->db->join('gc_member_franchisee_contract as contract','contract.Contract_ID=payment.Contract_ID','left');
		$this->db->join('gc_payment_mode as mode','mode.ID=payment.Payment_type_ID','left');
		$this->db->join('gc_bank as gc_bank', 'gc_bank.ID = payment.Bank_ID', 'left');
		$this->db->where('contract.Membership_ID',$id);
		$this->db->where('contract.Contract_ID',$contract_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	
	}

function get_direct_details($id) {
		$this->db->select('sum(contract.Amount) as direct_member_payment');
		$this->db->from('gc_member_franchisee_contract as contract');
		$this->db->join('gc_member_level_details as level', 'level.Child_ID = contract.Membership_ID', 'left');
		$this->db->where('level.Membership_ID',$id);
		$this->db->where('level.Level_ID',1);
		$this->db->where('contract.Withdrawn_status',5);
		$this->db->where('contract.Contract_status',6);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}
	

	public function get_ref_details($membership_ID){
		return $this->db->get_where('gc_membership',array('Membership_ID'=>$membership_ID))->row('First_name');
	}

	function get_members_records($id) {

		// $this->db->select('member.First_name,member.Last_name,member.Created_date,member.Mobile,member.Gender,member.Membership_code,member.Status as Member_status,type.Membership_type,contract.Contract_ID,payments.Payment_status');

		 $this->db->select('member.First_name,member.Last_name,member.Created_date,member.Mobile,member.Gender,member.Membership_code,member.Status as Member_status,type.Membership_type,payments.Payment_status,contract.Contract_ID,member.Membership_type,member.Register_from,member.Payment_verify,member.Created_by');
		 $this->db->from('gc_membership as member');
		 $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
		$this->db->where('member.Membership_ID',$id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	
	}

public function get_member_done_by($id){
	return $this->db->get_where('gc_users',array('id'=>$id))->row('firstname');
}
	
public function Profile_tab_details($Membership_ID){

}
public function Referal_tab_details($Membership_ID){
	$this->db->select('member.Membership_ID,member.Membership_code,member.Mobile,CONCAT(member.First_name,member.Last_name) as Name,contract.Amount,member.Created_date');
	$this->db->from('gc_membership as member');
	$this->db->join('gc_franchisee_member_relation as relation','relation.Child_ID=member.Membership_ID','left');
	$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=relation.Child_ID','left');
	$this->db->where('relation.Parent_ID',$Membership_ID);
	// $this->db->where('contract.Invest_type',1);
	$query=$this->db->get();
	if($query->num_rows()>0){
		return $query->result_array();
	}else{
		return NULL;
	}
}
public function Investment_tab_details($Membership_ID){
	$this->db->select('member.Membership_ID,member.Membership_code,CONCAT(member.First_name,member.Last_name) as Name,member.Doc_verify,contract.Date,contract.Invest_type,contract.Amount,contract.Contract_status');
	$this->db->from('gc_membership as member');
	$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=member.Membership_ID','left');
	$this->db->where('member.Membership_ID',$Membership_ID);
	$query=$this->db->get();
	if($query->num_rows()>0){
		return $query->result_array();
	}else{
		return NULL;
	}
}
public function Level_benefits_tab_details($Membership_ID){
	return $this->db->select('lvl.*,type.alias_name')->where('lvl.Status',1)->join('gc_payout_type as type','type.id=lvl.Payout_type','left')->get('gc_level as lvl')->result_array();
}
public function Level_list_tab_details($Membership_ID){
	return $this->db->select('lvl.*,type.alias_name')->where('lvl.Status',1)->join('gc_payout_type as type','type.id=lvl.Payout_type','left')->get('gc_level as lvl')->result_array();
}
public function Upline_view_tab_details($Membership_ID){
	// $membership_id=$this->db->get_where('gc_membership',array('Membership_ID'=>$Membership_ID))->row('Membership_ID');
	$membership_id=$Membership_ID;
	$final_array=[];
	$limit=1;
		for($i=1;$i<=9;$i++){
			$this->db->select('tree.Parent_ID,member.Membership_code,CONCAT(member.First_name,member.Last_name) as Name,member.Mobile,member.Current_level');
			$this->db->from('gc_franchisee_member_relation as tree');
			$this->db->join('gc_membership as member', 'member.Membership_ID = tree.Parent_ID', 'left');
			$this->db->where('tree.Child_ID',$membership_id);
			
			$query = $this->db->get();
			if($query->num_rows() > 0){
				$tmp=[];
				$binary4=$query->result_array();
				$membership_id=$binary4[0]['Parent_ID'];

				 if(!empty($binary4[0]['Parent_ID'])){
					$tmp=array('Membership_ID'=>$binary4[0]['Parent_ID'],
						'Membership_code'=>$binary4[0]['Membership_code'],
						'Name'=>$binary4[0]['Name'],
						'Level'=>$binary4[0]['Current_level'],
						'Mobile'=>$binary4[0]['Mobile']);

				array_push($final_array,$tmp);
				 }
				
				//$limit++;
			}
		
		}

return $final_array;
}
public function Payments_tab_details($Membership_ID){

}


public function get_topup_amount($Membership_ID){
	$query=$this->db->select('sum(Amount) as Amount')->where(array('Membership_ID'=>$Membership_ID,'Invest_type' => 2))->get('gc_member_franchisee_contract')->result_array();
	if(!empty($query)){
		return $query[0]['Amount'];
	}else{
		return 0;
	}
}

public function get_levels_details($Level_ID,$Membership_ID,$Invest_type){
	$this->db->select('COUNT(level.Child_ID) as Total_clients,SUM(contract.Amount) as Total_initial');
	$this->db->from('gc_member_level_details as level');
	$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
	$this->db->where('level.Membership_ID',$Membership_ID);
	$this->db->where('level.Level_ID',$Level_ID);
	if(!empty($Invest_type)){
		$this->db->where('contract.Invest_type',$Invest_type);
	}
	
	$query=$this->db->get();
	if($query->num_rows()>0){
		return $query->result_array();
	}else{
		return NULL;
	}
}

public function get_levels_details_count($Level_ID,$Membership_ID){
	$this->db->select('COUNT(level.Child_ID) as Total_clients');
	$this->db->from('gc_member_level_details as level');
	$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
	$this->db->where('level.Membership_ID',$Membership_ID);
	$this->db->where('level.Level_ID',$Level_ID);
	$query=$this->db->get();
	if($query->num_rows()>0){
		return $query->result_array();
	}else{
		return NULL;
	}
}


public function get_levelwise_details($Level_ID,$Membership_ID){
	$this->db->select('member.Membership_ID,CONCAT(member.First_name,member.Last_name) as Name,member.Membership_code,member.Created_date,member.Reference_code');
	$this->db->from('gc_member_level_details as level');
	// $this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
	$this->db->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
	$this->db->where('level.Membership_ID',$Membership_ID);
	// $this->db->where('member.Membership_ID',$Membership_ID);
	$this->db->where('level.Level_ID',$Level_ID);
	$query=$this->db->get();
	if($query->num_rows()>0){
		return $query->result_array();
	}else{
		return NULL;
	}
}





public function get_member_invest($Membership_ID){
	$this->db->select('SUM(Amount) as Total_initial');
	$this->db->from('gc_member_franchisee_contract');
	$this->db->where('Membership_ID',$Membership_ID);
	$this->db->where('Contract_status',6);
	$query=$this->db->get();
	if($query->num_rows()>0){
		return $query->result_array();
	}else{
		return NULL;
	}
}
	
	function getall_members_by_id($member) {
		$this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name,users.email_address as loginemail,users.og_password as loginpassword,area.id as taluk_id,area.area_name as taluk_name,city.id as City_id,city.city_name as City_name,state.id as State_id,state.state_name as State_name,country.id as Country_id,country.country_name as Country_name');
		$this->db->from('gc_membership as member');
		$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
		$this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
		$this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
		$this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_users as users', 'users.id = member.Membership_ID', 'left');
		$this->db->join('gc_areas as area','area.id = address.Area', 'left');
		$this->db->join('gc_cities as city', 'city.id = address.City', 'left');
		$this->db->join('gc_states as state', 'state.id = address.State', 'left');
		$this->db->join('gc_countries as country', 'country.id = address.Country', 'left');

		// $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
		$this->db->where_in("member.Membership_ID",$member);
		$this->db->group_by("member.Membership_ID");
		// if($status!=1){
		// $this->db->where_in("member.Status",$status);}
		// if($status1==10 || $status1==11){
		//     if($status1==10){
		//         $this->db->where("bank.Status",5);
		//     }elseif($status1==11){
		//         $this->db->where("documents.Status",5);
		//     }
		// }
		$this->db->group_by("payments.Membership_ID");
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

function getall_members($status,$status1) {

		// $this->db->select('member.*,contract.*,member.Status as Member_status,contract.Status as Cont_status,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name,');
// 
		// $this->db->select('member.Membership_ID,bank.Bank_ID as Bank_Bank_ID');
		$this->db->select('member.Activated_date,member.Membership_ID,member.Register_from,member.First_name,member.Last_name,member.Created_date,member.Mobile,member.Gender,member.Membership_code,member.Status as Member_status,type.Membership_type,bank.Status as Bank_status,payments.Payment_status,bank.Bank_ID as Bank_Bank_ID,contract.Contract_ID,contract.Contract_status_date,bank.Status as Bank_status');
		  // $this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name,users.email_address as loginemail,users.og_password as loginpassword');
		$this->db->from('gc_membership as member');
		$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
		// $this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
		// $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
		// $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
		$this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
		// $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
		$this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
		// $this->db->join('gc_users as users', 'users.id = member.Membership_ID', 'left');

		// $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
		$this->db->group_by("member.Membership_ID");
		if($status!=1){
		$this->db->where_in("member.Status",$status);
		}



		if($status1==10 || $status1==11){
			if($status1==10){
				$this->db->where("bank.Status",5);
			}
			elseif($status1==11){
				$this->db->where("documents.Status",5);
			}
		}elseif($status1==12){
			$this->db->where("member.Doc_verify",6);
			$this->db->where("member.Bank_verify",6);
			$this->db->where("member.Payment_verify",5);
		}elseif($status1==13){
			$this->db->where("member.Doc_verify",6);
			$this->db->where("member.Bank_verify",6);
			$this->db->where("member.Payment_verify",9);
		}
		// $this->db->group_by("payments.Membership_ID");
		// $this->db->limit(250);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			// var_dump($query->result_array());die();
			return  $query->result_array();
		}
		return NULL;
	}

	function getall_members1($status,$status1) {

		// $this->db->select('member.*,contract.*,member.Status as Member_status,contract.Status as Cont_status,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name,');
// 
		// $this->db->select('member.Membership_ID,bank.Bank_ID as Bank_Bank_ID');
		$this->db->select('member.Membership_ID');
		  // $this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name,users.email_address as loginemail,users.og_password as loginpassword');
		$this->db->from('gc_membership as member');
		// $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
		// $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
		// $this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
		// $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
		// $this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
		// $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
		$this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
		// $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
		$this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
		// $this->db->join('gc_users as users', 'users.id = member.Membership_ID', 'left');

		// $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
		$this->db->group_by("member.Membership_ID");
		if($status!=1){
		$this->db->where("member.Status",$status);}
		if($status1==10 || $status1==11){
			if($status1==10){
				$this->db->where("bank.Status",5);
			}
			elseif($status1==11){
				$this->db->where("documents.Status",5);
			}
		}
		// $this->db->group_by("payments.Membership_ID");
		$this->db->limit(250);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			// var_dump($query->result_array());die();
			return  $query->result_array();
		}
		return NULL;
	}

 function calculate_binary_commission($Cal_date) {
	$Cal_date=date('Y-m-d',strtotime($Cal_date));

	// $date = "2019-03-05";
	$Cal_date=$date;
	$d = date_parse_from_format("Y-m-d", $Cal_date);

	// $mnt=$d["month"]-1; //hide for Testing purpose..this is original

	$mnt=$d["month"];


	$first_day_this_month = date('Y-m-01');
	$dt=date('Y')."-".$mnt."-01";
	$dt=date('Y-m-d',strtotime($dt));
	// echo 'First_date-'.$last_day_this_month  = date('Y-m-01',strtotime($dt));
	$first_day_this_month  = date('Y-m-01',strtotime($dt));
	// $first_day_this_month  = "2019-03-01";
	// echo 'Last_date-'.$last_day_april_2010 = date('Y-m-t', strtotime($dt));
	$last_day_this_month = date('Y-m-t', strtotime($dt));
	// $last_day_this_month = "2019-03-30";


	$this->db->where('MONTH(Commission_date)',$d["month"]);
	$comision_status=  $this->db->count_all_results('gc_binary_commisions');
	if($comision_status<=0){ // Commission status if start

	$Cal_date=date('Y-m-d',strtotime($Cal_date));
	$final_dates=[];
	$yrl_dates_0=[];
			$this->db->select('Weeks');
			$this->db->where('Status',1);
			$this->db->where('ID',2);
			$query = $this->db->get('gc_leveltype');
			if ($query->num_rows() > 0) {
				$days=$query->result_array();
				$week_days=explode(',',$days[0]['Weeks']);
				$final_days=[];
				$final_days1=[];


			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
			foreach($yr as $key => $y){
			$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
			}
			$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
			

					$this->db->select('Date');
					$query = $this->db->get('gc_individual_calendar');
					if ($query->num_rows() > 0) {
						$db_leave=$query->result_array();
					}else{
						$db_leave=[];
					}

					$empt_leave=[];
					foreach($db_leave as $lv){
						array_push($empt_leave,$lv['Date']);

					}
					$final_dates=array_values(array_diff($final_dates,$empt_leave));
				}
				if(in_array($Cal_date, $final_dates)){ // commission_date check if start

	$this->db->select('Membership_ID');
	// $this->db->where('Membership_type',1);
	$this->db->where('Status',6);
	$query_member=$this->db->get('gc_membership');
	if($query_member->num_rows() >0){ // Member Num Rows if Start  
		$member=$query_member->result_array();
		// var_dump($member);die();
		foreach($member as $memership){ // Member Foreach Start

			$this->db->select('sum(Total_B_V) as Own_bv');
			$this->db->where('Date >=',$first_day_this_month);
			$this->db->where('Date <=',$last_day_this_month);
			$this->db->where('Membership_ID',$memership['Membership_ID']);
			$Own_com_query=$this->db->get('gc_binary_transaction_details');
			$Own_com=$Own_com_query->result_array();
			if(!empty($Own_com[0]['Own_bv'])){
			   $Own_binary_commission=$Own_com[0]['Own_bv']; 
		   }else{
				$Own_binary_commission=0;
		   }


			$this->db->select('Child_ID,Position_type');
			$this->db->where_in('Parent_ID',$memership['Membership_ID']);
			$this->db->order_by('Position_type');
			$query_bin = $this->db->get('gc_binary_member_relation');
			if($query_bin->num_rows() > 0){  // Query_bin numrows if start
				$member_binary=$query_bin->result_array();
				// var_dump($member_binary);
				if($query_bin->num_rows()==2){ // Query_bin numrows1 if start 
					
					// foreach($member_binary as $bin){
					//     if($bin['Position_type']==1){

					//     }
					// }
					if($member_binary[0]['Position_type']==1){
						$left_tree=$member_binary[0]['Child_ID'];
						$right_tree=$member_binary[1]['Child_ID'];
						 }else{
							$left_tree=$member_binary[1]['Child_ID'];
							$right_tree=$member_binary[0]['Child_ID'];
						 }
					 
				} // Query_bin numrows1 else start 
				else{ // Query_bin numrows1 if end 
					if($member_binary[0]['Position_type']==1){
						$left_tree=$member_binary[0]['Child_ID'];
						$right_tree='';
						 }else{
							$left_tree='';
							$right_tree=$member_binary[0]['Child_ID'];
						}
				} // Query_bin numrows1 else end 
				
// echo 'parent='.$memership['Membership_ID'].'<br>';
// echo 'left_tree='.$left_tree.'<br>';
// echo 'right_tree='.$right_tree.'<br>';
				// *** Left Tree Members start *** //
				if(!empty($left_tree)){
				$final_left_tree=[$left_tree];
				$left_parent_id=[$left_tree];

							$left_limit=1;
							for($i=1;$i<=10000;$i++){ // left for start  
							// for($i=1;$i<=$left_limit;$i++){  
								$this->db->select('Child_ID');
								$this->db->where_in('Parent_ID',$left_parent_id);
								// $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
								$left_query = $this->db->get('gc_binary_member_relation');
								if($left_query->num_rows() > 0){
									foreach($left_query->result_array() as $key => $val){
										$left_parent_id[$key]=$val['Child_ID'];
										array_push($final_left_tree,$val['Child_ID']);
									}
									//print_r($left_parent_id);echo '<br>';
										//$left_limit++;
								}
				
							} // left for end
							// var_dump($final_left_tree);die();

							 // *** Left Tree Members commision getting start *** //
							$this->db->select('sum(Total_B_V) as Left_bv');
							$this->db->where('Date >=',$first_day_this_month);
							$this->db->where('Date <=',$last_day_this_month);
							$this->db->where_in('Membership_ID',$final_left_tree);
							$left_com_query=$this->db->get('gc_binary_transaction_details');
							$left_com=$left_com_query->result_array();
							if(!empty($left_com[0]['Left_bv'])){
							   $left_binary_commission=$left_com[0]['Left_bv']; 
						   }else{
								$left_binary_commission=0;
						   }
							
							 // *** Left Tree Members commision getting end *** //
				}else{
					$left_binary_commission=0;
				}
				// *** Left Tree Members end *** //

				// *** Right Tree Members start *** //
				if(!empty($right_tree)){
				$final_right_tree=[$right_tree];
				$right_parent_id=[$right_tree];

							$right_limit=1;
							for($j=1;$j<=1000;$j++){ // right for start
							// for($j=1;$j<=$right_limit;$j++){
								$this->db->select('Child_ID');
								$this->db->where_in('Parent_ID',$right_parent_id);
								// $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
								$right_query = $this->db->get('gc_binary_member_relation');
								if($right_query->num_rows() > 0){
									foreach($right_query->result_array() as $key => $val){
										$right_parent_id[$key]=$val['Child_ID'];
										array_push($final_right_tree,$val['Child_ID']);
									}
									//print_r($parent_id);echo '<br>';
										//$right_limit++;
								}
				
							} // right for end

							  // *** right Tree Members commision getting start *** //
							$this->db->select('sum(Total_B_V) as Right_bv');
							$this->db->where('Date >=',$first_day_this_month);
							$this->db->where('Date <=',$last_day_this_month);
							$this->db->where_in('Membership_ID',$final_right_tree);
							$right_com_query=$this->db->get('gc_binary_transaction_details');
							$right_com=$right_com_query->result_array();
							if(!empty($right_com[0]['Right_bv'])){
							   $right_binary_commission=$right_com[0]['Right_bv']; 
						   }else{
								$right_binary_commission=0;
						   }
							 // *** right Tree Members commision getting end *** //
				}else{
					$right_binary_commission=0;
				}
				// *** Right Tree Members end *** //

				if($left_binary_commission>=$right_binary_commission){
					$final_com=$left_binary_commission;
					$final_non_com=$right_binary_commission;
				}else{
					$final_com=$right_binary_commission;
					$final_non_com=$left_binary_commission;
				}

				 $this->db->select('Members_count');
				 $this->db->where('Membership_ID',$memership['Membership_ID']);
				 $member = $this->db->get('gc_membership');
				 $mem_count=$member->result_array();

				 $tot_mem_count=$mem_count[0]['Members_count'];


				 $this->db->select('*');
				 $this->db->where('Status',1);
				 $query_setting = $this->db->get('gc_bv_settings');
				 $setting_val=$query_setting->result_array();
				 $B_V=$setting_val[0]['B_V'];
				 $B_V_percentage=$setting_val[0]['B_V_Commission'];

				 $bv_per_cal=($final_com/$B_V) * $B_V_percentage;
				 $final_Commission=round(($final_com * $bv_per_cal) / 100);

				 $declined_bv_per_cal=($final_non_com/$B_V) * $B_V_percentage;
				 $declined_final_Commission=round(($final_non_com * $declined_bv_per_cal) / 100);

				 $own_bv_per_cal=($Own_binary_commission/$B_V) * $B_V_percentage;
				 $own_final_Commission=round(($Own_binary_commission * $own_bv_per_cal) / 100);

				 if($tot_mem_count >= 2 && $own_bv_per_cal >=1000){

					if($own_bv_per_cal>=1000 && $own_bv_per_cal<=2499){
						$bin_com=5;
					}elseif($own_bv_per_cal>=2500 && $own_bv_per_cal<=4999){
						$bin_com=8;
					}else{
						$bin_com=10;
					}

					$final_Commission=round(($bv_per_cal * $bin_com) / 100);

						$binary_commission_data=array(
												'Company_ID' => $this->session->userdata('CompanyId'),
												'Branch_id' => $this->session->userdata('CompanyId'),
												'Transaction_ID' => '',
												'Transaction_detail_ID' => '',
												'Membership_ID' => $memership['Membership_ID'],
												'Order_ID' => '',
												'Total_B_V' => $final_com,
												'Commission_type' => 4,
												'Commission_percentage' => $bin_com,
												'Commission_amount' => $final_Commission,
												'Commission_date' => $Cal_date,
												'Payout_ID' => 3,
												'Remarks' => 'Binary BV Commission',
												'Status' => 1
											);
				 $this->db->insert('gc_binary_commisions',$binary_commission_data);

				 }

				 $own_binary_commission_data=array(
												'Company_ID' => $this->session->userdata('CompanyId'),
												'Branch_id' => $this->session->userdata('CompanyId'),
												'Transaction_ID' => '',
												'Transaction_detail_ID' => '',
												'Membership_ID' => $memership['Membership_ID'],
												'Order_ID' => '',
												'Total_B_V' => $Own_binary_commission,
												'Commission_type' => '',
												'Commission_percentage' => $B_V.' : '.$B_V_percentage,
												'Commission_amount' => $own_bv_per_cal,
												'Commission_date' => $Cal_date,
												'Payout_ID' => 3,
												'Remarks' => 'Self BV Commission',
												'Status' => 12
											);
				 $this->db->insert('gc_binary_commisions',$own_binary_commission_data);


				 $declined_binary_commission_data=array(
												'Company_ID' => $this->session->userdata('CompanyId'),
												'Branch_id' => $this->session->userdata('CompanyId'),
												'Transaction_ID' => '',
												'Transaction_detail_ID' => '',
												'Membership_ID' => $memership['Membership_ID'],
												'Order_ID' => '',
												'Total_B_V' => $final_non_com,
												'Commission_type' => '',
												'Commission_percentage' => $B_V.' : '.$B_V_percentage,
												'Commission_amount' => $declined_bv_per_cal,
												'Commission_date' => $Cal_date,
												'Payout_ID' => 3,
												'Remarks' => 'Declined Commission',
												'Status' => 11
											);
				 $this->db->insert('gc_binary_commisions',$declined_binary_commission_data);


			}  // Query_bin numrows if end
		} // Member Foreach End
	} // Member Num Rows if end

	} // commission_date check if end

	} // Commission status if end

	}


public function get_pay_date($Cal_date){
	$Cal_date=date('Y-m-d',strtotime($Cal_date));
	$final_dates=[];
	$yrl_dates_0=[];
			$this->db->select('Weeks');
			$this->db->where('Status',1);
			$this->db->where('ID',1);
			$query = $this->db->get('gc_leveltype');
			if ($query->num_rows() > 0) {
				$days=$query->result_array();
				$week_days=explode(',',$days[0]['Weeks']);
				$final_days=[];
				$final_days1=[];


			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
			foreach($yr as $key => $y){
			$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
			}
			$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
			

					$this->db->select('Date');
					$query = $this->db->get('gc_individual_calendar');
					if ($query->num_rows() > 0) {
						$db_leave=$query->result_array();
					}else{
						$db_leave=[];
					}

					$empt_leave=[];
					foreach($db_leave as $lv){
						array_push($empt_leave,$lv['Date']);

					}
					$final_dates=array_values(array_diff($final_dates,$empt_leave));
				}
				if(in_array($Cal_date, $final_dates)){
					$pay_date=$Cal_date;
				}else{
					$pay_date=$this->get_next_paydate($Cal_date);
				}

			return $pay_date;
}

function calculate_commission($Cal_date) {


$Cal_date=date('Y-m-d',strtotime($Cal_date));
$final_dates=[];
$yrl_dates_0=[];
		// $this->db->select('Weeks');
		// $this->db->where('Status',1);
		// $this->db->where('ID',1);
		// $query = $this->db->get('gc_leveltype');
		// if ($query->num_rows() > 0) {
		//     $days=$query->result_array();
		//     $week_days=explode(',',$days[0]['Weeks']);
		//     $final_days=[];
		//     $final_days1=[];


		// $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		// foreach($yr as $key => $y){
		// $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
		// }
		// $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
		

		//         $this->db->select('Date');
		//         $query = $this->db->get('gc_individual_calendar');
		//         if ($query->num_rows() > 0) {
		//             $db_leave=$query->result_array();
		//         }else{
		//             $db_leave=[];
		//         }

		//         $empt_leave=[];
		//         foreach($db_leave as $lv){
		//             array_push($empt_leave,$lv['Date']);

		//         }
		//         // echo "<pre>";
		//         // print_r($empt_leave);echo "</pre>";die();
		//         //print_r($db_leave);die();
		//         $final_dates=array_values(array_diff($final_dates,$empt_leave));
		//         //echo "<pre>";
		//         //print_r($final_dates);echo "</pre>";die();
		//     //if(in_array(date('Y-m-d'), $final_dates)){
		//     if(in_array($Cal_date, $final_dates)){


				//$previous_trading=$this->get_previous_date(date('Y-m-d'));
				$previous_trading=$this->get_previous_date1($Cal_date);

				// $this->db->where('Commision_date',$previous_trading);
				// $comision_status=  $this->db->count_all_results('gc_member_commission');
				// if($comision_status<=0){

//  Topup Commission Calculation Start 
				$this->db->select('member.Membership_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,member.Payout_ID');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				$this->db->where('contract.Pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$query = $this->db->get();
				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members=$query->result_array();
					foreach ($final_members as $key => $value_member) {
						
					
					//echo ' insert';
					//echo 'insert';die();
				// Get Transaction Tabl
					$samparr=[];
				// $this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID');
				$this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID,member.Members_count');
				$this->db->from('gc_transaction as transaction');
				$this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');
				$this->db->join('gc_transaction_details as t_det', 't_det.Transaction_ID = transaction.Transaction_ID', 'left');

				$this->db->where('transaction.Transaction_status',1);
				$this->db->where('member.Status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$this->db->where('t_det.Commision_type',1);
				$this->db->where('t_det.Membership_ID',$value_member['Membership_ID']);
				$this->db->where('t_det.Contract_ID',$value_member['Contract_ID']);
				// $this->db->where('member.Membership_ID',$value_member['Membership_ID']);
				$this->db->group_by('t_det.Transaction_ID');
				// $this->db->where('transaction.Transaction_date <=',date('Y-m-d',strtotime($previous_trading)));
				$query1 = $this->db->get();
				if ($query1->num_rows() > 0) {
					$transaction=$query1->result_array();
					 //var_dump($transaction);die();
					foreach($transaction as $tran){
						//echo $tran['Payment_status_date'];
						$pay_date=$tran['Payment_status_date'];
						$this->db->select('*');
						$this->db->from('gc_payout_setting');
						$query = $this->db->get();
						if ($query->num_rows() > 0) {
					$set_day=$query->result_array();
					$setting_day=$set_day[0]['Schedule_day'];

				}else{
					$setting_day=0;
				}
				//echo $pay_date;
				$cms_start=$this->get_advance_date1($setting_day,date('Y-m-d',strtotime($pay_date)));
				//die();
				if($Cal_date > $cms_start){



					$this->db->select('sum(topup.Value) as Volume,sum(contract.Amount) as Vol_am');
					// $this->db->select('level.Child_ID');
					 $this->db->from('gc_member_level_details as level');
					 $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level.Child_ID', 'left');
					 $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
					 $this->db->join('gc_membership as member', 'member.Membership_ID = level.Child_ID', 'left');
					 $this->db->where('level.Membership_ID',$tran['Membership_ID']);
					 $this->db->where('level.Level_ID',1);
					 $this->db->where('member.Status',6);
					 $this->db->where('contract.Withdrawn_status',5);
					 $this->db->where('contract.Contract_ID',$value_member['Contract_ID']);
					  $query_volume = $this->db->get();
					  $Volume_amnt=$query_volume->result_array();
					  if(!empty($Volume_amnt[0]['Vol_am'])){
						$vol_amt=$Volume_amnt[0]['Vol_am'];
					  }else{
						$vol_amt=0;
					  }
					  $this->db->select('*');
					$this->db->from('gc_commission_setting');
					$this->db->where('Status',1);
					$query_commission = $this->db->get();
					  $commission_setting=$query_commission->result_array();

					  // if($commission_setting[0]['Members_count']>=$tran['Members_count'] || $commission_setting[0]['Volume_amount']>=$vol_amt){
					  if($vol_amt>=7500){
					  // if($commission_setting[0]['Volume_amount']>=$vol_amt){
						//echo 'eligible';
					  
					//echo "insert1"; die();
					$commision_data=array(
							'Company_id'       => $this->session->userdata('CompanyId'),
							'Branch_id'        => $this->session->userdata('CompanyId'),
							'Transaction_ID'   => $tran['Transaction_ID'],
							'Membership_ID'    => $tran['Membership_ID'], 
							'Contract_ID'      => $tran['Contract_ID'], 
							'Transaction_type' => '',
							'Commision_date'   => date('Y-m-d',strtotime($previous_trading)), 
							'Remarks'          => '',
							'Created_by'       => $this->session->userdata('UserId')
							);
					
				

					$this->db->insert('gc_member_commission',$commision_data);
					$commision_id=$this->db->insert_id();
					// $commision_id=1;

					// Get Transaction detail Table
					$this->db->select('tran_det.*,gc_lvl.Payout_type');
					$this->db->from('gc_transaction_details as tran_det');
					$this->db->join('gc_membership as member', 'member.Membership_ID = tran_det.Membership_ID', 'left');
					$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = tran_det.Contract_ID', 'left');
					$this->db->join('gc_member_level_details as lvl_det', 'lvl_det.Member_level_detail_ID = tran_det.Member_level_detail_ID', 'left');
					$this->db->join('gc_level as gc_lvl', 'gc_lvl.ID = lvl_det.Level_ID', 'left');
					$this->db->where('tran_det.Status',1);
					$this->db->where('tran_det.Transaction_ID',$tran['Transaction_ID']);
					$this->db->where('member.Status',6);
					$this->db->where('contract.Withdrawn_status',5);
					$this->db->where('contract.Contract_status',6);
					$query2 = $this->db->get();
					  if ($query2->num_rows() > 0) {

						$transaction_detail=$query2->result_array();

						foreach($transaction_detail as $tran_det){
							if($tran_det['Member_level_detail_ID']!=''){
								$payout_member=$tran_det['Payout_type'];
							}else{
								$payout_member=$tran_det['Payout_ID'];
							}
							$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => $commision_id,
							'Transaction_ID'           => $tran_det['Transaction_ID'],
							'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
							'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
							'Membership_ID'            => $tran_det['Membership_ID'], 
							'Contract_ID'              => $tran_det['Contract_ID'], 
							'Commision_type'           => $tran_det['Commision_type'],
							'Payout_ID'                => $payout_member,
							'Commision_date'           => date('Y-m-d',strtotime($previous_trading)), 
							'Amount'                   => $tran_det['Amount'], 
							'Commision'                => $tran_det['Commision'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId')
							);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);


				$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $value_member['Payout_ID']))->result_array();
		if(!empty($py_qry)){
			$pay_flag=$py_qry[0]['Pay_flag'];
			$py_days=$py_qry[0]['Days'];
		}else{
			$pay_flag=2;
			$py_days=15;
		}
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days')));
	  $Pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days'));
	  $member_update_data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  $next_exact_payout=$this->get_excat_next_payout($Cal_date);
	  $member_update_data['Payout_date']=$next_exact_payout;
	  // $lvl_py_days=15-1;
	  // $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
	  // $member_update_data['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
		$this->db->where('Membership_ID',$value_member['Membership_ID']);
		$this->db->where('Contract_ID',$value_member['Contract_ID']);
		$this->db->update('gc_franchisee_member_relation',$member_update_data);

						}
						 //print_r($commision_detail_data);die();

					  }

					} // Memberscount or Volume if End

				  }
			}

		  } //else End
					} // Members Foreach End
				 } // Membership Count if end

//  Topup Commission Calculation End 

//  Level Commission Calculation start              


				$this->db->select('member.Membership_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,contract.Lvl_pay_date,member.Payout_ID');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				$this->db->where('contract.Lvl_pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$query = $this->db->get();

				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members1=$query->result_array();
					foreach ($final_members1 as $key => $value_member1) {
						
					
					//echo ' insert';
					//echo 'insert';die();
				// Get Transaction Tabl
					$samparr=[];
				// $this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID');
				$this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID,member.Members_count');
				$this->db->from('gc_transaction as transaction');
				
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');
				$this->db->join('gc_transaction_details as t_det', 't_det.Transaction_ID = transaction.Transaction_ID', 'left');
				$this->db->join('gc_membership as member', 'member.Membership_ID = t_det.Membership_ID', 'left');

				$this->db->where('transaction.Transaction_status',1);
				$this->db->where('member.Status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$this->db->where('t_det.Commision_type!=',1);
				$this->db->where('t_det.Membership_ID',$value_member1['Membership_ID']);
				$this->db->where('t_det.Contract_ID',$value_member1['Contract_ID']);
				// $this->db->where('member.Membership_ID',$value_member1['Membership_ID']);
				$this->db->group_by('t_det.Transaction_ID');
				// $this->db->where('transaction.Transaction_date <=',date('Y-m-d',strtotime($previous_trading)));
				$query1 = $this->db->get();
				// var_dump($query1->result_array());die();
				if ($query1->num_rows() > 0) {
					$transaction=$query1->result_array();
					 //var_dump($transaction);die();
					foreach($transaction as $tran){
						//echo $tran['Payment_status_date'];
						$pay_date=$tran['Payment_status_date'];
						$this->db->select('*');
						$this->db->from('gc_payout_setting');
						$query = $this->db->get();
						if ($query->num_rows() > 0) {
					$set_day=$query->result_array();
					$setting_day=$set_day[0]['Schedule_day'];

				}else{
					$setting_day=0;
				}
				//echo $pay_date;
				$cms_start=$this->get_advance_date1($setting_day,date('Y-m-d',strtotime($pay_date)));
				//die();
				if($Cal_date > $cms_start){



					$this->db->select('sum(topup.Value) as Volume,sum(contract.Amount) as Vol_am');
					// $this->db->select('level.Child_ID');
					 $this->db->from('gc_member_level_details as level');
					 $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level.Child_ID', 'left');
					 $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
					 $this->db->join('gc_membership as member', 'member.Membership_ID = level.Child_ID', 'left');
					 $this->db->where('level.Membership_ID',$tran['Membership_ID']);
					 $this->db->where('level.Level_ID',1);
					 $this->db->where('member.Status',6);
					 $this->db->where('contract.Withdrawn_status',5);
					 $this->db->where('contract.Contract_ID',$value_member1['Contract_ID']);
					  $query_volume = $this->db->get();
					  $Volume_amnt=$query_volume->result_array();
					  if(!empty($Volume_amnt[0]['Vol_am'])){
						$vol_amt=$Volume_amnt[0]['Vol_am'];
					  }else{
						$vol_amt=0;
					  }

					  $this->db->select('*');
					$this->db->from('gc_commission_setting');
					$this->db->where('Status',1);
					$query_commission = $this->db->get();
					  $commission_setting=$query_commission->result_array();

					  if($commission_setting[0]['Members_count']>=$tran['Members_count'] || $commission_setting[0]['Volume_amount']>=$vol_amt){
						//echo 'eligible';
					  
					//echo "insert1"; die();
					$commision_data=array(
							'Company_id'       => $this->session->userdata('CompanyId'),
							'Branch_id'        => $this->session->userdata('CompanyId'),
							'Transaction_ID'   => $tran['Transaction_ID'],
							'Membership_ID'    => $tran['Membership_ID'], 
							'Contract_ID'      => $tran['Contract_ID'], 
							'Transaction_type' => '',
							'Commision_date'   => date('Y-m-d',strtotime($previous_trading)), 
							'Remarks'          => '',
							'Created_by'       => $this->session->userdata('UserId')
							);
					
				

					$this->db->insert('gc_member_commission',$commision_data);
					$commision_id=$this->db->insert_id();
					// $commision_id=1;

					// Get Transaction detail Table
					$this->db->select('tran_det.*,gc_lvl.Payout_type');
					$this->db->from('gc_transaction_details as tran_det');
					$this->db->join('gc_membership as member', 'member.Membership_ID = tran_det.Membership_ID', 'left');
					$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = tran_det.Contract_ID', 'left');
					$this->db->join('gc_member_level_details as lvl_det', 'lvl_det.Member_level_detail_ID = tran_det.Member_level_detail_ID', 'left');
					$this->db->join('gc_level as gc_lvl', 'gc_lvl.ID = lvl_det.Level_ID', 'left');
					$this->db->where('tran_det.Status',1);
					$this->db->where('tran_det.Transaction_ID',$tran['Transaction_ID']);
					$this->db->where('member.Status',6);
					$this->db->where('contract.Withdrawn_status',5);
					$this->db->where('contract.Contract_status',6);
					$query2 = $this->db->get();
					  if ($query2->num_rows() > 0) {

						$transaction_detail=$query2->result_array();

						foreach($transaction_detail as $tran_det){
							if($tran_det['Member_level_detail_ID']!=''){
								$payout_member=$tran_det['Payout_type'];
							}else{
								$payout_member=$tran_det['Payout_ID'];
							}
							$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => $commision_id,
							'Transaction_ID'           => $tran_det['Transaction_ID'],
							'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
							'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
							'Membership_ID'            => $tran_det['Membership_ID'], 
							'Contract_ID'              => $tran_det['Contract_ID'], 
							'Commision_type'           => $tran_det['Commision_type'],
							'Payout_ID'                => $payout_member,
							'Commision_date'           => date('Y-m-d',strtotime($previous_trading)), 
							'Amount'                   => $tran_det['Amount'], 
							'Commision'                => $tran_det['Commision'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId')
							);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);


		$py_qry1 = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $value_member1['Payout_ID']))->result_array();
		if(!empty($py_qry1)){
			$pay_flag=$py_qry1[0]['Pay_flag'];
			$py_days=$py_qry1[0]['Days'];
		}else{
			$pay_flag=2;
			$py_days=15;
		}
		$lvl_py_days=15;
	  // $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
	  $Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
	  $member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
	  $this->db->where('Membership_ID',$value_member1['Membership_ID']);
		$this->db->where('Contract_ID',$value_member1['Contract_ID']);
		$this->db->update('gc_member_franchisee_contract',$member_update_data1);

						}
						 //print_r($commision_detail_data);die();

					  }

					} // Memberscount or Volume if End

				  }
			}

		  }//else End
					} // Members Foreach End
				 } // Membership Count if end
// Level Commission Calculation end

						//die();
			   

		//}

	//}

}

public function bulk_calculation(){
	$start = '2019-01-01';
	$end='2019-05-14';
	// $end = '2019-05-' . date('t', strtotime($start));
	 while(strtotime($start) <= strtotime($end)) {
		$Cal_date = date('Y-m-d', strtotime($start));
		//$day_name = date('l', strtotime($start));
		$start = date("Y-m-d", strtotime("+1 day", strtotime($start)));
		//echo $day_num ."ss<br/>";
		//echo $Cal_date;
	//}die();
	$Cal_date=date('Y-m-d',strtotime($Cal_date));
	$final_dates=[];
	$yrl_dates_0=[];

	$previous_trading=$this->get_previous_date1($Cal_date);

	//  Topup Commission Calculation Start 
				$this->db->select('member.Membership_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,member.Payout_ID');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				$this->db->where('contract.Pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$query = $this->db->get();
				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members=$query->result_array();
					// var_dump($final_members);die();
					foreach ($final_members as $key => $value_member) {
						
					
					//echo ' insert';
					//echo 'insert';die();
				// Get Transaction Tabl
					$samparr=[];
				// $this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID');
				$this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID,member.Members_count');
				$this->db->from('gc_transaction as transaction');
				$this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');
				$this->db->join('gc_transaction_details as t_det', 't_det.Transaction_ID = transaction.Transaction_ID', 'left');

				$this->db->where('transaction.Transaction_status',1);
				$this->db->where('member.Status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$this->db->where('t_det.Commision_type',1);
				$this->db->where('t_det.Membership_ID',$value_member['Membership_ID']);
				$this->db->where('t_det.Contract_ID',$value_member['Contract_ID']);
				// $this->db->where('member.Membership_ID',$value_member['Membership_ID']);
				$this->db->group_by('t_det.Transaction_ID');
				// $this->db->where('transaction.Transaction_date <=',date('Y-m-d',strtotime($previous_trading)));
				$query1 = $this->db->get();
				if ($query1->num_rows() > 0) {
					$transaction=$query1->result_array();
					 // var_dump($transaction);
					foreach($transaction as $tran){
						//echo $tran['Payment_status_date'];
						$pay_date=$tran['Payment_status_date'];
						$this->db->select('*');
						$this->db->from('gc_payout_setting');
						$query = $this->db->get();
						if ($query->num_rows() > 0) {
					$set_day=$query->result_array();
					$setting_day=$set_day[0]['Schedule_day'];

				}else{
					$setting_day=0;
				}
				//echo $pay_date;
				$cms_start=$this->get_advance_date1($setting_day,date('Y-m-d',strtotime($pay_date)));
				//die();
				if($Cal_date > $cms_start){
					


					
					  // if($commission_setting[0]['Volume_amount']>=$vol_amt){
						//echo 'eligible';
					  
					//echo "insert1"; die();

						// $array=['7','14','21','28'];
						$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);
						$per_date=date('d',strtotime($Cal_date));
						$temp_date=date('Y-m',strtotime($Cal_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);


					$commision_data=array(
							'Company_id'       => $this->session->userdata('CompanyId'),
							'Branch_id'        => $this->session->userdata('CompanyId'),
							'Transaction_ID'   => $tran['Transaction_ID'],
							'Membership_ID'    => $tran['Membership_ID'], 
							'Contract_ID'      => $tran['Contract_ID'], 
							'Transaction_type' => '',
							'Commision_date'   => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'      => date('Y-m-d',strtotime($payout_date)), 
							'Remarks'          => '',
							'Created_by'       => $this->session->userdata('UserId')
							);
					
				

					$this->db->insert('gc_member_commission',$commision_data);
					$commision_id=$this->db->insert_id();
					// $commision_id=1;

					// Get Transaction detail Table
					$this->db->select('tran_det.*,gc_lvl.Payout_type,contract.Doc_status,Payout_count,member.Mobile,member.Reference_ID,member.First_name');
					$this->db->from('gc_transaction_details as tran_det');
					$this->db->join('gc_membership as member', 'member.Membership_ID = tran_det.Membership_ID', 'left');
					$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = tran_det.Contract_ID', 'left');
					$this->db->join('gc_member_level_details as lvl_det', 'lvl_det.Member_level_detail_ID = tran_det.Member_level_detail_ID', 'left');
					$this->db->join('gc_level as gc_lvl', 'gc_lvl.ID = lvl_det.Level_ID', 'left');
					$this->db->where('tran_det.Status',1);
					$this->db->where('tran_det.Transaction_ID',$tran['Transaction_ID']);
					$this->db->where('member.Status',6);
					$this->db->where('contract.Withdrawn_status',5);
					$this->db->where('contract.Contract_status',6);
					$this->db->where('tran_det.Commision_type',1);
					$query2 = $this->db->get();
					  if ($query2->num_rows() > 0) {

						$transaction_detail=$query2->result_array();
						// var_dump($transaction_detail);
						foreach($transaction_detail as $tran_det){
							if($tran_det['Member_level_detail_ID']!=''){
								$payout_member=$tran_det['Payout_type'];
							}else{
								$payout_member=$tran_det['Payout_ID'];
							}

							$Doc_status=$tran_det['Doc_status'];
								if($Doc_status==2 && $tran_det['Payout_count']>=9){
									$Doc_status=2;

									$mem_ref=$this->db->get_where('gc_membership',array('Membership_ID' => $tran_det['Reference_ID']))->result_array();
									$final_sms=[];
									$mem1=array('Mobile' => $tran_det['Mobile'],'Name'=> $tran_det['First_name'],'Sms_content'=>'hi'.$tran_det['First_name']);
									array_push($final_sms,$mem1);

									$mem2=array('Mobile' => $mem_ref[0]['Mobile'],'Name'=> $mem_ref[0]['First_name'],'Sms_content'=>'hi'.$mem_ref[0]['First_name']);
									array_push($final_sms,$mem2);
									foreach ($final_sms as $sms) {

										$sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=NGU1ZDU0MTdlNDc&mobiles='.$sms['Mobile'].'&message='.urlencode($sms['Sms_content']).'&sender=VOSCAT&type=1&route=2';

									$ch = curl_init($sms_url);
									 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									 curl_setopt($ch, CURLOPT_POST, true);
									 curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
									 $response=curl_exec($ch);
									 // curl_close($ch);

									 if (curl_errno($ch)) {
										 $error = curl_error($ch);
									 }
									 $curl_data = explode(',', $response);
									 curl_close($ch);
									}

									

								}else{
									$Doc_status=1;
								}
							$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => $commision_id,
							'Transaction_ID'           => $tran_det['Transaction_ID'],
							'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
							'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
							'Membership_ID'            => $tran_det['Membership_ID'], 
							'Contract_ID'              => $tran_det['Contract_ID'], 
							'Commision_type'           => $tran_det['Commision_type'],
							'Payout_ID'                => $payout_member,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							
							'Amount'                   => $tran_det['Amount'], 
							'Commision'                => $tran_det['Commision'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 6,
							'Doc_status'               => $Doc_status
							);
							// var_dump($commision_detail_data);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);
							$Commision_detail_ID=$this->db->insert_id();

							$count=1;
							$this->db->where('Contract_ID',$tran_det['Contract_ID']);
							$this->db->where('Membership_ID',$tran_det['Membership_ID']);
							$this->db->set('Payout_count', "Payout_count +'$count'", FALSE);     
							$this->db->update('gc_member_franchisee_contract');

							$payout_data=array(
				'Company_id'                  => $this->session->userdata('CompanyId'),
				'Branch_id'                   => $this->session->userdata('CompanyId'),
				'Commision_detail_ID'         => $Commision_detail_ID,
				'Membership_ID'               => $tran_det['Membership_ID'],
				'Contract_ID'                 => $tran_det['Contract_ID'],
				'Commission_type'             => $tran_det['Commision_type'],
				'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
				'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
				'Payment_mode'                => 'Bank',
				'Bank_ID'                     => '',
				'Actual_amount'               => $tran_det['Amount'],
				'Charges'                     => 0,
				'Final_amount'                => $tran_det['Amount'],
				'Reference_no'                => '',
				'Payout_status'               => 1,
				'Commission_mode'             => 1
				); 
							$this->db->insert('gc_member_payouts',$payout_data);

							$history_data=array(
				 'Company_id'                 => $this->session->userdata('CompanyId'),
				 'Branch_id'                  => $this->session->userdata('CompanyId'), 
				 'Membership_ID'              => $tran_det['Membership_ID'],
				 'Contract_ID'                => $tran_det['Contract_ID'],
				 'Payout'                     => $payout_member,
				 'Payout_ID'                  => $payout_member,
				 'Date'                       => date('Y-m-d',strtotime($payout_date)),
				 'History_for'                => 'Credited Commission Amount is '.$tran_det['Amount'] ,
				 'Credit_amount'              => $tran_det['Amount'],
				 'Type'                       => 1,
				 'Debit_amount'               => 0
				  );
			$this->db->insert('gc_transaction_history',$history_data);

				$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $value_member['Payout_ID']))->result_array();
		if(!empty($py_qry)){
			$pay_flag=$py_qry[0]['Pay_flag'];
			$py_days=$py_qry[0]['Days'];
		}else{
			$pay_flag=2;
			$py_days=15;
		}
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days')));
	  $Pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days'));
	  $member_update_data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  $member_update_data['Payout_date']=$payout_date;

		$this->db->where('Membership_ID',$value_member['Membership_ID']);
		$this->db->where('Contract_ID',$value_member['Contract_ID']);
		$this->db->update('gc_member_franchisee_contract',$member_update_data);

						}
						 //print_r($commision_detail_data);die();

					  }

					//} // Memberscount or Volume if End

				  }
			}

		  } //else End
					} // Members Foreach End
				 } // Membership Count if end

//  Topup Commission Calculation End 


//  Level Commission Calculation End 
$this->db->select('member.Membership_ID,member.Reference_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,contract.Lvl_pay_date,member.Payout_ID,contract.Amount');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				$this->db->where('contract.Lvl_pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$this->db->where('contract.Contract_status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$query = $this->db->get();

				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members1=$query->result_array();
					foreach ($final_members1 as $key => $value_member1) {

		// if($value_member1[0]['Commission_mode']==1){ // Level Commission OR Self Commission is Start            	
		$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Doc_status,Payout_count,member.Mobile,member.First_name,contract.Payout_Date');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$value_member1['Reference_ID']);
			$this->db->where('member.Commission_mode',1);
			// $this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_status',6);
			$this->db->where('contract.Withdrawn_status',5);
			//$this->db->where('contract.Contract_status',6);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
				 
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){
			$crnt_lvl=$binary[0]['Current_level'];
			//if($crnt_lvl<=$i){
			$level['Level_ID']=$i;
			//}
			//else{
			   //$level['Level_ID']=$crnt_lvl;
			//}
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID = level.Level_ID', 'left');

			$this->db->where('level.Child_ID',$value_member1['Membership_ID']);
			$this->db->where('level.Membership_ID',$value_member1['Reference_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();

			if(!empty($level_details)){
			$Comission_amount1=$value_member1['Amount']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}
			else{
				$payout_id1=1;
				// if($level_details[0]['Payout_status']==2){
				// $payout_id1=$level_details[0]['New_payout_ID'];
				// }else{
				// $payout_id1=$level_details[0]['Old_payout_ID'];
				//         }
					}
// Commission Details Insert start 

					$Doc_status=$binary[0]['Doc_status'];
								if($Doc_status==2 && $binary[0]['Payout_count']>=9){
									$Doc_status=2;

									$mem_ref=$this->db->get_where('gc_membership',array('Membership_ID' => $binary[0]['Reference_ID']))->result_array();
									$final_sms=[];
									$mem1=array('Mobile' => $binary[0]['Mobile'],'Name'=> $binary[0]['First_name'],'Sms_content'=>'hi'.$binary[0]['First_name']);
									array_push($final_sms,$mem1);

									$mem2=array('Mobile' => $mem_ref[0]['Mobile'],'Name'=> $mem_ref[0]['First_name'],'Sms_content'=>'hi'.$mem_ref[0]['First_name']);
									array_push($final_sms,$mem2);
									foreach ($final_sms as $sms) {

										$sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=NGU1ZDU0MTdlNDc&mobiles='.$sms['Mobile'].'&message='.urlencode($sms['Sms_content']).'&sender=VOSCAT&type=1&route=2';

									$ch = curl_init($sms_url);
									 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									 curl_setopt($ch, CURLOPT_POST, true);
									 curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
									 $response=curl_exec($ch);
									 // curl_close($ch);

									 if (curl_errno($ch)) {
										 $error = curl_error($ch);
									 }
									 $curl_data = explode(',', $response);
									 curl_close($ch);
									}

									

								}else{
									$Doc_status=1;
								}


					$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);

					if($Cal_date<=date('Y-m-d',strtotime($binary[0]['Payout_date']))){
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Payout_date']));
					}else{
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Pay_date']));
					}

						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);
					
						$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => '',
							'Transaction_ID'           => '',
							'Transaction_detail_ID'    => '',
							'Member_level_detail_ID'   => $level_details[0]['Member_level_detail_ID'],
							'Membership_ID'            => $binary[0]['Membership_ID'], 
							'Contract_ID'              => $binary[0]['Contract_ID'], 
							'Commision_type'           => 2,
							'Payout_ID'                => $payout_id1,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							'Amount'                   => $Comission_amount1, 
							'Commision'                => $level_details[0]['Return'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 6,
							'Doc_status'               => $Doc_status
							);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);
							$Commision_detail_ID=$this->db->insert_id();

							$payout_data=array(
				'Company_id'                  => $this->session->userdata('CompanyId'),
				'Branch_id'                   => $this->session->userdata('CompanyId'),
				'Commision_detail_ID'         => $Commision_detail_ID,
				'Membership_ID'               => $binary[0]['Membership_ID'],
				'Contract_ID'                 => $binary[0]['Contract_ID'],
				'Commission_type'             => 2,
				'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
				'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
				'Payment_mode'                => 'Bank',
				'Bank_ID'                     => '',
				'Actual_amount'               => $Comission_amount1,
				'Charges'                     => 0,
				'Final_amount'                => $Comission_amount1,
				'Reference_no'                => '',
				'Payout_status'               => 1,
				'Commission_mode'             => 1
				); 
							$this->db->insert('gc_member_payouts',$payout_data);

							$history_data=array(
				 'Company_id'                 => $this->session->userdata('CompanyId'),
				 'Branch_id'                  => $this->session->userdata('CompanyId'), 
				 'Membership_ID'              => $binary[0]['Membership_ID'],
				 'Contract_ID'                => $binary[0]['Contract_ID'],
				 'Payout'                     => $payout_id1,
				 'Payout_ID'                  => $payout_id1,
				 'Date'                       => date('Y-m-d',strtotime($payout_date)),
				 'History_for'                => 'Credited Commission Amount is '.$Comission_amount1 ,
				 'Credit_amount'              => $Comission_amount1,
				 'Type'                       => 1,
				 'Debit_amount'               => 0
				  );
			$this->db->insert('gc_transaction_history',$history_data);

							$lvl_py_days=15;
							// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
							$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
							$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
							$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							$this->db->where('Contract_ID',$value_member1['Contract_ID']);
							$this->db->update('gc_member_franchisee_contract',$member_update_data1);

						}

					



// Commisssion Details Insert start

			}
		}
	}
	else{

			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Doc_status,Payout_count,member.Mobile,member.First_name,contract.Payout_date');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$this->db->where('member.Commission_mode',1);
			// $this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_status',6);
			$this->db->where('contract.Withdrawn_status',5);


			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){

			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
		   //  if($crnt_lvl<=$i){
			
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$value_member1['Membership_ID']);
			$this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();
			if(!empty($level_details)){
						$Comission_amount1=$level_details[0]['Value']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
				$payout_id1=1;
						// if($level_details[0]['Payout_status']==2){
						// $payout_id1=$level_details[0]['New_payout_ID'];
						// }else{
						// $payout_id1=$level_details[0]['Old_payout_ID'];
						// $payout_id1=$level_payout[0]['Payout_type'];
						// }
					}
// Commission Details Insert start 

					$this->db->select('sum(contract.Amount) as Vol_am');
					// $this->db->select('level.Child_ID');
					 $this->db->from('gc_member_level_details as level');
					 $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level.Child_ID', 'left');
					 // $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
					 $this->db->join('gc_membership as member', 'member.Membership_ID = level.Child_ID', 'left');
					 $this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
					 $this->db->where('level.Level_ID',1);
					 $this->db->where('member.Status',6);
					 $this->db->where('contract.Withdrawn_status',5);
					 // $this->db->where('contract.Contract_ID',$tran['Contract_ID']);
					  $query_volume = $this->db->get();
					  $Volume_amnt=$query_volume->result_array();
					  // var_dump($Volume_amnt);
					  if(!empty($Volume_amnt[0]['Vol_am'])){
						$vol_amt=$Volume_amnt[0]['Vol_am'];
					  }else{
						$vol_amt=0;
					  }
					  $this->db->select('*');
					  $this->db->from('gc_commission_setting');
					  $this->db->where('Status',1);
					  $query_commission = $this->db->get();
					  $commission_setting=$query_commission->result_array();

					  // if($commission_setting[0]['Members_count']>=$tran['Members_count'] || $commission_setting[0]['Volume_amount']>=$vol_amt){
					  $com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);

						if($Cal_date<=date('Y-m-d',strtotime($binary[0]['Payout_date']))){
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Payout_date']));
					}else{
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Pay_date']));
					}

						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);
					  if($vol_amt >=7500){

						$Doc_status=$binary[0]['Doc_status'];
								if($Doc_status==2 && $binary[0]['Payout_count']>=9){
									$Doc_status=2;

									$mem_ref=$this->db->get_where('gc_membership',array('Membership_ID' => $binary[0]['Reference_ID']))->result_array();
									$final_sms=[];
									$mem1=array('Mobile' => $binary[0]['Mobile'],'Name'=> $binary[0]['First_name'],'Sms_content'=>'hi'.$binary[0]['First_name']);
									array_push($final_sms,$mem1);

									$mem2=array('Mobile' => $mem_ref[0]['Mobile'],'Name'=> $mem_ref[0]['First_name'],'Sms_content'=>'hi'.$mem_ref[0]['First_name']);
									array_push($final_sms,$mem2);
									foreach ($final_sms as $sms) {

										$sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=NGU1ZDU0MTdlNDc&mobiles='.$sms['Mobile'].'&message='.urlencode($sms['Sms_content']).'&sender=VOSCAT&type=1&route=2';

									$ch = curl_init($sms_url);
									 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									 curl_setopt($ch, CURLOPT_POST, true);
									 curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
									 $response=curl_exec($ch);
									 // curl_close($ch);

									 if (curl_errno($ch)) {
										 $error = curl_error($ch);
									 }
									 $curl_data = explode(',', $response);
									 curl_close($ch);
									}

									

								}else{
									$Doc_status=1;
								}
						$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => '',
							'Transaction_ID'           => '',
							'Transaction_detail_ID'    => '',
							'Member_level_detail_ID'   => $level_details[0]['Member_level_detail_ID'],
							'Membership_ID'            => $binary[0]['Membership_ID'], 
							'Contract_ID'              => $binary[0]['Contract_ID'], 
							'Commision_type'           => 3,
							'Payout_ID'                => $payout_id1,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							'Amount'                   => $Comission_amount1, 
							'Commision'                => $level_details[0]['Return'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 6,
							'Doc_status'               => $Doc_status
							);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);
							$Commision_detail_ID=$this->db->insert_id();

			$payout_data=array(
							'Company_id'                  => $this->session->userdata('CompanyId'),
							'Branch_id'                   => $this->session->userdata('CompanyId'),
							'Commision_detail_ID'         => $Commision_detail_ID,
							'Membership_ID'               => $binary[0]['Membership_ID'],
							'Contract_ID'                 => $binary[0]['Contract_ID'],
							'Commission_type'             => 3,
							'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
							'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
							'Payment_mode'                => 'Bank',
							'Bank_ID'                     => '',
							'Actual_amount'               => $Comission_amount1,
							'Charges'                     => 0,
							'Final_amount'                => $Comission_amount1,
							'Reference_no'                => '',
							'Payout_status'               => 1,
							'Commission_mode'             => 1
							); 
							$this->db->insert('gc_member_payouts',$payout_data);

							$history_data=array(
				 'Company_id'                 => $this->session->userdata('CompanyId'),
				 'Branch_id'                  => $this->session->userdata('CompanyId'), 
				 'Membership_ID'              => $binary[0]['Membership_ID'],
				 'Contract_ID'                => $binary[0]['Contract_ID'],
				 'Payout'                     => $payout_id1,
				 'Payout_ID'                  => $payout_id1,
				 'Date'                       => date('Y-m-d',strtotime($payout_date)),
				 'History_for'                => 'Credited Commission Amount is '.$Comission_amount1 ,
				 'Credit_amount'              => $Comission_amount1,
				 'Type'                       => 1,
				 'Debit_amount'               => 0
				  );
			$this->db->insert('gc_transaction_history',$history_data);
// Commission Details Insert start

							$lvl_py_days=15;
							// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
							$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
							$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
							$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							$this->db->where('Contract_ID',$value_member1['Contract_ID']);
							$this->db->update('gc_member_franchisee_contract',$member_update_data1);
						}else{
							$lvl_py_days=15;
							// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
							$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
							$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
							$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							$this->db->where('Contract_ID',$value_member1['Contract_ID']);
							$this->db->update('gc_member_franchisee_contract',$member_update_data1);
						}
					}



	  
					}
				}

			}
		}
	// }
					}

				}






	}
}

public function calculate_daily_commission2($Cal_date){
		$Cal_date = date('Y-m-d', strtotime($Cal_date));
		//$day_name = date('l', strtotime($start));
		//$start = date("Y-m-d", strtotime("+1 day", strtotime($start)));
		//echo $day_num ."ss<br/>";
		//echo $Cal_date;
	//}die();
	//$Cal_date=date('Y-m-d',strtotime($Cal_date));
	$final_dates=[];
	$yrl_dates_0=[];

	$previous_trading=$this->get_previous_date1($Cal_date);

	//  Topup Commission Calculation Start 
				$this->db->select('member.Membership_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,member.Payout_ID');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				// $this->db->where('contract.Pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$this->db->where('contract.Contract_status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$query = $this->db->get();
				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members=$query->result_array();
					// var_dump($final_members);die();
					foreach ($final_members as $key => $value_member) {
						
					
					//echo ' insert';
					//echo 'insert';die();
				// Get Transaction Tabl
					$samparr=[];
				// $this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID');
				$this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID,member.Members_count');
				$this->db->from('gc_transaction as transaction');
				$this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');
				$this->db->join('gc_transaction_details as t_det', 't_det.Transaction_ID = transaction.Transaction_ID', 'left');

				$this->db->where('transaction.Transaction_status',1);
				$this->db->where('member.Status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$this->db->where('t_det.Commision_type',1);
				$this->db->where('t_det.Membership_ID',$value_member['Membership_ID']);
				$this->db->where('t_det.Contract_ID',$value_member['Contract_ID']);
				// $this->db->where('member.Membership_ID',$value_member['Membership_ID']);
				$this->db->group_by('t_det.Transaction_ID');
				// $this->db->where('transaction.Transaction_date <=',date('Y-m-d',strtotime($previous_trading)));
				$query1 = $this->db->get();
				if ($query1->num_rows() > 0) {
					$transaction=$query1->result_array();
					 // var_dump($transaction);
					foreach($transaction as $tran){
						//echo $tran['Payment_status_date'];
						$pay_date=$tran['Payment_status_date'];
						$this->db->select('*');
						$this->db->from('gc_payout_setting');
						$query = $this->db->get();
						if ($query->num_rows() > 0) {
					$set_day=$query->result_array();
					$setting_day=$set_day[0]['Schedule_day'];

				}else{
					$setting_day=0;
				}
				//echo $pay_date;
				$cms_start=$this->get_advance_date1($setting_day,date('Y-m-d',strtotime($pay_date)));
				//die();
				if($Cal_date > $cms_start){
					


					
					  // if($commission_setting[0]['Volume_amount']>=$vol_amt){
						//echo 'eligible';
					  
					//echo "insert1"; die();

						// $array=['7','14','21','28'];

						$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);

						$cl_dt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $tran['Membership_ID'],'Contract_ID' => $tran['Contract_ID']))->result_array();

					// if($Cal_date<=date('Y-m-d',strtotime($cl_dt[0]['Payout_date']))){
	 //            		$ref_payout_date=date('Y-m-d',strtotime($cl_dt[0]['Payout_date']));
	 //            	}else{
	 //            		$ref_payout_date=date('Y-m-d',strtotime($cl_dt[0]['Pay_date']));
	 //            	}
						$ref_payout_date=date('Y-m-d',strtotime($cl_dt[0]['Pay_date']));
						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);


					$commision_data=array(
							'Company_id'       => $this->session->userdata('CompanyId'),
							'Branch_id'        => $this->session->userdata('CompanyId'),
							'Transaction_ID'   => $tran['Transaction_ID'],
							'Membership_ID'    => $tran['Membership_ID'], 
							'Contract_ID'      => $tran['Contract_ID'], 
							'Transaction_type' => '',
							'Commision_date'   => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'      => date('Y-m-d',strtotime($payout_date)), 
							'Remarks'          => '',
							'Created_by'       => $this->session->userdata('UserId')
							);
					
				

					$this->db->insert('gc_daily_member_commission',$commision_data);
					$commision_id=$this->db->insert_id();
					// $commision_id=1;

					// Get Transaction detail Table
					$this->db->select('tran_det.*,gc_lvl.Payout_type');
					$this->db->from('gc_transaction_details as tran_det');
					$this->db->join('gc_membership as member', 'member.Membership_ID = tran_det.Membership_ID', 'left');
					$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = tran_det.Contract_ID', 'left');
					$this->db->join('gc_member_level_details as lvl_det', 'lvl_det.Member_level_detail_ID = tran_det.Member_level_detail_ID', 'left');
					$this->db->join('gc_level as gc_lvl', 'gc_lvl.ID = lvl_det.Level_ID', 'left');
					$this->db->where('tran_det.Status',1);
					$this->db->where('tran_det.Transaction_ID',$tran['Transaction_ID']);
					$this->db->where('member.Status',6);
					$this->db->where('contract.Withdrawn_status',5);
					$this->db->where('contract.Contract_status',6);
					$this->db->where('tran_det.Commision_type',1);
					$query2 = $this->db->get();
					  if ($query2->num_rows() > 0) {

						$transaction_detail=$query2->result_array();
						// var_dump($transaction_detail);
						foreach($transaction_detail as $tran_det){
							if($tran_det['Member_level_detail_ID']!=''){
								$payout_member=$tran_det['Payout_type'];
							}else{
								$payout_member=$tran_det['Payout_ID'];
							}
							$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => $commision_id,
							'Transaction_ID'           => $tran_det['Transaction_ID'],
							'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
							'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
							'Membership_ID'            => $tran_det['Membership_ID'], 
							'Contract_ID'              => $tran_det['Contract_ID'], 
							'Commision_type'           => $tran_det['Commision_type'],
							'Payout_ID'                => $payout_member,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							
							'Amount'                   => $tran_det['Amount']/15, 
							'Commision'                => $tran_det['Commision']/15,
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 1
							);
							// var_dump($commision_detail_data);
							$this->db->insert('gc_daily_member_commission_details',$commision_detail_data);
			//                 $Commision_detail_ID=$this->db->insert_id();

			//                 $payout_data=array(
			//     'Company_id'                  => $this->session->userdata('CompanyId'),
			//     'Branch_id'                   => $this->session->userdata('CompanyId'),
			//     'Commision_detail_ID'         => $Commision_detail_ID,
			//     'Membership_ID'               => $tran_det['Membership_ID'],
			//     'Contract_ID'                 => $tran_det['Contract_ID'],
			//     'Commission_type'             => $tran_det['Commision_type'],
			//     'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
			//     'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
			//     'Payment_mode'                => 'Bank',
			//     'Bank_ID'                     => '',
			//     'Actual_amount'               => $tran_det['Amount'],
			//     'Charges'                     => 0,
			//     'Final_amount'                => $tran_det['Amount'],
			//     'Reference_no'                => '',
			//     'Payout_status'               => 1,
			//     'Commission_mode'             => 1
			//     ); 
			//                 $this->db->insert('gc_member_payouts',$payout_data);

			//                 $history_data=array(
			//      'Company_id'                 => $this->session->userdata('CompanyId'),
			//      'Branch_id'                  => $this->session->userdata('CompanyId'), 
			//      'Membership_ID'              => $tran_det['Membership_ID'],
			//      'Contract_ID'                => $tran_det['Contract_ID'],
			//      'Payout'                     => $payout_member,
			//      'Payout_ID'                  => $payout_member,
			//      'Date'                       => date('Y-m-d',strtotime($payout_date)),
			//      'History_for'                => 'Credited Commission Amount is '.$tran_det['Amount'] ,
			//      'Credit_amount'              => $tran_det['Amount'],
			//      'Type'                       => 1,
			//      'Debit_amount'               => 0
			//       );
			// $this->db->insert('gc_transaction_history',$history_data);

	  //           $py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $value_member['Payout_ID']))->result_array();
	  //   if(!empty($py_qry)){
	  //       $pay_flag=$py_qry[0]['Pay_flag'];
	  //       $py_days=$py_qry[0]['Days']-1;
	  //   }else{
	  //       $pay_flag=2;
	  //       $py_days=15-1;
	  //   }
	  // // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days')));
	  // $Pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days'));
	  // $member_update_data['Pay_date']=date('Y-m-d',strtotime($Pay_date));

	  //   $this->db->where('Membership_ID',$value_member['Membership_ID']);
	  //   $this->db->where('Contract_ID',$value_member['Contract_ID']);
	  //   $this->db->update('gc_member_franchisee_contract',$member_update_data);

						}
						 //print_r($commision_detail_data);die();

					  }

					//} // Memberscount or Volume if End

				  }
			}

		  } //else End
					} // Members Foreach End
				 } // Membership Count if end

//  Topup Commission Calculation End 


//  Level Commission Calculation End 
$this->db->select('member.Membership_ID,member.Reference_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,contract.Lvl_pay_date,member.Payout_ID,contract.Amount');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				// $this->db->where('contract.Lvl_pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$this->db->where('contract.Contract_status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$query = $this->db->get();

				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members1=$query->result_array();
					foreach ($final_members1 as $key => $value_member1) {

		// if($value_member1[0]['Commission_mode']==1){ // Level Commission OR Self Commission is Start            	
		$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Payout_date');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$value_member1['Reference_ID']);
			$this->db->where('member.Commission_mode',1);
			// $this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_status',6);
			$this->db->where('contract.Withdrawn_status',5);
			//$this->db->where('contract.Contract_status',6);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
				 
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){
			$crnt_lvl=$binary[0]['Current_level'];
			//if($crnt_lvl<=$i){
			$level['Level_ID']=$i;
			//}
			//else{
			   //$level['Level_ID']=$crnt_lvl;
			//}
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID = level.Level_ID', 'left');

			$this->db->where('level.Child_ID',$value_member1['Membership_ID']);
			$this->db->where('level.Membership_ID',$value_member1['Reference_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();

			if(!empty($level_details)){
			$Comission_amount1=$value_member1['Amount']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}
			else{
				$payout_id1=1;
				// if($level_details[0]['Payout_status']==2){
				// $payout_id1=$level_details[0]['New_payout_ID'];
				// }else{
				// $payout_id1=$level_details[0]['Old_payout_ID'];
				//         }
					}
// Commission Details Insert start 

					$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);
						
						if($Cal_date<=date('Y-m-d',strtotime($binary[0]['Payout_date']))){
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Payout_date']));
					}else{
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Pay_date']));
					}

						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);
					
						$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => '',
							'Transaction_ID'           => '',
							'Transaction_detail_ID'    => '',
							'Member_level_detail_ID'   => $level_details[0]['Member_level_detail_ID'],
							'Membership_ID'            => $binary[0]['Membership_ID'], 
							'Contract_ID'              => $binary[0]['Contract_ID'], 
							'Commision_type'           => 2,
							'Payout_ID'                => $payout_id1,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							'Amount'                   => $Comission_amount1/15, 
							'Commision'                => $level_details[0]['Return']/15,
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 1
							);
							$this->db->insert('gc_daily_member_commission_details',$commision_detail_data);
						}
							// $Commision_detail_ID=$this->db->insert_id();

			//                 $payout_data=array(
			//     'Company_id'                  => $this->session->userdata('CompanyId'),
			//     'Branch_id'                   => $this->session->userdata('CompanyId'),
			//     'Commision_detail_ID'         => $Commision_detail_ID,
			//     'Membership_ID'               => $binary[0]['Membership_ID'],
			//     'Contract_ID'                 => $binary[0]['Contract_ID'],
			//     'Commission_type'             => 2,
			//     'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
			//     'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
			//     'Payment_mode'                => 'Bank',
			//     'Bank_ID'                     => '',
			//     'Actual_amount'               => $Comission_amount1,
			//     'Charges'                     => 0,
			//     'Final_amount'                => $Comission_amount1,
			//     'Reference_no'                => '',
			//     'Payout_status'               => 1,
			//     'Commission_mode'             => 1
			//     ); 
			//                 $this->db->insert('gc_member_payouts',$payout_data);

			//                 $history_data=array(
			//      'Company_id'                 => $this->session->userdata('CompanyId'),
			//      'Branch_id'                  => $this->session->userdata('CompanyId'), 
			//      'Membership_ID'              => $binary[0]['Membership_ID'],
			//      'Contract_ID'                => $binary[0]['Contract_ID'],
			//      'Payout'                     => $payout_id1,
			//      'Payout_ID'                  => $payout_id1,
			//      'Date'                       => date('Y-m-d',strtotime($payout_date)),
			//      'History_for'                => 'Credited Commission Amount is '.$Comission_amount1 ,
			//      'Credit_amount'              => $Comission_amount1,
			//      'Type'                       => 1,
			//      'Debit_amount'               => 0
			//       );
			// $this->db->insert('gc_transaction_history',$history_data);

							// $lvl_py_days=15-1;
						// 	// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
						// 	$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
						// 	$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
						// 	$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							// $this->db->where('Contract_ID',$value_member1['Contract_ID']);
							// $this->db->update('gc_member_franchisee_contract',$member_update_data1);



					



// Commisssion Details Insert start

			}
		}
	}
	else{

			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Payout_date');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$this->db->where('member.Commission_mode',1);
			// $this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_status',6);
			$this->db->where('contract.Withdrawn_status',5);


			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){

			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
		   //  if($crnt_lvl<=$i){
			
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$value_member1['Membership_ID']);
			$this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();

			if(!empty($level_details)){
						
			$Comission_amount1=$level_details[0]['Value']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
				$payout_id1=1;
						// if($level_details[0]['Payout_status']==2){
						// $payout_id1=$level_details[0]['New_payout_ID'];
						// }else{
						// $payout_id1=$level_details[0]['Old_payout_ID'];
						// $payout_id1=$level_payout[0]['Payout_type'];
						// }
					}
// Commission Details Insert start 

					$this->db->select('sum(contract.Amount) as Vol_am');
					// $this->db->select('level.Child_ID');
					 $this->db->from('gc_member_level_details as level');
					 $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level.Child_ID', 'left');
					 // $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
					 $this->db->join('gc_membership as member', 'member.Membership_ID = level.Child_ID', 'left');
					 $this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
					 $this->db->where('level.Level_ID',1);
					 $this->db->where('member.Status',6);
					 $this->db->where('contract.Withdrawn_status',5);
					 // $this->db->where('contract.Contract_ID',$tran['Contract_ID']);
					  $query_volume = $this->db->get();
					  $Volume_amnt=$query_volume->result_array();
					  // var_dump($Volume_amnt);
					  if(!empty($Volume_amnt[0]['Vol_am'])){
						$vol_amt=$Volume_amnt[0]['Vol_am'];
					  }else{
						$vol_amt=0;
					  }
					  $this->db->select('*');
					  $this->db->from('gc_commission_setting');
					  $this->db->where('Status',1);
					  $query_commission = $this->db->get();
					  $commission_setting=$query_commission->result_array();

					  // if($commission_setting[0]['Members_count']>=$tran['Members_count'] || $commission_setting[0]['Volume_amount']>=$vol_amt){
					  $com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);
						
						if($Cal_date<=date('Y-m-d',strtotime($binary[0]['Payout_date']))){
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Payout_date']));
					}else{
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Pay_date']));
					}

						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);
					  if($vol_amt >=7500){
						$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => '',
							'Transaction_ID'           => '',
							'Transaction_detail_ID'    => '',
							'Member_level_detail_ID'   => $level_details[0]['Member_level_detail_ID'],
							'Membership_ID'            => $binary[0]['Membership_ID'], 
							'Contract_ID'              => $binary[0]['Contract_ID'], 
							'Commision_type'           => 3,
							'Payout_ID'                => $payout_id1,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							'Amount'                   => $Comission_amount1/15, 
							'Commision'                => $level_details[0]['Return']/15,
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 1
							);
							$this->db->insert('gc_daily_member_commission_details',$commision_detail_data);
						}
							// $Commision_detail_ID=$this->db->insert_id();

			// $payout_data=array(
			//     			'Company_id'                  => $this->session->userdata('CompanyId'),
			//     			'Branch_id'                   => $this->session->userdata('CompanyId'),
			//     			'Commision_detail_ID'         => $Commision_detail_ID,
			//     			'Membership_ID'               => $binary[0]['Membership_ID'],
			//     			'Contract_ID'                 => $binary[0]['Contract_ID'],
			//     			'Commission_type'             => 3,
			//     			'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
			//     			'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
			//     			'Payment_mode'                => 'Bank',
			//     			'Bank_ID'                     => '',
			//     			'Actual_amount'               => $Comission_amount1,
			//     			'Charges'                     => 0,
			//     			'Final_amount'                => $Comission_amount1,
			//     			'Reference_no'                => '',
			//     			'Payout_status'               => 1,
			//     			'Commission_mode'             => 1
			//     			); 
			//                 $this->db->insert('gc_member_payouts',$payout_data);

			//                 $history_data=array(
			//      'Company_id'                 => $this->session->userdata('CompanyId'),
			//      'Branch_id'                  => $this->session->userdata('CompanyId'), 
			//      'Membership_ID'              => $binary[0]['Membership_ID'],
			//      'Contract_ID'                => $binary[0]['Contract_ID'],
			//      'Payout'                     => $payout_id1,
			//      'Payout_ID'                  => $payout_id1,
			//      'Date'                       => date('Y-m-d',strtotime($payout_date)),
			//      'History_for'                => 'Credited Commission Amount is '.$Comission_amount1 ,
			//      'Credit_amount'              => $Comission_amount1,
			//      'Type'                       => 1,
			//      'Debit_amount'               => 0
			//       );
			// $this->db->insert('gc_transaction_history',$history_data);
// Commission Details Insert start

							// $lvl_py_days=15-1;
						// 	// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
						// 	$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
						// 	$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
						// 	$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							// $this->db->where('Contract_ID',$value_member1['Contract_ID']);
							// $this->db->update('gc_member_franchisee_contract',$member_update_data1);
						}
						// else{
						// 	$lvl_py_days=15-1;
					// 		// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
					// 		$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
					// 		$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
					// 		$this->db->where('Membership_ID',$value_member1['Membership_ID']);
						// 	$this->db->where('Contract_ID',$value_member1['Contract_ID']);
						// 	$this->db->update('gc_member_franchisee_contract',$member_update_data1);
						// }



	  
					}
				}

			}
		}
	// }
					}

				}






	}

public function calculate_commission_new2($Cal_date){

		$Cal_date = date('Y-m-d', strtotime($Cal_date));
		//$day_name = date('l', strtotime($start));
		// $start = date("Y-m-d", strtotime("+1 day", strtotime($start)));
		//echo $day_num ."ss<br/>";
		//echo $Cal_date;
	//}die();
	// $Cal_date=date('Y-m-d',strtotime($Cal_date));
	$final_dates=[];
	$yrl_dates_0=[];

	$previous_trading=$this->get_previous_date1($Cal_date);

	//  Topup Commission Calculation Start 
				$this->db->select('member.Membership_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,member.Payout_ID');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				$this->db->where('contract.Pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$query = $this->db->get();
				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members=$query->result_array();
					// var_dump($final_members);die();
					foreach ($final_members as $key => $value_member) {
						
					
					//echo ' insert';
					//echo 'insert';die();
				// Get Transaction Tabl
					$samparr=[];
				// $this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID');
				$this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID,member.Members_count');
				$this->db->from('gc_transaction as transaction');
				$this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');
				$this->db->join('gc_transaction_details as t_det', 't_det.Transaction_ID = transaction.Transaction_ID', 'left');

				$this->db->where('transaction.Transaction_status',1);
				$this->db->where('member.Status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$this->db->where('t_det.Commision_type',1);
				$this->db->where('t_det.Membership_ID',$value_member['Membership_ID']);
				$this->db->where('t_det.Contract_ID',$value_member['Contract_ID']);
				// $this->db->where('member.Membership_ID',$value_member['Membership_ID']);
				$this->db->group_by('t_det.Transaction_ID');
				// $this->db->where('transaction.Transaction_date <=',date('Y-m-d',strtotime($previous_trading)));
				$query1 = $this->db->get();
				if ($query1->num_rows() > 0) {
					$transaction=$query1->result_array();
					 // var_dump($transaction);
					foreach($transaction as $tran){
						//echo $tran['Payment_status_date'];
						$pay_date=$tran['Payment_status_date'];
						$this->db->select('*');
						$this->db->from('gc_payout_setting');
						$query = $this->db->get();
						if ($query->num_rows() > 0) {
					$set_day=$query->result_array();
					$setting_day=$set_day[0]['Schedule_day'];

				}else{
					$setting_day=0;
				}
				//echo $pay_date;
				$cms_start=$this->get_advance_date1($setting_day,date('Y-m-d',strtotime($pay_date)));
				//die();
				if($Cal_date > $cms_start){
					


					
					  // if($commission_setting[0]['Volume_amount']>=$vol_amt){
						//echo 'eligible';
					  
					//echo "insert1"; die();

						// $array=['7','14','21','28'];
						$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);
						$per_date=date('d',strtotime($Cal_date));
						$temp_date=date('Y-m',strtotime($Cal_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);


					$commision_data=array(
							'Company_id'       => $this->session->userdata('CompanyId'),
							'Branch_id'        => $this->session->userdata('CompanyId'),
							'Transaction_ID'   => $tran['Transaction_ID'],
							'Membership_ID'    => $tran['Membership_ID'], 
							'Contract_ID'      => $tran['Contract_ID'], 
							'Transaction_type' => '',
							'Commision_date'   => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'      => date('Y-m-d',strtotime($payout_date)), 
							'Remarks'          => '',
							'Created_by'       => $this->session->userdata('UserId')
							);
					
				

					$this->db->insert('gc_member_commission',$commision_data);
					$commision_id=$this->db->insert_id();
					// $commision_id=1;

					// Get Transaction detail Table
					$this->db->select('tran_det.*,gc_lvl.Payout_type,contract.Doc_status,Payout_count,member.Mobile,member.Reference_ID,member.First_name');
					$this->db->from('gc_transaction_details as tran_det');
					$this->db->join('gc_membership as member', 'member.Membership_ID = tran_det.Membership_ID', 'left');
					$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = tran_det.Contract_ID', 'left');
					$this->db->join('gc_member_level_details as lvl_det', 'lvl_det.Member_level_detail_ID = tran_det.Member_level_detail_ID', 'left');
					$this->db->join('gc_level as gc_lvl', 'gc_lvl.ID = lvl_det.Level_ID', 'left');
					$this->db->where('tran_det.Status',1);
					$this->db->where('tran_det.Transaction_ID',$tran['Transaction_ID']);
					$this->db->where('member.Status',6);
					$this->db->where('contract.Withdrawn_status',5);
					$this->db->where('contract.Contract_status',6);
					$this->db->where('tran_det.Commision_type',1);
					$query2 = $this->db->get();
					  if ($query2->num_rows() > 0) {

						$transaction_detail=$query2->result_array();
						// var_dump($transaction_detail);
						foreach($transaction_detail as $tran_det){
							if($tran_det['Member_level_detail_ID']!=''){
								$payout_member=$tran_det['Payout_type'];
							}else{
								$payout_member=$tran_det['Payout_ID'];
							}


							$Doc_status=$tran_det['Doc_status'];
								if($Doc_status==2 && $tran_det['Payout_count']>=9){
									$Doc_status=2;

									$mem_ref=$this->db->get_where('gc_membership',array('Membership_ID' => $tran_det['Reference_ID']))->result_array();
									$final_sms=[];
									$mem1=array('Mobile' => $tran_det['Mobile'],'Name'=> $tran_det['First_name'],'Sms_content'=>'hi'.$tran_det['First_name']);
									array_push($final_sms,$mem1);

									$mem2=array('Mobile' => $mem_ref[0]['Mobile'],'Name'=> $mem_ref[0]['First_name'],'Sms_content'=>'hi'.$mem_ref[0]['First_name']);
									array_push($final_sms,$mem2);
									foreach ($final_sms as $sms) {

										$sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=NGU1ZDU0MTdlNDc&mobiles='.$sms['Mobile'].'&message='.urlencode($sms['Sms_content']).'&sender=VOSCAT&type=1&route=2';

									$ch = curl_init($sms_url);
									 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									 curl_setopt($ch, CURLOPT_POST, true);
									 curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
									 $response=curl_exec($ch);
									 // curl_close($ch);

									 if (curl_errno($ch)) {
										 $error = curl_error($ch);
									 }
									 $curl_data = explode(',', $response);
									 curl_close($ch);
									}

									

								}else{
									$Doc_status=1;
								}

							$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => $commision_id,
							'Transaction_ID'           => $tran_det['Transaction_ID'],
							'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
							'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
							'Membership_ID'            => $tran_det['Membership_ID'], 
							'Contract_ID'              => $tran_det['Contract_ID'], 
							'Commision_type'           => $tran_det['Commision_type'],
							'Payout_ID'                => $payout_member,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)),  
							'Amount'                   => $tran_det['Amount'], 
							'Commision'                => $tran_det['Commision'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 1,
							'Doc_status'               => $Doc_status
							);
							// var_dump($commision_detail_data);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);
			//                 $Commision_detail_ID=$this->db->insert_id();

							$count=1;
							$this->db->where('Contract_ID',$tran_det['Contract_ID']);
							$this->db->where('Membership_ID',$tran_det['Membership_ID']);
							$this->db->set('Payout_count', "Payout_count +'$count'", FALSE);     
							$this->db->update('gc_member_franchisee_contract');

			//                 $payout_data=array(
			//     'Company_id'                  => $this->session->userdata('CompanyId'),
			//     'Branch_id'                   => $this->session->userdata('CompanyId'),
			//     'Commision_detail_ID'         => $Commision_detail_ID,
			//     'Membership_ID'               => $tran_det['Membership_ID'],
			//     'Contract_ID'                 => $tran_det['Contract_ID'],
			//     'Commission_type'             => $tran_det['Commision_type'],
			//     'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
			//     'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
			//     'Payment_mode'                => 'Bank',
			//     'Bank_ID'                     => '',
			//     'Actual_amount'               => $tran_det['Amount'],
			//     'Charges'                     => 0,
			//     'Final_amount'                => $tran_det['Amount'],
			//     'Reference_no'                => '',
			//     'Payout_status'               => 1,
			//     'Commission_mode'             => 1
			//     ); 
			//                 $this->db->insert('gc_member_payouts',$payout_data);

			//                 $history_data=array(
			//      'Company_id'                 => $this->session->userdata('CompanyId'),
			//      'Branch_id'                  => $this->session->userdata('CompanyId'), 
			//      'Membership_ID'              => $tran_det['Membership_ID'],
			//      'Contract_ID'                => $tran_det['Contract_ID'],
			//      'Payout'                     => $payout_member,
			//      'Payout_ID'                  => $payout_member,
			//      'Date'                       => date('Y-m-d',strtotime($payout_date)),
			//      'History_for'                => 'Credited Commission Amount is '.$tran_det['Amount'] ,
			//      'Credit_amount'              => $tran_det['Amount'],
			//      'Type'                       => 1,
			//      'Debit_amount'               => 0
			//       );
			// $this->db->insert('gc_transaction_history',$history_data);

				$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $value_member['Payout_ID']))->result_array();
		if(!empty($py_qry)){
			$pay_flag=$py_qry[0]['Pay_flag'];
			$py_days=$py_qry[0]['Days'];
		}else{
			$pay_flag=2;
			$py_days=15;
		}
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days')));
	  $Pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days'));
	  $member_update_data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  $member_update_data['Payout_date']=$this->get_excat_next_payout($Cal_date);

	  

		$this->db->where('Membership_ID',$value_member['Membership_ID']);
		$this->db->where('Contract_ID',$value_member['Contract_ID']);
		$this->db->update('gc_member_franchisee_contract',$member_update_data);

						}
						 //print_r($commision_detail_data);die();

					  }

					//} // Memberscount or Volume if End

				  }
			}

		  } //else End
					} // Members Foreach End
				 } // Membership Count if end

//  Topup Commission Calculation End 


//  Level Commission Calculation End 
$this->db->select('member.Membership_ID,member.Reference_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,contract.Lvl_pay_date,member.Payout_ID,contract.Amount');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				$this->db->where('contract.Lvl_pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$this->db->where('contract.Contract_status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$query = $this->db->get();

				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members1=$query->result_array();
					foreach ($final_members1 as $key => $value_member1) {

		// if($value_member1[0]['Commission_mode']==1){ // Level Commission OR Self Commission is Start            	
		$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Payout_date,contract.Doc_status,Payout_count,member.Mobile,member.First_name,contract.Payout_Date');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$value_member1['Reference_ID']);
			$this->db->where('member.Commission_mode',1);
			// $this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_status',6);
			$this->db->where('contract.Withdrawn_status',5);
			//$this->db->where('contract.Contract_status',6);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
				 
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){
			$crnt_lvl=$binary[0]['Current_level'];
			//if($crnt_lvl<=$i){
			$level['Level_ID']=$i;
			//}
			//else{
			   //$level['Level_ID']=$crnt_lvl;
			//}
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID = level.Level_ID', 'left');

			$this->db->where('level.Child_ID',$value_member1['Membership_ID']);
			$this->db->where('level.Membership_ID',$value_member1['Reference_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();

			if(!empty($level_details)){
			$Comission_amount1=$value_member1['Amount']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}
			else{
				$payout_id1=1;
				// if($level_details[0]['Payout_status']==2){
				// $payout_id1=$level_details[0]['New_payout_ID'];
				// }else{
				// $payout_id1=$level_details[0]['Old_payout_ID'];
				//         }
					}
// Commission Details Insert start 
					$Doc_status=$binary[0]['Doc_status'];
								if($Doc_status==2 && $binary[0]['Payout_count']>=9){
									$Doc_status=2;

									$mem_ref=$this->db->get_where('gc_membership',array('Membership_ID' => $binary[0]['Reference_ID']))->result_array();
									$final_sms=[];
									$mem1=array('Mobile' => $binary[0]['Mobile'],'Name'=> $binary[0]['First_name'],'Sms_content'=>'hi'.$binary[0]['First_name']);
									array_push($final_sms,$mem1);

									$mem2=array('Mobile' => $mem_ref[0]['Mobile'],'Name'=> $mem_ref[0]['First_name'],'Sms_content'=>'hi'.$mem_ref[0]['First_name']);
									array_push($final_sms,$mem2);
									foreach ($final_sms as $sms) {

										$sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=NGU1ZDU0MTdlNDc&mobiles='.$sms['Mobile'].'&message='.urlencode($sms['Sms_content']).'&sender=VOSCAT&type=1&route=2';

									$ch = curl_init($sms_url);
									 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									 curl_setopt($ch, CURLOPT_POST, true);
									 curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
									 $response=curl_exec($ch);
									 // curl_close($ch);

									 if (curl_errno($ch)) {
										 $error = curl_error($ch);
									 }
									 $curl_data = explode(',', $response);
									 curl_close($ch);
									}

									

								}else{
									$Doc_status=1;
								}

					$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);
						
						if($Cal_date<=date('Y-m-d',strtotime($binary[0]['Payout_date']))){
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Payout_date']));
					}else{
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Pay_date']));
					}

						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);
					
						$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => '',
							'Transaction_ID'           => '',
							'Transaction_detail_ID'    => '',
							'Member_level_detail_ID'   => $level_details[0]['Member_level_detail_ID'],
							'Membership_ID'            => $binary[0]['Membership_ID'], 
							'Contract_ID'              => $binary[0]['Contract_ID'], 
							'Commision_type'           => 2,
							'Payout_ID'                => $payout_id1,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							'Amount'                   => $Comission_amount1, 
							'Commision'                => $level_details[0]['Return'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 1,
							'Doc_status'			   => $Doc_status
							);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);
							// $Commision_detail_ID=$this->db->insert_id();

	   //                      $payout_data=array(
	   //          'Company_id'                  => $this->session->userdata('CompanyId'),
	   //          'Branch_id'                   => $this->session->userdata('CompanyId'),
	   //          'Commision_detail_ID'         => $Commision_detail_ID,
	   //          'Membership_ID'               => $binary[0]['Membership_ID'],
	   //          'Contract_ID'                 => $binary[0]['Contract_ID'],
	   //          'Commission_type'             => 2,
	   //          'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
	   //          'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
	   //          'Payment_mode'                => 'Bank',
	   //          'Bank_ID'                     => '',
	   //          'Actual_amount'               => $Comission_amount1,
	   //          'Charges'                     => 0,
	   //          'Final_amount'                => $Comission_amount1,
	   //          'Reference_no'                => '',
	   //          'Payout_status'               => 1,
	   //          'Commission_mode'             => 1
	   //          ); 
	   //                      $this->db->insert('gc_member_payouts',$payout_data);

	   //                      $history_data=array(
	   //           'Company_id'                 => $this->session->userdata('CompanyId'),
	   //           'Branch_id'                  => $this->session->userdata('CompanyId'), 
	   //           'Membership_ID'              => $binary[0]['Membership_ID'],
	   //           'Contract_ID'                => $binary[0]['Contract_ID'],
	   //           'Payout'                     => $payout_id1,
	   //           'Payout_ID'                  => $payout_id1,
	   //           'Date'                       => date('Y-m-d',strtotime($payout_date)),
	   //           'History_for'                => 'Credited Commission Amount is '.$Comission_amount1 ,
	   //           'Credit_amount'              => $Comission_amount1,
	   //           'Type'                       => 1,
	   //           'Debit_amount'               => 0
	   //            );
	   //      $this->db->insert('gc_transaction_history',$history_data);

							$lvl_py_days=15;
							// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
							$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
							$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
							$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							$this->db->where('Contract_ID',$value_member1['Contract_ID']);
							$this->db->update('gc_member_franchisee_contract',$member_update_data1);

						}

					



// Commisssion Details Insert start

			}
		}
	}
	else{

			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Payout_date,contract.Doc_status,Payout_count,member.Mobile,member.First_name');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$this->db->where('member.Commission_mode',1);
			// $this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_status',6);
			$this->db->where('contract.Withdrawn_status',5);


			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){

			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
		   //  if($crnt_lvl<=$i){
			
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$value_member1['Membership_ID']);
			$this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();
			if(!empty($level_details)){
						$Comission_amount1=$level_details[0]['Value']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
				$payout_id1=1;
						// if($level_details[0]['Payout_status']==2){
						// $payout_id1=$level_details[0]['New_payout_ID'];
						// }else{
						// $payout_id1=$level_details[0]['Old_payout_ID'];
						// $payout_id1=$level_payout[0]['Payout_type'];
						// }
					}
// Commission Details Insert start 

					$this->db->select('sum(contract.Amount) as Vol_am');
					// $this->db->select('level.Child_ID');
					 $this->db->from('gc_member_level_details as level');
					 $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level.Child_ID', 'left');
					 // $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
					 $this->db->join('gc_membership as member', 'member.Membership_ID = level.Child_ID', 'left');
					 $this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
					 $this->db->where('level.Level_ID',1);
					 $this->db->where('member.Status',6);
					 $this->db->where('contract.Withdrawn_status',5);
					 // $this->db->where('contract.Contract_ID',$tran['Contract_ID']);
					  $query_volume = $this->db->get();
					  $Volume_amnt=$query_volume->result_array();
					  // var_dump($Volume_amnt);
					  if(!empty($Volume_amnt[0]['Vol_am'])){
						$vol_amt=$Volume_amnt[0]['Vol_am'];
					  }else{
						$vol_amt=0;
					  }
					  $this->db->select('*');
					  $this->db->from('gc_commission_setting');
					  $this->db->where('Status',1);
					  $query_commission = $this->db->get();
					  $commission_setting=$query_commission->result_array();

					  // if($commission_setting[0]['Members_count']>=$tran['Members_count'] || $commission_setting[0]['Volume_amount']>=$vol_amt){
					  $com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);
						
						if($Cal_date<=date('Y-m-d',strtotime($binary[0]['Payout_date']))){
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Payout_date']));
					}else{
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Pay_date']));
					}

						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);
					  if($vol_amt >=7500){

						$Doc_status=$binary[0]['Doc_status'];
								if($Doc_status==2 && $binary[0]['Payout_count']>=9){
									$Doc_status=2;

									$mem_ref=$this->db->get_where('gc_membership',array('Membership_ID' => $binary[0]['Reference_ID']))->result_array();
									$final_sms=[];
									$mem1=array('Mobile' => $binary[0]['Mobile'],'Name'=> $binary[0]['First_name'],'Sms_content'=>'hi'.$binary[0]['First_name']);
									array_push($final_sms,$mem1);

									$mem2=array('Mobile' => $mem_ref[0]['Mobile'],'Name'=> $mem_ref[0]['First_name'],'Sms_content'=>'hi'.$mem_ref[0]['First_name']);
									array_push($final_sms,$mem2);
									foreach ($final_sms as $sms) {

										$sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=NGU1ZDU0MTdlNDc&mobiles='.$sms['Mobile'].'&message='.urlencode($sms['Sms_content']).'&sender=VOSCAT&type=1&route=2';

									$ch = curl_init($sms_url);
									 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									 curl_setopt($ch, CURLOPT_POST, true);
									 curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
									 $response=curl_exec($ch);
									 // curl_close($ch);

									 if (curl_errno($ch)) {
										 $error = curl_error($ch);
									 }
									 $curl_data = explode(',', $response);
									 curl_close($ch);
									}

									

								}else{
									$Doc_status=1;
								}
						$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => '',
							'Transaction_ID'           => '',
							'Transaction_detail_ID'    => '',
							'Member_level_detail_ID'   => $level_details[0]['Member_level_detail_ID'],
							'Membership_ID'            => $binary[0]['Membership_ID'], 
							'Contract_ID'              => $binary[0]['Contract_ID'], 
							'Commision_type'           => 3,
							'Payout_ID'                => $payout_id1,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							'Amount'                   => $Comission_amount1, 
							'Commision'                => $level_details[0]['Return'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 1,
							'Doc_status'			   => $Doc_status
							);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);
							// $Commision_detail_ID=$this->db->insert_id();

			// $payout_data=array(
			//     			'Company_id'                  => $this->session->userdata('CompanyId'),
			//     			'Branch_id'                   => $this->session->userdata('CompanyId'),
			//     			'Commision_detail_ID'         => $Commision_detail_ID,
			//     			'Membership_ID'               => $binary[0]['Membership_ID'],
			//     			'Contract_ID'                 => $binary[0]['Contract_ID'],
			//     			'Commission_type'             => 3,
			//     			'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
			//     			'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
			//     			'Payment_mode'                => 'Bank',
			//     			'Bank_ID'                     => '',
			//     			'Actual_amount'               => $Comission_amount1,
			//     			'Charges'                     => 0,
			//     			'Final_amount'                => $Comission_amount1,
			//     			'Reference_no'                => '',
			//     			'Payout_status'               => 1,
			//     			'Commission_mode'             => 1
			//     			); 
			//                 $this->db->insert('gc_member_payouts',$payout_data);

			//                 $history_data=array(
			//      'Company_id'                 => $this->session->userdata('CompanyId'),
			//      'Branch_id'                  => $this->session->userdata('CompanyId'), 
			//      'Membership_ID'              => $binary[0]['Membership_ID'],
			//      'Contract_ID'                => $binary[0]['Contract_ID'],
			//      'Payout'                     => $payout_id1,
			//      'Payout_ID'                  => $payout_id1,
			//      'Date'                       => date('Y-m-d',strtotime($payout_date)),
			//      'History_for'                => 'Credited Commission Amount is '.$Comission_amount1 ,
			//      'Credit_amount'              => $Comission_amount1,
			//      'Type'                       => 1,
			//      'Debit_amount'               => 0
			//       );
			// $this->db->insert('gc_transaction_history',$history_data);
// Commission Details Insert start

							$lvl_py_days=15;
							// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
							$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
							$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
							$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							$this->db->where('Contract_ID',$value_member1['Contract_ID']);
							$this->db->update('gc_member_franchisee_contract',$member_update_data1);
						}else{
							$lvl_py_days=15;
							// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
							$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
							$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
							$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							$this->db->where('Contract_ID',$value_member1['Contract_ID']);
							$this->db->update('gc_member_franchisee_contract',$member_update_data1);
						}

					}


	  
					}
				}

			}
		}
	// }
					}

				}






	
}    

public function Activate_member_contract_by_wallet($query){
		$payment_data['Payment_status']=6;
		$this->db->where('Service_point_ID',$query[0]['Wallet_topup_ID']);
		$this->db->update('gc_wallet_payments',$payment_data);


		$reg_date=date('Y-m-d',strtotime($query[0]['Date']));
		// $payment_mode=$payment_data[0]['Payment_type_ID'];
		$payment_mode=$this->db->get_where('gc_wallet_payments',array('Service_point_ID' => $query[0]['Wallet_topup_ID']))->result_array()[0]['Payment_type_ID'];

		$Wallet_topup_ID=$query[0]['Wallet_topup_ID'];

				if($query[0]['Wallet_amount_from']==2){
						$query2 = $this->db->get_where('gc_service_wallet', array('Service_point_ID' => $query[0]['Wallet_service_point']))->result_array();
					if(count($query2)>0){
						if($query2[0]['Wallet_balance']>=$query[0]['Total_amount']){
							$wallet_data=array(
									  'Wallet_balance'=>$query2[0]['Wallet_balance']-$query[0]['Total_amount'],
									  'Updated_date'=>date('Y-m-d'));
							$this->db->where('Service_point_ID',$query[0]['Wallet_service_point']);
							$this->db->update('gc_service_wallet',$wallet_data);

							$query3 = $this->db->get_where('gc_users', array('id' => $query[0]['Wallet_service_point']))->result_array();
						$user_data=array('Wallet_balance'=>$query3[0]['Wallet_balance']-$query[0]['Total_amount']);
						$this->db->where('id',$query[0]['Wallet_service_point']);
						$this->db->update('gc_users',$user_data);

						}
							
						}
					}

						$data_status['Status']=6;
						$data_status['Processed_date']=date('Y-m-d');
						$this->db->where('Wallet_topup_ID',$Wallet_topup_ID);
						$this->db->update('gc_wallet_topup',$data_status);

					$tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();

						$payout_id=2;
						if(!empty($tp)){
							$cmsn_percentage=$tp[0]['Return'];
							$month=$tp[0]['Validity'];
						}else{
							$cmsn_percentage=20;
							$month=10;
						}

						$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();
						 
						 if(!empty($py_qry)){
							 $pay_flag=$py_qry[0]['Pay_flag'];
							 $py_days=$py_qry[0]['Days']-1;
						 }else{
							 $pay_flag=2;
							 $py_days=15-1;
						 }
						 


						$cmsn_per=$cmsn_percentage/$pay_flag;
						$membership_ID=$query[0]['Membership_ID'];
						
						$increment_code1 = $this->db->count_all_results('gc_member_franchisee_contract')+1;
						$contract_data['Contract_ref_no']   ="GRNC-CNT-0000".$increment_code1;
						$contract_data['Company_id']        = $this->session->userdata('CompanyId');
						$contract_data['Branch_id']         = $this->session->userdata('CompanyId');
						$contract_data['Payout_ID']         = $payout_id;
						$count=$this->db->where('Membership_ID',$membership_ID)->count_all_results('			gc_member_franchisee_contract');
						if ($count > 0) {
						   $contract_data['Invest_type']                      = 2;
						}else{
							$contract_data['Invest_type']                     = 1;

							// Memberhsip Update end
						$mbr_data['Status']=6;
						$mbr_data['Commission_mode']=1;
						$mbr_data['Final_commission_per']=$cmsn_per;
						$mbr_data['Payout_ID']=$payout_id;
						$mbr_data['Commission_per']=0;  
						$mbr_data['Activated_date']=date('Y-m-d',strtotime($reg_date));
						$mbr_data['End_date']=date('Y-m-d', strtotime($reg_date. ' + '.$month.' months'));
						 
						$this->db->where('Membership_ID',$membership_ID);
						$this->db->update('gc_membership',$mbr_data);
						}
						
						$contract_data['Topup_id']               = 1;
						$contract_data['Membership_type']        = 1;
						$contract_data['Membership_ID']          = $membership_ID;
						$contract_data['Final_commission_per']   = $cmsn_per;
						$contract_data['Amount']                 = $query[0]['Total_amount'];
						$contract_data['Payment_mode']           = $payment_mode;


						$contract_data['Date']              = date('Y-m-d',strtotime($reg_date));
						$contract_data['Payment_status_date'] = date('Y-m-d',strtotime($reg_date));
						$contract_data['Aggreement_mode']   = 1;
						$contract_data['Surety_mode']       = 1;
						$contract_data['Created_date']      = date('Y-m-d');
						//var_dump($contract_data);
						if($this->db->insert('gc_member_franchisee_contract', $contract_data)){
							$Contract_ID=$this->db->insert_id();
						}

						

						$activate=$this->bulk_activate_by_wallet($membership_ID,$Contract_ID,$Commission_mode=1,$cmsn_per,$Memberhip_type=1,$payout_id,$contract_data['Amount'],$reg_date);



}

public function bulk_activate_by_wallet($Membership_ID,$Contract_ID,$Commission_mode,$cmsn_per,$Memberhip_type,$Membership_payout,$contract_amount,$reg_date){


	$up_data['Membership_type']=$Memberhip_type;
	$this->db->where('Membership_ID',$Membership_ID);
	$this->db->update('gc_membership',$up_data);

	// $this->db->select('topup.Validity,topup.Value,topup.Return,contract.Multiples,contract.Amount');
 //        $this->db->from('gc_member_topup as topup');
		

 //        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');
 //        // $this->db->join('gc_membership as member', 'member.Payout_ID = topup.ID', 'left');

 //        $this->db->where('contract.Contract_ID',$Contract_ID);
 //        $this->db->where('contract.Membership_ID',$Membership_ID);
 //        $query = $this->db->get();
 //        $contract=$query->result_array();

		$tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();
		$contract=$this->db->get_where('gc_member_franchisee_contract',array('Contract_ID' => $Contract_ID,'Membership_ID' => $Membership_ID))->result_array();
// var_dump($contract);die();
		if(!empty($tp)){
			$month=$tp[0]['Validity'];
			// $Amount=$contract[0]['Value']*$contract[0]['Multiples'];
			
			// $Return=$tp[0]['Return'];
			// $pay_flag=$contract[0]['Pay_flag'];

			// if($contract[0]['Payout_status']==2){
			//     $payout_id=$contract[0]['New_payout_ID'];
			// }else{
			//     $payout_id=$contract[0]['Old_payout_ID'];
			// }
		}else{
			$month=0;
			
			// $Return=0;
			// $pay_flag=2;
		}

		// if(!empty($contract)){
		// 	$Amount=$contract[0]['Amount'];
		// }else{
		// 	$Amount=0;
		// }

		$Return=$cmsn_per;
		$Amount=$contract_amount;
		$new_pay=$Return;
		// $mem_qry = $this->db->select('Membership_ID,Payout_ID,Membership_type')->get_where('gc_membership', array('Membership_ID' => $Membership_ID))->result_array();
		// if(!empty($mem_qry[0]['Payout_ID'])){
		//     $payout_id=$mem_qry[0]['Payout_ID'];
		// }else{
			$payout_id=$Membership_payout;
		//}

		$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();
		if(!empty($py_qry)){
			$pay_flag=$py_qry[0]['Pay_flag'];
			$py_days=$py_qry[0]['Days']-1;
		}else{
			$pay_flag=2;
			$py_days=15-1;
		}

		// if($Commission_mode==2){
		//     $new_pay=$Return+($cmsn_per/$pay_flag);
		// }else{
		//     $new_pay=$Return;
		// }

		// $new_pay=$cmsn_per/$pay_flag;
		$new_pay=$cmsn_per;
// Memberhsip Update end
		$data['Status']=6;
		$data['Commission_mode']=$Commission_mode;
		$data['Final_commission_per']=$new_pay;
		$data['Payout_ID']=$payout_id;
		
	  //   if($Commission_mode==2){
	  //     $data['Commission_per']=$cmsn_per;  
	  // }else{
	  //       $data['Commission_per']=0;
	  // }
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  $Pay_date=date('Y-m-d', strtotime($reg_date. ' + '.$py_days.' days'));
	  $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  $lvl_py_days=15-1;
	  // $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$lvl_py_days.' days')));
	  $Lvl_pay_date=date('Y-m-d', strtotime($reg_date. ' + '.$lvl_py_days.' days'));
	  $data['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));

	  $next_exact_payout=$this->get_excat_next_payout($Pay_date);
	  // if($pay_flag==1){
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }else{
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }
		
	  // var_dump($data);die();
		// $data['Activated_date']=date('Y-m-d H:i:s');
		// $this->db->where('Membership_ID',$Membership_ID);
		// $this->db->update('gc_membership',$data);


// Membership Update end 
// Transaction Insert Start        
		$transaction=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $Membership_ID, 
							'Contract_ID' => $Contract_ID, 
							'Transaction_type' => 1,
							'Transaction_date' => date('Y-m-d',strtotime($reg_date)), 
							'Remarks' => '', 
							'Created_by' => $this->session->userdata('UserId') 
						);
		$this->db->insert('gc_transaction',$transaction);
		$transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
		$Comission_amount=$Amount*$new_pay/100;
		$transaction_detail=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $Membership_ID, 
							'Contract_ID' => $Contract_ID,
							'Member_level_detail_ID' => NULL, 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 1, 
							'Payout_ID' => $payout_id,
							'Amount' => $Comission_amount, 
							'Commision' => $new_pay,
							'New_pay_percent' => $new_pay,
							'Remarks' => '' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail);
// Transaction Detail (Top-up) Insert End   

// Transaction History (Debit) Insert start 
$history_data=array(
				 'Company_id'               => $this->session->userdata('CompanyId'),
				 'Branch_id'                => $this->session->userdata('CompanyId'), 
				 'Membership_ID' => $Membership_ID,
				 'Contract_ID'   => $Contract_ID,
				 'Payout_ID' => $payout_id,
				 'Date'  => date('Y-m-d',strtotime($reg_date)), 
				 'History_for'   => ' Topup Amount of  '.$Amount,
				 'Credit_amount' => 0,
				 'Debit_amount' => $Amount,
				  );
			$this->db->insert('gc_transaction_history',$history_data);  

// Transaction History (Debit) Insert End  

// Transaction Details (Direct&Push-up) Insert Start
		$this->db->select('Reference_ID');
		$this->db->from('gc_membership');
		$this->db->where('Membership_ID',$Membership_ID);
		$query = $this->db->get();
		$membership=$query->result_array();

if($Commission_mode==1){ // Level Commission OR Self Commission is Start
	$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$membership[0]['Reference_ID']);
			$this->db->where('member.Commission_mode',1);
			$this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_ID IS NOT NULL');
			//$this->db->where('contract.Contract_status',6);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){
			$crnt_lvl=$binary[0]['Current_level'];
			//if($crnt_lvl<=$i){
			$level['Level_ID']=$i;
			//}
			//else{
			   //$level['Level_ID']=$crnt_lvl;
			//}
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			$this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();


			$Comission_amount1=$Amount*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
				if($level_details[0]['Payout_status']==2){
				$payout_id1=$level_details[0]['New_payout_ID'];
				}else{
				$payout_id1=$level_details[0]['Old_payout_ID'];
						}
					}
// Transaction Details Insert start 
$transaction_detail1=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $binary[0]['Membership_ID'], 
							'Contract_ID' => $binary[0]['Contract_ID'],
							'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 2,
							'Payout_ID' => $payout_id1, 
							'Amount' => $Comission_amount1, 
							'Commision' => $level_details[0]['Return'],
							'Remarks' => '' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start

			}
		}
	}
	else{
			$this->db->select('*');
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$this->db->where('member.Commission_mode',1);
			$this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_ID IS NOT NULL');
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){

			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
		   //  if($crnt_lvl<=$i){
			
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount,contract.Payout_ID');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			$this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();
						$Comission_amount1=$level_details[0]['Value']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
						if($level_details[0]['Payout_status']==2){
						$payout_id1=$level_details[0]['New_payout_ID'];
						}else{
						$payout_id1=$level_details[0]['Old_payout_ID'];
						$payout_id1=$level_payout[0]['Payout_type'];
						}
					}
// Transaction Details Insert start 
$transaction_detail1=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $binary[0]['Membership_ID'], 
							'Contract_ID' => $binary[0]['Contract_ID'],
							'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 3,
							'Payout_ID' => $payout_id1, 
							'Amount' => $Comission_amount1, 
							'Commision' => $level_details[0]['Return'],
							'Remarks' => ''  
						);
		$this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
// Transaction Details (Direct&Push-up) Insert End        
					}
				}

			}
		}
} // Level Commission OR Self Commission is End
		// $user_data = array('status' => 1 );
		// $this->db->where('user_id',$Membership_ID);
		// $this->db->update('gc_users',$user_data);

		$data1['Start_date']=date('Y-m-d',strtotime($reg_date));

		// $data1['End_date']=date('Y-m-d', strtotime('+'.$month.'months'));
		$data1['End_date']=date('Y-m-d', strtotime($reg_date. ' + '.$month.' months'));
		$data1['Contract_status']=6;
		$data1['Commission_mode']=$Commission_mode;
		$data1['Final_commission_per']=$new_pay;
		$data1['Pay_date']=$Pay_date;
		$data1['Lvl_pay_date']=$Lvl_pay_date;
		$data1['Payout_date']=$next_exact_payout;
	  //   if($Commission_mode==2){
	  //     $data1['Commission_per']=$cmsn_per;  
	  // }else{
	  //       $data1['Commission_per']=0;
	  // }
		$data1['Contract_status_date']=date('Y-m-d',strtotime($reg_date));
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->where('Contract_ID',$Contract_ID);
		$this->db->update('gc_member_franchisee_contract',$data1);
		


}


public function calculate_commission_new($Cal_date){
	$Cal_date=date('Y-m-d',strtotime($Cal_date));
	$final_dates=[];
	$yrl_dates_0=[];

	$previous_trading=$this->get_previous_date1($Cal_date);

	//  Topup Commission Calculation Start 
				$this->db->select('member.Membership_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,member.Payout_ID');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				$this->db->where('contract.Pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$query = $this->db->get();
				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members=$query->result_array();
					// var_dump($final_members);die();
					foreach ($final_members as $key => $value_member) {
						
					
					//echo ' insert';
					//echo 'insert';die();
				// Get Transaction Tabl
					$samparr=[];
				// $this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID');
				$this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID,member.Members_count');
				$this->db->from('gc_transaction as transaction');
				$this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');
				$this->db->join('gc_transaction_details as t_det', 't_det.Transaction_ID = transaction.Transaction_ID', 'left');

				$this->db->where('transaction.Transaction_status',1);
				$this->db->where('member.Status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$this->db->where('t_det.Commision_type',1);
				$this->db->where('t_det.Membership_ID',$value_member['Membership_ID']);
				$this->db->where('t_det.Contract_ID',$value_member['Contract_ID']);
				// $this->db->where('member.Membership_ID',$value_member['Membership_ID']);
				$this->db->group_by('t_det.Transaction_ID');
				// $this->db->where('transaction.Transaction_date <=',date('Y-m-d',strtotime($previous_trading)));
				$query1 = $this->db->get();
				if ($query1->num_rows() > 0) {
					$transaction=$query1->result_array();
					 // var_dump($transaction);
					foreach($transaction as $tran){
						//echo $tran['Payment_status_date'];
						$pay_date=$tran['Payment_status_date'];
						$this->db->select('*');
						$this->db->from('gc_payout_setting');
						$query = $this->db->get();
						if ($query->num_rows() > 0) {
					$set_day=$query->result_array();
					$setting_day=$set_day[0]['Schedule_day'];

				}else{
					$setting_day=0;
				}
				//echo $pay_date;
				$cms_start=$this->get_advance_date1($setting_day,date('Y-m-d',strtotime($pay_date)));
				//die();
				if($Cal_date > $cms_start){
					$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);


					// $this->db->select('sum(contract.Amount) as Vol_am');
					// // $this->db->select('level.Child_ID');
					//  $this->db->from('gc_member_level_details as level');
					//  $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level.Child_ID', 'left');
					//  // $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
					//  $this->db->join('gc_membership as member', 'member.Membership_ID = level.Child_ID', 'left');
					//  $this->db->where('level.Membership_ID',$tran['Membership_ID']);
					//  $this->db->where('level.Level_ID',1);
					//  $this->db->where('member.Status',6);
					//  $this->db->where('contract.Withdrawn_status',5);
					//  // $this->db->where('contract.Contract_ID',$tran['Contract_ID']);
					//   $query_volume = $this->db->get();
					//   $Volume_amnt=$query_volume->result_array();
					//   // var_dump($Volume_amnt);
					//   if(!empty($Volume_amnt[0]['Vol_am'])){
					//     $vol_amt=$Volume_amnt[0]['Vol_am'];
					//   }else{
					//     $vol_amt=0;
					//   }
					//   $this->db->select('*');
					//   $this->db->from('gc_commission_setting');
					//   $this->db->where('Status',1);
					//   $query_commission = $this->db->get();
					//   $commission_setting=$query_commission->result_array();

					//   // if($commission_setting[0]['Members_count']>=$tran['Members_count'] || $commission_setting[0]['Volume_amount']>=$vol_amt){
					//   if($vol_amt>=7500){
					  // if($commission_setting[0]['Volume_amount']>=$vol_amt){
						//echo 'eligible';
					  
					//echo "insert1"; die();

						// $array=['7','14','21','28'];
						$per_date=date('d',strtotime($Cal_date));
						$temp_date=date('Y-m',strtotime($Cal_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);


					$commision_data=array(
							'Company_id'       => $this->session->userdata('CompanyId'),
							'Branch_id'        => $this->session->userdata('CompanyId'),
							'Transaction_ID'   => $tran['Transaction_ID'],
							'Membership_ID'    => $tran['Membership_ID'], 
							'Contract_ID'      => $tran['Contract_ID'], 
							'Transaction_type' => '',
							'Commision_date'   => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'      => date('Y-m-d',strtotime($payout_date)), 
							'Remarks'          => '',
							'Created_by'       => $this->session->userdata('UserId'),
							'Doc_status'       => ''
							);
					
				

					$this->db->insert('gc_member_commission',$commision_data);
					$commision_id=$this->db->insert_id();
					// $commision_id=1;

					// Get Transaction detail Table
					$this->db->select('tran_det.*,gc_lvl.Payout_type,contract.Doc_status,Payout_count,member.Mobile,member.Reference_ID,member.First_name');
					$this->db->from('gc_transaction_details as tran_det');
					$this->db->join('gc_membership as member', 'member.Membership_ID = tran_det.Membership_ID', 'left');
					$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = tran_det.Contract_ID', 'left');
					$this->db->join('gc_member_level_details as lvl_det', 'lvl_det.Member_level_detail_ID = tran_det.Member_level_detail_ID', 'left');
					$this->db->join('gc_level as gc_lvl', 'gc_lvl.ID = lvl_det.Level_ID', 'left');
					$this->db->where('tran_det.Status',1);
					$this->db->where('tran_det.Transaction_ID',$tran['Transaction_ID']);
					$this->db->where('member.Status',6);
					$this->db->where('contract.Withdrawn_status',5);
					$this->db->where('contract.Contract_status',6);
					$this->db->where('tran_det.Commision_type',1);
					$query2 = $this->db->get();
					  if ($query2->num_rows() > 0) {

						$transaction_detail=$query2->result_array();
						// var_dump($transaction_detail);
						foreach($transaction_detail as $tran_det){
							if($tran_det['Member_level_detail_ID']!=''){
								$payout_member=$tran_det['Payout_type'];
							}else{
								$payout_member=$tran_det['Payout_ID'];
							}
							
								$Doc_status=$tran_det['Doc_status'];
								if($Doc_status==2 && $tran_det['Payout_count']>=9){
									$Doc_status=2;

									$mem_ref=$this->db->get_where('gc_membership',array('Membership_ID' => $tran_det['Reference_ID']))->result_array();
									$final_sms=[];
									$mem1=array('Mobile' => $tran_det['Mobile'],'Name'=> $tran_det['First_name'],'Sms_content'=>'hi'.$tran_det['First_name']);
									array_push($final_sms,$mem1);

									$mem2=array('Mobile' => $mem_ref[0]['Mobile'],'Name'=> $mem_ref[0]['First_name'],'Sms_content'=>'hi'.$mem_ref[0]['First_name']);
									array_push($final_sms,$mem2);
									foreach ($final_sms as $sms) {

										$sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=NGU1ZDU0MTdlNDc&mobiles='.$sms['Mobile'].'&message='.urlencode($sms['Sms_content']).'&sender=VOSCAT&type=1&route=2';

									$ch = curl_init($sms_url);
									 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									 curl_setopt($ch, CURLOPT_POST, true);
									 curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
									 $response=curl_exec($ch);
									 // curl_close($ch);

									 if (curl_errno($ch)) {
										 $error = curl_error($ch);
									 }
									 $curl_data = explode(',', $response);
									 curl_close($ch);
									}

									

								}else{
									$Doc_status=1;
								}
							
							$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => $commision_id,
							'Transaction_ID'           => $tran_det['Transaction_ID'],
							'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
							'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
							'Membership_ID'            => $tran_det['Membership_ID'], 
							'Contract_ID'              => $tran_det['Contract_ID'], 
							'Commision_type'           => $tran_det['Commision_type'],
							'Payout_ID'                => $payout_member,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							
							'Amount'                   => $tran_det['Amount'], 
							'Commision'                => $tran_det['Commision'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 1,
							'Doc_status'               => $Doc_status
							);
							// var_dump($commision_detail_data);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);
							$Commision_detail_ID=$this->db->insert_id();

							$count=1;
							$this->db->where('Contract_ID',$tran_det['Contract_ID']);
							$this->db->where('Membership_ID',$tran_det['Membership_ID']);
							$this->db->set('Payout_count', "Payout_count +'$count'", FALSE);     
							$this->db->update('gc_member_franchisee_contract');


				//             $payout_data=array(
				// 'Company_id'                  => $this->session->userdata('CompanyId'),
				// 'Branch_id'                   => $this->session->userdata('CompanyId'),
				// 'Commision_detail_ID'         => $Commision_detail_ID,
				// 'Membership_ID'               => $tran_det['Membership_ID'],
				// 'Contract_ID'                 => $tran_det['Contract_ID'],
				// 'Commission_type'             => $tran_det['Commision_type'],
				// 'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
				// 'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
				// 'Payment_mode'                => 'Bank',
				// 'Bank_ID'                     => '',
				// 'Actual_amount'               => $tran_det['Amount'],
				// 'Charges'                     => 0,
				// 'Final_amount'                => $tran_det['Amount'],
				// 'Reference_no'                => '',
				// 'Payout_status'               => 1,
				// 'Commission_mode'             => 1
				// ); 
				//             $this->db->insert('gc_member_payouts',$payout_data);

				$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $value_member['Payout_ID']))->result_array();
		if(!empty($py_qry)){
			$pay_flag=$py_qry[0]['Pay_flag'];
			$py_days=$py_qry[0]['Days'];
		}else{
			$pay_flag=2;
			$py_days=15;
		}
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days')));
	  $Pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days'));
	  $member_update_data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  $member_update_data['Payout_date']=$payout_date;

		$this->db->where('Membership_ID',$value_member['Membership_ID']);
		$this->db->where('Contract_ID',$value_member['Contract_ID']);
		$this->db->update('gc_member_franchisee_contract',$member_update_data);

						}
						 //print_r($commision_detail_data);die();

					  }

					//} // Memberscount or Volume if End

				  }
			}

		  } //else End
					} // Members Foreach End
				 } // Membership Count if end

//  Topup Commission Calculation End 


//  Level Commission Calculation End 
$this->db->select('member.Membership_ID,member.Reference_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,contract.Lvl_pay_date,member.Payout_ID,contract.Amount');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				$this->db->where('contract.Lvl_pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$this->db->where('contract.Contract_status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$query = $this->db->get();

				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members1=$query->result_array();
					foreach ($final_members1 as $key => $value_member1) {

		// if($value_member1[0]['Commission_mode']==1){ // Level Commission OR Self Commission is Start            	
		$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Doc_status,Payout_count,member.Mobile,member.First_name,contract.Payout_Date');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$value_member1['Reference_ID']);
			$this->db->where('member.Commission_mode',1);
			// $this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_status',6);
			$this->db->where('contract.Withdrawn_status',5);
			//$this->db->where('contract.Contract_status',6);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
				 
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){
			$crnt_lvl=$binary[0]['Current_level'];
			//if($crnt_lvl<=$i){
			$level['Level_ID']=$i;
			//}
			//else{
			   //$level['Level_ID']=$crnt_lvl;
			//}
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID = level.Level_ID', 'left');

			$this->db->where('level.Child_ID',$value_member1['Membership_ID']);
			$this->db->where('level.Membership_ID',$value_member1['Reference_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();


			$Comission_amount1=$value_member1['Amount']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}
			else{
				$payout_id1=1;
				// if($level_details[0]['Payout_status']==2){
				// $payout_id1=$level_details[0]['New_payout_ID'];
				// }else{
				// $payout_id1=$level_details[0]['Old_payout_ID'];
				//         }
					}
// Commission Details Insert start 
					$Doc_status=$binary[0]['Doc_status'];
								if($Doc_status==2 && $binary[0]['Payout_count']>=9){
									$Doc_status=2;

									$mem_ref=$this->db->get_where('gc_membership',array('Membership_ID' => $binary[0]['Reference_ID']))->result_array();
									$final_sms=[];
									$mem1=array('Mobile' => $binary[0]['Mobile'],'Name'=> $binary[0]['First_name'],'Sms_content'=>'hi'.$binary[0]['First_name']);
									array_push($final_sms,$mem1);

									$mem2=array('Mobile' => $mem_ref[0]['Mobile'],'Name'=> $mem_ref[0]['First_name'],'Sms_content'=>'hi'.$mem_ref[0]['First_name']);
									array_push($final_sms,$mem2);
									foreach ($final_sms as $sms) {

										$sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=NGU1ZDU0MTdlNDc&mobiles='.$sms['Mobile'].'&message='.urlencode($sms['Sms_content']).'&sender=VOSCAT&type=1&route=2';

									$ch = curl_init($sms_url);
									 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									 curl_setopt($ch, CURLOPT_POST, true);
									 curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
									 $response=curl_exec($ch);
									 // curl_close($ch);

									 if (curl_errno($ch)) {
										 $error = curl_error($ch);
									 }
									 $curl_data = explode(',', $response);
									 curl_close($ch);
									}

									

								}else{
									$Doc_status=1;
								}
						$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);
						
						if($Cal_date<=date('Y-m-d',strtotime($binary[0]['Payout_date']))){
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Payout_date']));
					}else{
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Pay_date']));
					}

						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);

						$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => '',
							'Transaction_ID'           => '',
							'Transaction_detail_ID'    => '',
							'Member_level_detail_ID'   => $level_details[0]['Member_level_detail_ID'],
							'Membership_ID'            => $binary[0]['Membership_ID'], 
							'Contract_ID'              => $binary[0]['Contract_ID'], 
							'Commision_type'           => 2,
							'Payout_ID'                => $payout_id1,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							'Amount'                   => $Comission_amount1, 
							'Commision'                => $level_details[0]['Return'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 1,
							'Doc_status'               => $Doc_status
							);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);
							$Commision_detail_ID=$this->db->insert_id();



				//             $payout_data=array(
				// 'Company_id'                  => $this->session->userdata('CompanyId'),
				// 'Branch_id'                   => $this->session->userdata('CompanyId'),
				// 'Commision_detail_ID'         => $Commision_detail_ID,
				// 'Membership_ID'               => $binary[0]['Membership_ID'],
				// 'Contract_ID'                 => $binary[0]['Contract_ID'],
				// 'Commission_type'             => 2,
				// 'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
				// 'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
				// 'Payment_mode'                => 'Bank',
				// 'Bank_ID'                     => '',
				// 'Actual_amount'               => $Comission_amount1,
				// 'Charges'                     => 0,
				// 'Final_amount'                => $Comission_amount1,
				// 'Reference_no'                => '',
				// 'Payout_status'               => 1,
				// 'Commission_mode'             => 1
				// ); 
				//             $this->db->insert('gc_member_payouts',$payout_data);

							$lvl_py_days=15;
							// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
							$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
							$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
							$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							$this->db->where('Contract_ID',$value_member1['Contract_ID']);
							$this->db->update('gc_member_franchisee_contract',$member_update_data1);
						

					



// Commisssion Details Insert start

			}
		}
	}
	else{

			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Doc_status,Payout_count,member.Mobile,member.First_name,contract.Payout_date');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$this->db->where('member.Commission_mode',1);
			// $this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_status',6);
			$this->db->where('contract.Withdrawn_status',5);


			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){

			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
		   //  if($crnt_lvl<=$i){
			
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();
						$Comission_amount1=$level_details[0]['Value']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
				$payout_id1=1;
						// if($level_details[0]['Payout_status']==2){
						// $payout_id1=$level_details[0]['New_payout_ID'];
						// }else{
						// $payout_id1=$level_details[0]['Old_payout_ID'];
						// $payout_id1=$level_payout[0]['Payout_type'];
						// }
					}
// Commission Details Insert start 

$this->db->select('sum(contract.Amount) as Vol_am');
					// $this->db->select('level.Child_ID');
					 $this->db->from('gc_member_level_details as level');
					 $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level.Child_ID', 'left');
					 // $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
					 $this->db->join('gc_membership as member', 'member.Membership_ID = level.Child_ID', 'left');
					 $this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
					 $this->db->where('level.Level_ID',1);
					 $this->db->where('member.Status',6);
					 $this->db->where('contract.Withdrawn_status',5);
					 // $this->db->where('contract.Contract_ID',$tran['Contract_ID']);
					  $query_volume = $this->db->get();
					  $Volume_amnt=$query_volume->result_array();
					  // var_dump($Volume_amnt);
					  if(!empty($Volume_amnt[0]['Vol_am'])){
						$vol_amt=$Volume_amnt[0]['Vol_am'];
					  }else{
						$vol_amt=0;
					  }
					  $this->db->select('*');
					  $this->db->from('gc_commission_setting');
					  $this->db->where('Status',1);
					  $query_commission = $this->db->get();
					  $commission_setting=$query_commission->result_array();

					  // if($commission_setting[0]['Members_count']>=$tran['Members_count'] || $commission_setting[0]['Volume_amount']>=$vol_amt){

					  $com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);
						
						if($Cal_date<=date('Y-m-d',strtotime($binary[0]['Payout_date']))){
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Payout_date']));
					}else{
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Pay_date']));
					}

						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);

					  if($vol_amt>=7500){
						$Doc_status=$binary[0]['Doc_status'];
								if($Doc_status==2 && $binary[0]['Payout_count']>=9){
									$Doc_status=2;

									$mem_ref=$this->db->get_where('gc_membership',array('Membership_ID' => $binary[0]['Reference_ID']))->result_array();
									$final_sms=[];
									$mem1=array('Mobile' => $binary[0]['Mobile'],'Name'=> $binary[0]['First_name'],'Sms_content'=>'hi'.$binary[0]['First_name']);
									array_push($final_sms,$mem1);

									$mem2=array('Mobile' => $mem_ref[0]['Mobile'],'Name'=> $mem_ref[0]['First_name'],'Sms_content'=>'hi'.$mem_ref[0]['First_name']);
									array_push($final_sms,$mem2);
									foreach ($final_sms as $sms) {

										$sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=NGU1ZDU0MTdlNDc&mobiles='.$sms['Mobile'].'&message='.urlencode($sms['Sms_content']).'&sender=VOSCAT&type=1&route=2';

									$ch = curl_init($sms_url);
									 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									 curl_setopt($ch, CURLOPT_POST, true);
									 curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
									 $response=curl_exec($ch);
									 // curl_close($ch);

									 if (curl_errno($ch)) {
										 $error = curl_error($ch);
									 }
									 $curl_data = explode(',', $response);
									 curl_close($ch);
									}

									

								}else{
									$Doc_status=1;
								}
						$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => '',
							'Transaction_ID'           => '',
							'Transaction_detail_ID'    => '',
							'Member_level_detail_ID'   => $level_details[0]['Member_level_detail_ID'],
							'Membership_ID'            => $binary[0]['Membership_ID'], 
							'Contract_ID'              => $binary[0]['Contract_ID'], 
							'Commision_type'           => 3,
							'Payout_ID'                => $payout_id1,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							'Amount'                   => $Comission_amount1, 
							'Commision'                => $level_details[0]['Return'],
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId'),
							'Status'                   => 1,
							'Doc_status'                   => $Doc_status
							);
							$this->db->insert('gc_member_commission_details',$commision_detail_data);
							$Commision_detail_ID=$this->db->insert_id();

			// $payout_data=array(
			//     			'Company_id'                  => $this->session->userdata('CompanyId'),
			//     			'Branch_id'                   => $this->session->userdata('CompanyId'),
			//     			'Commision_detail_ID'         => $Commision_detail_ID,
			//     			'Membership_ID'               => $binary[0]['Membership_ID'],
			//     			'Contract_ID'                 => $binary[0]['Contract_ID'],
			//     			'Commission_type'             => 2,
			//     			'Generated_date'              => date('Y-m-d',strtotime($Cal_date)),
			//     			'Recieved_date  '             => date('Y-m-d',strtotime($payout_date)),
			//     			'Payment_mode'                => 'Bank',
			//     			'Bank_ID'                     => '',
			//     			'Actual_amount'               => $Comission_amount1,
			//     			'Charges'                     => 0,
			//     			'Final_amount'                => $Comission_amount1,
			//     			'Reference_no'                => '',
			//     			'Payout_status'               => 1,
			//     			'Commission_mode'             => 1
			//     			); 
			//                 $this->db->insert('gc_member_payouts',$payout_data);
// Commission Details Insert start

							$lvl_py_days=15;
							// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
							$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
							$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
							$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							$this->db->where('Contract_ID',$value_member1['Contract_ID']);
							$this->db->update('gc_member_franchisee_contract',$member_update_data1);
						}else{
							$lvl_py_days=15;
							// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
							$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
							$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
							$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							$this->db->where('Contract_ID',$value_member1['Contract_ID']);
							$this->db->update('gc_member_franchisee_contract',$member_update_data1);
						}


	  
					}
				}

			}
		}
	// }
					}

				}




}

public function calculate_daily_commission($Cal_date){
	$Cal_date=date('Y-m-d',strtotime($Cal_date));
	$final_dates=[];
	$yrl_dates_0=[];

	$previous_trading=$this->get_previous_date1($Cal_date);

// Topup Commission start 
	 $samparr=[];
				// $this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID');
				$this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID,member.Members_count');
				$this->db->from('gc_transaction as transaction');
				$this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');
				$this->db->join('gc_transaction_details as t_det', 't_det.Transaction_ID = transaction.Transaction_ID', 'left');

				$this->db->where('transaction.Transaction_status',1);
				$this->db->where('member.Status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$this->db->group_by('t_det.Transaction_ID');
				// $this->db->where('t_det.Commision_type',1);
				// $this->db->where('t_det.Membership_ID',$value_member['Membership_ID']);
				// $this->db->where('t_det.Contract_ID',$value_member['Contract_ID']);
				// $this->db->where('member.Membership_ID',$value_member['Membership_ID']);
				// $this->db->group_by('t_det.Transaction_ID');
				$this->db->where('transaction.Transaction_date <=',date('Y-m-d',strtotime($Cal_date)));
				$query1 = $this->db->get();
				if ($query1->num_rows() > 0) {
					$transaction=$query1->result_array();
					 // var_dump($transaction);
					foreach($transaction as $tran){
						//echo $tran['Payment_status_date'];
						$pay_date=$tran['Payment_status_date'];
						$this->db->select('*');
						$this->db->from('gc_payout_setting');
						$query = $this->db->get();
						if ($query->num_rows() > 0) {
					$set_day=$query->result_array();
					$setting_day=$set_day[0]['Schedule_day'];

				}else{
					$setting_day=0;
				}
				//echo $pay_date;
				$cms_start=$this->get_advance_date1($setting_day,date('Y-m-d',strtotime($pay_date)));
				//die();
				if($Cal_date > $cms_start){
					$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);

					$cl_dt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $tran['Membership_ID'],'Contract_ID' => $tran['Contract_ID']))->row()->Pay_date;
					$per_date=date('d',strtotime($cl_dt));
						$temp_date=date('Y-m',strtotime($cl_dt));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);


					$commision_data=array(
							'Company_id'       => $this->session->userdata('CompanyId'),
							'Branch_id'        => $this->session->userdata('CompanyId'),
							'Transaction_ID'   => $tran['Transaction_ID'],
							'Membership_ID'    => $tran['Membership_ID'], 
							'Contract_ID'      => $tran['Contract_ID'], 
							'Transaction_type' => '',
							'Commision_date'   => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'      => date('Y-m-d',strtotime($payout_date)), 
							'Remarks'          => '',
							'Created_by'       => $this->session->userdata('UserId')
							);
					
				

					$this->db->insert('gc_daily_member_commission',$commision_data);
					$commision_id=$this->db->insert_id();
					// $commision_id=1;

					// Get Transaction detail Table
					$this->db->select('tran_det.*,gc_lvl.Payout_type');
					$this->db->from('gc_transaction_details as tran_det');
					$this->db->join('gc_membership as member', 'member.Membership_ID = tran_det.Membership_ID', 'left');
					$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = tran_det.Contract_ID', 'left');
					$this->db->join('gc_member_level_details as lvl_det', 'lvl_det.Member_level_detail_ID = tran_det.Member_level_detail_ID', 'left');
					$this->db->join('gc_level as gc_lvl', 'gc_lvl.ID = lvl_det.Level_ID', 'left');
					$this->db->where('tran_det.Status',1);
					$this->db->where('tran_det.Transaction_ID',$tran['Transaction_ID']);
					$this->db->where('member.Status',6);
					$this->db->where('contract.Withdrawn_status',5);
					$this->db->where('contract.Contract_status',6);
					// $this->db->where('tran_det.Commision_type',1);
					$query2 = $this->db->get();
					  if ($query2->num_rows() > 0) {

						$transaction_detail=$query2->result_array();
						// var_dump($transaction_detail);
						foreach($transaction_detail as $tran_det){
							if($tran_det['Member_level_detail_ID']!=''){
								$payout_member=$tran_det['Payout_type'];
							}else{
								$payout_member=$tran_det['Payout_ID'];
							}
							
							$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => $commision_id,
							'Transaction_ID'           => $tran_det['Transaction_ID'],
							'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
							'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
							'Membership_ID'            => $tran_det['Membership_ID'], 
							'Contract_ID'              => $tran_det['Contract_ID'], 
							'Commision_type'           => $tran_det['Commision_type'],
							'Payout_ID'                => $payout_member,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							
							'Amount'                   => $tran_det['Amount']/15, 
							'Commision'                => $tran_det['Commision']/15,
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId')
							);
							// var_dump($commision_detail_data);
							$this->db->insert('gc_daily_member_commission_details',$commision_detail_data);
// Topup Commission End

// Level Commission Start


// Level Commission End                            
}

}
}

}
}
}


public function calculate_daily_commission1($Cal_date){

	$Cal_date=date('Y-m-d',strtotime($Cal_date));
	$final_dates=[];
	$yrl_dates_0=[];

	$previous_trading=$this->get_previous_date1($Cal_date);

	//  Topup Commission Calculation Start 
				$this->db->select('member.Membership_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,member.Payout_ID');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				// $this->db->where('contract.Pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$this->db->where('contract.Contract_status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$query = $this->db->get();
				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members=$query->result_array();
					// var_dump($final_members);die();
					foreach ($final_members as $key => $value_member) {
						
					
					//echo ' insert';
					//echo 'insert';die();
				// Get Transaction Tabl
					$samparr=[];
				// $this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID');
				$this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID,member.Members_count');
				$this->db->from('gc_transaction as transaction');
				$this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');
				$this->db->join('gc_transaction_details as t_det', 't_det.Transaction_ID = transaction.Transaction_ID', 'left');

				$this->db->where('transaction.Transaction_status',1);
				$this->db->where('member.Status',6);
				$this->db->where('contract.Withdrawn_status',5);
				// $this->db->where('t_det.Commision_type',1);
				$this->db->where('t_det.Membership_ID',$value_member['Membership_ID']);
				$this->db->where('t_det.Contract_ID',$value_member['Contract_ID']);
				// $this->db->where('member.Membership_ID',$value_member['Membership_ID']);
				$this->db->group_by('t_det.Transaction_ID');
				$this->db->where('transaction.Transaction_date <=',date('Y-m-d',strtotime($Cal_date)));
				$query1 = $this->db->get();
				if ($query1->num_rows() > 0) {
					$transaction=$query1->result_array();
					 // var_dump($transaction);
					foreach($transaction as $tran){
						//echo $tran['Payment_status_date'];
						$pay_date=$tran['Payment_status_date'];
						$this->db->select('*');
						$this->db->from('gc_payout_setting');
						$query = $this->db->get();
						if ($query->num_rows() > 0) {
					$set_day=$query->result_array();
					$setting_day=$set_day[0]['Schedule_day'];

				}else{
					$setting_day=0;
				}
				//echo $pay_date;
				$cms_start=$this->get_advance_date1($setting_day,date('Y-m-d',strtotime($pay_date)));
				//die();
				if($Cal_date > $cms_start){
					$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);


					// $this->db->select('sum(contract.Amount) as Vol_am');
					// // $this->db->select('level.Child_ID');
					//  $this->db->from('gc_member_level_details as level');
					//  $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level.Child_ID', 'left');
					//  // $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
					//  $this->db->join('gc_membership as member', 'member.Membership_ID = level.Child_ID', 'left');
					//  $this->db->where('level.Membership_ID',$tran['Membership_ID']);
					//  $this->db->where('level.Level_ID',1);
					//  $this->db->where('member.Status',6);
					//  $this->db->where('contract.Withdrawn_status',5);
					//  // $this->db->where('contract.Contract_ID',$tran['Contract_ID']);
					//   $query_volume = $this->db->get();
					//   $Volume_amnt=$query_volume->result_array();
					//   // var_dump($Volume_amnt);
					//   if(!empty($Volume_amnt[0]['Vol_am'])){
					//     $vol_amt=$Volume_amnt[0]['Vol_am'];
					//   }else{
					//     $vol_amt=0;
					//   }
					//   $this->db->select('*');
					// $this->db->from('gc_commission_setting');
					// $this->db->where('Status',1);
					// $query_commission = $this->db->get();
					//   $commission_setting=$query_commission->result_array();

					//   // if($commission_setting[0]['Members_count']>=$tran['Members_count'] || $commission_setting[0]['Volume_amount']>=$vol_amt){
					//   if($vol_amt>=7500){
					  // if($commission_setting[0]['Volume_amount']>=$vol_amt){
						//echo 'eligible';
					  
					//echo "insert1"; die();

							// $array=['7','14','21','28'];
						$per_date=date('d',strtotime($Cal_date));
						$temp_date=date('Y-m',strtotime($Cal_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);


					$commision_data=array(
							'Company_id'       => $this->session->userdata('CompanyId'),
							'Branch_id'        => $this->session->userdata('CompanyId'),
							'Transaction_ID'   => $tran['Transaction_ID'],
							'Membership_ID'    => $tran['Membership_ID'], 
							'Contract_ID'      => $tran['Contract_ID'], 
							'Transaction_type' => '',
							'Commision_date'   => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'      => date('Y-m-d',strtotime($payout_date)), 
							'Remarks'          => '',
							'Created_by'       => $this->session->userdata('UserId')
							);
					
				

					$this->db->insert('c_daily_member_commission',$commision_data);
					$commision_id=$this->db->insert_id();
					// $commision_id=1;

					// Get Transaction detail Table
					$this->db->select('tran_det.*,gc_lvl.Payout_type');
					$this->db->from('gc_transaction_details as tran_det');
					$this->db->join('gc_membership as member', 'member.Membership_ID = tran_det.Membership_ID', 'left');
					$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = tran_det.Contract_ID', 'left');
					$this->db->join('gc_member_level_details as lvl_det', 'lvl_det.Member_level_detail_ID = tran_det.Member_level_detail_ID', 'left');
					$this->db->join('gc_level as gc_lvl', 'gc_lvl.ID = lvl_det.Level_ID', 'left');
					$this->db->where('tran_det.Status',1);
					$this->db->where('tran_det.Transaction_ID',$tran['Transaction_ID']);
					$this->db->where('member.Status',6);
					$this->db->where('contract.Withdrawn_status',5);
					$this->db->where('contract.Contract_status',6);
					$this->db->where('tran_det.Commision_type',1);
					$query2 = $this->db->get();
					  if ($query2->num_rows() > 0) {

						$transaction_detail=$query2->result_array();
						// var_dump($transaction_detail);
						foreach($transaction_detail as $tran_det){
							if($tran_det['Member_level_detail_ID']!=''){
								$payout_member=$tran_det['Payout_type'];
							}else{
								$payout_member=$tran_det['Payout_ID'];
							}
							$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => $commision_id,
							'Transaction_ID'           => $tran_det['Transaction_ID'],
							'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
							'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
							'Membership_ID'            => $tran_det['Membership_ID'], 
							'Contract_ID'              => $tran_det['Contract_ID'], 
							'Commision_type'           => $tran_det['Commision_type'],
							'Payout_ID'                => $payout_member,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							
							'Amount'                   => $tran_det['Amount']/30, 
							'Commision'                => $tran_det['Commision']/30,
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId')
							);
							// var_dump($commision_detail_data);
							$this->db->insert('gc_daily_member_commission_details',$commision_detail_data);


				// $py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $value_member['Payout_ID']))->result_array();
		// if(!empty($py_qry)){
		//     $pay_flag=$py_qry[0]['Pay_flag'];
		//     $py_days=$py_qry[0]['Days']-1;
		// }else{
		//     $pay_flag=2;
		//     $py_days=15-1;
		// }
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days')));
	  // $Pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$py_days.' days'));
	  // $member_update_data['Pay_date']=date('Y-m-d',strtotime($Pay_date));

	  //   $this->db->where('Membership_ID',$value_member['Membership_ID']);
	  //   $this->db->where('Contract_ID',$value_member['Contract_ID']);
	  //   $this->db->update('gc_member_franchisee_contract',$member_update_data);

						}
						 //print_r($commision_detail_data);die();

					  }

					//} // Memberscount or Volume if End

				  }
			}

		  } //else End
					} // Members Foreach End
				 } // Membership Count if end

//  Topup Commission Calculation End 


//  Level Commission Calculation End 
$this->db->select('member.Membership_ID,member.Reference_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,contract.Lvl_pay_date,member.Payout_ID,contract.Amount,contract.Payout_date');
				$this->db->from('gc_membership as member');
				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
				// $this->db->where('contract.Lvl_pay_date',date('Y-m-d',strtotime($Cal_date)));
				$this->db->where('member.Status',6);
				$this->db->where('contract.Contract_status',6);
				$this->db->where('contract.Withdrawn_status',5);
				$query = $this->db->get();

				if ($query->num_rows() > 0) { // Memberhsip Count if start
					$final_members1=$query->result_array();
					foreach ($final_members1 as $key => $value_member1) {

		// if($value_member1[0]['Commission_mode']==1){ // Level Commission OR Self Commission is Start            	
		$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Payout_date');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$value_member1['Reference_ID']);
			$this->db->where('member.Commission_mode',1);
			$this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_status',6);
			$this->db->where('contract.Withdrawn_status',5);
			//$this->db->where('contract.Contract_status',6);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
				 
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){
			$crnt_lvl=$binary[0]['Current_level'];
			//if($crnt_lvl<=$i){
			$level['Level_ID']=$i;
			//}
			//else{
			   //$level['Level_ID']=$crnt_lvl;
			//}
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID = level.Level_ID', 'left');

			$this->db->where('level.Child_ID',$value_member1['Membership_ID']);
			$this->db->where('level.Membership_ID',$value_member1['Reference_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();


			$Comission_amount1=$value_member1['Amount']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}
			else{
				$payout_id1=1;
				// if($level_details[0]['Payout_status']==2){
				// $payout_id1=$level_details[0]['New_payout_ID'];
				// }else{
				// $payout_id1=$level_details[0]['Old_payout_ID'];
				//         }
					}
// Commission Details Insert start 
					$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);
						
						if($Cal_date<=date('Y-m-d',strtotime($binary[0]['Payout_date']))){
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Payout_date']));
					}else{
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Pay_date']));
					}

						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);

					$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => '',
							'Transaction_ID'           => '',
							'Transaction_detail_ID'    => '',
							'Member_level_detail_ID'   => $level_details[0]['Member_level_detail_ID'],
							'Membership_ID'            => $binary[0]['Membership_ID'], 
							'Contract_ID'              => $binary[0]['Contract_ID'], 
							'Commision_type'           => 2,
							'Payout_ID'                => $payout_id1,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							'Amount'                   => $Comission_amount1/30, 
							'Commision'                => $level_details[0]['Return']/30,
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId')
							);
							$this->db->insert('gc_daily_member_commission_details',$commision_detail_data);

							// $lvl_py_days=15-1;
						// 	// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
						// 	$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
						// 	$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
						// 	$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							// $this->db->where('Contract_ID',$value_member1['Contract_ID']);
							// $this->db->update('gc_member_franchisee_contract',$member_update_data1);



// Commisssion Details Insert start

			}
		}
	}
	else{

			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Payout_date');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$this->db->where('member.Commission_mode',1);
			$this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_status',6);
			$this->db->where('contract.Withdrawn_status',5);


			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){

			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
		   //  if($crnt_lvl<=$i){
			
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();
						$Comission_amount1=$level_details[0]['Value']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
				$payout_id1=1;
						// if($level_details[0]['Payout_status']==2){
						// $payout_id1=$level_details[0]['New_payout_ID'];
						// }else{
						// $payout_id1=$level_details[0]['Old_payout_ID'];
						// $payout_id1=$level_payout[0]['Payout_type'];
						// }
					}
// Commission Details Insert start 
$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);
						
						if($Cal_date<=date('Y-m-d',strtotime($binary[0]['Payout_date']))){
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Payout_date']));
					}else{
						$ref_payout_date=date('Y-m-d',strtotime($binary[0]['Pay_date']));
					}

						$per_date=date('d',strtotime($ref_payout_date));
						$temp_date=date('Y-m',strtotime($ref_payout_date));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							$payout_date=$this->fet_exact_payout_date($final_payout_date);
$commision_detail_data=array(
							'Company_id'               => $this->session->userdata('CompanyId'),
							'Branch_id'                => $this->session->userdata('CompanyId'),
							'Commission_ID'            => '',
							'Transaction_ID'           => '',
							'Transaction_detail_ID'    => '',
							'Member_level_detail_ID'   => $level_details[0]['Member_level_detail_ID'],
							'Membership_ID'            => $binary[0]['Membership_ID'], 
							'Contract_ID'              => $binary[0]['Contract_ID'], 
							'Commision_type'           => 3,
							'Payout_ID'                => $payout_id1,
							'Commision_date'           => date('Y-m-d',strtotime($Cal_date)), 
							'Payout_date'              => date('Y-m-d',strtotime($payout_date)), 
							'Amount'                   => $Comission_amount1/30, 
							'Commision'                => $level_details[0]['Return']/30,
							'Remarks'                  => '', 
							'Created_by'               => $this->session->userdata('UserId')
							);
							$this->db->insert('gc_daily_member_commission_details',$commision_detail_data);
// Commission Details Insert start

							// $lvl_py_days=15-1;
						// 	// $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days')));
						// 	$Lvl_pay_date=date('Y-m-d', strtotime($Cal_date. ' + '.$lvl_py_days.' days'));
						// 	$member_update_data1['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
						// 	$this->db->where('Membership_ID',$value_member1['Membership_ID']);
							// $this->db->where('Contract_ID',$value_member1['Contract_ID']);
							// $this->db->update('gc_member_franchisee_contract',$member_update_data1);

	  
					}
				}

			}
		}
	// }
					}

				}





}

public function get_three_yrs_holidays($year,$week_days){

//$week_days=['6','7'];
			//var_dump($week_days);
$date=new DateTime();
//$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

	if($week_days[$i] == $search){
		$arr[$i] = $week_days[$i];
		$search = $week_days[$i] + 1;
	}else{
		$arr2[$i] = $week_days[$i];
	}
}

$action = array_merge($arr,$arr2);
$days = array(
	 '1' => 'Monday',
	 '2' => 'Tuesday',
	 '3' => 'Wednesday',
	 '4' => 'Thursday',
	 '5' => 'Friday',
	 '6' => 'Saturday',
	 '7' => 'Sunday'
 );
$final_dt=[];
//var_dump($action);
foreach($action as $da){
if (array_key_exists($da,$days))
  {
	//$sim=array('N' => $days[$da], 'A' => $da);
  array_push($final_dt,$days[$da]);
  }

}
//var_dump($final_dt);

$final_dates=[];
for($i=1; $i<=52; $i++){
		foreach($final_dt as $newval){
		//date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
		array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
		}
	}
	return $final_dates;
}

public function get_three_yrs_holidays1($year,$week_days,$mnt){

//$week_days=['6','7'];
			//var_dump($week_days);
$date=new DateTime();
//$year=date('Y');
$date->setDate($year, $mnt, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

	if($week_days[$i] == $search){
		$arr[$i] = $week_days[$i];
		$search = $week_days[$i] + 1;
	}else{
		$arr2[$i] = $week_days[$i];
	}
}

$action = array_merge($arr,$arr2);
$days = array(
	 '1' => 'Monday',
	 '2' => 'Tuesday',
	 '3' => 'Wednesday',
	 '4' => 'Thursday',
	 '5' => 'Friday',
	 '6' => 'Saturday',
	 '7' => 'Sunday'
 );
$final_dt=[];
//var_dump($action);
foreach($action as $da){
if (array_key_exists($da,$days))
  {
	//$sim=array('N' => $days[$da], 'A' => $da);
  array_push($final_dt,$days[$da]);
  }

}
//var_dump($final_dt);

$final_dates=[];
for($i=1; $i<=52; $i++){
		foreach($final_dt as $newval){
		//date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
		array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
		}
	}
	return $final_dates;
}
public function get_advance_date($ad_days,$cur_date){

	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);
			//var_dump($week_days);
$date=new DateTime();
$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

	if($week_days[$i] == $search){
		$arr[$i] = $week_days[$i];
		$search = $week_days[$i] + 1;
	}else{
		$arr2[$i] = $week_days[$i];
	}
}

$action = array_merge($arr,$arr2);
$days = array(
	 '1' => 'Monday',
	 '2' => 'Tuesday',
	 '3' => 'Wednesday',
	 '4' => 'Thursday',
	 '5' => 'Friday',
	 '6' => 'Saturday',
	 '7' => 'Sunday'
 );
$final_dt=[];

foreach($action as $da){
if (array_key_exists($da,$days))
  {
  array_push($final_dt,$days[$da]);
  }

}

//var_dump($final_dt);
$final_dates=[];
for($i=1; $i<=52; $i++){
		foreach($final_dt as $newval){
		//date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
		array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
		}
	}
   $cur_date=date("Y-m-d", strtotime($cur_date));
	
	//var_dump($final_dates);
	foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
	$keyval= $key+$ad_days;
	if(isset($final_dates[$keyval])){
		return $final_dates[$keyval];
	}else{
		return date('Y-01-01');
	}
	
	break;
}else{
	$keyval=$key;
	$final_dates[$keyval];
}
	}
	//echo $serch_date=$final_dates[$keyval];
}

	}


public function fet_exact_payout_date($final_payout_date)
{
	$Cal_date=date('Y-m-d',strtotime($final_payout_date));
$final_dates=[];
$yrl_dates_0=[];
		$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);
			$final_days=[];
			$final_days1=[];


		$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
		

				$this->db->select('Date');
				$query = $this->db->get('gc_individual_calendar');
				if ($query->num_rows() > 0) {
					$db_leave=$query->result_array();
				}else{
					$db_leave=[];
				}

				$empt_leave=[];
				foreach($db_leave as $lv){
					array_push($empt_leave,$lv['Date']);

				}
				$final_dates=array_values(array_diff($final_dates,$empt_leave));
			if(in_array($Cal_date, $final_dates)){

				return $Cal_date;
			}else{
				return $this->get_next_pay_date($Cal_date);
			}
		}
}



	public function get_next_pay_date($cur_date){
$final_dates=[];
$yrl_dates_0=[];
	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);

			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
	
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

		 $this->db->select('Date');
				$query = $this->db->get('gc_individual_calendar');
				if ($query->num_rows() > 0) {
					$db_leave=$query->result_array();
				}else{
					$db_leave=[];
				}
				$empt_leave=[];
				foreach($db_leave as $lv){
					array_push($empt_leave,$lv['Date']);

				}
				
				//print_r($db_leave);die();
				$final_dates=array_values(array_diff($final_dates,$empt_leave));

	foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
	
	$keyval= $key;
	if(isset($final_dates[$keyval])){
		return $final_dates[$keyval];
	}
	
	break;
}else{
	$keyval=$key;
	$final_dates[$keyval];
}
	}
}

	}    

public function get_advance_date1($ad_days,$cur_date){
$final_dates=[];
$yrl_dates_0=[];
	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);

			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
	
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

		$this->db->select('Date');
				$query = $this->db->get('gc_individual_calendar');
				if ($query->num_rows() > 0) {
					$db_leave=$query->result_array();
				}else{
					$db_leave=[];
				}
				$empt_leave=[];
				foreach($db_leave as $lv){
					array_push($empt_leave,$lv['Date']);

				}
				
				//print_r($db_leave);die();
				$final_dates=array_values(array_diff($final_dates,$empt_leave));


	foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
	$keyval= $key+$ad_days;
	if(isset($final_dates[$keyval])){
		return $final_dates[$keyval];
	}else{
		return date('Y-01-01');
	}
	
	break;
}else{
	$keyval=$key;
	$final_dates[$keyval];
}
	}
}

	}

public function get_next_paydate($cur_date){
$final_dates=[];
$yrl_dates_0=[];
	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);

			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
	
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

		$this->db->select('Date');
				$query = $this->db->get('gc_individual_calendar');
				if ($query->num_rows() > 0) {
					$db_leave=$query->result_array();
				}else{
					$db_leave=[];
				}
				$empt_leave=[];
				foreach($db_leave as $lv){
					array_push($empt_leave,$lv['Date']);

				}
				
				//print_r($db_leave);die();
				$final_dates=array_values(array_diff($final_dates,$empt_leave));

	foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
	
	$keyval= $key;
	if(isset($final_dates[$keyval])){
		return $final_dates[$keyval];
	}else{
		return date('Y-01-01');
	}
	
	break;
}else{
	$keyval=$key;
	return $final_dates[$keyval];
}
	}
}

	}

	
public function getDays($y,$m,$d){ 
	$date = "$y-$m-01";
	$first_day = date('N',strtotime($date));
	$first_day = $d - $first_day + 1;
	$last_day =  date('t',strtotime($date));
	$days = array();
	for($i=$first_day; $i<=$last_day; $i=$i+7 ){
		$days[] = $y.'-'.$m.'-'.$i;
		//$days[] = implode(',',$days);
	}
	return $days;
}
	
public function getall_topups() {
		$this->db->select('*');
		$this->db->where('Status',1);
		$query = $this->db->get('gc_member_topup');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return 0;
	}

public function getall_payouts() {
		$this->db->select('*');
		$this->db->where('Status',1);
		$query = $this->db->get('gc_payout_type');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return 0;
	}


public function getall_payouts_franchasie() {
		$this->db->select('*');
		$this->db->where('Status',1);
		$this->db->where('Level_type_id',1);
		$query = $this->db->get('gc_payout_type');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return 0;
	}

public function update_bank_status($data,$Membership_ID) {
	$id=$data['Member_bank_ID'];
	unset($data['Member_bank_ID']);
		$this->db->where('Member_bank_ID',$id);
		$this->db->update('gc_member_banks',$data);
	   if($data['Status']==6){
		$data1['Status']=4;
		$data1['Bank_verify']=6;
		$this->db->where('Membership_ID',$Membership_ID);
		if($this->db->update('gc_membership',$data1)){
			return 1;
		}else{
			return 0;
		}
	}
		
	}

public function update_document_status($data,$Membership_ID) {
	$id=$data['Document_ID'];
	unset($data['Document_ID']);
		$this->db->where('Document_ID',$id);
		$this->db->update('gc_member_documents',$data);
if($data['Status']==6){
$data1['Status']=4;
$data1['Doc_verify']=6;
		$this->db->where('Membership_ID',$Membership_ID);
		if($this->db->update('gc_membership',$data1)){
			return 1;
			}else{
				return 0;
			}
}
		
	}

	
	public function block_member_contract($Membership_ID,$reason) {
		$data['Status']=8;
		$data['Blocking_reason']=$reason;
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->update('gc_membership',$data);

		$data1['Contract_status_date']=date('Y-m-d');
		$data1['Contract_status']=8;
		$this->db->where('Membership_ID',$Membership_ID);
		if($this->db->update('gc_member_franchisee_contract',$data1)){
			return 1;
		}else{
			return 0;
		}


	}


// public function Activate_member_contract2($Membership_ID,$Contract_ID,$Commission_mode,$cmsn_per,$Memberhip_type,$Membership_payout) {
public function Activate_member_contract2($Membership_ID,$Contract_ID) {
// echo '1';die();
// echo $Membership_ID.'-membership_type===='.$Memberhip_type;die();

if(!empty($Contract_ID)){


// echo $Membership_ID.'-membership_type2===='.$Memberhip_type;die();

		$this->db->select('topup.Validity,topup.Value,topup.Return,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Multiples,contract.Amount');
		$this->db->from('gc_member_topup as topup');
		$this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');
		// $this->db->join('gc_membership as member', 'member.Payout_ID = topup.ID', 'left');

		$this->db->where('contract.Contract_ID',$Contract_ID);
		$this->db->where('contract.Membership_ID',$Membership_ID);
		$query = $this->db->get();
		$contract=$query->result_array();

		$tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();
		$contract=$this->db->get_where('gc_member_franchisee_contract',array('Contract_ID' => $Contract_ID,'Membership_ID' => $Membership_ID))->result_array();
// var_dump($contract);die();
		if(!empty($tp)){
			$month=$tp[0]['Validity'];
			// $Amount=$contract[0]['Value']*$contract[0]['Multiples'];
			
			$Return=$tp[0]['Return'];
			// $pay_flag=$contract[0]['Pay_flag'];

			// if($contract[0]['Payout_status']==2){
			//     $payout_id=$contract[0]['New_payout_ID'];
			// }else{
			//     $payout_id=$contract[0]['Old_payout_ID'];
			// }
		}else{
			$month=10;
			
			$Return=20;
			// $pay_flag=2;
		}

		if(!empty($contract)){
			$Amount=$contract[0]['Amount'];
		}else{
			$Amount=0;
		}


		$mem_qry = $this->db->select('Membership_ID,Payout_ID,Membership_type,Commission_per,Commission_mode')->get_where('gc_membership', array('Membership_ID' => $Membership_ID))->result_array();
		if(!empty($mem_qry[0]['Payout_ID'])){
			$payout_id=$mem_qry[0]['Payout_ID'];
		}else{
			$payout_id=$Membership_payout;
		}

		$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();
		if(!empty($py_qry)){
			$pay_flag=$py_qry[0]['Pay_flag'];
			$py_days=$py_qry[0]['Days']-1;
		}else{
			$pay_flag=2;
			$py_days=15-1;
		}

		if($mem_qry[0]['Commission_mode']==2){
			$tmp=$mem_qry[0]['Commission_per']/$pay_flag;
			$new_pay=($Return/$pay_flag)+$tmp;
		}else{
			$new_pay=($Return/$pay_flag);
		}


// Memberhsip Update end
		$data['Status']=6;
		$data['Commission_mode']=$mem_qry[0]['Commission_mode'];
		$data['Final_commission_per']=$new_pay;
		$data['Payout_ID']=$payout_id;
		
		if($mem_qry[0]['Commission_mode']==2){
		  $data['Commission_per']=$mem_qry[0]['Commission_per'];  
	  }else{
			$data['Commission_per']=0;
	  }
	  $cr_date=date('Y-m-d',strtotime($contract[0]['Date']));
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime($cr_date. ' + '.$py_days.' days')));
	  $Pay_date=date('Y-m-d', strtotime($cr_date. ' + '.$py_days.' days'));
	  $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  $lvl_py_days=15-1;
	  // $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($cr_date. ' + '.$lvl_py_days.' days')));
	  $Lvl_pay_date=date('Y-m-d', strtotime($cr_date. ' + '.$lvl_py_days.' days'));
	  $data['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
	  // if($pay_flag==1){
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }else{
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }
		
	  // var_dump($data);die();
		$data['Activated_date']=$contract[0]['Date'];
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->update('gc_membership',$data);


// Membership Update end 
// Transaction Insert Start        
		$transaction=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $Membership_ID, 
							'Contract_ID' => $Contract_ID, 
							'Transaction_type' => 1,
							'Transaction_date' => date('Y-m-d'), 
							'Remarks' => '', 
							'Created_by' => $this->session->userdata('UserId') 
						);
		$this->db->insert('gc_transaction',$transaction);
		$transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
		$Comission_amount=$Amount*$new_pay/100;
		$transaction_detail=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $Membership_ID, 
							'Contract_ID' => $Contract_ID,
							'Member_level_detail_ID' => NULL, 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 1, 
							'Payout_ID' => $payout_id,
							'Amount' => $Comission_amount, 
							'Commision' => $new_pay,
							'New_pay_percent' => $new_pay,
							'Remarks' => '' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail);
// Transaction Detail (Top-up) Insert End   

// Transaction History (Debit) Insert start 
$history_data=array(
				 'Company_id'               => $this->session->userdata('CompanyId'),
				 'Branch_id'                => $this->session->userdata('CompanyId'), 
				 'Membership_ID' => $Membership_ID,
				 'Contract_ID'   => $Contract_ID,
				 'Payout_ID' => $payout_id,
				 'Date'  => date('Y-m-d'),
				 'History_for'   => ' Topup Amount of  '.$Amount,
				 'Credit_amount' => 0,
				 'Debit_amount' => $Amount,
				  );
			$this->db->insert('gc_transaction_history',$history_data);  

// Transaction History (Debit) Insert End  

// Transaction Details (Direct&Push-up) Insert Start
		$this->db->select('Reference_ID');
		$this->db->from('gc_membership');
		$this->db->where('Membership_ID',$Membership_ID);
		$query = $this->db->get();
		$membership=$query->result_array();
// echo '1';die();
//if($mem_qry[0]['Commission_mode']==1){ // Level Commission OR Self Commission is Start 

	$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Amount');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$membership[0]['Reference_ID']);
			$this->db->where('member.Commission_mode',1);
			$this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_ID IS NOT NULL');
			//$this->db->where('contract.Contract_status',6);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
				 
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){
			$crnt_lvl=$binary[0]['Current_level'];
			//if($crnt_lvl<=$i){
			$level['Level_ID']=$i;
			//}
			//else{
			   //$level['Level_ID']=$crnt_lvl;
			//}
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID = level.Level_ID', 'left');

			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();

			if(!empty($level_details)){
			$Comission_amount1=$Amount*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}
			else{
				$payout_id1=1;
				// if($level_details[0]['Payout_status']==2){
				// $payout_id1=$level_details[0]['New_payout_ID'];
				// }else{
				// $payout_id1=$level_details[0]['Old_payout_ID'];
				//         }
					}
// Transaction Details Insert start 
$transaction_detail1=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $binary[0]['Membership_ID'], 
							'Contract_ID' => $binary[0]['Contract_ID'],
							'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 2,
							'Payout_ID' => $payout_id1, 
							'Amount' => $Comission_amount1, 
							'Commision' => $level_details[0]['Return'],
							'Remarks' => '' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
				}

			}
		}
	}
	else{
			$this->db->select('*');
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$this->db->where('member.Commission_mode',1);
			$this->db->where('member.Membership_type',1);
			$this->db->where('contract.Contract_ID IS NOT NULL');
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){

			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
		   //  if($crnt_lvl<=$i){
			
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Payout_ID,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();
			if(!empty($level_details)){
						$Comission_amount1=$level_details[0]['Value']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
				$payout_id1=1;
						// if($level_details[0]['Payout_status']==2){
						// $payout_id1=$level_details[0]['New_payout_ID'];
						// }else{
						// $payout_id1=$level_details[0]['Old_payout_ID'];
						// $payout_id1=$level_payout[0]['Payout_type'];
						// }
					}
// Transaction Details Insert start 
$transaction_detail1=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $binary[0]['Membership_ID'], 
							'Contract_ID' => $binary[0]['Contract_ID'],
							'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 3,
							'Payout_ID' => $payout_id1, 
							'Amount' => $Comission_amount1, 
							'Commision' => $level_details[0]['Return'],
							'Remarks' => ''  
						);
		$this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
// Transaction Details (Direct&Push-up) Insert End   
							}     
					}
				}

			}
		}
//} // Level Commission OR Self Commission is End
		$user_data = array('status' => 1,'mail_status' => 1 );
		$this->db->where('user_id',$Membership_ID);
		$this->db->update('gc_users',$user_data);

		$payment_status=array('Payment_status' =>6);
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->where('Contract_ID',$Contract_ID);
		$this->db->update('gc_member_payments',$payment_status);

		$data1['Start_date']=date('Y-m-d',strtotime($contract[0]['Date']));

		$data1['End_date']=date('Y-m-d', strtotime($data1['Start_date']. ' + '.$month.' months'));
		$data1['Contract_status']=6;
		$data1['Commission_mode']=$mem_qry[0]['Commission_mode'];
		$data1['Final_commission_per']=$new_pay;
		$data1['Pay_date']=$Pay_date;
		$data1['Lvl_pay_date']=$Lvl_pay_date;
		$data1['Payout_date']=$this->get_excat_next_payout($Pay_date);
		if($mem_qry[0]['Commission_mode']==2){
		  $data1['Commission_per']=$mem_qry[0]['Commission_per'];  
	  }else{
			$data1['Commission_per']=0;
	  }
		$data1['Contract_status_date']=$data1['Start_date'];
		$data1['Payment_status_date']=$data1['Start_date'];
		$data1['Payment_status']=6;
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->where('Contract_ID',$Contract_ID);
		if($this->db->update('gc_member_franchisee_contract',$data1)){
			return 1;
		}else{
			return 0;
		}
	
}else{
	$mem_qry = $this->db->select('Membership_ID,Payout_ID,Membership_type,Commission_per,Commission_mode,Created_date')->get_where('gc_membership', array('Membership_ID' => $Membership_ID))->result_array();
// echo $Membership_ID.'-membership_type===='.$Memberhip_type;die();
	 if(!empty($mem_qry[0]['Payout_ID'])){
			$payout_id=$mem_qry[0]['Payout_ID'];
		}else{
			$payout_id=2;
		}

			$tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();
			if(!empty($tp)){
						$month=$tp[0]['Validity'];
			$Return=$tp[0]['Return'];
			}else{
				 $month=10;
						
				 $Return=20;
			}

		$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();
		if(!empty($py_qry)){
			$pay_flag=$py_qry[0]['Pay_flag'];
			$py_days=$py_qry[0]['Days']-1;
		}else{
			$pay_flag=2;
			$py_days=15-1;
		}

		if($mem_qry[0]['Commission_mode']==2){
			$new_pay=($Return+$mem_qry[0]['Commission_per'])/$pay_flag;
		}else{
			$new_pay=$Return/$pay_flag;
		}


// Memberhsip Update end
		$data['Status']=6;
		$data['Commission_mode']=$mem_qry[0]['Commission_mode'];
		$data['Final_commission_per']=$new_pay;
		$data['Payout_ID']=$payout_id;
		
		if($mem_qry[0]['Commission_mode']==2){
		  $data['Commission_per']=$mem_qry[0]['Commission_per'];  
	  }else{
			$data['Commission_per']=0;
	  }
	  $cr_date=date('Y-m-d',strtotime($mem_qry[0]['Created_date']));
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime($cr_date. ' + '.$py_days.' days')));
	  $Pay_date=date('Y-m-d', strtotime($cr_date. ' + '.$py_days.' days'));
	  $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  $lvl_py_days=15-1;
	  // $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($cr_date. ' + '.$lvl_py_days.' days')));
	  $Lvl_pay_date=date('Y-m-d', strtotime($cr_date. ' + '.$lvl_py_days.' days'));
	  $data['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
	  // if($pay_flag==1){
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }else{
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }
		
	  // var_dump($data);die();
	  // 
		$user_data = array('status' => 1 );
		$this->db->where('user_id',$Membership_ID);
		$this->db->update('gc_users',$user_data);

		$data['Activated_date']=date('Y-m-d',strtotime($mem_qry[0]['Created_date']));
		$data['End_date']=date('Y-m-d', strtotime($data['Activated_date']. ' + '.$month.' months'));
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->update('gc_membership',$data);

		return 1;



}



	
}

public function Activate_member_contract($Membership_ID,$Contract_ID,$Commission_mode,$cmsn_per,$Memberhip_type,$Membership_payout) {
// echo '1';die();
// echo $Membership_ID.'-membership_type===='.$Memberhip_type;die();


$mem_qry = $this->db->select('Membership_ID,Payout_ID,Membership_type,Created_date')->get_where('gc_membership', array('Membership_ID' => $Membership_ID))->result_array();
$reg_date=date('Y-m-d',strtotime($mem_qry[0]['Created_date']));
if ($Memberhip_type==2) {
// echo $Membership_ID.'-membership_type===='.$Memberhip_type;die();
	 if(!empty($mem_qry[0]['Payout_ID'])){
			$payout_id=$mem_qry[0]['Payout_ID'];
		}else{
			$payout_id=$Membership_payout;
		}

			$tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();
			if(!empty($tp)){
			$month=$tp[0]['Validity'];
			$Return=$tp[0]['Return'];
			}else{
				 $month=10;
						
				 $Return=20;
			}

		$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();
		if(!empty($py_qry)){
			$pay_flag=$py_qry[0]['Pay_flag'];
			$py_days=$py_qry[0]['Days']-1;
		}else{
			$pay_flag=2;
			$py_days=15-1;
		}

		if($Commission_mode==2){
			// $tmp=$cmsn_per/$pay_flag;
			$new_pay=($Return+$cmsn_per)/$pay_flag;
		}else{
			$new_pay=$Return/$pay_flag;
		}


// Memberhsip Update end
		$data['Status']=6;
		$data['Commission_mode']=$Commission_mode;
		$data['Final_commission_per']=$new_pay;
		$data['Payout_ID']=$payout_id;
		
		if($Commission_mode==2){
		  $data['Commission_per']=$cmsn_per;  
	  }else{
			$data['Commission_per']=0;
	  }
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  // $Pay_date=date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days'));
	  $Pay_date=date('Y-m-d', strtotime($reg_date. ' + '.$py_days.' days'));
	  $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  $lvl_py_days=15-1;
	  // $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$lvl_py_days.' days')));
	  // $Lvl_pay_date=date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$lvl_py_days.' days'));
	  $Lvl_pay_date=date('Y-m-d', strtotime($reg_date. ' + '.$lvl_py_days.' days'));
	  $data['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
	  // if($pay_flag==1){
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }else{
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }
		
	  // var_dump($data);die();
	  // 
		$user_data = array('status' => 1 );
		$this->db->where('user_id',$Membership_ID);
		$this->db->update('gc_users',$user_data);

		$data['Payment_verify']=6; 
		$data['Activated_date']=date('Y-m-d H:i:s');
		$data['End_date']=date('Y-m-d', strtotime('+'.$month.'months'));
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->update('gc_membership',$data);

		return 1;

}else {

// echo $Membership_ID.'-membership_type2===='.$Memberhip_type;die();

		// $this->db->select('topup.Validity,topup.Value,topup.Return,contract.Multiples,contract.Amount');
		// $this->db->from('gc_member_topup as topup');
		

		// $this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');
		// // $this->db->join('gc_membership as member', 'member.Payout_ID = topup.ID', 'left');

		// $this->db->where('contract.Contract_ID',$Contract_ID);
		// $this->db->where('contract.Membership_ID',$Membership_ID);
		// $query = $this->db->get();
		// $contract=$query->result_array();

		$tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();
		$contract=$this->db->get_where('gc_member_franchisee_contract',array('Contract_ID' => $Contract_ID,'Membership_ID' => $Membership_ID))->result_array();
// var_dump($contract);die();
		if(!empty($tp)){
			$month=$tp[0]['Validity'];
			// $Amount=$contract[0]['Value']*$contract[0]['Multiples'];
			
			$Return=$tp[0]['Return'];
			// $pay_flag=$contract[0]['Pay_flag'];

			// if($contract[0]['Payout_status']==2){
			//     $payout_id=$contract[0]['New_payout_ID'];
			// }else{
			//     $payout_id=$contract[0]['Old_payout_ID'];
			// }
		}else{
			$month=10;
			
			$Return=20;
			// $pay_flag=2;
		}

		if(!empty($contract)){
			$Amount=$contract[0]['Amount'];
		}else{
			$Amount=0;
		}


		$mem_qry = $this->db->select('Membership_ID,Payout_ID,Membership_type,Created_date')->get_where('gc_membership', array('Membership_ID' => $Membership_ID))->result_array();

		if(!empty($mem_qry[0]['Payout_ID'])){
			$payout_id=$mem_qry[0]['Payout_ID'];
			$reg_date=date('Y-m-d',strtotime($mem_qry[0]['Created_date']));
		}else{
			$payout_id=2;
			$reg_date=date('Y-m-d',strtotime($contract[0]['Date']));
		}

		$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();

		if(!empty($py_qry)){
			$pay_flag=$py_qry[0]['Pay_flag'];
			$py_days=$py_qry[0]['Days']-1;
		}else{
			$pay_flag=2;
			$py_days=15-1;
		}

		if($Commission_mode==2){
			// $tmp=$cmsn_per/$pay_flag;
			$new_pay=($Return+$cmsn_per)/$pay_flag;
		}else{
			$new_pay=$Return/$pay_flag;
		}


// Memberhsip Update end
		$data['Status']=6;
		$data['Commission_mode']=$Commission_mode;
		$data['Final_commission_per']=$new_pay;
		$data['Payout_ID']=$payout_id;
		$data['Payment_verify']=6;
		if($Commission_mode==2){
		  $data['Commission_per']=$cmsn_per;  
	  }else{
			$data['Commission_per']=0;
	  }
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  $Pay_date=date('Y-m-d', strtotime($reg_date. ' + '.$py_days.' days'));
	  $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  $lvl_py_days=15-1;
	  // $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($reg_date. ' + '.$lvl_py_days.' days')));
	  $Lvl_pay_date=date('Y-m-d', strtotime($reg_date. ' + '.$lvl_py_days.' days'));
	  $data['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));

	  $next_exact_payout=$this->get_excat_next_payout($Pay_date);
	  // if($pay_flag==1){
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }else{
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }
		
	  // var_dump($data);die();
		$data['Activated_date']=$reg_date;
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->update('gc_membership',$data);


// Membership Update end 
// Transaction Insert Start        
		$transaction=array(
							'Company_id'       => $this->session->userdata('CompanyId'),
							'Branch_id'        => $this->session->userdata('CompanyId'), 
							'Membership_ID'    => $Membership_ID, 
							'Contract_ID'      => $Contract_ID, 
							'Transaction_type' => 1,
							'Transaction_date' => date('Y-m-d'), 
							'Remarks'          => '', 
							'Created_by'       => $this->session->userdata('UserId') 
						);
		$this->db->insert('gc_transaction',$transaction);
		$transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
		$Comission_amount=$Amount*$Return/100;
		$transaction_detail=array(
							'Company_id'             => $this->session->userdata('CompanyId'),
							'Branch_id'              => $this->session->userdata('CompanyId'), 
							'Membership_ID'          => $Membership_ID, 
							'Contract_ID'            => $Contract_ID,
							'Member_level_detail_ID' => NULL, 
							'Transaction_ID'         => $transaction_id, 
							'Commision_type'         => 1, 
							'Payout_ID'              => $payout_id,
							'Amount'                 => $Comission_amount, 
							'Commision'              => $new_pay,
							'New_pay_percent'        => $new_pay,
							'Remarks'                => '' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail);
// Transaction Detail (Top-up) Insert End   

// Transaction History (Debit) Insert start 
$history_data=array(
				 'Company_id'               => $this->session->userdata('CompanyId'),
				 'Branch_id'                => $this->session->userdata('CompanyId'), 
				 'Membership_ID'            => $Membership_ID,
				 'Contract_ID'              => $Contract_ID,
				 'Payout_ID'                => $payout_id,
				 'Date'                     => $reg_date,
				 'History_for'              => ' Topup Amount of  '.$Amount,
				 'Credit_amount'            => 0,
				 'Debit_amount'             => $Amount,
				  );
			$this->db->insert('gc_transaction_history',$history_data);  

// Transaction History (Debit) Insert End  

// Transaction Details (Direct&Push-up) Insert Start
		$this->db->select('Reference_ID');
		$this->db->from('gc_membership');
		$this->db->where('Membership_ID',$Membership_ID);
		$query = $this->db->get();
		$membership=$query->result_array();
// echo '1';die();
if($Commission_mode==1){ // Level Commission OR Self Commission is Start 

	$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$membership[0]['Reference_ID']);
			$this->db->where('member.Commission_mode',1);
			$this->db->where('member.Membership_type',1);
			//$this->db->where('contract.Contract_status',6);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
				 
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){
			$crnt_lvl=$binary[0]['Current_level'];
			//if($crnt_lvl<=$i){
			$level['Level_ID']=$i;
			//}
			//else{
			   //$level['Level_ID']=$crnt_lvl;
			//}
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID = level.Level_ID', 'left');

			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();


			$Comission_amount1=$Amount*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}
			else{
				$payout_id1=1;
				// if($level_details[0]['Payout_status']==2){
				// $payout_id1=$level_details[0]['New_payout_ID'];
				// }else{
				// $payout_id1=$level_details[0]['Old_payout_ID'];
				//         }
					}
// Transaction Details Insert start 
$transaction_detail1=array(
							'Company_id'             => $this->session->userdata('CompanyId'),
							'Branch_id'              => $this->session->userdata('CompanyId'), 
							'Membership_ID'          => $binary[0]['Membership_ID'], 
							'Contract_ID'            => $binary[0]['Contract_ID'],
							'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
							'Transaction_ID'         => $transaction_id, 
							'Commision_type'         => 2,
							'Payout_ID'              => $payout_id1, 
							'Amount'                 => $Comission_amount1, 
							'Commision'              => $level_details[0]['Return'],
							'Remarks'                => '' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start

			}
		}
	}
	else{
			$this->db->select('*');
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$this->db->where('member.Commission_mode',1);
			$this->db->where('member.Membership_type',1);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){

			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
		   //  if($crnt_lvl<=$i){
			
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Payout_ID,contract.Amount as Value');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();
						$Comission_amount1=$level_details[0]['Value']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
				$payout_id1=1;
						// if($level_details[0]['Payout_status']==2){
						// $payout_id1=$level_details[0]['New_payout_ID'];
						// }else{
						// $payout_id1=$level_details[0]['Old_payout_ID'];
						// $payout_id1=$level_payout[0]['Payout_type'];
						// }
					}
// Transaction Details Insert start 
$transaction_detail1=array(
							'Company_id'             => $this->session->userdata('CompanyId'),
							'Branch_id'              => $this->session->userdata('CompanyId'), 
							'Membership_ID'          => $binary[0]['Membership_ID'], 
							'Contract_ID'            => $binary[0]['Contract_ID'],
							'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
							'Transaction_ID'         => $transaction_id, 
							'Commision_type'         => 3,
							'Payout_ID'              => $payout_id1, 
							'Amount'                 => $Comission_amount1, 
							'Commision'              => $level_details[0]['Return'],
							'Remarks'                => ''  
						);
		$this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
// Transaction Details (Direct&Push-up) Insert End        
					}
				}

			}
		}
} // Level Commission OR Self Commission is End
else{
		// Transaction Insert Start        
		$transaction_non_level=array(
							'Company_id'       => $this->session->userdata('CompanyId'),
							'Branch_id'        => $this->session->userdata('CompanyId'), 
							'Membership_ID'    => $Membership_ID, 
							'Contract_ID'      => $Contract_ID, 
							'Transaction_type' => 1,
							'Transaction_date' => date('Y-m-d'), 
							'Remarks'          => '', 
							'Created_by'       => $this->session->userdata('UserId') 
						);
		$this->db->insert('gc_transaction',$transaction_non_level);
		$transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
		$Comission_amount=$Amount*$Return/100;
		$transaction_detail_non_level=array(
							'Company_id'             => $this->session->userdata('CompanyId'),
							'Branch_id'              => $this->session->userdata('CompanyId'), 
							'Membership_ID'          => $Membership_ID, 
							'Contract_ID'            => $Contract_ID,
							'Member_level_detail_ID' => NULL, 
							'Transaction_ID'         => $transaction_id, 
							'Commision_type'         => 1, 
							'Payout_ID'              => $payout_id,
							'Amount'                 => $Comission_amount, 
							'Commision'              => $Return,
							'New_pay_percent'        => $new_pay,
							'Remarks'                => 'Not Level Commission' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail_non_level);
// Transaction Detail (Top-up) Insert End   
}
		$user_data = array('status' => 1,'mail_status' => 1 );
		$this->db->where('user_id',$Membership_ID);
		$this->db->update('gc_users',$user_data);

		$data1['Start_date']          =$reg_date;
		// $data1['End_date']            =date('Y-m-d', strtotime('+'.$month.'months'));
		$data1['End_date']=date('Y-m-d', strtotime($reg_date. ' + '.$month.' months'));
		$data1['Contract_status']     =6;
		$data1['Commission_mode']     =$Commission_mode;
		$data1['Final_commission_per']=$new_pay;
		$data1['Pay_date']            =$Pay_date;
		$data1['Lvl_pay_date']        =$Lvl_pay_date;
		$next_exact_payout            =$this->get_excat_next_payout($Pay_date);
		$data1['Payout_date']         =$next_exact_payout;
		if($Commission_mode==2){
		  $data1['Commission_per']    =$cmsn_per;  
	  }else{
			$data1['Commission_per']  =0;
	  }
		$data1['Contract_status_date']=$reg_date;
		$data1['Payment_status_date']=$reg_date;
		$data1['Payment_status']=6;
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->where('Contract_ID',$Contract_ID);
		if($this->db->update('gc_member_franchisee_contract',$data1)){
			return 1;
		}else{
			return 0;
		}
	}
	
}

public function get_excat_next_payout($cl_dt){
	//$cl_dt='2019-05-08';
	$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
					if(!empty($com_pay_date)){
						$commission_pay_date=$com_pay_date[0]['Pay_dates'];
					}else{
						$commission_pay_date='7,14,21,28';
					}
					$commission_pay_date=explode(',',$commission_pay_date);

						//$cl_dt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $tran['Membership_ID'],'Contract_ID' => $tran['Contract_ID']))->row()->Pay_date;
					$per_date=date('d',strtotime($cl_dt));
						$temp_date=date('Y-m',strtotime($cl_dt));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							return $payout_date=$this->fet_exact_payout_date($final_payout_date);
}

public function Activate_member_contract1($Membership_ID,$Contract_ID) {
		$data['Status']=6;
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->update('gc_membership',$data);

		$this->db->select('topup.Validity,Value,Return,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Date');
		$this->db->from('gc_member_topup as topup');
		$this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');
		$this->db->where('contract.Contract_ID',$Contract_ID);
		$this->db->where('contract.Membership_ID',$Membership_ID);
		$query = $this->db->get();
		$contract=$query->result_array();
		if(!empty($contract)){
			$month=$contract[0]['Validity'];
			$Amount=$contract[0]['Value'];
			$Return=$contract[0]['Return'];
			if($contract[0]['Payout_status']==2){
				$payout_id=$contract[0]['New_payout_ID'];
			}else{
				$payout_id=$contract[0]['Old_payout_ID'];
			}
		}else{
			$month=0;
			$Amount=0;
			$Return=0;
		}
// Transaction Insert Start        
		$transaction=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $Membership_ID, 
							'Contract_ID' => $Contract_ID, 
							'Transaction_type' => 1,
							'Transaction_date' => $contract[0]['Date'], 
							'Remarks' => '', 
							'Created_by' => $this->session->userdata('UserId') 
						);
		$this->db->insert('gc_transaction',$transaction);
		$transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
		$Comission_amount=$Amount*$Return/100;
		$transaction_detail=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $Membership_ID, 
							'Contract_ID' => $Contract_ID,
							'Member_level_detail_ID' => NULL, 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 1, 
							'Payout_ID' => $payout_id,
							'Amount' => $Comission_amount, 
							'Commision' => $Return,
							'Remarks' => '' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail);
// Transaction Detail (Top-up) Insert End   

// Transaction History (Debit) Insert start 
$history_data=array(
				 'Company_id'               => $this->session->userdata('CompanyId'),
				 'Branch_id'                => $this->session->userdata('CompanyId'), 
				 'Membership_ID' => $Membership_ID,
				 'Contract_ID'   => $Contract_ID,
				 'Payout_ID' => $payout_id,
				 'Date'  => $contract[0]['Date'],
				 'History_for'   => ' Topup Amount of  '.$Amount,
				 'Credit_amount' => 0,
				 'Debit_amount' => $Amount,
				  );
			$this->db->insert('gc_transaction_history',$history_data);  

// Transaction History (Debit) Insert End  

// Transaction Details (Direct&Push-up) Insert Start
		$this->db->select('Reference_ID');
		$this->db->from('gc_membership');
		$this->db->where('Membership_ID',$Membership_ID);
		$query = $this->db->get();
		$membership=$query->result_array();


$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$membership[0]['Reference_ID']);
			//$this->db->where('contract.Contract_status',6);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			$crnt_lvl=$binary[0]['Current_level'];
			//if($crnt_lvl<=$i){
			$level['Level_ID']=$i;
			//}
			//else{
			   //$level['Level_ID']=$crnt_lvl;
			//}
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			$this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();


						$Comission_amount1=$Amount*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
				if($level_details[0]['Payout_status']==2){
				$payout_id1=$level_details[0]['New_payout_ID'];
				}else{
				$payout_id1=$level_details[0]['Old_payout_ID'];
						}
					}
// Transaction Details Insert start 
$transaction_detail1=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $binary[0]['Membership_ID'], 
							'Contract_ID' => $binary[0]['Contract_ID'],
							'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 2,
							'Payout_ID' => $payout_id1, 
							'Amount' => $Comission_amount1, 
							'Commision' => $level_details[0]['Return'],
							'Remarks' => '' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start


		}
	}
	else{
			$this->db->select('*');
			$this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
		   //  if($crnt_lvl<=$i){
			
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			$this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();
						$Comission_amount1=$level_details[0]['Value']*($level_details[0]['Return']/2)/100;
						$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
						if($level_details[0]['Payout_status']==2){
						$payout_id1=$level_details[0]['New_payout_ID'];
						}else{
						$payout_id1=$level_details[0]['Old_payout_ID'];
						}
					}
// Transaction Details Insert start 
$transaction_detail1=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $binary[0]['Membership_ID'], 
							'Contract_ID' => $binary[0]['Contract_ID'],
							'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 3,
							'Payout_ID' => $payout_id1, 
							'Amount' => $Comission_amount1, 
							'Commision' => $level_details[0]['Return'],
							'Remarks' => ''  
						);
		$this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
// Transaction Details (Direct&Push-up) Insert End        

				}

			}
		}

		$data1['Start_date']=$contract[0]['Date'];
		$data1['End_date']=date('Y-m-d', strtotime('+'.$month.'months', strtotime($contract[0]['Date'])));
		// $data1['End_date'] = date('Y-m-d', strtotime("+3 months", strtotime($effectiveDate)));
		$data1['Contract_status']=6;
		$data1['Contract_status_date']=$contract[0]['Date'];
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->where('Contract_ID',$Contract_ID);
		if($this->db->update('gc_member_franchisee_contract',$data1)){
			return 1;
		}else{
			return 0;
		}
	}

	
	
function get_referer_by_id($referer) {

		$this->db->select('Membership_ID,First_name,Last_name,Membership_code');
		$this->db->where('Membership_ID',$referer);
		$query = $this->db->get('gc_membership');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

function get_referer_by_code($referer) {

		$this->db->select('Membership_ID,First_name,Last_name,Membership_code,Wallet_balance,Status');
		$this->db->where('Status!=',7);
		$this->db->where('Status!=',8);
		$where = '(Membership_code="'.$referer.'" or Mobile = "'.$referer.'")';
		$this->db->where($where);
		$query = $this->db->get('gc_membership');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return 0;
	}

function get_payments_details($pay_type) {

		$this->db->select('ID');
		$this->db->where("Payment_mode LIKE '%$pay_type%'");
		$query = $this->db->get('gc_payment_mode');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}    

function get_cntrct_details($topup) {   

		$this->db->select('ID,Value,Payout_type');
		$this->db->where('Value',$topup);
		$query = $this->db->get('gc_member_topup');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}    
	

	

function mobile_verify($mobile) {

		$this->db->select('Membership_ID,First_name,Last_name,Membership_code,Status');
		$this->db->where('Mobile',$mobile);
		$query = $this->db->get('gc_membership');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}
	

function get_topup_details($topup) {

		$this->db->select('ID,Value,Validity,Payout_type,Return');
		$this->db->where('ID',$topup);
		$this->db->where('Status',1);
		$query = $this->db->get('gc_member_topup');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return 0;
	}

	function getall_membershiptype() {

		$this->db->select('*');
		$this->db->where('Status',1);
		$query = $this->db->get('gc_membershiptype');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return 0;
	}

	function getall_invest_type() {

		$this->db->select('*');
		$this->db->where('Status',1);
		$this->db->where('Level_type_id',1);
		$query = $this->db->get('gc_invest_type');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return 0;
	}   

	function get_all_topup_list_by_invest_type($id,$level_type) {

		$this->db->select('*');
		$this->db->where('Status',1);
		$this->db->where('Level_type_id',$level_type);
		$this->db->where('Invest_type_id',$id);
		$query = $this->db->get('gc_member_topup');
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}



function get_parent_detail($id) {

	$this->db->select('table.Membership_ID,table.First_name,table.Last_name,table.Membership_code,table.Reference_ID,table.Current_level,table.Photo,table.Members_count,table1.Member_color,table.Members_count,table.Created_date,table.Photo_path');
	$this->db->join('gc_tree_color_setting as table1', 'table1.Member_type = table.Membership_type', 'left');
	$this->db->where('table.Membership_ID',$id);
	$this->db->where('table1.Member_level',1);
	$query = $this->db->get('gc_membership as table');
	if ($query->num_rows() > 0) {   
		return  $query->result_array();
	}
	// return 0;
	}

	function get_parent_referer($id) {

	$this->db->select('table.Membership_code');
	$this->db->where('table.Membership_ID',$id);
	$query = $this->db->get('gc_membership as table');
	if ($query->num_rows() > 0) {   
		return  $query->result_array();
	}
	// return 0;
	}

	

function get_child_by_parent($id) { 

		 $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Membership_code,member.Current_level,tree.Child_ID,table1.Member_color,member.Photo,member.Photo_path,member.Members_count,member.Created_date,tree.Parent_ID');
		 $this->db->select('members.First_name as parentfname,members.Membership_code as parentmemcode');
		 $this->db->from('gc_franchisee_member_relation as tree');
		 $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
		 $this->db->join('gc_membership as members', 'members.Membership_ID = tree.Parent_ID', 'left');
		 $this->db->join('gc_tree_color_setting as table1', 'table1.Member_type = member.Membership_type', 'left');
		 // $this->db->join('gc_member_franchisee_contract as table2', 'table2.Membership_ID = member.Membership_ID', 'left');
		 // $this->db->join('gc_member_topup as table3', 'table3.ID = table2.Topup_id', 'left');

		// $this->db->where('table1.Member_level',1);
		// $this->db->where('table2.Invest_type',1);
		$this->db->where('tree.Parent_ID',$id);
		$this->db->group_by('member.Membership_ID');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		// return 0;
	}

function get_child_by_parent_contract($id) { 

		 $this->db->select('sum(table3.Value) as contract');
		 $this->db->from('gc_franchisee_member_relation as tree');
		 $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
		 $this->db->join('gc_membership as members', 'members.Membership_ID = tree.Parent_ID', 'left');
		 $this->db->join('gc_member_franchisee_contract as table2', 'table2.Membership_ID = member.Membership_ID', 'left');
		 $this->db->join('gc_member_topup as table3', 'table3.ID = table2.Topup_id', 'left');
		$this->db->where('table2.Invest_type',2);
		$this->db->where('tree.Parent_ID',$id);
		// $this->db->group_by('table2.Membership_ID');
		// $this->db->group_by('table3.Value');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		// return 0;
	}

function get_child_by_parent_binary($id) { 

		 $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Membership_code,member.Current_level,tree.Child_ID,table1.Member_color,member.Photo,member.Members_count,member.Created_date');
		 $this->db->from('gc_binary_member_relation as tree');
		 $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
		 $this->db->join('gc_tree_color_setting as table1', 'table1.Member_type = member.Membership_type', 'left');

		$this->db->where('table1.Member_level',1);
		$this->db->where('tree.Parent_ID',$id);
		$this->db->order_by('tree.Position_type');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		// return 0;
	}


function get_child_by_parent_binary1($id) {
		// var_dump($id);
		 $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Membership_code,member.Current_level,tree.Child_ID,table1.Member_color,member.Photo,member.Members_count');
		 $this->db->from('gc_binary_member_relation as tree');
		 $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
		 $this->db->join('gc_tree_color_setting as table1', 'table1.Member_type = member.Membership_type', 'left');
		 
		$this->db->where('table1.Member_level',1);
		$this->db->where('tree.Parent_ID',$id);
		$query = $this->db->get()->result_array();
		// var_dump($query);
		if (count($query) > 0) {
			return  $query;
		}
		return 0;
	}

function get_pincode_details($pincode){
$this->db->select('area.id as taluk_id,area.area_name as taluk_name,city.id as City_id,city.city_name as City_name,state.id as State_id,state.state_name as State_name,country.id as Country_id,country.country_name as Country_name');

		$this->db->from('gc_areas as area');
		$this->db->join('gc_cities as city', 'city.id = area.city_id', 'left');
		$this->db->join('gc_states as state', 'state.id = area.state_id', 'left');
		$this->db->join('gc_countries as country', 'country.id = area.country_id', 'left');
		$this->db->where("area.Pincode",$pincode);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();
		}
		return NULL;
	}    

function get_bank_details($bank){
		$this->db->select('ID');
		$this->db->from('gc_bank');
		$this->db->where("Bank_name",$bank);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();
		}
		return NULL;
	} 

 public function adding_excel_data1($excel_member){
		//var_dump($excel_member);
		// echo '1= '.$excel_member['Date'];echo "<br>";
		// echo '3= '.strtotime(str_replace('/', '-', $excel_member['Date']));echo "<br>";
		$Register_date=date('Y-m-d', strtotime(str_replace('/', '-', $excel_member['Reg_date'])));
if($excel_member['Invest_type']=='Initial' || $excel_member['Invest_type']=='initial'){
	$invest_type=1;
}else{
	$invest_type=2;
}
if($invest_type==1){
		$reference_id=$this->get_referer_by_code($excel_member['Referal_ID']);
		$reference_id=$reference_id[0]['Membership_ID']; // 

	   // $pan=$excel_member["Document_no_pan"];
	   //  if(!empty($pan)){
	   //  $newpan = substr($pan, -5);
	   //  }else{
	   //     $newpan=$this->generatePIN(5); 
	   //  }
	   //  $newmob = substr($excel_member['Mobile'], -5);
		$Membership_code=$excel_member['Mobile'];

	   
		
		if($excel_member['Gender']=='Male' || $excel_member['Gender']=='male'){
			$prefix=1;
		}else{
			$prefix=2;
		}
		if($excel_member['Payment_type_ID']=='CONVERSION'){
			$member_mode=2;
		}else{
			$member_mode=1;
		}
		$member=array(
			'First_name'      => $excel_member['First_name'],
			'Last_name'       => $excel_member['Last_name'],
			'F_f_name'        => $excel_member['F_f_name'],
			'F_l_name'        => $excel_member['F_l_name'],
			'Reference_ID'    => $reference_id,
			'Reference_code'  => $excel_member['Referal_ID'],
			'Prefix'          => $prefix,
			'F_prefix'        => $prefix,
			'Gender'          => $excel_member['Gender'],
			'Email'           => $excel_member['Email'],
			'Mobile'          => $excel_member['Mobile'],
			'Reg_date'        =>date('Y-m-d', strtotime(str_replace('/', '-', $excel_member['Reg_date']))),
			'DOB'             => $excel_member['DOB'],
			'Membership_mode' => $member_mode,
			'Register_from'   => 'Web',
		);

// var_dump($member);
		$pin=$this->get_pincode_details($excel_member['Pincode']);
		if(!empty($pin)){
			$area=$pin[0]['taluk_id'];
			$city=$pin[0]['City_id'];
			$state=$pin[0]['State_id'];
			$country=$pin[0]['Country_id'];
		}else{
			 $area=2;
			$city=1;
			$state=1;
			$country=101;
		}

		$address_data=array(
			 'Address_1'    => $excel_member['Address_1'],
			 'Address_type' => 1,
			'Address_2'     => $excel_member['Address_2'],
			'Landmark'      => $excel_member['Address_2'],
			'Pincode'       => $excel_member['Pincode'],
			'Area'          => $area,
			'City'          => $city,
			'State'         => $state,
			'Country'       => $country,
		);
// var_dump($address_data);

if($excel_member['Invest_type']=='Initial' || $excel_member['Invest_type']=='initial'){
	$invest_type=1;
}else{
	$invest_type=2;
}
if($invest_type==1){
		if (!is_dir('./attachments/Members/'.$Membership_code))
				  {
					  mkdir('./attachments/Members/'.$Membership_code, 0777, true);
				  }
				  $dir_exist = true; // flag for checking the directory exist or not
				  if (!is_dir('./attachments/Members/'.$Membership_code))
				  {
					  mkdir('./attachments/Members/'.$Membership_code, 0777, true);
					  $dir_exist = false; // dir not exist
				  }
				  if(!define('UPLOAD_DIR','./attachments/Members/'.$Membership_code.'/')){
					define('UPLOAD_DIR', './attachments/Members/'.$Membership_code.'/');
				  }

// $file =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Profiles/pan.jpg';
// $newfile =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Members/'.$Membership_code.'/'.$Membership_code.'_pan.jpg';
// copy($file, $newfile); 


$file1 =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Profiles/aadhar.jpg';
$newfile1 =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Members/'.$Membership_code.'/'.$Membership_code.'_aadhar.jpg';
copy($file1, $newfile1); 


// $file2 =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Profiles/cheque.jpg';
// $newfile2 =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Members/'.$Membership_code.'/'.$Membership_code.'_cheque.jpg';
// copy($file2, $newfile2); 
		$upload_data=[];
			$upload_data['upload_data_1']['Document_type']='Aadhar';
			$upload_data['upload_data_1']['Document_no']=$excel_member['Document_no_aadhar'];
			$upload_data['upload_data_1']['Document_name']=$Membership_code.'_aadhar.jpg';
			$upload_data['upload_data_1']['Folder_name']=$Membership_code;
		// for($i=1;$i<=3;$i++){
		//     if($i==1){
		//     $upload_data['upload_data_'.$i]['Document_type']='Pan';
		//     $upload_data['upload_data_'.$i]['Document_no']=$excel_member['Document_no_pan'];
		//     $upload_data['upload_data_'.$i]['Document_name']=$Membership_code.'_pan.jpg';
		//     $upload_data['upload_data_'.$i]['Folder_name']=$Membership_code;
		// }elseif($i==2){
		//     $upload_data['upload_data_'.$i]['Document_type']='Aadhar';
		//     $upload_data['upload_data_'.$i]['Document_no']=$excel_member['Document_no_aadhar'];
		//     $upload_data['upload_data_'.$i]['Document_name']=$Membership_code.'_aadhar.jpg';
		//     $upload_data['upload_data_'.$i]['Folder_name']=$Membership_code;
		// }else{
		//      $upload_data['upload_data_'.$i]['Document_type']='Cheque';
		//     $upload_data['upload_data_'.$i]['Document_no']=$excel_member['Document_no_cheque'];
		//     $upload_data['upload_data_'.$i]['Document_name']=$Membership_code.'_cheque.jpg';
		//     $upload_data['upload_data_'.$i]['Folder_name']=$Membership_code;
		// }
		// //var_dump($upload_data);
		// }
}


// var_dump($upload_data);
		// $nominee_data=array(
		//     'Nominee_name' => $excel_member['Nominee_name'],
		//      'Nominee_relationship' => $excel_member['Nominee_relationship'],
		//      'Nominee_mobile' => $excel_member['Nominee_mobile'],
		// );
// var_dump($nominee_data);


} // check topup Or Initial End

		$bank=$this->get_bank_details($excel_member['Bank_ID']);
		if(!empty($bank)){
			$bank_id=$bank[0]['ID'];
		}else{
			 $bank_id=2;
		}

	$bank_data=array(
						'Bank_ID'        => $bank_id,
						'Account_holder' => $excel_member['Account_holder'],
						'Account_no'     => $excel_member['Account_no'],
						'Branch'         => $excel_member['Branch'],
						'IFSC'           => $excel_member['IFSC']
					);

// var_dump($bank_data);
// echo $excel_member['Topup_id'];
// $peyment=$this->get_cntrct_details($excel_member['Topup_id']);
if($excel_member['Invest_type']=='Initial' || $excel_member['Invest_type']=='initial'){
	$invest_type=1;
}else{
	$invest_type=2;
}
// if(!empty($peyment)){
//             $Topup_id=$peyment[0]['ID'];
//             $value=$peyment[0]['Value'];
//             $Payout_type=$peyment[0]['Payout_type'];
//         }else{
//             $member_topup_data = array(
									
//                      'Company_id' =>$this->session->userdata('CompanyId'),
//                      'Branch_id' =>$this->session->userdata('CompanyId'),
//                       'Franchise' => $excel_member['Topup_id']."- Investment",
//                       'Alias_name' => $excel_member['Topup_id']."- L",
//                       'Level_type_id' => 1,  
//                       'Invest_type_id' => 1,  
//                       'Value' => $excel_member['Topup_id'],  
//                       'Validity' => 11,  
//                       'Payout_type' => 1,  
//                       'Return' => 0.5,  
//                       'Description' => $excel_member['Topup_id']."- Investment");
//                       $this->db->insert('gc_member_topup',$member_topup_data); 
//                       $Topup_id=$this->db->insert_id();
//                       //'Status' => $Status
					 
//              // $Topup_id=1;
//              $value=$excel_member['Topup_id'];
//              $Payout_type=1;
//         }

// if(!empty($excel_member['Payout_type'])){
// if($Payout_type==$excel_member['Payout_type']){
//     $old_payout=$Payout_type;
//     $new_payout=0;
//     $payout_status=1;
// }else{
//     $old_payout=$Payout_type;
//     $new_payout=$excel_member['Payout_type'];
//     $payout_status=2;
// }
// }else{
//     $old_payout=$Payout_type;
//     $new_payout=0;
//     $payout_status=1;
// }

// if($excel_member['Topup_id']!=0){
// if($excel_member['Payment_type_ID']=='CONVERSION'){	
// $amount=$excel_member['Topup_id']/70;
// $final_amount=round($amount/10)*10;	
// }else{
// $amount=$excel_member['Topup_id']/75;
// $final_amount=round($amount/10)*10;
// }
// }
// else{
// $final_amount=0;		
// }

if($excel_member['Topup_id']!=0){
	$final_amount=$excel_member['Topup_id'];

}else{
	$final_amount=0;
}



	$contract_data=array(
				'Membership_type'      => $excel_member['Membership_type'],
				'Topup_id'             => $excel_member['Topup'],
				'Amount'               => $final_amount,
				'Commission_mode'      => $excel_member['Commission_mode'],
				// 'Old_payout_ID'     => $Payout_type,
				'Payout_ID'            => $excel_member['Payout_type'],
				'Final_commission_per' => 20,
				'Date'                 => $Register_date,
				// 'New_payout_ID'     => $new_payout,
				'Payout_status'        => 1,
				'Invest_type'          => $invest_type

	);

// var_dump($contract_data);

 $peyment=$this->get_payments_details($excel_member['Payment_type_ID']);
if(!empty($peyment)){
			$Payment_type_ID=$peyment[0]['ID'];
		}else{
			 $Payment_type_ID=6;
		}

	$payment_data=array(
		'Payment_type_ID' => $Payment_type_ID,
		'Bank_ID'         => $bank_id,
		'Reference_no'    => $excel_member['Reference_no'],
		'Date'            => date('Y-m-d', strtotime(str_replace('/', '-', $excel_member['Date']))),
		'Amount'          => $final_amount,
		'Remarks'         => '');

// var_dump($payment_data);

	$agreement_data=array(
		'Delivery_mode' =>1);

if($invest_type==1){
	// var_dump($contract_data);
// die();
	$result=$this->adding_excel_membership_data1($member,$address_data,$bank_data,$upload_data,$contract_data,$payment_data,$agreement_data,$Membership_code);
}else{

	   $Membership_ID=$this->get_referer_by_code($excel_member['Mobile']);
	   $Membership_ID=$Membership_ID[0]['Membership_ID']; //
	   $contract_data['Membership_ID']=$Membership_ID;
	   // var_dump($contract_data);die();
	 $result=$this->add_membership_upgrade_by_excel($contract_data,$payment_data,$agreement_data,$Register_date);
}

		
	}   

	
	function adding_excel_data($excel_member){
		//var_dump($excel_member);
		// echo '1= '.$excel_member['Date'];echo "<br>";
		// echo '3= '.strtotime(str_replace('/', '-', $excel_member['Date']));echo "<br>";
		$Register_date=date('Y-m-d', strtotime(str_replace('/', '-', $excel_member['Reg_date'])));
if($excel_member['Invest_type']=='Initial' || $excel_member['Invest_type']=='initial'){
	$invest_type=1;
}else{
	$invest_type=2;
}
if($invest_type==1){
		$reference_id=$this->get_referer_by_code($excel_member['Referal_ID']);
		$reference_id=$reference_id[0]['Membership_ID']; // 

	   // $pan=$excel_member["Document_no_pan"];
	   //  if(!empty($pan)){
	   //  $newpan = substr($pan, -5);
	   //  }else{
	   //     $newpan=$this->generatePIN(5); 
	   //  }
	   //  $newmob = substr($excel_member['Mobile'], -5);
		$Membership_code=$excel_member['Mobile'];

	   
		
		if($excel_member['Gender']=='Male' || $excel_member['Gender']=='male'){
			$prefix=1;
		}else{
			$prefix=2;
		}
		$member=array(
			'First_name' => $excel_member['First_name'],
			'Last_name' => $excel_member['Last_name'],
			'F_f_name' => $excel_member['F_f_name'],
			'F_l_name' => $excel_member['F_l_name'],
			'Reference_ID' => $reference_id,
			'Prefix' => $prefix,
			'F_prefix' => $prefix,
			'Gender' => $excel_member['Gender'],
			'Email' => $excel_member['Email'],
			'Mobile' => $excel_member['Mobile'],
			'Reg_date' =>date('Y-m-d', strtotime(str_replace('/', '-', $excel_member['Reg_date']))),
			'DOB' => date('Y-m-d', strtotime(str_replace('/', '-', $excel_member['DOB']))),
			'Register_from' => 'Web',
		);

// var_dump($member);
		$pin=$this->get_pincode_details($excel_member['Pincode']);
		if(!empty($pin)){
			$area=$pin[0]['taluk_id'];
			$city=$pin[0]['City_id'];
			$state=$pin[0]['State_id'];
			$country=$pin[0]['Country_id'];
		}else{
			 $area=2;
			$city=1;
			$state=1;
			$country=101;
		}

		$address_data=array(
			 'Address_1' => $excel_member['Address_1'],
			 'Address_type' => 1,
			'Address_2' => $excel_member['Address_2'],
			'Landmark' => $excel_member['Address_2'],
			'Pincode' => $excel_member['Pincode'],
			'Area' => $area,
			'City' => $city,
			'State' => $state,
			'Country' => $country,
		);
// var_dump($address_data);

if($excel_member['Invest_type']=='Initial' || $excel_member['Invest_type']=='initial'){
	$invest_type=1;
}else{
	$invest_type=2;
}
if($invest_type==1){
		if (!is_dir('./attachments/Members/'.$Membership_code))
				  {
					  mkdir('./attachments/Members/'.$Membership_code, 0777, true);
				  }
				  $dir_exist = true; // flag for checking the directory exist or not
				  if (!is_dir('./attachments/Members/'.$Membership_code))
				  {
					  mkdir('./attachments/Members/'.$Membership_code, 0777, true);
					  $dir_exist = false; // dir not exist
				  }
				  if(!define('UPLOAD_DIR','./attachments/Members/'.$Membership_code.'/')){
					define('UPLOAD_DIR', './attachments/Members/'.$Membership_code.'/');
				  }

$file =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Profiles/pan.jpg';
$newfile =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Members/'.$Membership_code.'/'.$Membership_code.'_pan.jpg';
copy($file, $newfile); 


$file1 =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Profiles/aadhar.jpg';
$newfile1 =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Members/'.$Membership_code.'/'.$Membership_code.'_aadhar.jpg';
copy($file1, $newfile1); 


$file2 =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Profiles/cheque.jpg';
$newfile2 =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Members/'.$Membership_code.'/'.$Membership_code.'_cheque.jpg';
copy($file2, $newfile2); 
		$upload_data=[];
		for($i=1;$i<=3;$i++){
			if($i==1){
			$upload_data['upload_data_'.$i]['Document_type']='Pan';
			$upload_data['upload_data_'.$i]['Document_no']=$excel_member['Document_no_pan'];
			$upload_data['upload_data_'.$i]['Document_name']=$Membership_code.'_pan.jpg';
			$upload_data['upload_data_'.$i]['Folder_name']=$Membership_code;
		}elseif($i==2){
			$upload_data['upload_data_'.$i]['Document_type']='Aadhar';
			$upload_data['upload_data_'.$i]['Document_no']=$excel_member['Document_no_aadhar'];
			$upload_data['upload_data_'.$i]['Document_name']=$Membership_code.'_aadhar.jpg';
			$upload_data['upload_data_'.$i]['Folder_name']=$Membership_code;
		}else{
			 $upload_data['upload_data_'.$i]['Document_type']='Cheque';
			$upload_data['upload_data_'.$i]['Document_no']=$excel_member['Document_no_cheque'];
			$upload_data['upload_data_'.$i]['Document_name']=$Membership_code.'_cheque.jpg';
			$upload_data['upload_data_'.$i]['Folder_name']=$Membership_code;
		}
		//var_dump($upload_data);
		}
}


// var_dump($upload_data);
		$nominee_data=array(
			'Nominee_name' => $excel_member['Nominee_name'],
			 'Nominee_relationship' => $excel_member['Nominee_relationship'],
			 'Nominee_mobile' => $excel_member['Nominee_mobile'],
		);
// var_dump($nominee_data);


} // check topup Or Initial End

		$bank=$this->get_bank_details($excel_member['Bank_ID']);
		if(!empty($bank)){
			$bank_id=$bank[0]['ID'];
		}else{
			 $bank_id=2;
		}

	$bank_data=array(
						'Bank_ID' => $bank_id,
						'Account_holder' => $excel_member['Account_holder'],
						'Account_no' => $excel_member['Account_no'],
						'Branch' => $excel_member['Branch'],
						'IFSC' => $excel_member['IFSC']
					);

// var_dump($bank_data);
// echo $excel_member['Topup_id'];
$peyment=$this->get_cntrct_details($excel_member['Topup_id']);
if($excel_member['Invest_type']=='Initial' || $excel_member['Invest_type']=='initial'){
	$invest_type=1;
}else{
	$invest_type=2;
}
if(!empty($peyment)){
			$Topup_id=$peyment[0]['ID'];
			$value=$peyment[0]['Value'];
			$Payout_type=$peyment[0]['Payout_type'];
		}else{
			$member_topup_data = array(
									
					 'Company_id' =>$this->session->userdata('CompanyId'),
					 'Branch_id' =>$this->session->userdata('CompanyId'),
					  'Franchise' => $excel_member['Topup_id']."- Investment",
					  'Alias_name' => $excel_member['Topup_id']."- L",
					  'Level_type_id' => 1,  
					  'Invest_type_id' => 1,  
					  'Value' => $excel_member['Topup_id'],  
					  'Validity' => 11,  
					  'Payout_type' => 1,  
					  'Return' => 0.5,  
					  'Description' => $excel_member['Topup_id']."- Investment");
					  $this->db->insert('gc_member_topup',$member_topup_data); 
					  $Topup_id=$this->db->insert_id();
					  //'Status' => $Status
					 
			 // $Topup_id=1;
			 $value=$excel_member['Topup_id'];
			 $Payout_type=1;
		}

if(!empty($excel_member['Payout_type'])){
if($Payout_type==$excel_member['Payout_type']){
	$old_payout=$Payout_type;
	$new_payout=0;
	$payout_status=1;
}else{
	$old_payout=$Payout_type;
	$new_payout=$excel_member['Payout_type'];
	$payout_status=2;
}
}else{
	$old_payout=$Payout_type;
	$new_payout=0;
	$payout_status=1;
}
	$contract_data=array(
				'Membership_type' => $excel_member['Membership_type'],
				'Topup_id'        => $Topup_id,
				'Old_payout_ID' => $Payout_type,
				'New_payout_ID' => $new_payout,
				'Payout_status' => $payout_status,
				'Invest_type' => $invest_type,

	);

// var_dump($contract_data);

 $peyment=$this->get_payments_details($excel_member['Payment_type_ID']);
if(!empty($peyment)){
			$Payment_type_ID=$peyment[0]['ID'];
		}else{
			 $Payment_type_ID=6;
		}

	$payment_data=array(
		'Payment_type_ID' => $Payment_type_ID,
		'Bank_ID' => $bank_id,
		'Reference_no' => $excel_member['Reference_no'],
		'Date' => date('Y-m-d', strtotime(str_replace('/', '-', $excel_member['Date']))),
		'Amount' => $value,
		'Remarks' => '');

// var_dump($payment_data);

	$agreement_data=array(
		'Delivery_mode' =>1);

if($invest_type==1){
	// var_dump($contract_data);
// die();
	$result=$this->adding_excel_membership_data($member,$address_data,$nominee_data,$bank_data,$upload_data,$contract_data,$payment_data,$agreement_data,$Membership_code);
}else{

		$Membership_ID=$this->get_referer_by_code($excel_member['Mobile']);
	   $Membership_ID=$Membership_ID[0]['Membership_ID']; //
	   $contract_data['Membership_ID']=$Membership_ID;
	   // var_dump($contract_data);die();
	 $result=$this->add_membership_upgrade_by_excel($contract_data,$payment_data,$agreement_data);
}

		
	}

public function generatePIN($digits){
	$i = 0;
	$pin = "";
	while($i < $digits){
		$pin .= mt_rand(0, 9);
		$i++;
	}       
	return $pin;
}


function adding_excel_membership_data1($member,$address_data,$bank_data,$upload_data,$contract_data,$payment_data,$agreement_data,$Membership_code) {
// var_dump($member);
// var_dump($address_data);
// var_dump($bank_data);
// var_dump($upload_data);
// var_dump($contract_data);
// var_dump($payment_data);
// var_dump($agreement_data);
// var_dump($Membership_code);
// die();


	   $Register_date=date('Y-m-d',strtotime($member['Reg_date']));
	   // $Register_date=date('Y-m-d', strtotime(str_replace('/', '-', $excel_member['Reg_date'])));
		// Start Membership Insert
		// var_dump($upload_data);
	   unset($member['Reg_date']);
			if($member['Register_from']=='Web'){
				$Company_ID=$this->session->userdata('CompanyId');
			}else{
				$Company_ID=1;
			}
		$member['Company_id']   = $Company_ID;
		$member['Branch_id']   = $Company_ID;

		if(!empty($contract_data)){
			$member['Membership_type']   = $contract_data['Membership_type'];
			$member['Payout_ID']   		 = $contract_data['Payout_ID'];
			$member['Commission_mode']   = $contract_data['Commission_mode'];
			$member['Final_commission_per']   = $contract_data['Final_commission_per'];
		}else{
			$member['Membership_type']   =1;
			$member['Payout_ID']   		 = 1;
			$member['Commission_mode']   = 1;
			$member['Final_commission_per']   = 0;
		}
		if($member['Commission_mode']==2){
			$member['Commission_per']   = 10;
		}else{
			$member['Commission_per']   = 0;
		}

		// if(!empty($contract_data['Membership_type'])){
		//      $member['Membership_type']   = $contract_data['Membership_type'];
		//  }else{
		//      $member['Membership_type']   = 2;
		//  }
			
		// Membership Code
		$pan=$upload_data["upload_data_1"]["Document_no"];
		// if(!empty($pan)){
		// $newpan = substr($pan, -5);
		// $newmob = substr($member['Mobile'], -5);
		// $member['Membership_code']=$newpan.$newmob;
		// $Membership_code=$newpan.$newmob;
		// }else{
		//     $member['Membership_code']=$Membership_code;
		//     $Membership_code=$member['Membership_code'];
		// }
		$Membership_code=$member['Mobile'];
		

		if($member['Gender']=='Male' || $member['Gender']=='male'){
		$file =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Profiles/male.jpg';
		}else{
			$file =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Profiles/female.jpg';
		}
		
		$newfile =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Members/'.$Membership_code.'/'.$Membership_code.'_Profile.jpg';
		copy($file, $newfile);


	$photo_name=$Membership_code.'_Profile.jpg';
	$member['Membership_code']=$member['Mobile'];
		// $photo_name = $this->member_profile_attachment_1($member['Membership_code'],$profile_name,$names);

		$member['Random_ID']="GCI".rand(00000000,99999999);
		$increment_code = $this->db->count_all_results('gc_membership')+1;
		$member['Member_no']="GRNC-MEM-0000".$increment_code;
		$member['Member_sequence']=$increment_code-1;
		$member['DOB']=date("Y-m-d", strtotime($member['DOB']));
		// $member['DOB']=date('Y-m-d', strtotime(str_replace('/', '-', $member['DOB'])));
		// if($member['Membership_type']==1){
		// 	$member['Status']=5;
		// }else{
		// 	$member['Status']=4;
		// }
		$member['Status']=4;
		$member['Photo']=$photo_name;
		$member['Photo_path']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$member['Membership_code'].'/';
		$member['Created_by']=$this->session->userdata('UserId');
		$member['Created_date']=$Register_date;


// var_dump($member);
		if($this->db->insert('gc_membership', $member)){
			$Membership_ID=$this->db->insert_id();
		}

	// $Membership_ID=1;

// end Membership Insert

//start Member upload_data Insert
		foreach($upload_data as $key =>$upld)
		{
			$upld['Membership_ID']   = $Membership_ID;
			$upld['File_path']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$member['Membership_code'].'/';
			$upld['Company_id']   = $Company_ID;
			$upld['Branch_id']   = $Company_ID;
			$upld['Status']   = 6;
			$upload_data[$key]=$upld;
		}
		// var_dump($upload_data);
		foreach($upload_data as $upld_data)
		{   
			$this->db->insert('gc_member_documents', $upld_data);
		   
		}
		
		// die();
//end Member upload_data Insert

//start Member Address Insert
		$address_data['Membership_ID']   = $Membership_ID;
		$address_data['Company_id']   = $Company_ID;
		$address_data['Branch_id']   = $Company_ID;
		// var_dump($address_data);
		$this->db->insert('gc_member_address', $address_data);
//end Member Address Insert

// start User Insert
	   $user_data['user_id']         = $Membership_ID;
	   $user_data['company_id']      = 1;
	   $user_data['branch_id']       = 1;
	   $user_data['firstname']       = $member['First_name'];
	   $user_data['username']        = $member['Membership_code'];
	   $user_data['password']        = md5($member['Membership_code']);
	   $user_data['og_password']     = $member['Membership_code'];
	   $user_data['email_address']   = $member['Email'];
	   $user_data['mobile_number']   = $member['Mobile'];
	   $user_data['address_line_1']  = $address_data['Address_1'];
	   $user_data['address_line_2']  = $address_data['Address_2'];
	   $user_data['zipcode']         = $address_data['Pincode'];
	   $user_data['country_id']      = $address_data['Country'];
	   $user_data['state_id']        = $address_data['State'];
	   $user_data['city_id']         = $address_data['City'];
	   $user_data['user_type_id']    = 3;
	   // var_dump($user_data);
	   $this->db->insert('gc_users', $user_data);
	   $user_insert_id=$this->db->insert_id();

// end User Insert  
// Start User Insert
	   $membership_upload_data['Created_by']   = $user_insert_id;
	   $this->db->where('Membership_ID', $Membership_ID);
	   $this->db->update('gc_membership', $membership_upload_data);
// End User Insert 
// Open Cart Table

	// $reg = array('firstname'         => $member['First_name'],
	//              'lastname'          => $member['Last_name'],
	//              'customer_group_id' => '1',
	//              'language_id'       => '1',
	//              'email'             => $member['Email'],
	//              'telephone'         => $member['Mobile'],
	//              'status'            => '1',
	//              'email'             => $member['Email'],                         
	//              'password'          => md5($member['Mobile']),                         
	//              'Member_id'         => $Membership_ID,                         
	//             );
	//     $opencart = $this->load->database('greencrest_ecommerce', TRUE);
	//     // opencart
	//     if ($opencart->insert('oc_customer', $reg)) {
	//          $opencart->insert_id();
	//     } 

// End Open Cart Table


//start Member nominee_data Insert
		// $nominee_data['Membership_ID']   = $Membership_ID;
		// $nominee_data['Company_id']   = $Company_ID;
		// $nominee_data['Branch_id']   = $Company_ID;
		// var_dump($nominee_data);
		// $this->db->insert('gc_member_nominees', $nominee_data);
//end Member nominee_data Insert

//start Member bank_data Insert
		$bank_data['Membership_ID']   = $Membership_ID;
		$bank_data['Company_id']   = $Company_ID;
		$bank_data['Branch_id']   = $Company_ID;
		$bank_data['Status']   = 6;
		// var_dump($bank_data);
		$this->db->insert('gc_member_banks', $bank_data);
//end Member bank_data Insert

//start Member contract_data Insert
		if($contract_data['Membership_type']==1){
			if(isset($contract_data)){
			$contract_data['Membership_ID']   = $Membership_ID;
			$increment_code1 = $this->db->count_all_results('gc_member_franchisee_contract')+1;
			$contract_data['Contract_ref_no']="GRNC-CNT-0000".$increment_code1;
			$contract_data['Company_id']   = $Company_ID;
			$contract_data['Branch_id']   = $Company_ID;
			$contract_data['Branch_id']   = $Company_ID;
			$contract_data['Date']   = $Register_date;
			// var_dump($contract_data);
			if($this->db->insert('gc_member_franchisee_contract', $contract_data)){
				$Contract_ID=$this->db->insert_id();
			}
			// $Contract_ID=36;
		}
//start Member payment_data Insert
		if(isset($payment_data)){
				$payment_data['Membership_ID']   = $Membership_ID;
				$payment_data['Contract_ID']   = $Contract_ID;
				$payment_data['Company_id']   = $Company_ID;
				$payment_data['Branch_id']   = $Company_ID;
				$payment_data['Date']   = date('Y-m-d',strtotime($payment_data['Date']));
				$payment_data['Payment_status']   = 5;
				$payment_data['Created_date']   = $Register_date;
		   
			
			// var_dump($payment_data);
			$this->db->insert('gc_member_payments', $payment_data);
		}    
//end Member payment_data Insert

//start Member agreement_data Insert
		if(isset($agreement_data)){
			$agreement_data['Membership_ID']   = $Membership_ID;
			$agreement_data['Contract_ID']   = $Contract_ID;
			$agreement_data['Company_id']   = $Company_ID;
			$agreement_data['Date']   = $Register_date;
			$agreement_data['Branch_id']   = $Company_ID;
			// var_dump($agreement_data);
			$this->db->insert('gc_member_agreement', $agreement_data);
		}
//end Member agreement_data Insert
		}
			
//end Member contract_data Insert



// BV Values Data Insert Start
			// $bv_empty_data=array('Company_id' => $Company_ID,
			//                      'Branch_id' => $Company_ID,
			//                      'Membership_ID' => $Membership_ID);
			// $this->db->insert('gc_bv_values', $bv_empty_data);

// BV Values Data Insert End  

//start Member Franchisee Member Relationship Insert
		$franchisee_relation['Child_ID']        = $Membership_ID;
		$franchisee_relation['Level_type_ID']   = 1;
		$franchisee_relation['Parent_id']   = $member['Reference_ID'];
		// $franchisee_relation['Position']   = 1;
		$this->db->where('Parent_ID',$member['Reference_ID']);  
		$member_seq = $this->db->count_all_results('gc_franchisee_member_relation')+1;

		$franchisee_relation['Position']   = $member_seq;
		if($franchisee_relation['Position'] % 2 == 0){ 
			$determin = "2";  
		}else{ 
			$determin = "1"; 
		}
		$franchisee_relation['Determination']   = $determin;
		$franchisee_relation['Company_id']   = $Company_ID;
		$franchisee_relation['Branch_id']   = $Company_ID;
		$franchisee_relation['Date']   = $Register_date;
		// var_dump($franchisee_relation);
		$this->db->insert('gc_franchisee_member_relation', $franchisee_relation);
//end Member Franchisee Member Relationship Insert

//start Member binary Member Relationship Insert
		// $binary_relation['Child_ID']        = $Membership_ID;
		// $binary_relation['Level_type_ID']   = 2;
		// $binary_relation['Refer_parent_ID']   = $member['Reference_ID'];
		// $binary_relation['Position']   = $member_seq;
		//     $parent_id=$binary_relation['Refer_parent_ID'];
		//     if($binary_relation['Position'] % 2 == 0){ // determination if Start
		//          $p_type=2;
		//         $determin = 2;
		//         if($parent_id==1){
		//             $Ex_position_type=2;
		//         }
		//         else{
		//             $this->db->select('*');
		//             $this->db->where('Child_ID',$parent_id);
		//             $query = $this->db->get('gc_binary_member_relation');
		//             $binary=$query->result_array();
		//             $Ex_position_type=$binary[0]['Ex_position_type'];
		//         }

		//         }  // determination if End

		//     else{  // determination else Start
		//         $p_type=1;
		//         $determin = 1;
		//         if($parent_id==1){
		//             $Ex_position_type=1;
		//             }
		//         else{
		//             $this->db->select('*');
		//             $this->db->where('Child_ID',$parent_id);
		//             $query = $this->db->get('gc_binary_member_relation');
		//             $binary=$query->result_array();
		//             $Ex_position_type=$binary[0]['Ex_position_type'];
		//         }
		//     } // determination else End

		//                 $limit=1;
		//                 for($i=1;$i<=$limit;$i++){
		//                     $this->db->select('*');
		//                     $this->db->where('Position_type',$p_type);
		//                     $this->db->where('Ex_position_type',$Ex_position_type);
		//                     $this->db->where('Parent_ID',$parent_id);
		//                     $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
		//                     $query4 = $this->db->get('gc_binary_member_relation');
		//                     if($query4->num_rows() > 0){
		//                         $binary4=$query4->result_array();
		//                         $parent_id=$binary4[0]['Child_ID'];
		//                         $limit++;
		//                     }
			
		//                 }
		// $binary_relation['Determination']   = $determin;
		// $binary_relation['Position_type']   = $p_type;
		// $binary_relation['Ex_position_type']   = $Ex_position_type;
		// $binary_relation['Parent_id']    =  $parent_id;
		// $binary_relation['Company_id']   =  $Company_ID;
		// $binary_relation['Branch_id']    =  $Company_ID;
		// $binary_relation['Date']   = $Register_date;
		// $this->db->insert('gc_binary_member_relation', $binary_relation);
//end Member binary Member Relationship Insert

$member_update['Members_count']   = $member_seq;
$this->db->where('Membership_ID', $member['Reference_ID']);
$this->db->update('gc_membership', $member_update);

			


//start Member binary Member Levels Insert
$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$member['Reference_ID']);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			//var_dump($binary);
			$crnt_lvl=$binary[0]['Current_level'];
			 $level['Level_ID']=$i;
			if($crnt_lvl<=$i){
			$member_level=$i;
			}
			else{
				$member_level=$crnt_lvl;
			}
			$ref_ID=$binary[0]['Reference_ID'];
 // Member Level Master Insert start
			$levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_master['Company_id']       =  $Company_ID;
			$levels_master['Branch_id']        =  $Company_ID;
			$levels_master['Level_ID']         =  1;
			$levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_master['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_master['Date']   = $Register_date;
			$this->db->insert('gc_member_levels', $levels_master);
			$level_insert_id=$this->db->insert_id();

// Member Level Master Insert end         
// Member Level Details Insert start 
			$levels_data['Member_level_ID']  =  $level_insert_id;
			$levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_data['Child_ID']         =  $Membership_ID;
			$levels_data['Company_id']       =  $Company_ID;
			$levels_data['Branch_id']        =  $Company_ID;
			$levels_data['Level_ID']         =  $level['Level_ID'];
			// $levels_data['Position']         =  $binary_relation['Ex_position_type'];
			$levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_data['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_data['Level_date']   = $Register_date;
			$this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start
// Membership Current Level Insert start
			$mem_lvl['Current_level']=$member_level;
			
			$this->db->where('Membership_ID',$binary[0]['Membership_ID']);
			$this->db->update('gc_membership', $mem_lvl);
// Membership Current Level Insert end

		}
	}
	else{
			$this->db->select('*');
			$this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
			if($crnt_lvl<=$i){
			$member_level=$i;
			}
			else{
				$member_level=$crnt_lvl;
			}
			$ref_ID=$binary[0]['Reference_ID'];

 // Member Level Master Insert start
			$levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_master['Company_id']       =  $Company_ID;
			$levels_master['Branch_id']        =  $Company_ID;
			$levels_master['Level_ID']         =  $level['Level_ID'];
			$levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_master['Payout_status']    =  $binary[0]['Payout_status'];
			$this->db->insert('gc_member_levels', $levels_master);
			$levels_master['Date']             = $Register_date;
			$level_insert_id=$this->db->insert_id();
// Member Level Master Insert end         
// Member Level Details Insert start 
			$levels_data['Member_level_ID']  =  $level_insert_id;
			$levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_data['Child_ID']         =  $Membership_ID;
			$levels_data['Company_id']       =  $Company_ID;
			$levels_data['Branch_id']        =  $Company_ID;
			$levels_data['Level_ID']         =  $level['Level_ID'];
			// $levels_data['Position']         =  $binary_relation['Ex_position_type'];
			$levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_data['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_data['Level_date']       = $Register_date;
			$this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start

// Membership Current Level Insert start
			$mem_lvl['Current_level']=$member_level;
			$this->db->where('Membership_ID',$binary[0]['Membership_ID']);
			$this->db->update('gc_membership', $mem_lvl);
// Membership Current Level Insert end            
			
// Membership Member Grade Update start            

//             $level_counts=[];
//             $grade_ids=[];
//             for($j=1;$j<=9;$j++){
//                 $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
//                 $this->db->where('Level_ID',$j);
//                 $mem_counts =  $this->db->count_all_results('gc_member_levels');
//                 $level_counts['Level_'.$j]=$mem_counts;
//             }
//             //var_dump($level_counts);
//                 $this->db->select('*');
//                 $this->db->where('Status',1);
//                 $query =  $this->db->get('gc_grade');
//                  if($query->num_rows() > 0) {
//                 $grade=$query->result_array();

//                 foreach($grade as $gradevals){
//                     foreach($level_counts as $lvl){
//                         $array=[];
// $a=0;

//   if($lvl['Level_1'] >= $gradevals['Level_1_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_2'] >= $gradevals['Level_2_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_3'] >= $gradevals['Level_3_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_4'] >= $gradevals['Level_4_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_5'] >= $gradevals['Level_5_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_6'] >= $gradevals['Level_6_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_7'] >= $gradevals['Level_7_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_8'] >= $gradevals['Level_8_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_9'] >= $gradevals['Level_9_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;

//       $check=in_array(1, $array) < 0;
//       if($check==true){
//         array_push($grade_ids,$gradevals['ID']);
//       //echo 'insert'.'<br>';
//   }
//   else{
//   //echo 'do nothing'.'<br>';
// }
//                     }
//                 }
//                 //var_dump($grade_ids);
//                 if(!empty($grade_ids)){
//                 $this->db->select('ID,min(Grade_level) as Grade_level');
//                 $this->db->where('Status',1);
//                 $this->db->where_in('ID',$grade_ids);
//                 $least=$this->db->get('gc_grade');
//                 if($least->num_rows() > 0) {
//                    $least_c=$least->row();
//                 $inserting_grade=$least_c->ID;
//                 $membership_data['Member_grade']=$inserting_grade;
//                 $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
//                 $this->db->update('gc_membership',$membership_data);
//                 }
//             }

//             }
		
// Membership Member Grade Update end


				}

			}
		}
	}

function adding_excel_membership_data($member,$address_data,$nominee_data,$bank_data,$upload_data,$contract_data,$payment_data,$agreement_data,$Membership_code) {

	   $Register_date=date('Y-m-d',strtotime($member['Reg_date']));
	   // $Register_date=date('Y-m-d', strtotime(str_replace('/', '-', $excel_member['Reg_date'])));
		// Start Membership Insert
		// var_dump($upload_data);
	   unset($member['Reg_date']);
			if($member['Register_from']=='Web'){
				$Company_ID=$this->session->userdata('CompanyId');
			}else{
				$Company_ID=1;
			}
		$member['Company_id']   = $Company_ID;
		$member['Branch_id']   = $Company_ID;

		if(isset($contract_data)){
			$member['Membership_type']   = $contract_data['Membership_type'];
		}
		if(!empty($contract_data['Membership_type'])){
			 $member['Membership_type']   = $contract_data['Membership_type'];
		 }else{
			 $member['Membership_type']   = 2;
		 }
			
		// Membership Code
		$pan=$upload_data["upload_data_1"]["Document_no"];
		// if(!empty($pan)){
		// $newpan = substr($pan, -5);
		// $newmob = substr($member['Mobile'], -5);
		// $member['Membership_code']=$newpan.$newmob;
		// $Membership_code=$newpan.$newmob;
		// }else{
		//     $member['Membership_code']=$Membership_code;
		//     $Membership_code=$member['Membership_code'];
		// }
		$Membership_code=$member['Mobile'];
		

		if($member['Gender']=='Male' || $member['Gender']=='male'){
		$file =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Profiles/male.jpg';
		}else{
			$file =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Profiles/female.jpg';
		}
		
		$newfile =  $_SERVER['DOCUMENT_ROOT'] .base_url().'attachments/Members/'.$Membership_code.'/'.$Membership_code.'_Profile.jpg';
		copy($file, $newfile);


	$photo_name=$Membership_code.'_Profile.jpg';
	$member['Membership_code']=$member['Mobile'];
		// $photo_name = $this->member_profile_attachment_1($member['Membership_code'],$profile_name,$names);

		$member['Random_ID']="GC".rand(00000000,99999999);
		$increment_code = $this->db->count_all_results('gc_membership')+1;
		$member['Member_no']="GRNC-MEM-0000".$increment_code;
		$member['Member_sequence']=$increment_code-1;
		$member['DOB']=date("Y-m-d", strtotime($member['DOB']));
		// $member['DOB']=date('Y-m-d', strtotime(str_replace('/', '-', $member['DOB'])));
		$member['Status']=4;
		$member['Photo']=$photo_name;
		$member['Photo_path']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$member['Membership_code'].'/';
		$member['Created_by']=$this->session->userdata('UserId');
		$member['Created_date']=$Register_date;


// var_dump($member);
		if($this->db->insert('gc_membership', $member)){
			$Membership_ID=$this->db->insert_id();
		}

	// $Membership_ID=1;

// end Membership Insert

//start Member upload_data Insert
		foreach($upload_data as $key =>$upld)
		{
			$upld['Membership_ID']   = $Membership_ID;
			$upld['File_path']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$member['Membership_code'].'/';
			$upld['Company_id']   = $Company_ID;
			$upld['Branch_id']   = $Company_ID;
			$upld['Status']   = 6;
			$upload_data[$key]=$upld;
		}
		// var_dump($upload_data);
		foreach($upload_data as $upld_data)
		{   
			$this->db->insert('gc_member_documents', $upld_data);
		   
		}
		
		// die();
//end Member upload_data Insert

//start Member Address Insert
		$address_data['Membership_ID']   = $Membership_ID;
		$address_data['Company_id']   = $Company_ID;
		$address_data['Branch_id']   = $Company_ID;
		// var_dump($address_data);
		$this->db->insert('gc_member_address', $address_data);
//end Member Address Insert

// start User Insert
	   $user_data['user_id']         = $Membership_ID;
	   $user_data['company_id']      = 1;
	   $user_data['branch_id']       = 1;
	   $user_data['firstname']       = $member['First_name'];
	   $user_data['username']        = $member['Membership_code'];
	   $user_data['password']        = md5($member['Mobile']);
	   $user_data['og_password']     = $member['Mobile'];
	   $user_data['email_address']   = $member['Email'];
	   $user_data['mobile_number']   = $member['Mobile'];
	   $user_data['address_line_1']  = $address_data['Address_1'];
	   $user_data['address_line_2']  = $address_data['Address_2'];
	   $user_data['zipcode']         = $address_data['Pincode'];
	   $user_data['country_id']      = $address_data['Country'];
	   $user_data['state_id']        = $address_data['State'];
	   $user_data['city_id']         = $address_data['City'];
	   $user_data['user_type_id']    = 3;
	   // var_dump($user_data);
	   $this->db->insert('gc_users', $user_data);

// end User Insert  

// Open Cart Table

	// $reg = array('firstname'         => $member['First_name'],
	//              'lastname'          => $member['Last_name'],
	//              'customer_group_id' => '1',
	//              'language_id'       => '1',
	//              'email'             => $member['Email'],
	//              'telephone'         => $member['Mobile'],
	//              'status'            => '1',
	//              'email'             => $member['Email'],                         
	//              'password'          => md5($member['Mobile']),                         
	//              'Member_id'         => $Membership_ID,                         
	//             );
	//     $opencart = $this->load->database('greencrest_ecommerce', TRUE);
	//     // opencart
	//     if ($opencart->insert('oc_customer', $reg)) {
	//          $opencart->insert_id();
	//     } 

// End Open Cart Table


//start Member nominee_data Insert
		$nominee_data['Membership_ID']   = $Membership_ID;
		$nominee_data['Company_id']   = $Company_ID;
		$nominee_data['Branch_id']   = $Company_ID;
		// var_dump($nominee_data);
		$this->db->insert('gc_member_nominees', $nominee_data);
//end Member nominee_data Insert

//start Member bank_data Insert
		$bank_data['Membership_ID']   = $Membership_ID;
		$bank_data['Company_id']   = $Company_ID;
		$bank_data['Branch_id']   = $Company_ID;
		$bank_data['Status']   = 6;
		// var_dump($bank_data);
		$this->db->insert('gc_member_banks', $bank_data);
//end Member bank_data Insert

//start Member contract_data Insert
		if(isset($contract_data)){
			$contract_data['Membership_ID']   = $Membership_ID;
			$increment_code1 = $this->db->count_all_results('gc_member_franchisee_contract')+1;
			$contract_data['Contract_ref_no']="GRNC-CNT-0000".$increment_code1;
			$contract_data['Company_id']   = $Company_ID;
			$contract_data['Branch_id']   = $Company_ID;
			$contract_data['Branch_id']   = $Company_ID;
			$contract_data['Date']   = $Register_date;
			// var_dump($contract_data);
			if($this->db->insert('gc_member_franchisee_contract', $contract_data)){
				$Contract_ID=$this->db->insert_id();
			}
			// $Contract_ID=36;
		}    
//end Member contract_data Insert

//start Member payment_data Insert
		if(isset($payment_data)){
				$payment_data['Membership_ID']   = $Membership_ID;
				$payment_data['Contract_ID']   = $Contract_ID;
				$payment_data['Company_id']   = $Company_ID;
				$payment_data['Branch_id']   = $Company_ID;
				$payment_data['Date']   = date('Y-m-d',strtotime($payment_data['Date']));
				$payment_data['Payment_status']   = 5;
				$payment_data['Created_date']   = $Register_date;
		   
			
			// var_dump($payment_data);
			$this->db->insert('gc_member_payments', $payment_data);
		}    
//end Member payment_data Insert

//start Member agreement_data Insert
		if(isset($agreement_data)){
			$agreement_data['Membership_ID']   = $Membership_ID;
			$agreement_data['Contract_ID']   = $Contract_ID;
			$agreement_data['Company_id']   = $Company_ID;
			$agreement_data['Date']   = $Register_date;
			$agreement_data['Branch_id']   = $Company_ID;
			// var_dump($agreement_data);
			$this->db->insert('gc_member_agreement', $agreement_data);
		}
//end Member agreement_data Insert

// BV Values Data Insert Start
			$bv_empty_data=array('Company_id' => $Company_ID,
								 'Branch_id' => $Company_ID,
								 'Membership_ID' => $Membership_ID);
			$this->db->insert('gc_bv_values', $bv_empty_data);

// BV Values Data Insert End  

//start Member Franchisee Member Relationship Insert
		$franchisee_relation['Child_ID']        = $Membership_ID;
		$franchisee_relation['Level_type_ID']   = 1;
		$franchisee_relation['Parent_id']   = $member['Reference_ID'];
		// $franchisee_relation['Position']   = 1;
		$this->db->where('Parent_ID',$member['Reference_ID']);  
		$member_seq = $this->db->count_all_results('gc_franchisee_member_relation')+1;

		$franchisee_relation['Position']   = $member_seq;
		if($franchisee_relation['Position'] % 2 == 0){ 
			$determin = "2";  
		}else{ 
			$determin = "1"; 
		}
		$franchisee_relation['Determination']   = $determin;
		$franchisee_relation['Company_id']   = $Company_ID;
		$franchisee_relation['Branch_id']   = $Company_ID;
		$franchisee_relation['Date']   = $Register_date;
		// var_dump($franchisee_relation);
		$this->db->insert('gc_franchisee_member_relation', $franchisee_relation);
//end Member Franchisee Member Relationship Insert

//start Member binary Member Relationship Insert
		// $binary_relation['Child_ID']        = $Membership_ID;
		// $binary_relation['Level_type_ID']   = 2;
		// $binary_relation['Refer_parent_ID']   = $member['Reference_ID'];
		// $binary_relation['Position']   = $member_seq;
		//     $parent_id=$binary_relation['Refer_parent_ID'];
		//     if($binary_relation['Position'] % 2 == 0){ // determination if Start
		//          $p_type=2;
		//         $determin = 2;
		//         if($parent_id==1){
		//             $Ex_position_type=2;
		//         }
		//         else{
		//             $this->db->select('*');
		//             $this->db->where('Child_ID',$parent_id);
		//             $query = $this->db->get('gc_binary_member_relation');
		//             $binary=$query->result_array();
		//             $Ex_position_type=$binary[0]['Ex_position_type'];
		//         }

		//         }  // determination if End

		//     else{  // determination else Start
		//         $p_type=1;
		//         $determin = 1;
		//         if($parent_id==1){
		//             $Ex_position_type=1;
		//             }
		//         else{
		//             $this->db->select('*');
		//             $this->db->where('Child_ID',$parent_id);
		//             $query = $this->db->get('gc_binary_member_relation');
		//             $binary=$query->result_array();
		//             $Ex_position_type=$binary[0]['Ex_position_type'];
		//         }
		//     } // determination else End

		//                 $limit=1;
		//                 for($i=1;$i<=$limit;$i++){
		//                     $this->db->select('*');
		//                     $this->db->where('Position_type',$p_type);
		//                     $this->db->where('Ex_position_type',$Ex_position_type);
		//                     $this->db->where('Parent_ID',$parent_id);
		//                     $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
		//                     $query4 = $this->db->get('gc_binary_member_relation');
		//                     if($query4->num_rows() > 0){
		//                         $binary4=$query4->result_array();
		//                         $parent_id=$binary4[0]['Child_ID'];
		//                         $limit++;
		//                     }
			
		//                 }
		// $binary_relation['Determination']   = $determin;
		// $binary_relation['Position_type']   = $p_type;
		// $binary_relation['Ex_position_type']   = $Ex_position_type;
		// $binary_relation['Parent_id']    =  $parent_id;
		// $binary_relation['Company_id']   =  $Company_ID;
		// $binary_relation['Branch_id']    =  $Company_ID;
		// $binary_relation['Date']   = $Register_date;
		// $this->db->insert('gc_binary_member_relation', $binary_relation);
//end Member binary Member Relationship Insert

$member_update['Members_count']   = $member_seq;
$this->db->where('Membership_ID', $member['Reference_ID']);
$this->db->update('gc_membership', $member_update);

			


//start Member binary Member Levels Insert
$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$member['Reference_ID']);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			//var_dump($binary);
			$crnt_lvl=$binary[0]['Current_level'];
			 $level['Level_ID']=$i;
			if($crnt_lvl<=$i){
			$member_level=$i;
			}
			else{
				$member_level=$crnt_lvl;
			}
			$ref_ID=$binary[0]['Reference_ID'];
 // Member Level Master Insert start
			$levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_master['Company_id']       =  $Company_ID;
			$levels_master['Branch_id']        =  $Company_ID;
			$levels_master['Level_ID']         =  1;
			$levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_master['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_master['Date']   = $Register_date;
			$this->db->insert('gc_member_levels', $levels_master);
			$level_insert_id=$this->db->insert_id();

// Member Level Master Insert end         
// Member Level Details Insert start 
			$levels_data['Member_level_ID']  =  $level_insert_id;
			$levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_data['Child_ID']         =  $Membership_ID;
			$levels_data['Company_id']       =  $Company_ID;
			$levels_data['Branch_id']        =  $Company_ID;
			$levels_data['Level_ID']         =  $level['Level_ID'];
			$levels_data['Position']         =  $binary_relation['Ex_position_type'];
			$levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_data['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_data['Level_date']   = $Register_date;
			$this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start
// Membership Current Level Insert start
			$mem_lvl['Current_level']=$member_level;
			
			$this->db->where('Membership_ID',$binary[0]['Membership_ID']);
			$this->db->update('gc_membership', $mem_lvl);
// Membership Current Level Insert end

		}
	}
	else{
			$this->db->select('*');
			$this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
			if($crnt_lvl<=$i){
			$member_level=$i;
			}
			else{
				$member_level=$crnt_lvl;
			}
			$ref_ID=$binary[0]['Reference_ID'];

 // Member Level Master Insert start
			$levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_master['Company_id']       =  $Company_ID;
			$levels_master['Branch_id']        =  $Company_ID;
			$levels_master['Level_ID']         =  $level['Level_ID'];
			$levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_master['Payout_status']    =  $binary[0]['Payout_status'];
			$this->db->insert('gc_member_levels', $levels_master);
			$levels_master['Date']             = $Register_date;
			$level_insert_id=$this->db->insert_id();
// Member Level Master Insert end         
// Member Level Details Insert start 
			$levels_data['Member_level_ID']  =  $level_insert_id;
			$levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_data['Child_ID']         =  $Membership_ID;
			$levels_data['Company_id']       =  $Company_ID;
			$levels_data['Branch_id']        =  $Company_ID;
			$levels_data['Level_ID']         =  $level['Level_ID'];
			$levels_data['Position']         =  $binary_relation['Ex_position_type'];
			$levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_data['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_data['Level_date']       = $Register_date;
			$this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start

// Membership Current Level Insert start
			$mem_lvl['Current_level']=$member_level;
			$this->db->where('Membership_ID',$binary[0]['Membership_ID']);
			$this->db->update('gc_membership', $mem_lvl);
// Membership Current Level Insert end            
			
// Membership Member Grade Update start            

//             $level_counts=[];
//             $grade_ids=[];
//             for($j=1;$j<=9;$j++){
//                 $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
//                 $this->db->where('Level_ID',$j);
//                 $mem_counts =  $this->db->count_all_results('gc_member_levels');
//                 $level_counts['Level_'.$j]=$mem_counts;
//             }
//             //var_dump($level_counts);
//                 $this->db->select('*');
//                 $this->db->where('Status',1);
//                 $query =  $this->db->get('gc_grade');
//                  if($query->num_rows() > 0) {
//                 $grade=$query->result_array();

//                 foreach($grade as $gradevals){
//                     foreach($level_counts as $lvl){
//                         $array=[];
// $a=0;

//   if($lvl['Level_1'] >= $gradevals['Level_1_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_2'] >= $gradevals['Level_2_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_3'] >= $gradevals['Level_3_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_4'] >= $gradevals['Level_4_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_5'] >= $gradevals['Level_5_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_6'] >= $gradevals['Level_6_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_7'] >= $gradevals['Level_7_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_8'] >= $gradevals['Level_8_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_9'] >= $gradevals['Level_9_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;

//       $check=in_array(1, $array) < 0;
//       if($check==true){
//         array_push($grade_ids,$gradevals['ID']);
//       //echo 'insert'.'<br>';
//   }
//   else{
//   //echo 'do nothing'.'<br>';
// }
//                     }
//                 }
//                 //var_dump($grade_ids);
//                 if(!empty($grade_ids)){
//                 $this->db->select('ID,min(Grade_level) as Grade_level');
//                 $this->db->where('Status',1);
//                 $this->db->where_in('ID',$grade_ids);
//                 $least=$this->db->get('gc_grade');
//                 if($least->num_rows() > 0) {
//                    $least_c=$least->row();
//                 $inserting_grade=$least_c->ID;
//                 $membership_data['Member_grade']=$inserting_grade;
//                 $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
//                 $this->db->update('gc_membership',$membership_data);
//                 }
//             }

//             }
		
// // Membership Member Grade Update end


				}

			}
		}
	}

function random_strings($length_of_string) { 

	return substr(bin2hex(random_bytes($length_of_string)),0, $length_of_string); 

}


function get_currency($id) { 
$data=$this->db->get_where('gc_currency',array('Mode' => $id))->result_array();
if(!empty($data)){
	return $data[0]['Value'];
}else{
	if($id==1){
		return 75;
	}else{
		return 70;
	}
}

}



function update_membership($member,$address_data,$nominee_data,$bank_data,$photo,$Membership_ID,$Membership_code) {
		$profile_name = 'Photo';
		$names = 'Profile';
		$photo_name = $this->member_profile_attachment_1($Membership_code,$profile_name,$names);
		if($photo_name!==''){
		$member['Photo']=$photo_name;
		$member['Photo_path']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/';
		}else{
			unset($member['Photo']);
		}
		$member['DOB']=date("Y-m-d", strtotime($member['DOB']));
		$member['Updated_by']=$this->session->userdata('UserId');
		$member['Updated_date']=date('Y-m-d');

		$this->db->where('Membership_ID', $Membership_ID);
		$this->db->update('gc_membership', $member);

		$this->db->where('Membership_ID', $Membership_ID);
		$this->db->update('gc_member_address', $address_data);

		$this->db->where('Membership_ID', $Membership_ID);
		$this->db->update('gc_member_nominees', $nominee_data);

		$this->db->where('Membership_ID', $Membership_ID);
		$this->db->update('gc_member_banks', $bank_data);

}

function add_membership($member,$address_data,$nominee_data,$bank_data,$upload_data,$contract_data,$payment_data,$agreement_data,$Membership_code) {

// print_r($member);echo '<br>';
// print_r($address_data);echo '<br>';
// print_r($nominee_data);echo '<br>';
// print_r($bank_data);echo '<br>';
// print_r($upload_data);echo '<br>';
// print_r($contract_data);echo '<br>';
// print_r($payment_data);echo '<br>';
// print_r($agreement_data);die();


	   $Register_date=date('Y-m-d',strtotime($member['Reg_date']));
		// Start Membership Insert
		// var_dump($upload_data);
	   unset($member['Reg_date']);
			if($member['Register_from']=='Web'){
				$Company_ID=$this->session->userdata('CompanyId');
			}else{
				$Company_ID=1;
			}
		$member['Company_id']   = $Company_ID;
		$member['Branch_id']   = $Company_ID;

		// if(isset($contract_data)){
		//     $member['Membership_type']   = $contract_data['Membership_type'];
		// }
		// if(!empty($contract_data['Membership_type'])){
		//      $member['Membership_type']   = $contract_data['Membership_type'];
		//  }else{
		//      $member['Membership_type']   = 2;
		//  }
			
		// Membership Code
		// $pan=$upload_data["upload_data_1"]["Document_no"];
		// if(!empty($pan)){
		// $newpan = substr($pan, -5);
		// }
		// $newmob = substr($member['Mobile'], -5);
		// $member['Membership_code']=$newpan.$newmob;
		$member['Membership_code']=$Membership_code;

		$profile_name = 'Photo';
		$names = 'Profile';
		$photo_name = $this->member_profile_attachment_1($member['Membership_code'],$profile_name,$names);

		//echo $rnd=random_strings(10);
		
		
		// $member['Random_ID']=random_string('alnum',10);
		$member['Random_ID']="GC".rand(00000000,99999999);
		if(!empty($contract_data)){
			$member['Payout_ID']=$contract_data['Payout_ID'];
		}else{
			$member['Payout_ID']='';
		}
		$increment_code = $this->db->count_all_results('gc_membership')+1;
		$member['Member_no']="GRNC-MEM-0000".$increment_code;
		$member['Member_sequence']=$increment_code-1;
		$member['DOB']=date("Y-m-d", strtotime($member['DOB']));
		$member['Status']=5;
		$member['Photo']=$photo_name;
		$member['Photo_path']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$member['Membership_code'].'/';
		$member['Created_by']=$this->session->userdata('UserId');
		$member['Created_date']=$Register_date;
		$member['Register_from']='admin';
		$member['Payout_ID']=2;
		$member['Final_commission_per']=10;
		$member['Membership_type']=1;


		if($this->db->insert('gc_membership', $member)){
			$Membership_ID=$this->db->insert_id();
		}


// end Membership Insert

//start Member upload_data Insert
		foreach($upload_data as $key =>$upld)
		{
			$upld['Membership_ID']   = $Membership_ID;
			
			$upld['Company_id']   = $Company_ID;
			$upld['Branch_id']   = $Company_ID;
			$upload_data[$key]=$upld;
		}
		foreach($upload_data as $upld_data)
		{   
			$this->db->insert('gc_member_documents', $upld_data);
		   
		}
		
		// die();
//end Member upload_data Insert

//start Member Address Insert
		$address_data['Membership_ID']   = $Membership_ID;
		$address_data['Company_id']   = $Company_ID;
		$address_data['Branch_id']   = $Company_ID;
		$this->db->insert('gc_member_address', $address_data);
//end Member Address Insert

// start User Insert
	   $user_data['user_id']         = $Membership_ID;
	   $user_data['company_id']      = 1;
	   $user_data['branch_id']       = 1;
	   $user_data['firstname']       = $member['First_name'];
	   $user_data['username']        = $member['Membership_code'];
	   $user_data['password']        = md5($member['Membership_code']);
	   // $user_data['password']        = md5($member['Mobile']);
	   $user_data['og_password']     = $member['Mobile'];
	   $user_data['email_address']   = $member['Email'];
	   $user_data['mobile_number']   = $member['Mobile'];
	   $user_data['address_line_1']  = $address_data['Address_1'];
	   $user_data['address_line_2']  = $address_data['Address_2'];
	   $user_data['zipcode']         = $address_data['Pincode'];
	   $user_data['country_id']         = $address_data['Country'];
	   $user_data['state_id']         = $address_data['State'];
	   $user_data['city_id']         = $address_data['City'];
	   $user_data['user_type_id']    = 3;
	   $this->db->insert('gc_users', $user_data);

// end User Insert  

// Open Cart Table

	// $reg = array('firstname'         => $member['First_name'],
	//              'lastname'          => $member['Last_name'],
	//              'customer_group_id' => '1',
	//              'language_id'       => '1',
	//              'email'             => $member['Email'],
	//              'telephone'         => $member['Mobile'],
	//              'status'            => '1',
	//              'email'             => $member['Email'],                         
	//              'password'          => md5($member['Mobile']),                         
	//              'Member_id'         => $Membership_ID,                         
	//             );
	//     $opencart = $this->load->database('greencrest_ecommerce', TRUE);
	//     // opencart
	//     if ($opencart->insert('oc_customer', $reg)) {
	//          $opencart->insert_id();
	//     } 

// End Open Cart Table


//start Member nominee_data Insert
		$nominee_data['Membership_ID']   = $Membership_ID;
		$nominee_data['Company_id']   = $Company_ID;
		$nominee_data['Branch_id']   = $Company_ID;
		$this->db->insert('gc_member_nominees', $nominee_data);
//end Member nominee_data Insert

//start Member bank_data Insert
		$bank_data['Membership_ID']   = $Membership_ID;
		$bank_data['Company_id']   = $Company_ID;
		$bank_data['Branch_id']   = $Company_ID;
		$bank_data['Created_date']   = date('Y-m-d H:i:s',strtotime($Register_date));
		$this->db->insert('gc_member_banks', $bank_data);
//end Member bank_data Insert

//start Member contract_data Insert
		if($member['Membership_type']==1){
			if(isset($contract_data)){
			if(!empty($contract_data)){
			$contract_data['Topup_id']        =1;               
			$contract_data['Membership_type'] =$member['Membership_type'];
			$contract_data['Aggreement_mode'] =$member['Aggreement_mode'];
			$contract_data['Surety_mode']     =$member['Surety_mode'];
			$contract_data['Membership_ID']   = $Membership_ID;
			$contract_data['Payout_ID']       =2;
			$contract_data['Final_commission_per']=10;
			$increment_code1                  = $this->db->count_all_results('gc_member_franchisee_contract')+1;
			$contract_data['Contract_ref_no'] ="GRNC-CNT-0000".$increment_code1;
			$contract_data['Company_id']      = $Company_ID;
			$contract_data['Branch_id']       = $Company_ID;
			$contract_data['Branch_id']       = $Company_ID;
			$contract_data['Date']            = $Register_date;
			if($this->db->insert('gc_member_franchisee_contract', $contract_data)){
				$Contract_ID=$this->db->insert_id();
			}
			}
			//$Contract_ID='';

			// if($contract_data['Membership_type']==2){
			//     $contract_data['Payment_status']=6;
			//     $contract_data['Pay_percentage']=0;
			//     $contract_data['Payment_status_date']=$Register_date;
			// }

		}
		}
			
//end Member contract_data Insert

//start Member payment_data Insert
		if($member['Membership_type']==1){
		if(isset($payment_data)){
			if(!empty($payment_data)){
				foreach($payment_data as $key =>$payment)
			{
				// if($contract_data['Membership_type']==2){
				//     $payment['Payment_status']   = 6;
				// }
				$payment['Membership_ID']   = $Membership_ID;
				$payment['Contract_ID']   = $Contract_ID;
				$payment['Company_id']   = $Company_ID;
				$payment['Branch_id']   = $Company_ID;
				//$payment['Date']   = date('Y-m-d',strtotime($payment_data['Date']));
				$payment['Payment_status']   = 5;
				$payment['Created_date']   = $Register_date;
				$payment['Created_by']   = 1;
				$payment_data[$key]=$payment;
			}
			$this->db->insert_batch('gc_member_payments', $payment_data);
			}
			
		}    
	}
//end Member payment_data Insert

//start Member agreement_data Insert
	if($member['Membership_type']==1){
		if(isset($agreement_data)){
			if(!empty($agreement_data)){
			$agreement_data['Membership_ID']   = $Membership_ID;
			$agreement_data['Contract_ID']   = $Contract_ID;
			$agreement_data['Company_id']   = $Company_ID;
			$agreement_data['Date']   = $Register_date;
			$agreement_data['Branch_id']   = $Company_ID;
			if(!empty($agreement_data['Cheque_date'])){
				$agreement_data['Cheque_date']   = date('Y-m-d',strtotime($agreement_data['Cheque_date']));
			}else{
				$agreement_data['Cheque_date']='';
			}
			
			$this->db->insert('gc_member_agreement', $agreement_data);
			}
			
		}
	}
//end Member agreement_data Insert

// BV Values Data Insert Start
			// $bv_empty_data=array('Company_id' => $Company_ID,
			//                      'Branch_id' => $Company_ID,
			//                      'Membership_ID' => $Membership_ID);
			// $this->db->insert('gc_bv_values', $bv_empty_data);

// BV Values Data Insert End        


//start Member Franchisee Member Relationship Insert
		$franchisee_relation['Child_ID']        = $Membership_ID;
		$franchisee_relation['Level_type_ID']   = 1;
		$franchisee_relation['Parent_id']   = $member['Reference_ID'];
		// $franchisee_relation['Position']   = 1;
		$this->db->where('Parent_ID',$member['Reference_ID']);  
		$member_seq = $this->db->count_all_results('gc_franchisee_member_relation')+1;

		$franchisee_relation['Position']   = $member_seq;
		if($franchisee_relation['Position'] % 2 == 0){ 
			$determin = "2";  
		}else{ 
			$determin = "1"; 
		}
		$franchisee_relation['Determination']   = $determin;
		$franchisee_relation['Company_id']   = $Company_ID;
		$franchisee_relation['Branch_id']   = $Company_ID;
		$franchisee_relation['Date']   = $Register_date;
		$this->db->insert('gc_franchisee_member_relation', $franchisee_relation);
//end Member Franchisee Member Relationship Insert

//start Member binary Member Relationship Insert
		// $binary_relation['Child_ID']        = $Membership_ID;
		// $binary_relation['Level_type_ID']   = 2;
		// $binary_relation['Refer_parent_ID']   = $member['Reference_ID'];
		// $binary_relation['Position']   = $member_seq;
		//     $parent_id=$binary_relation['Refer_parent_ID'];
		//     if($binary_relation['Position'] % 2 == 0){ // determination if Start
		//          $p_type=2;
		//         $determin = 2;
		//         if($parent_id==1){
		//             $Ex_position_type=2;
		//         }
		//         else{
		//             $this->db->select('*');
		//             $this->db->where('Child_ID',$parent_id);
		//             $query = $this->db->get('gc_binary_member_relation');
		//             $binary=$query->result_array();
		//             $Ex_position_type=$binary[0]['Ex_position_type'];
		//         }

		//         }  // determination if End

		//     else{  // determination else Start
		//         $p_type=1;
		//         $determin = 1;
		//         if($parent_id==1){
		//             $Ex_position_type=1;
		//             }
		//         else{
		//             $this->db->select('*');
		//             $this->db->where('Child_ID',$parent_id);
		//             $query = $this->db->get('gc_binary_member_relation');
		//             $binary=$query->result_array();
		//             $Ex_position_type=$binary[0]['Ex_position_type'];
		//         }
		//     } // determination else End

		//                 $limit=1;
		//                 for($i=1;$i<=$limit;$i++){
		//                     $this->db->select('*');
		//                     $this->db->where('Position_type',$p_type);
		//                     $this->db->where('Ex_position_type',$Ex_position_type);
		//                     $this->db->where('Parent_ID',$parent_id);
		//                     $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
		//                     $query4 = $this->db->get('gc_binary_member_relation');
		//                     if($query4->num_rows() > 0){
		//                         $binary4=$query4->result_array();
		//                         $parent_id=$binary4[0]['Child_ID'];
		//                         $limit++;
		//                     }
			
		//                 }
		// $binary_relation['Determination']   = $determin;
		// $binary_relation['Position_type']   = $p_type;
		// $binary_relation['Ex_position_type']   = $Ex_position_type;
		// $binary_relation['Parent_id']    =  $parent_id;
		// $binary_relation['Company_id']   =  $Company_ID;
		// $binary_relation['Branch_id']    =  $Company_ID;
		// $binary_relation['Date']   = $Register_date;
		
		// $this->db->insert('gc_binary_member_relation', $binary_relation);
//end Member binary Member Relationship Insert

$member_update['Members_count']   = $member_seq;
$this->db->where('Membership_ID', $member['Reference_ID']);
$this->db->update('gc_membership', $member_update);

			


//start Member binary Member Levels Insert
$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$member['Reference_ID']);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			//var_dump($binary);
			$crnt_lvl=$binary[0]['Current_level'];
			 $level['Level_ID']=$i;
			if($crnt_lvl<=$i){
			$member_level=$i;
			}
			else{
				$member_level=$crnt_lvl;
			}
			$ref_ID=$binary[0]['Reference_ID'];
 // Member Level Master Insert start
			$levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_master['Company_id']       =  $Company_ID;
			$levels_master['Branch_id']        =  $Company_ID;
			$levels_master['Level_ID']         =  1;
			$levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_master['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_master['Date']   = $Register_date;
			$this->db->insert('gc_member_levels', $levels_master);
			$level_insert_id=$this->db->insert_id();

// Member Level Master Insert end         
// Member Level Details Insert start 
			$levels_data['Member_level_ID']  =  $level_insert_id;
			$levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_data['Child_ID']         =  $Membership_ID;
			$levels_data['Company_id']       =  $Company_ID;
			$levels_data['Branch_id']        =  $Company_ID;
			$levels_data['Level_ID']         =  $level['Level_ID'];
			// $levels_data['Position']         =  $binary_relation['Ex_position_type'];
			$levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_data['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_data['Level_date']   = $Register_date;
			$this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start
// Membership Current Level Insert start
			$mem_lvl['Current_level']=$member_level;
			
			$this->db->where('Membership_ID',$binary[0]['Membership_ID']);
			$this->db->update('gc_membership', $mem_lvl);
// Membership Current Level Insert end

		}
	}
	else{
			$this->db->select('*');
			$this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
			if($crnt_lvl<=$i){
			$member_level=$i;
			}
			else{
				$member_level=$crnt_lvl;
			}
			$ref_ID=$binary[0]['Reference_ID'];

 // Member Level Master Insert start
			$levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_master['Company_id']       =  $Company_ID;
			$levels_master['Branch_id']        =  $Company_ID;
			$levels_master['Level_ID']         =  $level['Level_ID'];
			$levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_master['Payout_status']    =  $binary[0]['Payout_status'];
			$this->db->insert('gc_member_levels', $levels_master);
			$levels_master['Date']             = $Register_date;
			$level_insert_id=$this->db->insert_id();
// Member Level Master Insert end         
// Member Level Details Insert start 
			$levels_data['Member_level_ID']  =  $level_insert_id;
			$levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_data['Child_ID']         =  $Membership_ID;
			$levels_data['Company_id']       =  $Company_ID;
			$levels_data['Branch_id']        =  $Company_ID;
			$levels_data['Level_ID']         =  $level['Level_ID'];
			// $levels_data['Position']         =  $binary_relation['Ex_position_type'];
			$levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_data['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_data['Level_date']       = $Register_date;
			$this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start

// Membership Current Level Insert start
			$mem_lvl['Current_level']=$member_level;
			$this->db->where('Membership_ID',$binary[0]['Membership_ID']);
			$this->db->update('gc_membership', $mem_lvl);
// Membership Current Level Insert end            
			
// Membership Member Grade Update start            

//             $level_counts=[];
//             $grade_ids=[];
//             for($j=1;$j<=9;$j++){
//                 $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
//                 $this->db->where('Level_ID',$j);
//                 $mem_counts =  $this->db->count_all_results('gc_member_levels');
//                 $level_counts['Level_'.$j]=$mem_counts;
//             }
//             //var_dump($level_counts);
//                 $this->db->select('*');
//                 $this->db->where('Status',1);
//                 $query =  $this->db->get('gc_grade');
//                  if($query->num_rows() > 0) {
//                 $grade=$query->result_array();

//                 foreach($grade as $gradevals){
//                     foreach($level_counts as $lvl){
//                         $array=[];
// $a=0;

//   if($lvl['Level_1'] >= $gradevals['Level_1_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_2'] >= $gradevals['Level_2_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_3'] >= $gradevals['Level_3_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_4'] >= $gradevals['Level_4_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_5'] >= $gradevals['Level_5_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_6'] >= $gradevals['Level_6_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_7'] >= $gradevals['Level_7_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_8'] >= $gradevals['Level_8_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;
//   if($lvl['Level_9'] >= $gradevals['Level_9_count']){
//       $array[$a]=1;
//       }else{
//       $array[$a]=0;
//       }
//       $a++;

//       $check=in_array(1, $array) < 0;
//       if($check==true){
//         array_push($grade_ids,$gradevals['ID']);
//       //echo 'insert'.'<br>';
//   }
//   else{
//   //echo 'do nothing'.'<br>';
// }
//                     }
//                 }
//                 //var_dump($grade_ids);
//                 if(!empty($grade_ids)){
//                 $this->db->select('ID,min(Grade_level) as Grade_level');
//                 $this->db->where('Status',1);
//                 $this->db->where_in('ID',$grade_ids);
//                 $least=$this->db->get('gc_grade');
//                 if($least->num_rows() > 0) {
//                    $least_c=$least->row();
//                 $inserting_grade=$least_c->ID;
//                 $membership_data['Member_grade']=$inserting_grade;
//                 $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
//                 $this->db->update('gc_membership',$membership_data);
//                 }
//             }

//             }
		
// Membership Member Grade Update end


				}

			}
		}
	}
 
 public function add_membership_upgrade($contract_data,$agreement_data)
 {
	 //start Member contract_data Insert
		if(isset($contract_data)){
			$mem=$this->db->get_where('gc_membership',array('Membership_ID' => $contract_data['Membership_ID']))->row();
			$reg_date=$contract_data['Reg_date'];
			unset($contract_data['Reg_date']);
			$payout=$mem->Payout_ID;
			$increment_code1 = $this->db->count_all_results('gc_member_franchisee_contract')+1;
			$contract_data['Contract_ref_no']   ="GRNC-CNT-0000".$increment_code1;
			$contract_data['Company_id']        = $this->session->userdata('CompanyId');
			$contract_data['Branch_id']         = $this->session->userdata('CompanyId');
			$contract_data['Payout_ID']         = $payout;
			$count=$this->db->where('Membership_ID',$contract_data['Membership_ID'])->count_all_results('gc_member_franchisee_contract');
			if ($count>0) {
			   $contract_data['Invest_type']                      = 2;
			}else{
				$contract_data['Invest_type']                     = 1;
			}
			
			$contract_data['Topup_id']          = 1;
			$contract_data['Date']              = date('Y-m-d',strtotime($reg_date));
			$contract_data['Payment_status_date']              = date('Y-m-d',strtotime($reg_date));
			$contract_data['Aggreement_mode']   = $agreement_data['Aggreement_mode'];
			$contract_data['Surety_mode']       = $agreement_data['Surety_mode'];
			$contract_data['Created_date']      = date('Y-m-d');
			//var_dump($contract_data);
			if($this->db->insert('gc_member_franchisee_contract', $contract_data)){
				$Contract_ID=$this->db->insert_id();
			}
		  
		}    
//end Member contract_data Insert
//
		$wallet_balance  =  $this->get_wallet_balance($contract_data['Membership_ID']);
		$wallet_data=array('Wallet_balance' => $wallet_balance[0]['Wallet_balance']-$contract_data['Amount']);
		$this->db->where('Membership_ID', $contract_data['Membership_ID']);
		$this->db->update('gc_membership', $wallet_data);

$mem_qry = $this->db->get_where('gc_membership', array('Membership_ID' => $contract_data['Membership_ID']))->result_array();
if(!empty($mem_qry)){
	$activate=$this->topup_activate($contract_data['Membership_ID'],$Contract_ID,$mem_qry[0]['Commission_mode'],$mem_qry[0]['Final_commission_per'],$contract_data['Membership_type'],$mem_qry[0]['Payout_ID'],$contract_data['Amount'],$reg_date);
}




//start Member payment_data Insert
		// if(isset($payment_data)){
		//     foreach($payment_data as $key =>$payment)
		//     {
		//         $payment['Membership_ID']   = $contract_data['Membership_ID'];
		//         $payment['Contract_ID']   = $Contract_ID;
		//         $payment['Company_id']   = $this->session->userdata('CompanyId');
		//         $payment['Branch_id']   = $this->session->userdata('CompanyId');
		//         $payment['Payment_status']   = 5;
		//         $payment['Invest_type']   = 2;

		//         $payment_data[$key]=$payment;
		//     }
		//     $this->db->insert_batch('gc_member_payments', $payment_data);
		// }    
//end Member payment_data Insert
//
//start Member agreement_data Insert
		// if(isset($agreement_data)){
		//     $agreement_data['Membership_ID']   = $contract_data['Membership_ID'];
		//     $agreement_data['Contract_ID']   = $Contract_ID;
		//     $agreement_data['Company_id']   = $this->session->userdata('CompanyId');
		//     $agreement_data['Branch_id']   = $this->session->userdata('CompanyId');
		//     $this->db->insert('gc_member_agreement', $agreement_data);
		// }
//end Member agreement_data Insert
 }

public function topup_activate($Membership_ID,$Contract_ID,$Commission_mode,$cmsn_per,$Memberhip_type,$Membership_payout,$contract_amount,$reg_date){

	$up_data['Membership_type']=$Memberhip_type;
	$this->db->where('Membership_ID',$Membership_ID);
	$this->db->update('gc_membership',$up_data);

	$this->db->select('topup.Validity,topup.Value,topup.Return,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Multiples,contract.Amount');
		$this->db->from('gc_member_topup as topup');
		

		$this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');
		// $this->db->join('gc_membership as member', 'member.Payout_ID = topup.ID', 'left');

		$this->db->where('contract.Contract_ID',$Contract_ID);
		$this->db->where('contract.Membership_ID',$Membership_ID);
		$query = $this->db->get();
		$contract=$query->result_array();

		$tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();
		$contract=$this->db->get_where('gc_member_franchisee_contract',array('Contract_ID' => $Contract_ID,'Membership_ID' => $Membership_ID))->result_array();
// var_dump($contract);die();
		if(!empty($tp)){
			$month=$tp[0]['Validity'];
			// $Amount=$contract[0]['Value']*$contract[0]['Multiples'];
			
			// $Return=$tp[0]['Return'];
			// $pay_flag=$contract[0]['Pay_flag'];

			// if($contract[0]['Payout_status']==2){
			//     $payout_id=$contract[0]['New_payout_ID'];
			// }else{
			//     $payout_id=$contract[0]['Old_payout_ID'];
			// }
		}else{
			$month=0;
			
			// $Return=0;
			// $pay_flag=2;
		}

		// if(!empty($contract)){
		// 	$Amount=$contract[0]['Amount'];
		// }else{
		// 	$Amount=0;
		// }

		$Return=$cmsn_per;
		$Amount=$contract_amount;
		$new_pay=$Return;
		// $mem_qry = $this->db->select('Membership_ID,Payout_ID,Membership_type')->get_where('gc_membership', array('Membership_ID' => $Membership_ID))->result_array();
		// if(!empty($mem_qry[0]['Payout_ID'])){
		//     $payout_id=$mem_qry[0]['Payout_ID'];
		// }else{
			$payout_id=$Membership_payout;
		//}

		$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();
		if(!empty($py_qry)){
			$pay_flag=$py_qry[0]['Pay_flag'];
			$py_days=$py_qry[0]['Days']-1;
		}else{
			$pay_flag=2;
			$py_days=15-1;
		}

		// if($Commission_mode==2){
		//     $new_pay=$Return+($cmsn_per/$pay_flag);
		// }else{
		//     $new_pay=$Return;
		// }


// Memberhsip Update end
		$data['Status']=6;
		$data['Commission_mode']=$Commission_mode;
		$data['Final_commission_per']=$new_pay;
		$data['Payout_ID']=$payout_id;
		
	  //   if($Commission_mode==2){
	  //     $data['Commission_per']=$cmsn_per;  
	  // }else{
	  //       $data['Commission_per']=0;
	  // }
	  // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  $Pay_date=date('Y-m-d', strtotime($reg_date. ' + '.$py_days.' days'));
	  $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  $lvl_py_days=15-1;
	  // $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$lvl_py_days.' days')));
	  $Lvl_pay_date=date('Y-m-d', strtotime($reg_date. ' + '.$lvl_py_days.' days'));
	  $data['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));

	  $next_exact_payout=$this->get_excat_next_payout($Pay_date);
	  // if($pay_flag==1){
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }else{
	  //   $py_days=15;
	  //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
	  //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
	  // }
		
	  // var_dump($data);die();
		// $data['Activated_date']=date('Y-m-d H:i:s');
		// $this->db->where('Membership_ID',$Membership_ID);
		// $this->db->update('gc_membership',$data);


// Membership Update end 
// Transaction Insert Start        
		$transaction=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $Membership_ID, 
							'Contract_ID' => $Contract_ID, 
							'Transaction_type' => 1,
							'Transaction_date' => $reg_date, 
							'Remarks' => '', 
							'Created_by' => $this->session->userdata('UserId') 
						);
		$this->db->insert('gc_transaction',$transaction);
		$transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
		$Comission_amount=$Amount*$new_pay/100;
		$transaction_detail=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $Membership_ID, 
							'Contract_ID' => $Contract_ID,
							'Member_level_detail_ID' => NULL, 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 1, 
							'Payout_ID' => $payout_id,
							'Amount' => $Comission_amount, 
							'Commision' => $Return,
							'New_pay_percent' => $new_pay,
							'Remarks' => '' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail);
// Transaction Detail (Top-up) Insert End   

// Transaction History (Debit) Insert start 
$history_data=array(
				 'Company_id'               => $this->session->userdata('CompanyId'),
				 'Branch_id'                => $this->session->userdata('CompanyId'), 
				 'Membership_ID' => $Membership_ID,
				 'Contract_ID'   => $Contract_ID,
				 'Payout_ID' => $payout_id,
				 'Date'  => $reg_date,
				 'History_for'   => ' Topup Amount of  '.$Amount,
				 'Credit_amount' => 0,
				 'Debit_amount' => $Amount,
				  );
			$this->db->insert('gc_transaction_history',$history_data);  

// Transaction History (Debit) Insert End  

// Transaction Details (Direct&Push-up) Insert Start
		$this->db->select('Reference_ID');
		$this->db->from('gc_membership');
		$this->db->where('Membership_ID',$Membership_ID);
		$query = $this->db->get();
		$membership=$query->result_array();

if($Commission_mode==1){ // Level Commission OR Self Commission is Start
	$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$membership[0]['Reference_ID']);
			$this->db->where('member.Commission_mode',1);
			$this->db->where('member.Membership_type',1);
			//$this->db->where('contract.Contract_status',6);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){
			$crnt_lvl=$binary[0]['Current_level'];
			//if($crnt_lvl<=$i){
			$level['Level_ID']=$i;
			//}
			//else{
			   //$level['Level_ID']=$crnt_lvl;
			//}
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			$this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();


			$Comission_amount1=$Amount*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
				if($level_details[0]['Payout_status']==2){
				$payout_id1=$level_details[0]['New_payout_ID'];
				}else{
				$payout_id1=$level_details[0]['Old_payout_ID'];
						}
					}
// Transaction Details Insert start 
$transaction_detail1=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $binary[0]['Membership_ID'], 
							'Contract_ID' => $binary[0]['Contract_ID'],
							'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 2,
							'Payout_ID' => $payout_id1, 
							'Amount' => $Comission_amount1, 
							'Commision' => $level_details[0]['Return'],
							'Remarks' => '' 
						);
		$this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start

			}
		}
	}
	else{
			$this->db->select('*');
			$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$this->db->where('member.Commission_mode',1);
			$this->db->where('member.Membership_type',1);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			if($binary[0]['Commission_mode']==1){

			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
		   //  if($crnt_lvl<=$i){
			
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
			$ref_ID=$binary[0]['Reference_ID'];

			$this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount,contract.Payout_ID');
			$this->db->from('gc_member_level_details as level');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			$this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
			$this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
			$this->db->where('level.Child_ID',$Membership_ID);
			$this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
			$query= $this->db->get();
			$level_details=$query->result_array();
						$Comission_amount1=$level_details[0]['Value']*($level_details[0]['Return']/2)/100;
			$this->db->select('Payout_type');
			$this->db->from('gc_level');
			$this->db->where('ID',$level['Level_ID']);
			$query_lvl= $this->db->get();
			if($query_lvl->num_rows() > 0) {
			$level_payout=$query_lvl->result_array();
			$payout_id1=$level_payout[0]['Payout_type'];
			}else{
						if($level_details[0]['Payout_status']==2){
						$payout_id1=$level_details[0]['New_payout_ID'];
						}else{
						$payout_id1=$level_details[0]['Old_payout_ID'];
						$payout_id1=$level_payout[0]['Payout_type'];
						}
					}
// Transaction Details Insert start 
$transaction_detail1=array(
							'Company_id' => $this->session->userdata('CompanyId'),
							'Branch_id' => $this->session->userdata('CompanyId'), 
							'Membership_ID' => $binary[0]['Membership_ID'], 
							'Contract_ID' => $binary[0]['Contract_ID'],
							'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
							'Transaction_ID' => $transaction_id, 
							'Commision_type' => 3,
							'Payout_ID' => $payout_id1, 
							'Amount' => $Comission_amount1, 
							'Commision' => $level_details[0]['Return'],
							'Remarks' => ''  
						);
		$this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
// Transaction Details (Direct&Push-up) Insert End        
					}
				}

			}
		}
} // Level Commission OR Self Commission is End
		// $user_data = array('status' => 1 );
		// $this->db->where('user_id',$Membership_ID);
		// $this->db->update('gc_users',$user_data);

		$data1['Start_date']=date('Y-m-d',strtotime($reg_date));

		// $data1['End_date']=date('Y-m-d', strtotime('+'.$month.'months'));
		$data1['End_date']=date('Y-m-d', strtotime($reg_date. ' + '.$month.' months'));
		$data1['Contract_status']=6;
		$data1['Commission_mode']=$Commission_mode;
		$data1['Final_commission_per']=$new_pay;
		$data1['Pay_date']=$Pay_date;
		$data1['Lvl_pay_date']=$Lvl_pay_date;
		$data1['Payout_date']=$next_exact_payout;
	  //   if($Commission_mode==2){
	  //     $data1['Commission_per']=$cmsn_per;  
	  // }else{
	  //       $data1['Commission_per']=0;
	  // }
		$data1['Contract_status_date']=date('Y-m-d',strtotime($reg_date));
		$this->db->where('Membership_ID',$Membership_ID);
		$this->db->where('Contract_ID',$Contract_ID);
		$this->db->update('gc_member_franchisee_contract',$data1);
		

}

  public function add_membership_upgrade_by_excel($contract_data,$payment_data,$agreement_data,$Register_date)
 {
	 //start Member contract_data Insert
		if(isset($contract_data)){
			
			$increment_code1 = $this->db->count_all_results('gc_member_franchisee_contract')+1;
			$contract_data['Contract_ref_no']="GRNC-CNT-0000".$increment_code1;
			$contract_data['Company_id']   = $this->session->userdata('CompanyId');
			$contract_data['Branch_id']   = $this->session->userdata('CompanyId');
			$contract_data['Invest_type']   = 2;
			$contract_data['Topup_id']   = 1;
			$contract_data['Created_date']      = date('Y-m-d');
			// var_dump($contract_data);
			if($this->db->insert('gc_member_franchisee_contract', $contract_data)){
				$Contract_ID=$this->db->insert_id();
			}
			//$Contract_ID=36;
		}    
//end Member contract_data Insert
//
//start Member payment_data Insert
		if(isset($payment_data)){
				$payment_data['Membership_ID']   = $contract_data['Membership_ID'];
				$payment_data['Contract_ID']   = $Contract_ID;
				$payment_data['Company_id']   = $this->session->userdata('CompanyId');
				$payment_data['Branch_id']   = $this->session->userdata('CompanyId');
				$payment_data['Payment_status']   = 5;
				$payment_data['Invest_type']   = 2;
				$payment_data['Date']   = $Register_date;
			$this->db->insert('gc_member_payments', $payment_data);
		}    
//end Member payment_data Insert
//
//start Member agreement_data Insert
		if(isset($agreement_data)){
			$agreement_data['Membership_ID']   = $contract_data['Membership_ID'];
			$agreement_data['Contract_ID']   = $Contract_ID;
			$agreement_data['Company_id']   = $this->session->userdata('CompanyId');
			$agreement_data['Branch_id']   = $this->session->userdata('CompanyId');

			$this->db->insert('gc_member_agreement', $agreement_data);
		}
//end Member agreement_data Insert
 }

	 public function member_profile_attachment($dir) { 

				  // create an album if not already exist in uploads dir
				  // wouldn't make more sence if this part is done if there are no errors and right before the upload ??
				  //var_dump($dir);
				  if (!is_dir('./attachments/Members/' .$dir))
				  {
					  mkdir('./attachments/Members/' .$dir, 0777, true);
				  }
				  $dir_exist = true; // flag for checking the directory exist or not
				  if (!is_dir('./attachments/Members/' .$dir))
				  {
					  mkdir('./attachments/Members/' .$dir, 0777, true);
					  $dir_exist = false; // dir not exist
				  }
					  
				 $config['upload_path']          = './attachments/Members/'.$dir.'/';
				 $config['allowed_types']        = 'gif|jpg|png|doc|pdf|docx';
				 $config['max_size']             = 10000; 
				 $new_name                       = $dir.'_Profile';
				 $config['file_name']            = $new_name;
				  

				$this->load->library('upload', $config);

				if ( ! $this->upload->do_upload('Photo'))
				{
						 $error = array('error' => $this->upload->display_errors());
						  $file_name = '';
						  return $error;                     
				}
				else
				{
						$data = array('upload_data' => $this->upload->data());
						$upload_data = $this->upload->data(); 
						$file_name =   $upload_data['file_name'];
						
						return $file_name;
				}
		}        


	public function member_profile_attachment_1($ref_no,$profile_name,$name) {     
		 // var_dump($profile_name);
		 // var_dump($name);

		   if (!is_dir('./attachments/Members/'.$ref_no))
				  {
					  mkdir('./attachments/Members/'.$ref_no, 0777, true);
				  }
				  $dir_exist = true; // flag for checking the directory exist or not
				  if (!is_dir('./attachments/Members/'.$ref_no))
				  {
					  mkdir('./attachments/Members/'.$ref_no, 0777, true);
					  $dir_exist = false; // dir not exist
				  }

		 $config['upload_path']          = './attachments/Members/'.$ref_no.'/';
		 $config['allowed_types']        = 'gif|jpg|png';
		 $new_name                       = $ref_no.'_'.$name;
		 $config['file_name']            = $new_name;
		 //var_dump($config['file_name']);
		 
				$this->load->library('upload', $config);
				$this->upload->initialize($config);

				if ( ! $this->upload->do_upload($profile_name))
				{
						$error = array('error' => $this->upload->display_errors());
						$file_name = '';
						//print_r($error);
						 return $file_name;                 
				}
				else
				{   
						$data = array('upload_data' => $this->upload->data());
						$upload_data = $this->upload->data(); 
						$file_name =   $upload_data['file_name'];
						// die();
						return $file_name;
				}

	}

	function get_contract_details($mobile) {

		$this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Photo,member.Mobile,contract.*,type.Membership_type as Membership_name,topup.Franchise,payout.Payout_type,topup.Value,topup.Validity,topup.Return,banks.Status as bank_status,contract.Start_date,contract.End_date,aggrement.Delivery_mode,aggrement.Referer_name');
		$this->db->from('gc_membership as member');
		$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
		$this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_ID', 'left');
		$this->db->join('gc_payout_type as payout', 'payout.id = contract.Old_payout_ID', 'left');
		$this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
		$this->db->join('gc_member_banks as banks', 'banks.Member_bank_ID = member.Membership_ID', 'left');

		$this->db->join('gc_member_agreement as aggrement', 'aggrement.Membership_ID = member.Membership_ID', 'left');
		$this->db->group_by('contract.Contract_ID');
		$this->db->where('contract.Status',7);
		
		$this->db->where('contract.Membership_ID',$mobile);
		// $this->db->where('member.Membership_ID',$mobile);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return  $query->result_array();
		}
		return NULL;
	}

public function get_previous_date($cur_date){

	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);

			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
	
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

			//var_dump($week_days);
$date=new DateTime();
$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

	if($week_days[$i] == $search){
		$arr[$i] = $week_days[$i];
		$search = $week_days[$i] + 1;
	}else{
		$arr2[$i] = $week_days[$i];
	}
}

$action = array_merge($arr,$arr2);
$days = array(
	 '1' => 'Monday',
	 '2' => 'Tuesday',
	 '3' => 'Wednesday',
	 '4' => 'Thursday',
	 '5' => 'Friday',
	 '6' => 'Saturday',
	 '7' => 'Sunday'
 );
$final_dt=[];

foreach($action as $da){
if (array_key_exists($da,$days))
  {
  array_push($final_dt,$days[$da]);
  }

}

//var_dump($final_dt);
$final_dates=[];
for($i=1; $i<=52; $i++){
		foreach($final_dt as $newval){
		//date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
		array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
		}
	}
   $cur_date=date("Y-m-d", strtotime($cur_date));
	
	//var_dump($final_dates);
	foreach($final_dates as $key=> $fin){
if($cur_date==$fin){

	
	if($key>=1){
	$keyval= $key-1;
	return  $final_dates[$keyval];
}else{
	//$keyval= date("Y",strtotime("-1 year")).'-12-31';
	return  date("Y",strtotime("-1 year")).'-12-31';
}
	

}else{
	$keyval=$key;
	$final_dates[$keyval];
}
	}
	//echo $serch_date=$final_dates[$keyval];
}

	}

public function get_previous_date1($cur_date){
$final_dates=[];
$yrl_dates_0=[];
	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);

			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
	
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

				$this->db->select('Date');
				$query = $this->db->get('gc_individual_calendar');
				if ($query->num_rows() > 0) {
					$db_leave=$query->result_array();
				}else{
					$db_leave=[];
				}
				$empt_leave=[];
				foreach($db_leave as $lv){
					array_push($empt_leave,$lv['Date']);

				}
				
				//print_r($db_leave);die();
				$final_dates=array_values(array_diff($final_dates,$empt_leave));

	foreach($final_dates as $key=> $fin){
if($cur_date==$fin){

	
	if($key>=1){
	$keyval= $key-1;
	return  $final_dates[$keyval];
}else{
	//$keyval= date("Y",strtotime("-1 year")).'-12-31';
	return  date("Y",strtotime("-1 year")).'-12-31';
}
	

}else{
	$keyval=$key;
	$final_dates[$keyval];
}
	}
}

	}


	function binary_tree_old(){
		//start Member binary Member Relationship Insert
		$binary_relation['Child_ID']        = $Membership_ID;
		$binary_relation['Level_type_ID']   = 2;
		$binary_relation['Refer_parent_ID']   = $member['Reference_ID'];
		$binary_relation['Position']   = $member_seq;
		if($binary_relation['Position'] % 2 == 0){
			$determin = "2";
			$p_type ="2" ; 
		$this->db->select('*');
		$this->db->where('Position_type',$p_type);
		$this->db->where('Parent_ID',$binary_relation['Refer_parent_ID']);
		$this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
		$query1 = $this->db->get('gc_binary_member_relation');
		if ($query1->num_rows() > 0) {
			$binary=$query1->result_array();

			$this->db->select('*');
			$this->db->where('Position_type',$p_type);
			$this->db->where('Ex_position_type',$binary[0]['Ex_position_type']);
			$this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
			$query4 = $this->db->get('gc_binary_member_relation');
			$binary4=$query4->result_array();
			$parent=$binary4[0]["Child_ID"];
			$new_p_type=$binary4[0]['Ex_position_type'];

		}else{
			$parent=$binary_relation['Refer_parent_ID'];
			$this->db->select('*');
			$this->db->where('Child_ID',$binary_relation['Refer_parent_ID']);
			$query5 = $this->db->get('gc_binary_member_relation');
			$binary5=$query5->result_array();
			$new_p_type=$binary5[0]['Ex_position_type'];
		}
		}else{
			$determin = "1";
			$p_type ="1"; 
		$this->db->select('*');
		$this->db->where('Position_type',$p_type);
		$this->db->where('Parent_ID',$binary_relation['Refer_parent_ID']);
		$this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
		$query = $this->db->get('gc_binary_member_relation');
		if($query->num_rows() > 0) {
			$binary=$query->result_array();
			$this->db->select('*');
			$this->db->where('Position_type',$p_type);
			$this->db->where('Ex_position_type',$binary[0]['Ex_position_type']);
			$this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
			$query4 = $this->db->get('gc_binary_member_relation');
			$binary4=$query4->result_array();
			$parent=$binary4[0]["Child_ID"];
			$new_p_type=$binary4[0]['Ex_position_type'];
		}else{
			$parent=$binary_relation['Refer_parent_ID'];
			$this->db->select('*');
			$this->db->where('Child_ID',$binary_relation['Refer_parent_ID']);
			$query3 = $this->db->get('gc_binary_member_relation');
			$binary1=$query3->result_array();
			$new_p_type=$binary1[0]['Ex_position_type'];
		}
		}
		$binary_relation['Determination']   = $determin;
		$binary_relation['Position_type']   = $p_type;
		
		$this->db->select('*');
		$query1 = $this->db->get('gc_binary_member_relation');
		$row=$query1->num_rows();
		if($row==0){
			$binary_relation['Position_type']   = "";
			$binary_relation['Ex_position_type']   = "";
		}elseif($row==1){
			$binary_relation['Ex_position_type']   = $p_type;
		}elseif($row==2){
			$binary_relation['Ex_position_type']   = $p_type;
		}else{
			$binary_relation['Ex_position_type']   = $new_p_type;
		}

		$binary_relation['Parent_id']    =  $parent;
		$binary_relation['Company_id']   =  $Company_ID;
		$binary_relation['Branch_id']    =  $Company_ID;
		$binary_relation['Date']   = $Register_date;
		// var_dump($binary_relation);die();
		$this->db->insert('gc_binary_member_relation', $binary_relation);
//end Member binary Member Relationship Insert
	}

	function binary_tree_new(){
		//start Member binary Member Relationship Insert
		$binary_relation['Child_ID']        = $Membership_ID;
		$binary_relation['Level_type_ID']   = 2;
		$binary_relation['Refer_parent_ID']   = $member['Reference_ID'];
		$binary_relation['Position']   = $member_seq;
		// $binary_relation['Child_ID']        = 7;
		//     $binary_relation['Level_type_ID']   = 2;
		//     $binary_relation['Refer_parent_ID']   = 1;
		//     $binary_relation['Position']   = 3;
			$parent_id=$binary_relation['Refer_parent_ID'];
			if($binary_relation['Position'] % 2 == 0){ // determination if Start
				// echo 'right';
				 $p_type=2;
				$determin = 2;
				if($parent_id==1){
					// echo 'right';
					$Ex_position_type=2;
				}
				else{
					$this->db->select('*');
					$this->db->where('Child_ID',$parent_id);
					$query = $this->db->get('testing_tree');
					$binary=$query->result_array();
					$Ex_position_type=$binary[0]['Ex_position_type'];
				}

						 $limit=1;
						for($i=1;$i<=$limit;$i++){
							$this->db->select('*');
							$this->db->where('Position_type',$p_type);
							$this->db->where('Ex_position_type',$Ex_position_type);
							$this->db->where('Parent_ID',$parent_id);
							$this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
							$query4 = $this->db->get('testing_tree');
							if($query4->num_rows() > 0){
								$binary4=$query4->result_array();
								$parent_id=$binary4[0]['Child_ID'];
								$limit++;
							}
			
						}
						
			}  // determination if End
			else{  // determination else Start
				// echo 'left';
				$p_type=1;
				$determin = 1;
				if($parent_id==1){
					// echo 'left';
					$Ex_position_type=1;
					}
				else{
					$this->db->select('*');
					$this->db->where('Child_ID',$parent_id);
					$query = $this->db->get('testing_tree');
					$binary=$query->result_array();
					$Ex_position_type=$binary[0]['Ex_position_type'];
				}

						$limit=1;
						for($i=1;$i<=$limit;$i++){
							$this->db->select('*');
							$this->db->where('Position_type',$p_type);
							$this->db->where('Ex_position_type',$Ex_position_type);
							$this->db->where('Parent_ID',$parent_id);
							$this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
							$query4 = $this->db->get('testing_tree');
							if($query4->num_rows() > 0){
								$binary4=$query4->result_array();
								$parent_id=$binary4[0]['Child_ID'];
								$limit++;
							}
			
						}
						 
			}  // determination else End
			//echo $parent_id;
		$binary_relation['Determination']   = $determin;
		$binary_relation['Position_type']   = $p_type;
		$binary_relation['Ex_position_type']   = $Ex_position_type;
		$binary_relation['Parent_id']    =  $parent_id;
		$binary_relation['Company_id']   =  $Company_ID;
		$binary_relation['Branch_id']    =  $Company_ID;
		$binary_relation['Date']   = $Register_date;
		// var_dump($binary_relation);die();
		$this->db->insert('gc_binary_member_relation', $binary_relation);
//end Member binary Member Relationship Insert
	}



}



