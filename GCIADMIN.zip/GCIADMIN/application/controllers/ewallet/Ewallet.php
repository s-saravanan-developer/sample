<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Ewallet extends CI_Controller {

	public function __construct() {

		parent::__construct();

		if ($this->session->userdata('is_logged_in') == '') {
			redirect('login');
			session_destroy();

		}
		$this->load->model('master/Users_model');
		// $this->load->model('ewallet/Ewallet_model');
		$this->load->model('ewallet/Ewallet_model');
		$this->load->model('sales_point/Sales_point_model');
		$this->load->model('member/Membership_model');
		$this->load->model('Report_model');


	}

	public function index()
	{
		if(!empty($this->input->get('id'))){
			$id=decrypt($this->input->get('id'));
			$status=decrypt($this->input->get('status'));
			$template['url']=$this->input->get('url');
			$dates=$this->db->get_where('gc_membership',array('Membership_code' => $id))->result_array();
			$date=date('Y-m-d',strtotime($dates[0]['Created_date']));
			$membership=$dates[0]['Membership_ID'];
			$automatic_flag=1;

			$wlt_statuses=$this->db->get_where('gc_wallet_topup',array('Membership_ID' => $membership,'Date' => $date))->result_array();
			$wlt_status=$wlt_statuses[0]['Status'];
			$wlt_date=$wlt_statuses[0]['Processed_date'];
			$topup=$wlt_statuses[0]['Wallet_topup_ID'];


			if($wlt_status==1){
				$template['page']='ewallet/view_active_requests';
				$template['payout']    =  $this->Ewallet_model->get_today_requests($date,$id);
				
			}else{
				$date=$wlt_date;
				$template['page']='ewallet/view_wallet_later';
				$template['payout']    =  $this->Ewallet_model->get_today_pay_later1($date,$membership,$topup);
				
			}
				$this->load->model('ewallet/Ewallet_model');
				$template['sales_point']    =  $this->Sales_point_model->getall_sales_points();
				
				// var_dump($template['payout']);die();
				$template['mobile']    =  $id;
				$template['date']      =  $date;
				$template['automatic_flag']      =  $automatic_flag;
				$template['status']      =  $status;
				// $template['pre_date']=$this->get_previous_date1(date('Y-m-d'));
				$this->load->view('template',$template);

		}else{
			$id='';
			$date=date('Y-m-d');
			$automatic_flag='';
			$status='';
			$template['url']='';
			$template['page']='ewallet/view_active_requests';
		// $this->load->model('ewallet/Ewallet_model');
		$this->load->model('ewallet/Ewallet_model');
		$template['sales_point']    =  $this->Sales_point_model->getall_sales_points();
		$template['payout']    =  $this->Ewallet_model->get_today_requests($date,$id);
		// var_dump($template['payout']);die();
		$template['mobile']    =  $id;
		$template['date']      =  $date;
		$template['automatic_flag']      =  $automatic_flag;
		$template['status']      =  $status;
		// $template['pre_date']=$this->get_previous_date1(date('Y-m-d'));
		$this->load->view('template',$template);

		}


		
		// $template['page']='ewallet/view_active_requests';
		// // $this->load->model('ewallet/Ewallet_model');
		// $this->load->model('ewallet/Ewallet_model');
		// $template['sales_point']    =  $this->Sales_point_model->getall_sales_points();
		// $template['payout']    =  $this->Ewallet_model->get_today_requests($date,$id);
		// // var_dump($template['payout']);die();
		// $template['mobile']    =  $id;
		// $template['date']      =  $date;
		// $template['automatic_flag']      =  $automatic_flag;
		// $template['status']      =  $status;
		// // $template['pre_date']=$this->get_previous_date1(date('Y-m-d'));
		// $this->load->view('template',$template);
		
	}



public function update_payment_data(){

extract($_POST);


if (isset($_POST['update']) || isset($_POST['unverified']) || isset($_POST['reupload'])) {
	
        foreach ($payment_data as $key => $value) {

			$name='Payment_'.$key;
			$file_name='upload'.$key;

			$photo_name = $this->payment_attachment($Membership_code,$file_name,$name);
			if (!empty($photo_name)) {
				$value['Photo_path'] = "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/'.$photo_name;
				$value['Statement'] = "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/'.$photo_name;
			}		

			$value['Date']=date('Y-m-d',strtotime($value['Date']));
			$this->db->where('Payment_ID',$value['Payment_ID']);
			$this->db->update('gc_wallet_payments',$value);
		}

		if (isset($_POST['update']) || isset($_POST['unverified'])) {
			$mbr_data['Payment_verify']=9;
			$wlt_data['Status']=4; 
		}else{
			$mbr_data['Payment_verify']=5;
			$wlt_data['Status']=1; 
		}
		$this->db->where('Membership_code',$Membership_code);
		$this->db->update('gc_membership',$mbr_data);

						date_default_timezone_set('Asia/Kolkata');
						$remark='-[Payment_verify_pending_reupload@'.date('Y-m-d H:i:s').']';
						$this->db->where('Membership_code',$Membership_code);
						$this->db->set('Update_history', "CONCAT(Update_history,'$remark')", FALSE);   
						$this->db->update('gc_membership');

		
		$wlt_data['Processed_date']=date('Y-m-d');
		$this->db->where('Wallet_topup_ID',$Wallet_topup_ID);
		$this->db->update('gc_wallet_topup',$wlt_data);

		if(isset($_POST['update'])){
			redirect('ewallet/Ewallet');
		}elseif(isset($_POST['unverified'])){
			redirect('membership/Membership/payment_members');
		}else{
			if($redirect_flag==1){
				redirect('ewallet/Ewallet/pay_later');
			}else{
				redirect('membership/Membership/payment_reupload_members');	
			}
			
		}

    }elseif(isset($_POST['verify_payment']) || isset($_POST['normal_verify_payment'])) {
        
        foreach ($payment_data as $key => $value) {

			$name='Payment_'.$key;
			$file_name='upload'.$key;

			$photo_name = $this->payment_attachment($Membership_code,$file_name,$name);
			if (!empty($photo_name)) {
				$value['Photo_path'] = "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/'.$photo_name;
				$value['Statement'] = "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/'.$photo_name;
			}		

			$value['Date']=date('Y-m-d',strtotime($value['Date']));
			$value['Payment_status']=6;
			$this->db->where('Payment_ID',$value['Payment_ID']);
			$this->db->update('gc_wallet_payments',$value);
		}

		


		$reg_date=date('Y-m-d',strtotime($payment_data[0]['Date']));
		$payment_mode=$payment_data[0]['Payment_type_ID'];


		$query = $this->db->get_where('gc_wallet_topup', array('Wallet_topup_ID' => $Wallet_topup_ID))->result_array();
				// var_dump($query);
				if(!empty($query)){	

				if($query[0]['Wallet_amount_from']==2){
						$query2 = $this->db->get_where('gc_service_wallet', array('Service_point_ID' => $query[0]['Wallet_service_point']))->result_array();
					if(count($query2)>0){
						if($query2[0]['Wallet_balance']>=$query[0]['Total_amount']){
							$wallet_data=array(
									  'Wallet_balance'=>$query2[0]['Wallet_balance']-$query[0]['Total_amount'],
									  'Updated_date'=>date('Y-m-d'));
							$this->db->where('Service_point_ID',$query[0]['Wallet_service_point']);
							$this->db->update('gc_service_wallet',$wallet_data);

							$query3 = $this->db->get_where('gc_users', array('id' => $query[0]['Wallet_service_point']))->result_array();
						$user_data=array('Wallet_balance'=>$query3[0]['Wallet_balance']-$query[0]['Total_amount']);
						$this->db->where('id',$query[0]['Wallet_service_point']);
						$this->db->update('gc_users',$user_data);

						// $query1 = $this->db->get_where('gc_membership', array('Membership_ID' => $query[0]['Membership_ID']))->result_array();
						// 	$member_data['Wallet_balance']=$query1[0]['Wallet_balance']+$query[0]['Total_amount'];
						// 	$this->db->where('Membership_ID',$query[0]['Membership_ID']);
						// 	$this->db->update('gc_membership',$member_data);

						

						// Contract Insert Start
						// $reg_date=$contract_data['Reg_date'];
      //       			unset($contract_data['Reg_date']);

            			// Contract Insert END

						}
							
						}
					}

						$data_status['Status']=6;
						$data_status['Processed_date']=date('Y-m-d');
						$this->db->where('Wallet_topup_ID',$Wallet_topup_ID);
						$this->db->update('gc_wallet_topup',$data_status);

					   $tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();

            			$payout_id=2;
            			if(!empty($tp)){
            				$cmsn_percentage=$tp[0]['Return'];
            				$month=$tp[0]['Validity'];
            			}else{
            				$cmsn_percentage=20;
            				$month=10;
            			}

            			$py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();
       					 
       					 if(!empty($py_qry)){
       					     $pay_flag=$py_qry[0]['Pay_flag'];
       					     $py_days=$py_qry[0]['Days']-1;
       					 }else{
       					     $pay_flag=2;
       					     $py_days=15-1;
       					 }
       					 
       					 $cmsn_per=$cmsn_percentage/$pay_flag;

       					 $membership_ID=$query[0]['Membership_ID'];
            			
            			// $increment_code1 = $this->db->count_all_results('gc_member_franchisee_contract')+1;
            			// $contract_data['Contract_ref_no']   ="GRNC-CNT-0000".$increment_code1;
            			$increment_code1=(substr($this->db->select('Contract_ref_no')->order_by('Contract_ID','desc')->limit(1)->get('gc_member_franchisee_contract')->row('Contract_ref_no'),9))+1;
						$contract_data['Contract_ref_no'] ='GRNC-CNT-'.sprintf("%'.06d", $increment_code1);
						
            			$contract_data['Company_id']        = $this->session->userdata('CompanyId');
            			$contract_data['Branch_id']         = $this->session->userdata('CompanyId');
            			$contract_data['Payout_ID']         = $payout_id;
            			$count=$this->db->where('Membership_ID',$membership_ID)->count_all_results('			gc_member_franchisee_contract');
            			if ($count > 0) {
            			   $contract_data['Invest_type']                      = 2;
            			   $contract_data['Pay_status']      				  = 5;
            			}else{
            			    $contract_data['Invest_type']                     = 1;
            			    $contract_data['Pay_status']      				  = 6;

            			    // Memberhsip Update end
        				$mbr_data['Status']=6;
        				$mbr_data['Commission_mode']=1;
        				$mbr_data['Final_commission_per']=$cmsn_per;
        				$mbr_data['Payout_ID']=$payout_id;
     					$mbr_data['Commission_per']=0;  
     					$mbr_data['Payment_verify']=6;  
     					$mbr_data['Activated_date']=date('Y-m-d',strtotime($reg_date));
        				$mbr_data['End_date']=date('Y-m-d', strtotime($reg_date. ' + '.$month.' months'));
     					 
 						$this->db->where('Membership_ID',$membership_ID);
     					$this->db->update('gc_membership',$mbr_data);

     					date_default_timezone_set('Asia/Kolkata');
						$remark='-[Payment_verify_activation1@'.date('Y-m-d H:i:s').']';
						$this->db->where('Membership_ID',$membership_ID);
						$this->db->set('Update_history', "CONCAT(Update_history,'$remark')", FALSE);   
						$this->db->update('gc_membership');

            			}
            			
            			$contract_data['Topup_id']               = 1;
            			$contract_data['Membership_type']        = 1;
            			$contract_data['Membership_ID']          = $membership_ID;
            			$contract_data['Final_commission_per']   = $cmsn_per;
            			$contract_data['Amount']                 = $query[0]['Total_amount'];
            			$contract_data['Payment_mode']           = $payment_mode;


            			$contract_data['Date']                   = date('Y-m-d',strtotime($reg_date));
            			$contract_data['Payment_status_date']    = date('Y-m-d',strtotime($reg_date));
            			$contract_data['Payment_status']         = 6;
            			$contract_data['Aggreement_mode']        = 1;
            			$contract_data['Surety_mode']            = 1;
            			$contract_data['Created_date']           = date('Y-m-d');
            			// var_dump($contract_data);die();
            			if($this->db->insert('gc_member_franchisee_contract', $contract_data)){
            			    $Contract_ID=$this->db->insert_id();
            			}

            			

            			$activate=$this->Ewallet_model->topup_activate($membership_ID,$Contract_ID,$Commission_mode=1,$cmsn_per,$Memberhip_type=1,$payout_id,$contract_data['Amount'],$reg_date,$contract_data['Invest_type']);


}


if(isset($_POST['normal_verify_payment'])){
	redirect('ewallet/Ewallet');
}else{
	redirect('membership/Membership/payment_members');
}
    }



		




	
	}



public function get_excat_next_payout($cl_dt){
	//$cl_dt='2019-05-08';
	$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
                	if(!empty($com_pay_date)){
                		$commission_pay_date=$com_pay_date[0]['Pay_dates'];
                	}else{
                		$commission_pay_date='7,14,21,28';
                	}
                	$commission_pay_date=explode(',',$commission_pay_date);

                      	//$cl_dt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $tran['Membership_ID'],'Contract_ID' => $tran['Contract_ID']))->row()->Pay_date;
					$per_date=date('d',strtotime($cl_dt));
                      	$temp_date=date('Y-m',strtotime($cl_dt));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							// return $payout_date=$this->fet_exact_payout_date($final_payout_date);
							return $payout_date=date('Y-m-d',strtotime($final_payout_date));
}

public function fet_exact_payout_date($final_payout_date)
{
	$Cal_date=date('Y-m-d',strtotime($final_payout_date));
$final_dates=[];
$yrl_dates_0=[];
		$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
		    $days=$query->result_array();
		    $week_days=explode(',',$days[0]['Weeks']);
		    $final_days=[];
		    $final_days1=[];


		$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
		

		        $this->db->select('Date');
		        $query = $this->db->get('gc_individual_calendar');
		        if ($query->num_rows() > 0) {
		            $db_leave=$query->result_array();
		        }else{
		            $db_leave=[];
		        }

		        $empt_leave=[];
		        foreach($db_leave as $lv){
		            array_push($empt_leave,$lv['Date']);

		        }
		        $final_dates=array_values(array_diff($final_dates,$empt_leave));
		    if(in_array($Cal_date, $final_dates)){

		    	return $Cal_date;
		    }else{
		    	return $this->get_next_pay_date($Cal_date);
		    }
		}
}




public function get_next_pay_date($cur_date){
$final_dates=[];
$yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

         $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));

    foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
    
    $keyval= $key;
    if(isset($final_dates[$keyval])){
        return $final_dates[$keyval];
    }
    
    break;
}else{
    $keyval=$key;
    $final_dates[$keyval];
}
    }
}

    }   
    public function payment_attachment($ref_no,$file_name,$name) {  

           if (!is_dir('./attachments/Members/'.$ref_no))
          {
              mkdir('./attachments/Members/'.$ref_no, 0777, true);
          }
          	$dir_exist = true; 
          if (!is_dir('./attachments/Members/'.$ref_no))
          {
              mkdir('./attachments/Members/'.$ref_no, 0777, true);
              $dir_exist = false; 
          }

         $config['upload_path']          = './attachments/Members/'.$ref_no.'/';
         $config['allowed_types']        = 'gif|jpg|png';
         $new_name                       = $ref_no.'_'.$name;
         $config['file_name']            = $new_name;

        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if ( ! $this->upload->do_upload($file_name))
        {
                $error = array('error' => $this->upload->display_errors());
                $file_name = '';
                 return $file_name;                 
        }
        else
        {   
                $data = array('upload_data' => $this->upload->data());
                $upload_data = $this->upload->data(); 
                $file_name =   $upload_data['file_name'];
                return $file_name;
        }

    }


		public function active_wallets_ready()
	{
		
		$template['page']='ewallet/view_active_wallets_ready';
		$template['sales_point']    =  $this->Sales_point_model->getall_sales_points();
		$template['payout']    =  $this->Ewallet_model->get_today_processed_requests();
		$this->load->view('template',$template);
		
	}

		public function pay_later()
	{
		
		$template['page']='ewallet/view_wallet_later';
		$template['sales_point']    =  $this->Sales_point_model->getall_sales_points();
		$template['payout']    =  $this->Ewallet_model->get_today_pay_later();
		$template['status'] =9;
		$template['flag']   =1;
		$this->load->view('template',$template);
		
	}
		public function wallet_history()
	{
		
		$template['page']='ewallet/view_wallet_history';
		$template['sales_point']    =  $this->Sales_point_model->getall_sales_points();
		$template['payout']    =  $this->Ewallet_model->get_today_wallet_history();
		$this->load->view('template',$template);
		
	}

	public function process_payout(){
		$id = ( explode( ',', $this->input->post('id') ));
		// var_dump($id);die();

		// $date =  date('Y-m-d',strtotime($this->input->post('date')));
		//var_dump($id);die();
		foreach ($id as  $value) {
				$this->Ewallet_model->process_payout($value);
			 }
	}

public function cancel_payout(){
		$id = ( explode( ',', $this->input->post('id') ));
		// var_dump($id);die();
		foreach ($id as  $value) {
				$this->Ewallet_model->cancel_payout($value);
			 }
	}
public function payout_later(){
		$id = ( explode( ',', $this->input->post('id') ));
		// var_dump($id);die();
		foreach ($id as  $value) {
				$this->Ewallet_model->payout_later($value);
			 }
	}

public function mark_as_paid(){
		$id = ( explode( ',', $this->input->post('id') ));
		// var_dump($id);die();
		foreach ($id as  $value) {
				$this->Ewallet_model->mark_as_paid($value);
			 }
	}

	public function payout_remittance()
	{
		
		$template['page']='ewallet/view_payout_remittance';
		$this->load->view('template',$template);
		
	}

	public function completed_payments()
	{
		
		$template['page']='ewallet/view_completed_payments';
		$this->load->view('template',$template);
		
	}

	public function withdraw()
	{
		
		$template['page']='ewallet/view_member_withdraw';
		$this->load->view('template',$template);
		
	}
	public function get_wallet_details()
	{
		
		$mobile = $this->input->post("mobile");  
		$sales_point = $this->input->post("sales_point");
		$payment_mode = $this->input->post("payment_mode");

		$date=$this->input->post("date");
		$this->load->model('ewallet/Ewallet_model');
		$template['payout'] =  $this->Ewallet_model->get_wallet_details($mobile,$date,$sales_point,$payment_mode);
		$this->load->view('ewallet/ajax_wallet',$template);
	
		
	}
	public function get_wallet_processed_details()
	{
		
		$mobile = $this->input->post("mobile");  
		$sales_point = $this->input->post("sales_point");
		$date=$this->input->post("date");
		$this->load->model('ewallet/Ewallet_model');
		$template['payout'] =  $this->Ewallet_model->get_wallet_processed_details($mobile,$date,$sales_point);
		$this->load->view('ewallet/ajax_wallet',$template);
		
	}

	public function get_pay_later_details()
	{
		
		$mobile = $this->input->post("mobile");  
		$sales_point = $this->input->post("sales_point");
		$date=$this->input->post("date");
		$this->load->model('ewallet/Ewallet_model');
		$template['payout'] =  $this->Ewallet_model->get_pay_later_details($mobile,$date,$sales_point);
		$this->load->view('ewallet/ajax_wallet',$template);
		
	}

	public function get_wallets_history_details()
	{
		
		$mobile = $this->input->post("mobile");  
		$sales_point = $this->input->post("sales_point");
		$date=$this->input->post("date");
		$this->load->model('ewallet/Ewallet_model');
		$template['payout'] =  $this->Ewallet_model->get_wallets_history_details($mobile,$date,$sales_point);
		$this->load->view('ewallet/ajax_wallet',$template);
		
	}

	public function get_wallet_details_view(){
		$service_point_id = $this->input->post("Topup_id");
		$template['service_point']    =  $this->Sales_point_model->getall_service_entries_by_id($service_point_id);
		$template['service_payment']    =  $this->Sales_point_model->getall_service_payments_by_id($service_point_id);
		// var_dump($template['service_payment']);die();
		$template['sales_point']    =  $this->Sales_point_model->getall_sales_points();
		$template['bank']            =  $this->Membership_model->getall_bank();
        $template['payment_mode']    =  $this->Membership_model->getall_payment_modes();
        $template['service_point_id']    =  $service_point_id;
        $this->load->view('ewallet/ajax_wallet',$template);
	}

	public function get_previous_date($cur_date){
//$cur_date=date('Y-m-d');
	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);
			//var_dump($week_days);
$date=new DateTime();
$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

	if($week_days[$i] == $search){
		$arr[$i] = $week_days[$i];
		$search = $week_days[$i] + 1;
	}else{
		$arr2[$i] = $week_days[$i];
	}
}

$action = array_merge($arr,$arr2);
$days = array(
	 '1' => 'Monday',
	 '2' => 'Tuesday',
	 '3' => 'Wednesday',
	 '4' => 'Thursday',
	 '5' => 'Friday',
	 '6' => 'Saturday',
	 '7' => 'Sunday'
 );
$final_dt=[];

foreach($action as $da){
if (array_key_exists($da,$days))
  {
  array_push($final_dt,$days[$da]);
  }

}

//var_dump($final_dt);
$final_dates=[];
for($i=1; $i<=52; $i++){
		foreach($final_dt as $newval){
		//date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
		array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
		}
	}
   $cur_date=date("Y-m-d", strtotime($cur_date));
	
	//var_dump($final_dates);
	foreach($final_dates as $key=> $fin){
if($cur_date==$fin){
	$keyval= $key-1;
	return $final_dates[$keyval];
}else{
	$keyval=$key;
	$final_dates[$keyval];
}
	}
	//echo $serch_date=$final_dates[$keyval];
}

	}

	public function check5(){
		$check_date=date('Y-m-d');
		$type=$this->db->select('*')->from('gc_payout_type')->where('id',3)->where('status',1)->get()->row();
		$pay_d=$type->Days;
		// $pay_d=3;

		$days = array(
					'1' => 'Monday',
					'2' => 'Tuesday',
					'3' => 'Wednesday',
					'4' => 'Thursday',
					'5' => 'Friday',
					'6' => 'Saturday',
					'7' => 'Sunday'
						);
$pay_day=$days[$pay_d];
echo $mnth_date=date("Y-m-d", strtotime("first ".$pay_day." of this month"));echo '<br/>';
$cur_day=ucfirst(date('l',strtotime($check_date)));

//echo $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
if(date('Y-m-d')==$mnth_date){
//echo "matched";echo '<br/>';
	$final_dates=[];
	$yrl_dates_0=[];
	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);

			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
	
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
		 $this->db->select('Date');
				$query = $this->db->get('gc_individual_calendar');
				if ($query->num_rows() > 0) {
					$db_leave=$query->result_array();
				}else{
					$db_leave=[];
				}
				$empt_leave=[];
				foreach($db_leave as $lv){
					array_push($empt_leave,$lv['Date']);

				}
				
				//print_r($db_leave);die();
				$final_dates=array_values(array_diff($final_dates,$empt_leave));

		if(in_array($mnth_date, $final_dates)){
			
				//echo 'get values';
				$prev_date=date("Y-m-d", strtotime("first ".$pay_day." of previous month"));
				//echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
				$end_date=$this->get_previous_date1($mnth_date);
				$this->db->select('sum(commission.Amount) as Tot_week_amount');
		$this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
		$this->db->from('gc_member_commission_details as commission');
		
		$this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
		$this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
		$this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
		$this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
	   

		$this->db->where('commission.Commision_date>=',$prev_date);
		$this->db->where('commission.Commision_date<=',$end_date);
		$this->db->where('commission.Status',1);
		$this->db->group_by('commission.Commision_type');
		$this->db->group_by('commission.Membership_ID');
		$this->db->where('commission.Payout_ID',3);
		$query = $this->db->get();  
		if ($query->num_rows() > 0) {
			return $query->result_array();
		}else{
			//echo 'null';
		return NULL;
	}
				//echo $prev_date=date('Y-m')
				
			
			
		}else{
			//echo 'today leave';
		}
	}
	
}else{
	$cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
	//echo "not Match";
	if(date('Y-m-d')==$cms_start){
		//echo "Match Next Day";

		$prev_date=date("Y-m-d", strtotime("first ".$pay_day." of previous month"));
		//echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
		
				$end_date=$this->get_previous_date1($cms_start);
				$this->db->select('sum(commission.Amount) as Tot_week_amount');
		$this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
		$this->db->from('gc_member_commission_details as commission');
		
		$this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
		$this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
		$this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
		$this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
	   

		$this->db->where('commission.Commision_date >=',$prev_date);
		$this->db->where('commission.Commision_date <=',$end_date);
		$this->db->where('commission.Status',1);
		$this->db->group_by('commission.Commision_type');
		$this->db->group_by('commission.Membership_ID');
		$this->db->where('commission.Payout_ID',3);
		$query = $this->db->get();  
		if ($query->num_rows() > 0) {
			return $query->result_array();
		}else{
			//echo 'null';
		return NULL;
	}

	}else{
		return NULL;
		//echo "Not Match Next Day";
	}
}
// $cur_day='Wednesday';
//echo $cur_day;die();
}

public function get_previous_date1($cur_date){
$final_dates=[];
$yrl_dates_0=[];
	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);

			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
	
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

		 $this->db->select('Date');
				$query = $this->db->get('gc_individual_calendar');
				if ($query->num_rows() > 0) {
					$db_leave=$query->result_array();
				}else{
					$db_leave=[];
				}
				$empt_leave=[];
				foreach($db_leave as $lv){
					array_push($empt_leave,$lv['Date']);

				}
				
				//print_r($db_leave);die();
				$final_dates=array_values(array_diff($final_dates,$empt_leave));

	foreach($final_dates as $key=> $fin){
if($cur_date==$fin){

	
	if($key>=1){
	$keyval= $key-1;
	return  $final_dates[$keyval];
}else{
	//$keyval= date("Y",strtotime("-1 year")).'-12-31';
	return  date("Y",strtotime("-1 year")).'-12-31';
}
	

}else{
	$keyval=$key;
	$final_dates[$keyval];
}
	}
}

	}

	
	public function get_advance_date1($cur_date){
$final_dates=[];
$yrl_dates_0=[];
	$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
			$days=$query->result_array();
			$week_days=explode(',',$days[0]['Weeks']);

			$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
	
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

		 $this->db->select('Date');
				$query = $this->db->get('gc_individual_calendar');
				if ($query->num_rows() > 0) {
					$db_leave=$query->result_array();
				}else{
					$db_leave=[];
				}
				$empt_leave=[];
				foreach($db_leave as $lv){
					array_push($empt_leave,$lv['Date']);

				}
				
				//print_r($db_leave);die();
				$final_dates=array_values(array_diff($final_dates,$empt_leave));

	foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
	
	$keyval= $key;
	if(isset($final_dates[$keyval])){
		return $final_dates[$keyval];
	}else{
		return date('Y-01-01');
	}
	
	break;
}else{
	$keyval=$key;
	$final_dates[$keyval];
}
	}
}

	}

	public function get_three_yrs_holidays($year,$week_days){

//$week_days=['6','7'];
			//var_dump($week_days);
$date=new DateTime();
//$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

	if($week_days[$i] == $search){
		$arr[$i] = $week_days[$i];
		$search = $week_days[$i] + 1;
	}else{
		$arr2[$i] = $week_days[$i];
	}
}

$action = array_merge($arr,$arr2);
$days = array(
	 '1' => 'Monday',
	 '2' => 'Tuesday',
	 '3' => 'Wednesday',
	 '4' => 'Thursday',
	 '5' => 'Friday',
	 '6' => 'Saturday',
	 '7' => 'Sunday'
 );
$final_dt=[];
//var_dump($action);
foreach($action as $da){
if (array_key_exists($da,$days))
  {
	//$sim=array('N' => $days[$da], 'A' => $da);
  array_push($final_dt,$days[$da]);
  }

}
//var_dump($final_dt);

$final_dates=[];
for($i=1; $i<=52; $i++){
		foreach($final_dt as $newval){
		//date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
		array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
		}
	}
	return $final_dates;
}

function sample(){

	 //$pre_date=$this->get_previous_date1(date('Y-m-d')); 
	   $check_date='2018-07-02';
		$type=$this->db->select('*')->from('gc_payout_type')->where('id',2)->where('status',1)->get()->row();
		$pay_d=$type->Days;
		// $pay_d=3;
		$days = array(
					'1' => 'Monday',
					'2' => 'Tuesday',
					'3' => 'Wednesday',
					'4' => 'Thursday',
					'5' => 'Friday',
					'6' => 'Saturday',
					'7' => 'Sunday'
						);
$pay_day=$days[$pay_d];
$cur_day=ucfirst(date('l',strtotime($check_date)));
// $cur_day='Wednesday';

if($pay_day===$cur_day){
	 //echo '';
	 $prev_date= date('Y-m-d', strtotime('previous '.$pay_day, strtotime($check_date)));
	  $end_date=$this->get_previous_date1($check_date);
		$this->db->select('sum(commission.Amount) as Tot_week_amount');
		$this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no,pyt.payout_type');
		$this->db->from('gc_member_commission_details as commission');
		
		$this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
		$this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
		$this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
		$this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
		$this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
		$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');

		$this->db->join('gc_payout_type as pyt', 'pyt.id = commission.Payout_ID', 'left');
	   

		$this->db->where('commission.Commision_date >=',$prev_date);
		$this->db->where('commission.Commision_date <=',$end_date);
		$this->db->where('commission.Status',1);
		// $this->db->group_by('commission.Commision_type');
		$this->db->group_by('commission.Membership_ID');
		$this->db->where('commission.Payout_ID',2);
		if(!empty($mobile)){
		$where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
		$this->db->where($where);}
		$query = $this->db->get();  
		if ($query->num_rows() > 0) {
			//var_dump($query->result_array());
			$wk=$query->result_array();
			
			for($i=0;$i<count($wk);$i++){
				$wk[$i]['Prev_date']=$prev_date;
				$wk[$i]['End_date']=$end_date;

			}
			  
		}else{
		   return NULL; 
		}


	}else{
		return NULL;
	}
	
}


function sam(){
	echo $data_payout_date= $this->Report_model->get_curent_payout_date(10617,'2019-07-10');echo '<br>';
	$py_days=14;
	$data_payout_date=date('Y-m-d', strtotime($data_payout_date. ' - '.$py_days.' days'));
	echo $data1['Payout_date']=$this->Ewallet_model->get_excat_next_payout1($data_payout_date);
}

}
