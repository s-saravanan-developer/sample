<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Location_model extends CI_Model {

	private $location_country 	= 'gc_countries';	
	private $location_state 	= 'gc_states';	
	private $location_city 		= 'gc_cities';	

	/**
	 * Countrty Data View 
	 */
	public function get_location_country()
	{
		$this->db->select($this->location_country . '.*');
		$this->db->where_not_in('status',3);
		
        $query = $this->db->get($this->location_country);
        if ($query->num_rows() > 0) {
        	$country_base = $query->result_array(); 
            foreach ($country_base as $key => $value) {
                $delete_status = $this->check_delete_status_country($value['id']);
                if(isset($delete_status)){ 
                    $country_base[$key]['delete_status'] = 1; 
                }
                else{ 
                    $country_base[$key]['delete_status'] = 0;
                }    
            }
            return $country_base;
        }
        return NULL;
	}

		public function check_delete_status_country($country_id)
	{
		    $this->db->select('country.id');
	        $this->db->from('gc_countries as country');        
	        $this->db->join('gc_states as state','state.country_id = country.id','left');
	        $this->db->where('state.country_id',$country_id.'' );
	        $query = $this->db->get();        
	        if ($query->num_rows() > 0) {
	            return $query->result_array();
	        }
	        return NULL;
	}

	public function get_location_country_export($id)
	{
		$this->db->select($this->location_country . '.*');
		$this->db->where_not_in('status',3);
		$id = explode(",", $id); 

		 $this->db->where_in('id', $id);
        $query = $this->db->get($this->location_country);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}

		public function get_location_country1()
	{
		$this->db->select($this->location_country . '.*');
		$this->db->where('status',1);
        $query = $this->db->get($this->location_country);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}

	/**
	 * Countrty Data Add 
	 */
	public function adding_country($country_data)
	{
		// Check Already Inserted 
		$this->db->select('*');
		$this->db->from('gc_countries');
		$this->db->where('country_name', $country_data['country_name']);
		$this->db->where('status', 3);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {      
            $Updated = $query->result_array();
            $Updated[0]['status'] = '1';$id = $Updated[0]['id'];
			$this->db->where('id', $id);
        	$this->db->update('gc_countries', $Updated[0]);
			$this->session->set_flashdata('country_success', 'Added');
        }
			else{
				// Insert The New Value
				$country_data['Created_by']=$this->session->userdata('UserId');				
				$country_data['company_id']=$this->session->userdata('CompanyId');
				// $country_data['financial_yr_id']=$this->session->userdata('Financial_yr_id');
				
				$this->db->insert('gc_countries', $country_data);

				$modify['Module_name']="Country";
				$modify['Data']=$country_data['country_name'];
				$modify['Action']="1";
				$modify['Created_by']=$this->session->userdata('UserId');
				$this->db->insert('gc_modification_history', $modify);
				

			    $this->session->set_flashdata('country_success', 'Added');
			}
        
	}

		public function duplicate_checkedit($data,$table_name,$colum,$id){
	
		$this->db->select('*');
		$this->db->from($table_name);
		$this->db->where($colum, $data);
		$this->db->where('id!=', $id);
		$this->db->where('status!=', 3);
		$query = $this->db->get();
		if ($query->num_rows() > 0) { 
			return 1;
        }else{
        	return 0;
        }     
	}


	/**
	 * Countrty Data Edit 
	 */
	public function editing_country($country_data_edit,$id)
	{
		$this->db->db_debug = false;
		$country_data_edit['updated_date'] = date('Y-m-d H:i:s');
		$this->db->where('id', $id);
		$country_data_edit['Updated_by']=$this->session->userdata('UserId');
		if (!$this->db->update('gc_countries', $country_data_edit)) {			
			var_dump($this->db->error());		
			$this->session->set_flashdata('country_duplicate', 'Dupliacate Value');
		}else{
			$country_data_edit['Updated_by']=$this->session->userdata('UserId');
			$this->db->update('gc_countries', $country_data_edit);

			$modify['Module_name']="Country";
				$modify['Data']=$country_data_edit['country_name'];
				$modify['Action']="2";
				$modify['Created_by']=$this->session->userdata('UserId');
				$this->db->insert('gc_modification_history', $modify);

            $this->session->set_flashdata('country_success', 'Updated');			
			return TRUE;
		}
		
		return FALSE;		
	}

	/**
	 * Countrty Data Delete 
	 */
	public function deleting_country($table_name,$id)
	{
		//echo 'Table Name =>'.$table_name.'  Id ==>'.$id;
		$this->db->select('country_id');$this->db->from('gc_states');$this->db->where('country_id', $id);$this->db->where('status!=',3);
		$state_query = $this->db->get();
		$this->db->select('country_id');$this->db->from('gc_cities');$this->db->where('country_id', $id);$this->db->where('status!=',3);
		$city_query = $this->db->get();
		$this->db->select('Country');$this->db->from('gc_company_table');$this->db->where('Country', $id);$this->db->where('CompanyStatus!=',3);
		$company_query = $this->db->get();
		$this->db->select('country_id');$this->db->from('gc_hub_branch');$this->db->where('country_id', $id);$this->db->where('status!=',3);
		$branch_query = $this->db->get();
		$this->db->select('country_id');$this->db->from('gc_users');$this->db->where('country_id', $id);$this->db->where('status!=',3);
		$users_query = $this->db->get();
		$this->db->select('	B_country_id');$this->db->from('gc_customers');$this->db->where('	B_country_id', $id);$this->db->where('status!=',3);
		$customers_query = $this->db->get();
		$this->db->select('S_country_id');$this->db->from('gc_ventors_table');$this->db->where('B_country_id', $id);$this->db->where('Status!=',3);
		$vendor_query = $this->db->get();		
		//echo "<pre>";
		//echo "State";
		$state_data = $state_query->row_array();
		//print_r($state_data);
		//echo "City";
		$city_data = $city_query->row_array();				
		//print_r($city_data);
		//echo "Comapany";
		$company_data = $company_query->row_array();		
		//print_r($company_data);
		//echo "Branch";	
		$branch_data = $branch_query->row_array();
		//print_r($branch_data);
		//echo "users";
		$users_data = $users_query->row_array();
		//print_r($users_data);
		//echo "Customer";
		$customers_data = $customers_query->row_array();		
		//print_r($customers_data);
		//echo "Vendor";
		$vendor_data = $vendor_query->row_array();		
		//print_r($vendor_data);
		//echo "</pre>";
		if ($state_data > 0 || $city_data > 0 || $company_data > 0 || $branch_data > 0 || $users_data > 0 || $vendor_data > 0 ) {
			//echo "Duplicate";
			$this->session->set_flashdata('country_duplicate', 'Already Used in Some Page');
		}
		else{
			$this->db->where('id', $id);
			$query = $this->db->get('gc_countries');
			$get['data']=$query->result_array();
				$modify['Module_name']="Country";
				$modify['Data']=$get['data'][0]['country_name'];
				$modify['Action']="3";
				$modify['Created_by']=$this->session->userdata('UserId');
				$this->db->insert('gc_modification_history', $modify);
			//echo 'No Used in Others';
			$data['status'] ="3";
			$data['Deleted_by']=$this->session->userdata('UserId');
			$this->db->where('id', $id);
			if ($this->db->update($table_name, $data)) {
	            $this->session->set_flashdata('country_success', 'Deleted');      
				return TRUE;
			}
		}
		return FALSE;				
	 }
	/**
	 * Countrty Data Delete 
	 */
	public function delete($table_name,$id)
	{
		$data['status'] ="3";
		$this->db->where('id', $id);
		if ($this->db->update($table_name, $data)) {
            $this->session->set_flashdata('country_success', 'Deleted');
            $this->session->set_flashdata('state_success', 'Deleted');
            $this->session->set_flashdata('city_success', 'Deleted');
            $this->session->set_flashdata('area_success', 'Deleted');            
            $this->session->set_flashdata('Users_success', 'Deleted');            
			return TRUE;
		}
		return FALSE;		
	}

	/**
	 * State Opertation Model
	 */

	public function get_location_state()
	{
		$this->db->select('gc_states.id as state_id,gc_states.state_name as state_name,	gc_states.alis_name,gc_states.country_id as country_id,gc_states.status as status,gc_countries.country_name as country_name,gc_states.state_code as state_code');
		$this->db->from('gc_states');
		$this->db->join('gc_countries', 'gc_countries.id = gc_states.country_id', 'left');
		$this->db->where('gc_states.status',1);
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}

	public function get_location_state_export($id)
	{
		$this->db->select('gc_states.id as state_id,gc_states.state_name as state_name,	gc_states.alis_name,gc_states.country_id as country_id,gc_states.status as status,gc_countries.country_name as country_name,gc_states.state_code as state_code');
		$this->db->from('gc_states');
		$this->db->join('gc_countries', 'gc_countries.id = gc_states.country_id', 'left');
		$id = explode(",", $id); 

		 $this->db->where_in('gc_states.id', $id);
		//$this->db->where_in('gc_states.id',$id);
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}


		public function get_location_state1()
	{
		$this->db->select('gc_states.id as state_id,gc_states.state_name as state_name,	gc_states.alis_name,gc_states.country_id as country_id,gc_states.status as status,gc_countries.country_name as country_name,gc_states.state_code as state_code');
		$this->db->from('gc_states');
		$this->db->join('gc_countries', 'gc_countries.id = gc_states.country_id', 'left');
		$this->db->where('gc_states.status!=',3);
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {

        	$state_base = $query->result_array(); 
            foreach ($state_base as $key => $value) {
                $delete_status = $this->check_delete_status_state($value['state_id']);
                if(isset($delete_status)){ 
                    $state_base[$key]['delete_status'] = 1; 
                }
                else{ 
                    $state_base[$key]['delete_status'] = 0;
                }    
            }
            return $state_base;
        }
        return NULL;
	}

	/**
	 * 
	 * Countrty Data Add 
	 */
	public function adding_state($state_data)
	{
		// Check Already Inserted 
		$this->db->select('*');
		$this->db->from('gc_states');
		$this->db->where('state_name', $state_data['state_name']);
		$this->db->where('status', 3);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {      
            $Updated = $query->result_array();
            $Updated[0]['status'] = '1';$id = $Updated[0]['id'];
			$this->db->where('id', $id);
        	$this->db->update('gc_states', $Updated[0]);
			$this->session->set_flashdata('country_success', 'Added');
			return TRUE;
		}
		else{
			$state_data['Created_by']		=	$this->session->userdata('UserId');
			$state_data['company_id']		=	$this->session->userdata('CompanyId');
			// $state_data['financial_yr_id']	=	$this->session->userdata('UserId');

			$this->db->insert('gc_states', $state_data);

			$modify['Module_name']="State";
			$modify['Data']=$state_data['state_name'];
			$modify['Action']="1";
			$modify['Created_by']=$this->session->userdata('UserId');				
			$this->db->insert('gc_modification_history', $modify);
            $this->session->set_flashdata('state_success', 'Added');			
			return TRUE;
		}
		return FALSE;		
	}

	/**
	 * State Data Edit 
	 */
	public function editing_state($state_data_edit,$id)
	{
		$modify['Module_name']="State";
				$modify['Data']=$state_data_edit['state_name'];
				$modify['Action']="2";
				$modify['Created_by']=$this->session->userdata('UserId');
				$this->db->insert('gc_modification_history', $modify);

		$state_data_edit['Updated_by']=$this->session->userdata('UserId');
		$state_data_edit['updated_date'] = date('Y-m-d H:i:s');
		$this->db->where('id', $id);
		if ($this->db->update('gc_states', $state_data_edit)) {
            $this->session->set_flashdata('state_success', 'Updated');			
			return TRUE;
		}
		return FALSE;		
	}

	/**
	 * Countrty Data Delete 
	 */
	public function deleting_state($table_name,$id)
	{
		
			$data['Deleted_by']=$this->session->userdata('UserId');
      		$data['status'] ="3";
			$this->db->where('id', $id);
			if ($this->db->update($table_name, $data)) {
	            $this->session->set_flashdata('state_success', 'Deleted');      
				return TRUE;
		
		}		
	}


	/**
	 * City Operation
	 * @return [type] [description]
	 */
	public function get_location_city()
	{
		$this->db->select('
			 city.country_id as c_id,city.state_id,city.city_name,city.alis_name,city.status,city.id as city_id,city.city_code,
			 state.id as state_id,state.state_name,
			 country.country_name
			');
		$this->db->from('gc_cities as city');
		$this->db->join('gc_states as state', 'state.id = city.state_id', 'left');
		$this->db->join('gc_countries as country', 'country.id = city.country_id', 'left');
		$this->db->where('city.status!=',3);
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {
        	$city_base = $query->result_array(); 
            foreach ($city_base as $key => $value) {
                $delete_status = $this->check_delete_status_city($value['city_id']);
                if(isset($delete_status)){ 
                    $city_base[$key]['delete_status'] = 1; 
                }
                else{ 
                    $city_base[$key]['delete_status'] = 0;
                }    
            }
            return $city_base;
        }
        return NULL;
	}

public function get_location_city_export($id)
	{
		$this->db->select('
			 city.country_id as c_id,city.state_id,city.city_name,city.alis_name,city.status,city.id as city_id,city.city_code,
			 state.id as state_id,state.state_name,
			 country.country_name
			');
		$this->db->from('gc_cities as city');
		$this->db->join('gc_states as state', 'state.id = city.state_id', 'left');
		$this->db->join('gc_countries as country', 'country.id = city.country_id', 'left');
		$id = explode(",", $id); 

		 $this->db->where_in('city.id', $id);
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}

	public function get_location_area()
	{
		$this->db->select('
			 area.country_id as country_id,area.state_id,area.city_id,area.area_name,area.alis_name,area.status,area.id as area_id,
			 state.id as state_id,state.state_name,
			 country.country_name,city.city_name,area.Pincode,area.id
			');
		$this->db->from('gc_areas as area');
		$this->db->join('gc_cities as city', 'city.id = area.city_id', 'left');
		$this->db->join('gc_states as state', 'state.id = area.state_id', 'left');
		$this->db->join('gc_countries as country', 'country.id = area.country_id', 'left');
		$this->db->where('area.status!=',3);
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}


	public function get_location_area_export($id)
	{
		$this->db->select('
			 area.country_id as country_id,area.state_id,area.city_id,area.area_name,area.alis_name,area.status,area.id as area_id,
			 state.id as state_id,state.state_name,
			 country.country_name,city.city_name
			');
		$this->db->from('gc_areas as area');
		$this->db->join('gc_cities as city', 'city.id = area.city_id', 'left');
		$this->db->join('gc_states as state', 'state.id = area.state_id', 'left');
		$this->db->join('gc_countries as country', 'country.id = area.country_id', 'left');
		$id = explode(",", $id); 

		 $this->db->where_in('area.id', $id);
		//$this->db->where('area.status!=',3);
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}

	function get_city_by_state_id($id) {
        $this->db->select($this->location_city . '.id, city_name');
        $this->db->where($this->location_city . '.state_id', $id);
        $this->db->where($this->location_city . '.status', 1);
        $this->db->where($this->location_city . '.is_deleted', 0);
        $this->db->order_by($this->location_city . '.city_name');
        $query = $this->db->get($this->location_city);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }


    public function get_full_city_data()
	{
		$this->db->select('*');
		$this->db->from('gc_cities');
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}

	public function adding_city($city_data)
	{
		// Check Already Inserted 
		$this->db->select('*');
		$this->db->from('gc_cities');
		$this->db->where('city_name', $city_data['city_name']);
		$this->db->where('status', 3);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {      
            $Updated = $query->result_array();
            $Updated[0]['status'] = '1';$id = $Updated[0]['id'];
			$this->db->where('id', $id);
        	$this->db->update('gc_cities', $Updated[0]);
			$this->session->set_flashdata('country_success', 'Added');
			return TRUE;
		}
		else{
			$city_data['Created_by']		=	$this->session->userdata('UserId');
			$city_data['company_id']		=	$this->session->userdata('CompanyId');
			// $city_data['financial_yr_id']	=	$this->session->userdata('Financial_yr_id');
			$this->db->insert('gc_cities', $city_data);

			$modify['Module_name']="City";
				$modify['Data']=$city_data['city_name'];
				$modify['Action']="1";
				$modify['Created_by']=$this->session->userdata('UserId');
				$this->db->insert('gc_modification_history', $modify);
            $this->session->set_flashdata('city_success', 'Added');
			return TRUE;
		}
		return FALSE;		
	}

	public function editing_city($city_data_edit,$id)
	{
		$modify['Module_name']="State";
				$modify['Data']=$city_data_edit['city_name'];
				$modify['Action']="2";
				$modify['Created_by']=$this->session->userdata('UserId');
				$this->db->insert('gc_modification_history', $modify);


		$city_data_edit['Updated_by']=$this->session->userdata('UserId');
		$city_data_edit['updated_date'] = date('Y-m-d H:i:s');
		$this->db->where('id', $id);
		
		if ($this->db->update('gc_cities', $city_data_edit)) {
            $this->session->set_flashdata('city_success', 'Updated');
			return TRUE;
		}
		return FALSE;		
	}

	// City Editing Data
	 
	public function get_city_edit($id)
	{
		$this->db->select('*,city.id as city_id,city.state_id as city_state_id');
		$this->db->from('gc_cities as city');
		$this->db->join('gc_states as state', 'state.id = city.state_id', 'left');
		$this->db->join('gc_countries as country', 'country.id = city.country_id', 'left');
		$this->db->where('city.id', $id);
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}

	public function get_full_states_data(){
		$this->db->select('*');
		$this->db->from('gc_states');
		$this->db->where('status!=',3);
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}

	public function get_states_by_country_id($id) {
        $this->db->select('tab_1.id,tab_1.state_name');  
        $this->db->join($this->location_country.' AS tab_2', 'tab_2.id = tab_1.country_id', 'LEFT');        
        $this->db->where('tab_1.country_id', $id);
        $this->db->where('tab_1.is_deleted', 0);
        $this->db->where('tab_1.status', 1);
        $query = $this->db->get($this->location_state.' AS tab_1');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL; 
    }

	/**
	 * City Data Delete 
	 */
	public function deleting_city($table_name,$id)
	{
			$data['Deleted_by']=$this->session->userdata('UserId');
			$data['status'] ="3";
			$this->db->where('id', $id);
			if ($this->db->update($table_name, $data)) {
	            $this->session->set_flashdata('city_success', 'Deleted');      
				return TRUE;
			
		}		
	}


    //ADDING AND EDITING AREA DATA'S

    public function adding_area($cityarea_data)
	{
		$modify['Module_name']="City";	
				$modify['Data']=$cityarea_data['area_name'];
				$modify['Action']="1";
				$modify['Created_by']=$this->session->userdata('UserId');
				$this->db->insert('gc_modification_history', $modify);

		$cityarea_data['Created_by']=$this->session->userdata('UserId');
		$cityarea_data['company_id']=$this->session->userdata('CompanyId');
		$cityarea_data['Pincode']=$cityarea_data['Pincode'];
		if ($this->db->insert('gc_areas', $cityarea_data)) {
            $this->session->set_flashdata('area_success', 'Inserted');
			return TRUE;
		}
		return FALSE;		
	}


		// City Editing Data
	 
	public function get_area_edit($id)
	{
		$this->db->select('
			 area.country_id as country_id,area.state_id,area.city_id,area.area_name,area.status,area.id as area_id,
			 area.udf_1,area.udf_2,area.udf_3,area.udf_4,area.udf_5,area.udf_6,state.id as state_id,state.state_name,
			 country.country_name,city.city_name
			');
		$this->db->from('gc_areas as area');
		$this->db->join('gc_cities as city', 'city.id = area.city_id', 'left');
		$this->db->join('gc_states as state', 'state.id = area.state_id', 'left');
		$this->db->join('gc_countries as country', 'country.id = area.country_id', 'left');
		$this->db->where('area.status!=',3);
		$this->db->where('area.id', $id);
		$query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}

	public function editing_area($cityarea_data_edit)
	{	//var_dump($cityarea_data_edit);die();
			$modify['Module_name']="State";
			$modify['Data']=$cityarea_data_edit['area_name'];
			$modify['Action']="2";
			$modify['Created_by']=$this->session->userdata('UserId');
			$this->db->insert('gc_modification_history', $modify);

		$city_data_edit['Updated_by']=$this->session->userdata('UserId');
		$city_data_edit['updated_date'] = date('Y-m-d H:i:s');
		$this->db->where('id', $cityarea_data_edit['id']);
		if ($this->db->update('gc_areas', $cityarea_data_edit)) {
            $this->session->set_flashdata('area_success', 'Updated');
			return TRUE;
		}
		return FALSE;		
	}

	/**
	 * City Data Delete 
	 */
	public function deleting_area($table_name,$id)
	{

       	
       		$data['Deleted_by']=$this->session->userdata('UserId');
        	$data['status'] ="3";
			$this->db->where('id', $id);
			if ($this->db->update($table_name, $data)) {
	            $this->session->set_flashdata('area_success', 'Deleted');      
				return TRUE;
			}
        
		return FALSE;		
	}


	function delete_checkbox($id,$table_name){
		

      
	// $data['updated_date'] = date('Y-m-d H:i:s');
      		$data['Status'] 		= 3;	

        $this->db->where('id', $id);
        if ($this->db->update($table_name, $data)) {
            $this->session->set_flashdata('country_success', 'Deleted');
            return TRUE;
       }
		
		return FALSE;				
	 }

function active_all_checkbox($id,$table_name){
      
		 	// $data['updated_date'] = date('Y-m-d H:i:s');
      		$data['Status'] 		= 1;	

        $this->db->where('id', $id);
        if ($this->db->update($table_name, $data)) {
            $this->session->set_flashdata('country_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}

function deactivate_all_checkbox($id,$table_name){

      // $data['updated_date'] = date('Y-m-d H:i:s');
      $data['Status'] 		= 2;

        $this->db->where('id', $id);
        if ($this->db->update($table_name, $data)) {
            $this->session->set_flashdata('country_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}



//states

function delete_checkbox_states($id){

	$this->db->select('state_id');$this->db->from('gc_cities');$this->db->where('state_id', $id);$this->db->where('status!=',3);
		$city_query = $this->db->get();
		$this->db->select('StateID');$this->db->from('gc_company_table');$this->db->where('StateID', $id);$this->db->where('CompanyStatus!=',3);
		$company_query = $this->db->get();
		$this->db->select('state_id');$this->db->from('gc_hub_branch');$this->db->where('state_id', $id);$this->db->where('status!=',3);
		$branch_query = $this->db->get();
		$this->db->select('state_id');$this->db->from('gc_users');$this->db->where('state_id', $id);$this->db->where('status!=',3);
		$users_query = $this->db->get();
		$this->db->select('B_state_id');$this->db->from('gc_customers');$this->db->where('B_state_id', $id);$this->db->where('status!=',3);
		$customers_query = $this->db->get();
		$this->db->select('S_state_id');$this->db->from('gc_ventors_table');$this->db->where('S_state_id', $id);$this->db->where('Status!=',3);
		$vendor_query = $this->db->get();	
		//echo "<pre>";		
		//echo "City";
		$city_data = $city_query->row_array();				
		//print_r($city_data);
		//echo "Comapany";
		$company_data = $company_query->row_array();		
		//print_r($company_data);
		//echo "Branch";	
		$branch_data = $branch_query->row_array();
		//print_r($branch_data);
		//echo "users";
		$users_data = $users_query->row_array();
		//print_r($users_data);
		//echo "Customer";
		$customers_data = $customers_query->row_array();		
		//print_r($customers_data);
		//echo "Vendor";
		$vendor_data = $vendor_query->row_array();		
		//print_r($vendor_data);
		//echo "</pre>";
		if ($city_data > 0 || $company_data > 0 || $branch_data > 0 || $users_data > 0 || $vendor_data > 0 ) {
			//echo "Duplicate";
			$this->session->set_flashdata('duplicate', 'Already Used in Some Page');
		}
		else{

$data['updated_date'] = date('Y-m-d H:i:s');
      		$data['status'] 		= 3;	

        $this->db->where('id', $id);
        if ($this->db->update('gc_states', $data)) {
            $this->session->set_flashdata('state_success', 'Deleted');
            return TRUE;
       }
	}
		return FALSE;				
	 }


function active_all_checkbox_states($id){
      
		 	$data['updated_date'] = date('Y-m-d H:i:s');
      		$data['status'] 		= 1;	

        $this->db->where('id', $id);
        if ($this->db->update('gc_states', $data)) {
            $this->session->set_flashdata('state_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}

function deactivate_all_checkbox_states($id){

      $data['updated_date'] = date('Y-m-d H:i:s');
      $data['status'] 		= 2;

        $this->db->where('id', $id);
        if ($this->db->update('gc_states', $data)) {
            $this->session->set_flashdata('state_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}
  

//cities

function delete_checkbox_cities($id){

	$this->db->select('CityID');$this->db->from('gc_company_table');$this->db->where('CityID', $id);$this->db->where('CompanyStatus!=',3);
		$company_query = $this->db->get();
		$this->db->select('city_id');$this->db->from('gc_hub_branch');$this->db->where('city_id', $id);$this->db->where('status!=',3);
		$branch_query = $this->db->get();
		$this->db->select('city_id');$this->db->from('gc_users');$this->db->where('city_id', $id);$this->db->where('status!=',3);
		$users_query = $this->db->get();
		$this->db->select('S_city_id');$this->db->from('gc_customers');$this->db->where('S_city_id', $id);$this->db->where('status!=',3);
		$customers_query = $this->db->get();
		$this->db->select('S_city_id');$this->db->from('gc_ventors_table');$this->db->where('S_city_id', $id);$this->db->where('Status!=',3);
		$vendor_query = $this->db->get();
		//echo "<pre>";
		//echo "Comapany";
		$company_data = $company_query->row_array();		
		//print_r($company_data);
		//echo "Branch";	
		$branch_data = $branch_query->row_array();
		//print_r($branch_data);
		//echo "users";
		$users_data = $users_query->row_array();
		//print_r($users_data);
		//echo "Customer";
		$customers_data = $customers_query->row_array();		
		//print_r($customers_data);
		//echo "Vendor";
		$vendor_data = $vendor_query->row_array();		
		//print_r($vendor_data);
		//echo "</pre>";
		if ($company_data > 0 || $branch_data > 0 || $users_data > 0 || $vendor_data > 0 ) {
			//echo "Duplicate";
			$this->session->set_flashdata('duplicate', 'Already Used in Some Page');
		}
		else{

$data['updated_date'] = date('Y-m-d H:i:s');
      		$data['status'] = 3;	

        $this->db->where('id', $id);
        if ($this->db->update('gc_cities', $data)) {
            $this->session->set_flashdata('city_success', 'Deleted');
            return TRUE;
       }
	}
		return FALSE;				
	 }


function active_all_checkbox_cities($id){
      
		 	$data['updated_date'] = date('Y-m-d H:i:s');
      		$data['status'] 		= 1;	

        $this->db->where('id', $id);
        if ($this->db->update('gc_cities', $data)) {
            $this->session->set_flashdata('city_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}

function deactivate_all_checkbox_cities($id){

      $data['updated_date'] = date('Y-m-d H:i:s');
      $data['status'] 		= 2;

        $this->db->where('id', $id);
        if ($this->db->update('gc_cities', $data)) {
            $this->session->set_flashdata('city_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}

//areas


function delete_checkbox_areas($id){
$data['updated_date'] = date('Y-m-d H:i:s');
      		$data['status'] 		= 3;	

        $this->db->where('id', $id);
        if ($this->db->update('gc_areas', $data)) {
            $this->session->set_flashdata('area_success', 'Deleted');
            return TRUE;
       }
	
		return FALSE;				
	 }


function active_all_checkbox_areas($id){
      
		 	$data['updated_date'] = date('Y-m-d H:i:s');
      		$data['status'] 		= 1;	

        $this->db->where('id', $id);
        if ($this->db->update('gc_areas', $data)) {
            $this->session->set_flashdata('area_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}

function deactivate_all_checkbox_areas($id){

      $data['updated_date'] = date('Y-m-d H:i:s');
      $data['status'] 		= 2;

        $this->db->where('id', $id);
        if ($this->db->update('gc_areas', $data)) {
            $this->session->set_flashdata('area_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}



	
	public function check_delete_status_state($state_id)
	{
		    $this->db->select('state.id');
	        $this->db->from('gc_states as state');        
	        $this->db->join('gc_cities as city','city.state_id = state.id','left');
	        $this->db->where('city.state_id',$state_id.'' );
	        $query = $this->db->get();        
	        if ($query->num_rows() > 0) {
	            return $query->result_array();
	        }
	        return NULL;
	}

	public function check_delete_status_city($city_id)
	{
		    $this->db->select('city.id');
	        $this->db->from('gc_cities as city');        
	        $this->db->join('gc_company_table as company','company.CityID = city.id','left');
	        $this->db->join('gc_hub_branch as region','region.city_id = city.id','left');
	        $this->db->join('gc_areas as areas','areas.city_id = city.id','left');
	        $this->db->where('company.CityID = '.$city_id.' or region.city_id = '.$city_id.' or areas.city_id = '.$city_id.'' );
	        $query = $this->db->get();        
	        if ($query->num_rows() > 0) {
	            return $query->result_array();
	        }
	        return NULL;
	}

	
		

}

/* End of file Location_model.php */
/* Location: ./application/models/master/Location_model.php */