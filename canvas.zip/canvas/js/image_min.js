                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                if(!window.__td){window.__MT=100;window.__ti=0;window.__td=[];window.__td.length=window.__MT;window.__noTrace=false;}








if(typeof vp=="undefined")
{
var vp={};
}




if(typeof vp.image=="undefined")
{
vp.image=function(){};
}






vp.image.Image=function $vpfn_ToP1c$HVj_JuflU1$kG9dA28$17(type,id){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}





var me=this;






this.type=(typeof type=="undefined"?vp.image.Type.Upload:parseInt(type,10));




this.id=(id?parseInt(id,10):vp.image.Image.InvalidId);





this.token=null;





this.fileId=null;







this.plantPrefix=null;





this.previewUrl=null;




this.languageId=1;







this.width=null;





this.height=null;





this.name=null;





this.dateCreated=null;





this.dateTaken=null;





this.canDelete=null;





this.colorOverrides=null;




this.isLogo=null;
this.isPhoto=null;
this.isStamp=null;
this.isEmbroidery=null;
this.isThermography=null;
this.isVector=null;
this.thermographyColorCount=null;





this.maskUploadId=null;





this.equals=function $vpfn_9QBmkWIrV3l9CpGpvk5M5g144$18(oImage){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
if(oImage){

return me.id==oImage.id&&
me.type==oImage.type;

}
return false;
};
};





vp.image.Type={
Library:0,
Upload:1,
Logo:2,
CustomerSiteUpload:7,
EmailMarketingUpload:8,
Document:11,
Caricature:12,
Partner:13
};




vp.image.Image.InvalidId=-1;






vp.image.EditedImage=function $vpfn_2sq2nCG_D10D3bdY_kQBlw180$23(type,id)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}



var me=this;





this.inheritFrom=vp.image.Image;
this.inheritFrom(type,id);





this.rotation=vp.image.EditedImage.Rotation.None;





this.cropInfo={};
this.cropInfo.left=0;
this.cropInfo.right=0;
this.cropInfo.top=0;
this.cropInfo.bottom=0;




this.isCropped=function $vpfn_$poBvP6dGKpZ6958sH53IQ213$21()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
return((me.cropInfo.left!==0)||
(me.cropInfo.right!==0)||
(me.cropInfo.top!==0)||
(me.cropInfo.bottom!==0));
};




this.serializeJSON=function $vpfn_KQKXh0_4BkWKm_9HkB2rGA224$25()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var json={};
json.id=this.id;
json.type=this.type;
json.token=this.token;
json.plantPrefix=this.plantPrefix;
json.cropInfo=this.cropInfo;
json.rotation=this.rotation;
return JSON.stringify(json);
};
};






vp.image.parseJSON=function $vpfn_3lzDXzYdDMFQSgHCAHJ5Cw242$21(vData)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

var json=typeof(vData)==="string"?$.parseJSON(vData):vData;


var oImage=new vp.image.EditedImage(parseInt(json.type,10),parseInt(json.id,10));
if(json.token)
{
oImage.token=json.token;
}
if(json.fileId)
{
oImage.fileId=json.fileId;
}


oImage.plantPrefix=json.plantPrefix||"";
if(json.previewUrl)
{
oImage.previewUrl=json.previewUrl;
}



oImage.width=json.width;
oImage.height=json.height;
oImage.name=json.name;
oImage.dateCreated=json.dateCreated;
if(json.dateTaken)
{
oImage.dateTaken=json.dateTaken;
}
oImage.canDelete=json.canDelete;
oImage.isLogo=json.isLogo||false;
oImage.isStamp=json.isStamp||false;
oImage.isPhoto=json.isPhoto||false;
oImage.isMask=json.isMask||false;
oImage.isEmbroidery=json.isEmbroidery||false;
oImage.isThermography=json.isThermography||false;
oImage.isVector=json.isVector||false;
oImage.thermographyColorCount=json.thermographyColorCount;
oImage.colorOverrides=json.colorOverrides;


if(json.cropInfo)
{
oImage.cropInfo={};
oImage.cropInfo.left=parseFloat(json.cropInfo.left);
oImage.cropInfo.right=parseFloat(json.cropInfo.right);
oImage.cropInfo.top=parseFloat(json.cropInfo.top);
oImage.cropInfo.bottom=parseFloat(json.cropInfo.bottom);
}
if(json.rotation)
{
oImage.rotation=parseInt(json.rotation,10);
}

vp.image.imageDataStorage.addImage(oImage);

return oImage;
};




vp.image.EditedImage.Rotation={
None:0,
Rotation90:90,
Rotation180:180,
Rotation270:270
};






vp.image.StudioDocItemTypeToImageType=function $vpfn_atCFrMPAFRvTfTS_PuqyyA320$40(eDocItemType)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
switch(eDocItemType)
{
case DOCITEM_TYPE_LIBRARY_IMAGE:
case DOCITEM_TYPE_PLACEHOLDER:
return vp.image.Type.Library;
case DOCITEM_TYPE_UPLOADED_IMAGE:
return vp.image.Type.Upload;
case DOCITEM_TYPE_LOGO:
return vp.image.Type.Logo;
case DOCITEM_TYPE_CARICATURE:
return vp.image.Type.Caricature;
default:
throw"vp.image.StudioDocItemTypeToImageType: invalid document item type";
}
return null;
};







vp.image.ImageTypeToStudioDocItemType=function $vpfn_V9j3gwyT9nGJFm3JCU6MsA345$40(eImageType)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
switch(eImageType)
{
case vp.image.Type.Library:
return DOCITEM_TYPE_LIBRARY_IMAGE;
case vp.image.Type.Upload:
return DOCITEM_TYPE_UPLOADED_IMAGE;
case vp.image.Type.Logo:
return DOCITEM_TYPE_LOGO;
case vp.image.Type.Caricature:
return DOCITEM_TYPE_CARICATURE;
default:
throw"vp.image.StudioDocItemTypeToImageType: invalid document item type";
}
return null;
};







vp.image.convertStudioImageToEditedImage=function $vpfn_War2V4qPoYGBfArYgVx6zA369$43(oDocItemImage,oEditor)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

var imageType=vp.image.StudioDocItemTypeToImageType(oDocItemImage.type);


var image=new vp.image.EditedImage(imageType,oDocItemImage.getItemID());





image.cropInfo={};
vp.core.applyProperties(oDocItemImage.cropInfo,image.cropInfo);

image.container=oDocItemImage.imageContainer.parentNode;
image.externalId=oDocItemImage.id;
image.locked=oDocItemImage.locked;
image.rotation=oDocItemImage.coordinates.rotation.angleInDegrees;

return image;
};





vp.image.ImagePreview=function $vpfn_pihy2KQLmg8OCZBb022lgg396$24(image){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}



var me=this;




this.image=image;





this.previewSize={};
this.previewSize.width=0;
this.previewSize.height=0;






this.bestFit=true;






this.exactSize=false;




this.getPreviewUrl=function $vpfn_KgJlkfMwt51TsNXYNnUETg432$25(){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var sUrl=me.getPreviewUrlObject().toString();



if(me.image.type==vp.image.Type.Library){


if(vp.ui&&vp.ui.imageUrl){
sUrl=vp.ui.imageUrl(sUrl,true);
}
}

return sUrl;
};

this.getPreviewUrlObject=function $vpfn_f9lOATeWkSIA4TQfICteoA448$31(){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var bIsCropped=me.image.cropInfo&&me.image.isCropped();
var bIsRotated=me.image.rotation&&me.image.rotation!==vp.image.EditedImage.Rotation.None;
var bIsCustomized=bIsCropped||bIsRotated;
var bIsThumbnail=me.previewSize.width<=100&&me.previewSize.height<=100;

if(me.image.previewUrl&&bIsThumbnail&&!me.exactSize&&!bIsCustomized){



return new $.Url(me.image.previewUrl);
}
else if(me.image.type==vp.image.Type.Caricature){

return getCaricaturePreviewUrl();
}
else if(me.image.type==vp.image.Type.CustomerSiteUpload){

return new $.Url("/vp/util/image_preview.aspx?thumb=true&type=CustomerSiteUpload&image_id="+me.image.id);
}
else{

return getImagePreviewUrl();
}
};




var getImagePreviewUrl=function $vpfn__KUgiISVsxk8ju4B0b0l0w477$29(){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

var imageData=vp.image.imageDataStorage.getImageCached(me.image.id,me.image.type)||{};


var bRenderDistributed=!imageData.isEmbroidery;
var bLibrary=me.image.type==vp.image.Type.Library;
var sPrefix=bLibrary?'/any':(bRenderDistributed?imageData.plantPrefix||"":"");
var sPath=bLibrary?'/preview/image.caspx':'/preview/image.aspx';
var url=new $.Url(sPrefix+sPath);









var imageType="invalid";
var imageTypeEnum=me.image.type;
if(imageTypeEnum===undefined&&me.image.attributes!==null){
imageTypeEnum=me.image.attributes.type;
}
switch(imageTypeEnum){
case vp.image.Type.Library:
imageType="image";
break;
case vp.image.Type.Upload:
imageType="upload";
break;
case vp.image.Type.Logo:
imageType="logo";
break;
default:

break;
}
url.setItem('image_type',imageType);

if(me.image.type==vp.image.Type.Upload&&vp.image.ImagePreview.USE_MCP){
url.setItem("mcp_rp",1);
}


if(bRenderDistributed&&imageData.token){
url.setItem('image_token',imageData.token);
}
else{
url.setItem('image_id',me.image.id);
}





if(me.previewSize.width>0&&me.previewSize.height>0)
{
if(me.bestFit){
url.setItem('maxwidth',me.previewSize.width);
url.setItem('maxheight',me.previewSize.height);
}
else{
url.setItem('width',me.previewSize.width);
url.setItem('height',me.previewSize.height);
}
}
url.setItem('trim',1);



if(me.image.type==vp.image.Type.Upload){
url.setItem('png',1);
}
else{
url.setItem('trypng',1);
}


switch(me.image.rotation){
case vp.image.EditedImage.Rotation.Rotation90:
case vp.image.EditedImage.Rotation.Rotation180:
case vp.image.EditedImage.Rotation.Rotation270:
url.setItem('rotation',me.image.rotation);
break;
case vp.image.EditedImage.Rotation.None:
default:
break;
}


if(me.image.cropInfo&&me.image.isCropped()){
url.setItem('use_crop',1);
url.setItem('cropleft',me.image.cropInfo.left);
url.setItem('croptop',me.image.cropInfo.top);
url.setItem('cropright',me.image.cropInfo.right);
url.setItem('cropbottom',me.image.cropInfo.bottom);
}


if($.deparam(window.location.search)["admin"]){
url.setItem("admin",$.deparam(window.location.search)["admin"]);
}

return url;
};

var getCaricaturePreviewUrl=function $vpfn_vvzt9GqM9U2GxTZ$BhPL4Q584$34(){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var url=new $.Url('/vp/ns/caricatures/caricature_preview.aspx');


url.setItem('caricature_id',me.image.id);


url.setItem('width',me.previewSize.width);
url.setItem('height',me.previewSize.height);

return url;
};
};






vp.image.ImageInfo=function $vpfn_USQyJai8sSch1zBZ1_TUqw603$21(){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}



var me=this;





var my={};






my.image=null;





my.callbackFnOK=null;





my.callbackFnError=null;






this.intrinsicWidth=null;





this.intrinsicHeight=null;





this.name=null;





this.loadImageInfo=function $vpfn_Uy59YCeXrax2T7NLSr8KmQ657$25(oImage,cbOK,cbError){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

this.intrinsicWidth=null;
this.intrinsicHeight=null;
this.name=null;

my.image=oImage;
my.callbackFnOK=cbOK;
my.callbackFnError=cbError;

var url=new $.Url('/vp/ns/imageinfo.caspx');


url.setItem('image_id',my.image.id);



var imageType="invalid";
var imageTypeEnum=my.image.type;
if(imageTypeEnum===undefined&&my.image.attributes!==null){
imageTypeEnum=my.image.attributes.type;
}
switch(imageTypeEnum){
case vp.image.Type.Library:
imageType="image";
break;
case vp.image.Type.Upload:
imageType="upload";
break;
default:
throw"invalid image type";
break;
}
url.setItem('image_type',imageType);

try{
$.ajax({
url:url,
success:loadImageCallback
});
}catch(oError){
my.callbackFnError();
}
};





var loadImageCallback=function $vpfn_BXcZA9uOzl1PybfS0Kxzvg706$28(sResponse){if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
try{
var oInfo=$.parseJSON(sResponse);
if(oInfo.error){
my.callbackFnError();
}
else{
me.intrinsicWidth=oInfo.intrinsicWidth;
me.intrinsicHeight=oInfo.intrinsicHeight;
me.name=oInfo.name;

my.callbackFnOK();
}
}catch(oError){
alert(oError);
my.callbackFnError();
}
};
};




vp.image.ImageDataStorage=function $vpfn_hV5dJVuP3OS2ZfiwxJ$teA729$28()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var me=this;
var _uploadList={};
var _libraryImageList={};


this.getImageCached=function $vpfn_0BmcffmUjN9G2b7tXB0JEw736$26(iImageId,eImageType)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
if(iImageId>0&&eImageType===vp.image.Type.Upload)
{
return _uploadList[iImageId];
}
if(iImageId>0&&eImageType===vp.image.Type.Library)
{
return _libraryImageList[iImageId];
}
return null;
};


this.getImage=function $vpfn_UNqrM78miQ7gBAx4RNiZ7A750$20(iImageId,eImageType)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

if(typeof(eImageType)=="undefined")
{
eImageType=vp.image.Type.Upload;
}

if(eImageType!=vp.image.Type.Upload&&eImageType!=vp.image.Type.Library)
{
return null;
}


var oImage=me.getImageCached(iImageId,eImageType);
if(oImage)
{
return oImage;
}


if(iImageId>0)
{
try
{

var vData=$.ajaxAsmx(
{
url:new $.Url('/sales/images/imagedata.asmx?'),
methodName:"GetImageData",
data:{imageId:iImageId,imageType:eImageType},
async:false
});

var oData=$.parseJSON(vData);
if(oData.id>0)
{
return vp.image.parseJSON(oData);
}
}
catch(ex){}
}


return null;
};


this.addImage=function $vpfn_kvcexX3mPEnFy$W21ODyVw798$20(oImage)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
if(oImage.id>0&&oImage.type===vp.image.Type.Upload)
{
_uploadList[oImage.id]=oImage;
}
else if(oImage.id>0&&oImage.type===vp.image.Type.Library)
{
_libraryImageList[oImage.id]=oImage;
}
};
};

vp.image.imageDataStorage=new vp.image.ImageDataStorage();