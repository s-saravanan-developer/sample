<?php
require './vendor/autoload.php';

$html = "<div class='box' style='border: 4px solid #8FB3E7;
  padding: 20px;
  color: white;
  font-size: 100px;
  width: 800px;
  height: 400px;
  font-family: 'Roboto';
  background-color: #8BC6EC;
  background-image: linear-gradient(135deg, #8BC6EC 0%, #9599E2 100%);'>
  <h3>Hi, Saravanan </h3>
</div>";
// $css = ".ping { padding: 20px; font-family: 'sans-serif'; }";

$client = new GuzzleHttp\Client	();
// Retrieve your user_id and api_key from https://htmlcsstoimage.com/dashboard
$res = $client->request('POST', 'https://hcti.io/v1/image', [
  'auth' => ['426fea65-1888-41d7-befd-7bf9099133ed', '6e2f24f0-ec58-4ee9-9cda-4693fa221bf2'],
  'form_params' => ['html' => $html, 'css' => '']
]);

echo $res->getStatusCode();
echo $response= $res->getBody();
// {"url":"https://hcti.io/v1/image/5803a3f0-abd3-4f56-9e6c-3823d7466ed6"}
$response=json_decode($response);
?>

			<?php 
                $path = $response->url;
                $type = pathinfo($path, PATHINFO_EXTENSION);
                $data = file_get_contents($path);
                $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

              ?>
            <div id="image" >
              <img src="<?php echo $base64; ?>" id="result" style="width:800px;height:400px;" >
            </div>