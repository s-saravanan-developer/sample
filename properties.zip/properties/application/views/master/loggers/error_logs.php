
<div class="content-wrapper">
   <div class="content">
      <header class="page-header">
         <div class="d-flex align-items-center">
            <div class="mr-auto">
               <h1 class="separator">Error Logs</h1>
               <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i></a></li>
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard">Master</a></li>
                     <li class="breadcrumb-item active" aria-current="page">Error Logs</li>
                  </ol>
               </nav>
            </div>
            <ul class="actions top-right">
               <li class="dropdown">
                  <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                  <i class="la la-ellipsis-h"></i>
                  </a>
                  <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
                     <div class="dropdown-header">
                        Quick Actions
                     </div>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-clockwise"></i> Refresh
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-gear"></i> Manage Widgets
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-cloud-download"></i> Export
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-help"></i> Support
                     </a>
                  </div>
               </li>
            </ul>
         </div>
      </header>
      <section class="page-content container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="card">
                  <h5 class="card-header">
                     <div style="float: left;">
                         Error Log History
                     </div>
                     <div class="" style="float: right;">
                      <button class="btn btn-accent btn-floating btn-outline" data-toggle="modal" data-target="#multiexport">Clear logs</button>
                    </div>
                  </h5>
                  
                  <div class="card-body"><?php //var_dump($attempts);?>
                     <table id="bs4-table" class="table table-striped table-bordered table-responsive" style="width:100%">
                        <thead>
                           <tr>
                              <th style="width: 5%">S.No</th>
                              <th style="width: 25%">Error.Statement</th>
                              <th style="width: 25%">Error.File</th>
                              <th style="width: 2%">Err.Line</th>
                              <th style="width: 10%">Date.Time</th>
                              
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                              if (!empty($error_logs)) {
                                  $s = 1;
                                  foreach ($error_logs as $list) {
                                      ?>
                           <tr>
                              <td ><?php echo $s; ?></td>
                              <td class="s_no"><?php echo ucfirst($list['errstr']); ?></td>
                              <td class="s_no"><?php echo ucfirst($list['errfile']); ?></td>
                              <td class="s_no"><?php echo ucfirst($list['errline']); ?></td>
                              <td class="s_no"><?php echo ucfirst($list['time']); ?></td>
                           </tr>
                           <?php
                              $s++;
                              }
                              }
                              ?>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </section>
   </div>
</div>
</div>	

<!-- Model Execution -->

<!-- Editing -->

<!-- BASIC MODAL DEMO -->
<div class="modal fade" id="deletemodel" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Logg Attempt</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <!-- <form action="<?php echo base_url();?>master/unit/delete" method="POST"> -->
            <div class="modal-body">
              <div class="card">
                <div class="row">
                  <div class="form-group col-md-12">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Browser</label>
                                       </div>
                                       <div class="col-1">
                                           <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                           <label for="field-1" class="control-label company_code" id="label-browser"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>
                </div>
                <div class="row">
                  <div class="form-group col-md-12">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Ip</label>
                                       </div>
                                       <div class="col-1">
                                           <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                           <label for="field-1" class="control-label company_code" id="label-ip"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>
                </div>
                <div class="row">
                  <div class="form-group col-md-12">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Date & Time</label>
                                       </div>
                                       <div class="col-1">
                                           <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                           <label for="field-1" class="control-label company_code" id="label-date"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>
                </div>
                <div class="row">
                  <div class="form-group col-md-12">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Username</label>
                                       </div>
                                       <div class="col-1">
                                           <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                           <label for="field-1" class="control-label company_code" id="label-username"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>
                </div>
                <div class="row">
                  <div class="form-group col-md-12">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Password</label>
                                       </div>
                                       <div class="col-1">
                                           <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                           <label for="field-1" class="control-label company_code" id="label-password"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>
                </div>
              </div>
              
               <!-- Hiiden Values -->
               <!-- <input type="hidden" name="url" value="unit">
               <input class="delete_id" type="hidden" name="Units_id">
               <input class="table_name" type="hidden" name="table_name">	 -->					
            </div>
            <div class="delete-footer">
               <!-- <button type="submit" class="btn btn-primary">Yes, delete it!</button> -->
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>						
            </div>
         <!-- </form> -->
      </div>
   </div>
</div>


<script type="text/javascript">
  function view_logg(val,val1,val2,val3,val4,val5,val6,val7,val8,val9,val10){
$('#label-browser').text(val4);
      $('#label-ip').text(val5);     
      $('#label-date').text(val6);
      $('#label-username').text(val7);
      $('#label-password').text(val8);
  }
</script>


<div class="modal fade" id="multiexport" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Export</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
              
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
              <form action="<?php echo base_url(); ?>master/Loggers/clear_log_list" method="post">
               <button  type="submit" class="btn btn-primary multi_export">Yes, Clear it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>      
               </form>            
            </div>
            
      </div>
   </div>
</div>
