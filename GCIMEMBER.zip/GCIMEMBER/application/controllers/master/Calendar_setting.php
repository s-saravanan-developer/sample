<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calendar_setting extends CI_Controller {

	public function __construct() {
        parent::__construct();
        if ($this->session->userdata('is_logged_in') == '') {            
            redirect('login');
            session_destroy();
        }
        $this->load->helper(array('form', 'url'));
        $this->load->model('master/Users_model');
        $this->load->model('master/Company_model');
        $this->load->model('master/Location_model');
        $this->load->model('master/Calendar_setting_model');

        // $this->load->model('master/Upload_model');
        // $this->load->model('master/Users_model');
    }

	public function index()
	{      
		$template['table_name'] 	=	"gc_company_table";
        $template['weeks']        =   $this->Calendar_setting_model->get_weeks();
        $template['holiday']        =   $this->Calendar_setting_model->get_holidays();
        // var_dump($template['company']);die();
		$template['page']		    =	'master/settings/calendar_setting';
        $this->load->view('template',$template);
	}

    public function update_yearly_holiday()
    {      
        $Week_holiday = $this->input->post('Week_holiday');
        $Selected_Days = $this->input->post('Days');
        $Color = $this->input->post('Color');
        $Id = $this->input->post('Id');
        $final_days=[];
        $final_days1=[];
        foreach($Week_holiday as $value){
                $new = [];
                for($i = 1;$i<=12;$i++){
                    $days = $this->getDays(date('Y'),$i,$value);
                    $final[] = $days;
                    foreach($days as $key => $val){
                        $final_days1=array('Date' => $val,'Days' => $value);
                        array_push($final_days,$final_days1);
                        // array_push($final_days,$value);
                    // array_push($final_days1,$final_days);

                    }
                    
                }
                    
                // array_push($final_days)
        }
        // var_dump($final_days);
        // die();
        // $finaldays=implode(',',$final_days);
        $this->db->where('Event_status', 0);
        $this->db->delete('gc_individual_calendar');
        foreach($final_days as $final){

        $data_events = array(
                     "Company_id" => $this->session->userdata('CompanyId'),
                     "Date" => $final['Date'],
                     "Days" => $final['Days'],
                     "Event" => "Weekly Holidays",
                     "Description" => "Weekly Holidays",
                     "Color"=> $Color,
                     "Event_status" => 0,
                 );
        $events = $this->Calendar_setting_model->insert_weekly_holidays1($data_events,$Id);
    }
foreach($Week_holiday as $value){
                $new = [];
                for($j = 1;$j<=12;$j++){
                    $days = $this->getDays(date('Y'),$j,$value);
                    $final1[] = $days;
                    foreach($days as $val){
                        array_push($final_days1,$val);
                    }
                }
                // array_push($final_days)
        }
        // var_dump($final_days);
        $finaldays1=implode(',',$final_days1);
        $data_events1 = array(
                     "Company_id" => $this->session->userdata('CompanyId'),
                     "Date" => $finaldays1,
                     "Days" => implode(",", $Week_holiday),
                     "Event" => "Weekly Holidays",
                     "Color"=> $Color
                 );
        // var_dump($data_events1);die();
        $events = $this->Calendar_setting_model->insert_weekly_holidays($data_events1,$Id);

        redirect('master/Calendar_setting');
    }

    public function getDays($y,$m,$d){ 
    $date = "$y-$m-01";
    $first_day = date('N',strtotime($date));
    $first_day = $d - $first_day + 1;
    $last_day =  date('t',strtotime($date));
    $days = array();
    for($i=$first_day; $i<=$last_day; $i=$i+7 ){
        $days[] = $y.'-'.$m.'-'.$i;
        //$days[] = implode(',',$days);
    }
    return $days;
}


    public function get_events()
 {
     // Our Start and End Dates
     $start = $this->input->get("start");
     $end = $this->input->get("end");

     $startdt = new DateTime('now'); // setup a local datetime
     $startdt->setTimestamp($start); // Set the date based on timestamp
     $start_format = $startdt->format('Y-m-d H:i:s');

     $enddt = new DateTime('now'); // setup a local datetime
     $enddt->setTimestamp($end); // Set the date based on timestamp
     $end_format = $enddt->format('Y-m-d H:i:s');

     $events = $this->Calendar_setting_model->get_events($start_format, $end_format);
     // $events1 = $this->Calendar_setting_model->get_events1(date('Y'));
     $data_events = array();



     foreach($events->result() as $r) {

         $data_events[] = array(
             "id" => $r->Id,
             "title" => $r->Event,
             "description" => $r->Description,
             //"end" => $r->Date,
             "start" => $r->Date,
             "status" => $r->Event_status,
             "clr"=>$r->Color,
             "color" =>'#'.$r->Color

         );
     }

// $data_events1 = array();

// $samp_id=$events1[0]['Id'];
// $samp_title=$events1[0]['Event'];
// $samp_description=$events1[0]['Event'];
// $samp_end=$events1[0]['Date'];
// $samp_start=$events1[0]['Date'];
// $new_samp=explode(',',$samp_end);
// $Color=$events1[0]['Color'];

// foreach($new_samp as $sampval){
//     $data_events[] = array(
//              "id" => $samp_id,
//              "title" => $samp_title,
//              "description" => $samp_description,
//              "end" => date("Y-m-d", strtotime($sampval)),
//              "start" => date("Y-m-d", strtotime($sampval)),
//              "status" => $events1[0]['Event_status'],
//              "color" =>'#'.$Color
//          );

// }

     echo json_encode(array("events" => $data_events));
     // exit();
 }

   public function samp(){
    $events1 = $this->Calendar_setting_model->get_events1(date('Y'));
    // var_dump($events1);
   }

public function add_monthly_setting(){
    extract($_POST);
    $setting_data=array(
        'Event' => $event,
        'Date' => $date,
        'Description' => $description,
        'Color' => $color);

    $events1 = $this->Calendar_setting_model->add_monthly_setting($setting_data);
    return $events1;
    
   }

public function edit_monthly_setting(){
    extract($_POST);
    $setting_data=array(
        'Event' => $event,
        'Date' => $date,
        'Description' => $description,
        'Color' => $color );
    $events1 = $this->Calendar_setting_model->edit_monthly_setting($setting_data,$id);
    return $events1;
   }
   public function edit_monthly_setting1(){
    extract($_POST);
    $setting_data=array(
        'Date' => $date);
    $events1 = $this->Calendar_setting_model->edit_monthly_setting($setting_data,$id);
    return $events1;
   }

public function delete_monthly_setting(){
    extract($_POST);
    $events1 = $this->Calendar_setting_model->delete_monthly_setting($id);
    return $events1;
   }

public function insert_multiple_holiday(){
$unique_id = $this->input->post('unique_id');
$unique=explode(',',$unique_id);
        foreach($unique as $val){
             $holiday['multiple_'.$val]                  = $this->input->post('multiple_'.$val);
             $holiday['multiple_'.$val]['Date']=date("Y-m-d", strtotime($holiday['multiple_'.$val]['Date']));
        $Inserted_id1   =   $this->Calendar_setting_model->add_monthly_setting($holiday['multiple_'.$val]);
        }
        redirect('master/Calendar_setting');
}
   



}

?>