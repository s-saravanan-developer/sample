<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Branch extends CI_Controller {

	public function __construct() {
        parent::__construct();
        if ($this->session->userdata('is_logged_in') == '') {            
            redirect('login');
            session_destroy();
        }
        $this->load->model('master/Branch_model');
        $this->load->model('master/Location_model');
        $this->load->model('master/Company_model');
        $this->load->model('master/Categories_model');
        $this->load->model('master/Ventors_model');
        $this->load->model('Common_model');
    }

    /**
     * [Country Page]
     * @return [countty] Main Page
     * 
     */
	public function index()
	{		
		$template['table_name'] =	"mpro_hub_branch";
		$template['branch'] 	=	$this->Branch_model->get_all_branch_for_front_view();		
		$template['page']		=	'master/branch/branch';
        $this->load->view('template',$template);
	}

	public function delete()
	{
		$url 	= $this->input->post('url');	
		$id 	= $this->input->post('Branch_id');
		$table_name = $this->input->post('table_name'); $table_name = strtolower($table_name);
		$this->Branch_model->delete($table_name,$id);
		redirect('master/branch/');
	}

	public function adding_branch()
	{		
		$template['Prefix']         = $this->Branch_model->get_prefix();
		$template['hub_code'] 		= $this->Branch_model->get_hub_increment_code();	
		$template['company'] 		= $this->Company_model->get_all_company();	
		$template['branch_code'] 	= $this->Branch_model->get_branch_increment_code();
		$template['countries'] 		= $this->Location_model->get_location_country();
        $template['states'] 		= $this->Location_model->get_states_by_country_id(1);
		$template['table_name'] 	=	"mpro_hub_branch";		
		$template['page']			=	'master/branch/branch_add';
        $this->load->view('template',$template);
	}

	public function editing_branch()
	{	
		$id=$this->input->get('id');
		$template['countries'] 		= $this->Location_model->get_location_country();
        $template['states']         = $this->Location_model->get_full_states_data();
        $template['city'] 			= $this->Location_model->get_full_city_data();			
		$template['branch'] 	=	$this->Branch_model->get_all_branch_specific($id);		
		$template['table_name'] =	"mpro_hub_branch";		
		$template['page']		=	'master/branch/branch_edit';
        $this->load->view('template',$template);
	}

	public function editing_view()
	{	
		$id=$this->input->get('id');
		$template['countries'] 		= $this->Location_model->get_location_country();
        $template['states']         = $this->Location_model->get_full_states_data();
        $template['city'] 			= $this->Location_model->get_full_city_data();			
		$template['branch'] 	=	$this->Branch_model->get_all_branch_specific($id);		
		$template['table_name'] =	"mpro_hub_branch";		
		$template['page']		=	'master/branch/branch_view';
        $this->load->view('template',$template);
	}

	public function updating_branch ()
	{
		$id = $this->input->post('branch_id');
        $branch_edit = $this->input->post('branch');
        $this->Branch_model->updating_branch($branch_edit,$id);
        redirect('master/branch/');
	}

	public function adding_branch_insert()
	{	
		$branch_data          	= array();	
		$branch_data          	= $this->input->post('branch');
		$gst_no               	= $this->input->post('gst_no');		

		// die();
		$gst_prefix           	= $this->input->post('gst_no_prefix');
		$branch_data['gst_no']	= $gst_prefix.$gst_no;
		$hub_code             	= $this->input->post('hub_code');

		$Prefix         = $this->Branch_model->get_prefix();
		$template['hub_code'] 		= $this->Branch_model->get_hub_increment_code();
		$template['branch_code'] 	= $this->Branch_model->get_branch_increment_code();
		if($branch_data['branch_code']!=""){
			$branch_data['branch_code']=$Prefix[0]['branch_prefix']."-000".$template['branch_code'];
		}
		if($branch_data['hub_code']!=""){
			$branch_data['hub_code']=$Prefix[0]['hub_prefix']."-000".$template['hub_code'];
		}
		// Inserting Branch
		$branch_id            	=$this->Branch_model->inserting_branch($branch_data);

		$rate_setting_count = $this->db->count_all_results('mpro_product_rate_setting');
		$rate_region_count=$this->Branch_model->get_all_regions_by_id($branch_id);

	if($branch_data['branch_code']!=""){
		if($rate_setting_count!=0 && $rate_region_count==0){
			$data['Products'] = $this->Branch_model->get_all_Products();

			foreach($data['Products'] as $products){
				//echo $products['Tax'];
				$this->db->select('*')->from('mpro_gst_states');
				$this->db->where('state_id', $branch_data['state_id']);
				$query1 = $this->db->get();
				$get1['state_gst']=$query1->result_array();
				$division = array(
					'Product_id' => $products['Product_id'], 
					'company_id' => $this->session->userdata('CompanyId'),
					'Division' => $branch_id, 
					'Str_percent' => $products['Str_persent'], 
					'Ptr_percent' => $products['Ptr_persent'], 
					'tax' => $get1['state_gst'][0]['id'],
					'Status' => 1, 
					);
		           $this->Categories_model->adding_division($division);

		           $stocks = array(
					'Product_id' => $products['Product_id'], 
					'Company_id' => $this->session->userdata('CompanyId'),
					'Region_id' => $branch_id, 
					'Quantity' => 0, 
					'Status' => 1, 
					);

		           $this->Categories_model->adding_stocks($stocks);
			}
		}
	}
			
		$this->Branch_model->adding_branch_prefix($branch_id);	

		// Transaction Prefix Adding Functions 

			$region_name                                      = $this->Branch_model->get_state_code_data($branch_id);
            $region_code                                      = $region_name[0]['b_id']; 
            $reg                                              = strtoupper(substr($region_name[0]['alis_name'], 0, 2));
            $year                                             = explode('-',$this->session->userdata('financial_yr'));
            $year                                             = substr($year[0], 2, 2).substr($year[1], 2, 2);   
            
            // Basic STOCK PREFIX            
            $transaction_data['stock_transfer']               = $reg.$region_code.'ST'.$year;
            
            // Common Top
            $transaction_data['user_prefix']                  = $reg.$region_code.'U'.$year;            
            $transaction_data['customer_prefix']              = $reg.$region_code.'CUS'.$year;
            $transaction_data['employee_prefix']              = $reg.$region_code.'EMP'.$year;
            $transaction_data['vendor_prefix']                = $reg.$region_code.'SUP'.$year;
            $transaction_data['manufacture_prefix']           = $reg.$region_code.'MF'.$year;
            $transaction_data['dispatch_prefix']              = $reg.$region_code.'DP'.$year;

            $transaction_data['credit_prefix']              = $reg.$region_code.'CRE'.$year;
            $transaction_data['debit_prefix']               = $reg.$region_code.'DEP'.$year;

            $transaction_data['approval_prefix']               = $reg.$region_code.'APR'.$year;
            $transaction_data['credit_note_prefix']               = $reg.$region_code.'CRN'.$year;

            // Common Prefix 
            $transaction_data['scheme']                		  = $reg.$region_code.'SC'.$year;
            $transaction_data['grn']                          = $reg.$region_code.'G'.$year;
            $transaction_data['purchase_return']              = $reg.$region_code.'PR'.$year;

            // Close Book
            $transaction_data['close_date']              	  = date("t/m/Y", strtotime(date("t-m-Y")));
            $transaction_data['allow_change']              	  = '1';
            $transaction_data['close_book']              	  = '1';
            $transaction_data['warning_days']              	  = ' ';

            // advice 
            // $transaction_data['advice']              		  = $reg.$region_code.'A'.$year;


		$this->Branch_model->adding_transaction_prefix($branch_id,$transaction_data);		
		$this->Branch_model->adding_branch_details_user($branch_id,$branch_data);		
		
		// Adding Branch prefix Data
		// $this->Branch_model->inserting_branch($branch_data);		


		// Addin Supplier
		$count = 'MRP/SUP/-0000'.$this->Ventors_model->get_increment_code();

		$adding_ventors_data = array(
			'company_id'   => $branch_data['company_id'] ,
			'Division_id'  => $branch_id,
			'Ventor_name'   => $branch_data['type_name'] ,
			'Display_name'   => $branch_data['type_name'] ,
			'Company_name'   => $branch_data['type_name'] ,
			'Ventor_code'	=> $count,
			'Supplier_type_id' => '1',
			'Email_id'      => $branch_data['email'] ,
			'Mobile_number' => $branch_data['mobile'] ,
			'B_address1'    => $branch_data['address'] ,
			'B_address2'    => $branch_data['address2'] ,
			'B_country_id'  => $branch_data['country_id'] ,
			'B_state_id'    => $branch_data['state_id'] ,
			'B_city_id'     => $branch_data['city_id'] ,
			'Gstin'			=> $gst_no,
			'Gst_reg_type'  => $branch_data['gstType'],
			'Status'  		=> '1',
			'Created_by' 	=> $this->session->userdata('UserId'),
			 );

		 $this->Branch_model->adding_ventors_for_branch($adding_ventors_data);
		 
        redirect('master/branch');
	}

	// Prefix Funcion    
    public function prefix_setting()
    {        
    	$id = $this->input->get('id');
        $template['id'] 	       			   = $id;
        $template['advice'] 			       =  $this->Company_model->get_transaction_prefix_advice($id);
        $template['transaction_prefix']        =  $this->Company_model->get_transaction_prefix_data_branch($id);
        $template['transaction_prefix_common'] =  $this->Company_model->get_transaction_prefix_common($id);
        $template['branch'] 			       =  $this->Branch_model->get_all_branch_specific($id);
        $template['drug_type'] 			       =  $this->Branch_model->get_all_drug_type($id);
        $template['product'] 			       =  $this->Common_model->get_product();
        $template['page']           		   =   'master/branch/prefix_setting';
        $this->load->view('template',$template);
    }

	
	public function updating_tranaction_branch()
	{
		$id = $this->input->post('id');
        $this->Company_model->updating_transaction_prefix($_POST['transaction_prefix'],$id);
        redirect('master/branch/prefix_setting/');
	}

    public function get_statecode() {
       	$id = $this->input->post('id');
        $result=$this->Branch_model->get_state_code($id);
        echo json_encode($result);
    }


    // transaction_region Update
    public function updating_transaction_region_updating()
	{
		$data = array(
			'advice'     		 => $this->input->get_post('advice'), 
			'customer_order'     => $this->input->get_post('customer_order'), 
			'sales_invoice'      => $this->input->get_post('sales_invoice'), 
			'sales_return'       => $this->input->get_post('sales_return'), 
			'stock_transfer'     => $this->input->get_post('stock_transfer'), 
			'delivery_challange' => $this->input->get_post('delivery_challange'),
			'approval_prefix'     	 => $this->input->get_post('approval_prefix'), 
			'credit_note_prefix'     	 => $this->input->get_post('credit_note_prefix'),
			'collection_entry_prefix'     	 => $this->input->get_post('collection_entry_prefix')
		);
			$id =  $this->input->post('id_team');
			// $this->input->post('name')
			$result=$this->Branch_model->update_prefix_transaction($id,$data);
	}

	    // transaction_region Update
    public function updating_transaction_region_common_updating()
	{
		$data = array(
			'scheme'     => $this->input->get_post('scheme'), 
			'grn'      => $this->input->get_post('grn'), 
			'purchase_return'       => $this->input->get_post('purchase_return')
		);

		$id = $this->input->get_post('id');
		$result=$this->Branch_model->update_prefix_transaction_common($id,$data);		
	}

	public function updating_transaction_region_common_updating_top()
	{
		$data = array(
			'user_prefix'            => $this->input->get_post('user_prefix'), 
			'customer_prefix'        => $this->input->get_post('customer_prefix'), 
			'employee_prefix'        => $this->input->get_post('employee_prefix'), 
			'vendor_prefix'          => $this->input->get_post('vendor_prefix'), 
			'manufacture_prefix'     => $this->input->get_post('manufacture_prefix'), 
			'dispatch_prefix'     	 => $this->input->get_post('dispatch_prefix'), 
			'credit_prefix'     	 => $this->input->get_post('credit_prefix'), 
			'debit_prefix'     	 => $this->input->get_post('debit_prefix'), 
			'approval_prefix'     	 => $this->input->get_post('approval_prefix'), 
			'credit_note_prefix'     	 => $this->input->get_post('credit_note_prefix'), 
		);

		$id = $this->input->get_post('id');
		$result=$this->Branch_model->update_prefix_transaction_common($id,$data);		
	}

	public function updating_transaction_region_advice_setting()
	{
		 $gst = $this->input->get_post('gst');
		 $qty = $this->input->get_post('advice_qty');
		 $dispatch_buff_date = $this->input->get_post('dispatch_buff_date');

		if(isset($gst))
		{
			$data = array(
				'advice_gst' => $gst,					
				'advice_qty' => '',
				'dispatch_buff_date' => $dispatch_buff_date					
			);
		}
		else{
			$data = array(
				'advice_qty' => $qty,
				'advice_gst' => '',							
				'dispatch_buff_date' => $dispatch_buff_date		
			);
		}

		$id = $this->input->get_post('id');
		$result=$this->Branch_model->update_prefix_transaction_common($id,$data);		
	}

	// close Box
	public function updating_transaction_region_close_book()
	{
		$data = $this->input->get_post('close_book');
		$id = $this->input->get_post('id');
		//print_r($id);
		print_r($data);
		if(empty($data['close_book'])){
			$data['close_book'] = 0;
		}else if(empty($data['allow_change'])){
			$data['allow_change'] = 0;
		}
		$result=$this->Branch_model->update_prefix_transaction_advice($id,$data);		
	}

	// Sales Order
	public function updating_transaction_sales_order()
	{
		$id = $this->input->get_post('id');
		 $sales_order = array(
		 	'drug_item_type' => $this->input->get_post('drug_item_type'),
		 	'drug_price_type' => $this->input->get_post('drug_price_type'),
		 	'so_tax' => $this->input->get_post('so_tax'),
		 	'day_setting' => $this->input->get_post('day_setting'),
		 );

		$result=$this->Branch_model->update_prefix_sales_order($id,$sales_order);		
		
	}

	// Direct Sale
	public function updating_transaction_direct_sale()
	{
		// Check New Or Update
		extract($_POST);
		// var_dump($_POST);
		$Pro = implode(',', $Product_id);
		$direct_sale = array(
			'Type_id' => $Type_id, 
			'Product_id' => $Pro, 
			'discount' => $discount,
		);
		$result=$this->Branch_model->updating_sales_direct_data($id,$direct_sale);
	}
	
	
	public function delete_checkbox(){
	             $id = ( explode( ',', $this->input->get_post('id') ));             
	             foreach ($id as  $value) {
	             	$this->Branch_model->delete_checkbox($value);
	             }
	    }
	
	    public function active_all_checkbox(){
	             $id = ( explode( ',', $this->input->get_post('id') ));             
	             foreach ($id as  $value) {
	             	$this->Branch_model->active_all_checkbox($value);
	             }
	    }
	
	    public function deactivate_all_checkbox(){
	             $id = ( explode( ',', $this->input->get_post('id') ));  
	                      
	             foreach ($id as  $value) {

	             	$this->Branch_model->deactivate_all_checkbox($value);
	             }
	    }

	public function teambased_customer(){
        $id 	   								= 	$this->input->post('team_id');
        $region_id 								= 	$this->input->post('region_id');
        $check     								= 	$this->input->post('check');
		$template['customer']					=	$this->Branch_model->teambased_customer($region_id,$id);
        $template['product'] 			        =   $this->Common_model->get_product();
        $template['check'] 			        	=   $check;
        $template['existing_data']	        	=   $this->Branch_model->get_ds_existing_data($region_id,$id);
        $this->load->view('master/branch/ajax_direct_sales',$template);     
    } 



}

?>