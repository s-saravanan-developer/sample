<script>
   <?php
         if ($this->session->flashdata('categor_success')) 
         {
            echo "var data = ' ".$this->session->flashdata('categor_success')."';";
            echo "success(data);";
         }
         if ($this->session->flashdata('categor_error')) 
         {
            echo "var data = ' ".$this->session->flashdata('categor_error')."';";
            echo "duplicate(data);";
         }
   ?>
</script>
<div class="content-wrapper">
   <div class="content">
      <header class="page-header">
         <div class="d-flex align-items-center">
            <div class="mr-auto">
               <h1 class="separator">Categories</h1>
               <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i></a></li>
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard">Categories Management</a></li>
                     <li class="breadcrumb-item active" aria-current="page">Categories</li>
                  </ol>
               </nav>
            </div>
            <ul class="actions top-right">
               <li class="dropdown">
                  <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                  <i class="la la-ellipsis-h"></i>
                  </a>
                  <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
                     <div class="dropdown-header">
                        Quick Actions
                     </div>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-clockwise"></i> Refresh
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-gear"></i> Manage Widgets
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-cloud-download"></i> Export
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-help"></i> Support
                     </a>
                  </div>
               </li>
            </ul>
         </div>
      </header>
      <section class="page-content container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="card">
                  <h5 class="card-header">
                     <div style="float: left;">
                        Manage Categories	
                     </div>
                     <div style="float: right;">
                      <?php //if($this->Common_model->add_permission(Categories_global) != 0){ ?>
                        <button type="button" class="btn btn-success  btn-floating" data-toggle="tooltip" data-placement="top" data-original-title="Add New Category"> 
                        <p class="text-white" data-toggle="modal" data-target="#addusertype">
                        Add New Category</p>
                        </button>
                        <?php //} ?>
                     </div>
                  </h5>
                  <div class="card-body">
                     <table id="bs4-table" class="table table-striped table-bordered table-responsive" style="width:100%; overflow-y: auto;">
                        <thead>
                           <tr>

                            
                             <th class="text-center" style="width: 2%">
                                                               <input type="checkbox" name="checkbox" class="checkbox" id="select_all" /> 
                                                           </th>
                            
                            
                              <th style="width: 2%">S.No</th>
                              
                              <th style="width: 10%">Action</th>
                              <th style="width: 43%">Category Name</th>
                              <th style="width: 25%">Alias Name</th>
                              <th style="width: 10%">Status</th>                              
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                              if (!empty($category)) {
                                  $s = 1;
                                  foreach ($category as $list) {
                                      ?>
                           <tr>

                            
                             <td><input type="checkbox" name="checkbox" class="checkbox boxischecked" value="<?php echo ucfirst($list['id']); ?>"  /></td>
                            
                            
                              <td ><?php echo $s; ?></td>
                              <td>  
                              <?php //if($this->Common_model->edit_permission(Categories_global) != 0){ ?>          
                                 <a href="#" onclick="edit_category('<?php echo ucfirst($list['id']); ?>','<?php echo ucfirst($list['category_name']); ?>','<?php echo ucfirst($list['alis_name']); ?>','<?php echo ucfirst($list['status']); ?>')" id="usertypeedit" class="btn btn-info btn-sm editusertype" data-toggle="modal" data-target="#editusertype"><i class="zmdi zmdi-edit zmdi-hc-fw"   style="
                                    font-size: 17px;
                                    color:  white;
                                    " data-toggle="tooltip" data-placement="top" data-original-title="Edit"></i></a>

<?php //} ?><?php //if($this->Common_model->delete_permission(Categories_global) != 0){ ?>
                                      <?php if ($list['delete_status'] == 1) { ?> 

                                        <div class="btn btn-accent btn-sm">
                                        <i class="zmdi zmdi-delete zmdi-hc-fw" style="font-size: 17px;color:  white;" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"></i>
                                        </div>  

                                    <?php }else{ ?>

                                 <a href="" onclick="delete_category('<?php echo ucfirst($list['id']); ?>','<?php echo ucfirst($table_name); ?>')" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deletemodel"><i class="zmdi zmdi-delete zmdi-hc-fw" style="
                                    font-size: 17px;
                                    color:  white;
                                    " data-toggle="tooltip" data-placement="top" data-original-title="Delete"></i></a>

                                    <?php } ?><?php //} ?>
                                     
                              </td>
                              <td class="s_no"><?php echo ucfirst($list['category_name']); ?></td>
                               <td class="s_no"><?php echo ucfirst($list['alis_name']); ?></td>
                              <td><span class="badge badge-<?php echo ($list['status'] == 1) ? 'success' : 'danger'; ?>"><?php echo ($list['status'] == 1) ? 'Active' : 'In-Active'; ?></span></td>
                              
                           </tr>
                           <?php
                              $s++;
                              }
                              }  
                              ?>
                        </tbody>
                     </table>
                  </div>

                  
                   <div class="card-footer bg-light">
                    <?php //if($this->Common_model->delete_permission(Categories_global) != 0){ ?>
                               <button type="button" class="btn btn-danger delbtn"  data-toggle="modal" data-target="#deletemodel1">Delete</button>
                               <?php //} ?>
                               <?php //if($this->Common_model->others_permission(Categories_global) != 0){ ?>
                               <button type="" class="btn btn btn-success   delbtn"  data-toggle="modal" data-target="#active_all_model">Active</button>
                               <button type="" class="btn btn btn-info delbtn" data-toggle="modal" data-target="#deactive_all_model">In-Active
                               </button>
                                <button class="btn btn-primary region_input no-display" data-toggle="modal" data-target="#multiexport">Export Excel</button>
                                <button class="btn btn-primary region_input1" data-toggle="modal" data-target="#Export">Export Excel</button>
                                <?php //} ?>
                               </div>
                  
                  
               </div>
            </div>
         </div>
      </section>
   </div>
</div>
</div>	
<!-- Model Execution -->
<!-- categories RIGHT SIDE -->
<div id="addusertype" class="modal modal-right-side fade" data-backdrop="static" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel6">Categories</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <div class="modal-body"  style="overflow-y: auto">
            <div class="row">
               <div class="col">
                  <div class="card">
                     <h5 class="card-header">Add Categories</h5>
                     <?php
                        $attributes = array('id' => 'login_form','data-toggle' => 'validator');
                        echo form_open('master/categories/category_add', $attributes);
                        ?> 
                     <div class="card-body">
                        <div class="form-body">
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Category Name <span style="color:red">*</span></label>
                                    <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-sort-amount-asc zmdi-hc-fw"></i></span>
                                               </div>
                                    <input type="text" class="form-control check_data" name="category[category_name]" id="inputName" placeholder="Category Name" maxlength="25" onkeyup="duplicate_check()" required>
                                 </div>
                                 <div class="text-center duplicate-occur no-display">
                                           <code>This Category Name Is Already Used</code>
                                        </div>
                                 </div>
                              </div>
                               <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Alias Name </label>
                                    <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-sort-amount-asc zmdi-hc-fw"></i></span>
                                               </div>
                                    <input type="text" class="form-control check_data" name="category[alis_name]" id="inputName" placeholder="Alias Name"  maxlength="10" >
                                 </div>
                                 
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="col-form-label-lg" for="largeInput">Status</label>
                                    <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-equalizer zmdi-hc-fw"></i></span>
                                               </div>
                                    <select class="form-control" name="category[status]" id="defaultSelect" required="">
                                       <option value="1">Active</option>
                                       <option value="2">In-Active</option>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success  submit" id="addcategories">Save changes</button>
         </div>
         </form>
      </div>
   </div>
</div>
<!-- Editing -->
<!-- categories RIGHT SIDE -->
<div class="modal modal-right-side fade" id="editusertype" data-backdrop="static" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel6">Category</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <div class="modal-body">
            <div class="row">
               <div class="col">
                  <div class="card">
                     <h5 class="card-header">Edit Categories</h5>
                     <?php
                        $attributes = array('id' => 'login_form','data-toggle' => 'validator');
                        echo form_open('master/categories/category_edit', $attributes);
                        ?>
                     <div class="card-body">
                        <div class="form-body">
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Category Name <span style="color:red">*</span></label>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-sort-amount-asc zmdi-hc-fw"></i></span>
                                       </div>
                                    <input type="hidden" class="category_id" name="category_id" >
                                    <input type="text" onkeyup="duplicate_checkedit()" class="form-control category_name check_dataedit" maxlength="25" name="category_edit[category_name]" id="inputName" placeholder="Category Name" required >
                                 </div>
                                 <div class="text-center duplicate-occuredit no-display">
                                           <code>This Category Name Is Already Used</code>
                                        </div>
                              </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Alias Name </label>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-sort-amount-asc zmdi-hc-fw"></i></span>
                                       </div>
                                    <input type="hidden" class="category_id" name="category_id" >
                                    <input type="text"  class="form-control alis_name check_dataedit" name="category_edit[alis_name]" id="inputName" maxlength="10" placeholder="Alias Name"  >
                                 </div>
                                 
                              </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="col-form-label-lg" for="largeInput">Status</label>
                                    <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-equalizer zmdi-hc-fw"></i></span>
                                               </div>
                                    <select class="form-control status" name="category_edit[status]" id="defaultSelect" required="">
                                       <option value="1">Active</option>
                                       <option value="2">In-Active</option>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success  submit" id="editcategories">Update</button>
         </div>
         </form>	
      </div>
   </div>
</div>
<!-- BASIC MODAL DEMO -->
<div class="modal fade" id="deletemodel" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Delete</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <form action="<?php echo base_url();?>master/categories/delete" method="POST">
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
               <input type="hidden" name="url" value=" ">
               <input class="delete_id" type="hidden" name="delete_id">
               <input class="table_name" type="hidden" name="table_name">	
               <input type="hidden" name="check_data" value="Category_id"> 

            </div>
            <div class="delete-footer">
               <button type="submit" class="btn btn-primary">Yes, delete it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>						
            </div>
         </form>
      </div> 
   </div>
</div>





<div class="modal fade" id="deletemodel1" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Delete</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <button type="submit" id="del_all" class="btn btn-primary">Yes, delete it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
        
      </div>
   </div>
</div>


<div class="modal fade" id="deactive_all_model" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">In-Active</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <button type="submit" id="deactive_all" class="btn btn-primary">Yes, In-Active it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
        
      </div>
   </div>
</div>


<div class="modal fade" id="active_all_model" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Active</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <button type="submit" id="active_all" class="btn btn-primary">Yes, Active it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
        
      </div>
   </div>
</div>


<div class="modal fade" id="Export" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Export</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <a id="active_all" class="btn btn-primary export_link" data-dismiss="modal">Yes, Export it!</a>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
      </div>
   </div>
</div>


<div class="modal fade" id="multiexport" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Excel Export</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <button  type="submit" id="active_all" class="btn btn-primary multi_export" data-dismiss="modal">Yes, Export it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
        
      </div>
   </div>
</div>

<script type="text/javascript">
   function edit_category(val,val1,val2,val3){
      $('.duplicate-occuredit').addClass('no-display');
      $('#editcategories').removeAttr( "disabled", );
   	$('.category_id').val(val);
   	$('.category_name').val(val1);
      $('.alis_name').val(val2);		
   	$('.status').val(val3);
   
   }
   
   function delete_category(val,val1){
   	$('.delete_id').val(val);
   	$('.table_name').val(val1);
   	//alert($('.delete_id').val(val));
   }
      function duplicate_check() {
        // alert("hi");
      var check_data = $('.check_data').val();
      // alert(check_data);
      var result = '';
         $.ajax({
           type: "POST",
           url: "<?php echo base_url(); ?>master/location/duplicate_check",
           data: {data: check_data,table_name: 'mpro_categories',colum: 'category_name'},
           cache: true,
           async: false,
           success: function(data){
            // alert(data);
            result = data;
           }
         });
         if(result == 1){
            $('.duplicate-occur').removeClass('no-display');
            
            $('#addcategories').attr( "disabled","disabled");
            return false;
        }else{
            $('.duplicate-occur').addClass('no-display');
            $('#addcategories').removeAttr( "disabled", );
            return true;
        }
         
   }

   function duplicate_checkedit() {
        // alert("hi");
      var id = $('.category_id').val();
      var check_data = $('.check_dataedit').val();
      // alert(check_data);
      var result = '';
         $.ajax({
           type: "POST",
           url: "<?php echo base_url(); ?>master/location/duplicate_checkedit",
           data: {data: check_data,table_name: 'mpro_categories',colum: 'category_name',id:id},
           cache: true,
           async: false,
           success: function(data){
            
            result = data;
           }
         });
         if(result == 1){
            $('.duplicate-occuredit').removeClass('no-display');
            
            $('#editcategories').attr( "disabled","disabled");
            return false;
        }else{
            $('.duplicate-occuredit').addClass('no-display');
            $('#editcategories').removeAttr( "disabled", );
            return true;
        }
         
   }
</script>



<script type="text/javascript">

// To pass the value to the Controller

   $(document).ready(function() {
        $("#del_all").click(function(){
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function(){            
                favorite.push($(this).val());
            });
            //alert("Selected Countries are: " + favorite.join(","));
             $.ajax({
                        url: '<?php echo base_url() ?>master/categories/delete_checkbox2',
                        type: 'post',
                        data: {id:favorite.join(",")},
                    }).done(function(data) {
                       location.reload();



                    });
        });
    });

    $(document).ready(function() {
        $("#active_all").click(function(){
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function(){            
                favorite.push($(this).val());
            });
            //alert("Selected Countries are: " + favorite.join(","));
             $.ajax({
                        url: '<?php echo base_url() ?>master/categories/active_all_checkbox2',
                        type: 'post',
                        data: {id:favorite.join(",")},
                    }).done(function(data) {
                       location.reload();



                    });
        });
    });

     $(document).ready(function() {
        $("#deactive_all").click(function(){
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function(){            
                favorite.push($(this).val());
            });
            //alert("Selected Countries are: " + favorite.join(","));
             $.ajax({
                        url: '<?php echo base_url() ?>master/categories/deactivate_all_checkbox2',
                        type: 'post',
                        data: {id:favorite.join(",")},
                    }).done(function(data) {
                       location.reload();



                    });
        });
    });


$('.delbtn').prop('disabled', true);

$('.checkbox').change(function(){
    $('.delbtn').prop('disabled', $('.checkbox:checked').length == 0);
})


$('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;

            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
                
            });
        }
    });
$('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
             $('.region_input1').addClass('no-display');
             $('.region_input').removeClass('no-display');
        }else{
            $('#select_all').prop('checked',false);
             $('.region_input1').removeClass('no-display');
             $('.region_input').addClass('no-display');
        }
    });
$('.boxischecked').on('click',function(){

     if ($(this).prop('checked') == true) {
                $('.region_input1').addClass('no-display');
                $('.region_input').removeClass('no-display');
            } else {
                $('.region_input1').removeClass('no-display');
                $('.region_input').addClass('no-display');
            }

            
            checked_checkbox = Number($('input[type=checkbox].boxischecked:checked').length);
            // alert(checked_checkbox);
            if (checked_checkbox!=0) {
                $('.region_input1').addClass('no-display');
                $('.region_input').removeClass('no-display');
            } else {
                $('.region_input1').removeClass('no-display');
                $('.region_input').addClass('no-display');
            }


  });


$('.multi_export').click(function(){

             var favorite = [];
             $.each($("input[name='checkbox']:checked"), function(){            
                 favorite.push($(this).val());
             });

    window.location = "<?php echo base_url();?>export/multi_export_cat?url="+favorite;

});

$('.export_link').click(function(){
            // alert();
             window.location ="<?php echo base_url();?>export/export_cat";
});
</script>

