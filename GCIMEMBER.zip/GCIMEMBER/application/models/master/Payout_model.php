<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Payout_model extends CI_Model { 

    function getallpayout() {

        $this->db->select('table.*,table1.Week,table2.Level_type');
        $this->db->order_by("id", "DESC");
        $this->db->where('table.status!=',3);
        $this->db->join('gc_weeks as table1','table1.Id = table.Days','left');
        $this->db->join('gc_leveltype as table2','table2.ID = table.Level_type_id','left');
        $query = $this->db->get('gc_payout_type as table');
        if ($query->num_rows() > 0) {
            $country_base = $query->result_array(); 
            foreach ($country_base as $key => $value) {
                $delete_status = $this->check_delete_status_payout($value['id']);
                if(isset($delete_status)){ 
                    $country_base[$key]['delete_status'] = 1; 
                }
                else{ 
                    $country_base[$key]['delete_status'] = 0;
                }    
            }
            return $country_base;
        }
        return NULL;
    }

    public function check_delete_status_payout($id)
	{   
        $this->db->select('table.id');
        $this->db->from('gc_payout_type as table');        
        $this->db->join('gc_level as table1','table1.Payout_type = table.id','left');
        $this->db->join('gc_member_topup as table2','table2.Payout_type = table.id','left');
        $this->db->where('table1.Payout_type ='.$id.' or table2.Payout_type = '.$id.'');
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function Level_type_days($id) {
        $this->db->select('*');
        $this->db->from('gc_leveltype');
        $this->db->order_by("ID", "DESC");
        $this->db->where('ID',$id);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_weeks()
    {

        $this->db->select("*");
        $query = $this->db->get("gc_weeks");
        $this->db->order_by("Id", "DESC");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

}