<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

     public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
                $this->load->model('master/Users_model');
                $this->load->model('member/Membership_model');
        }


    public function index()
    {
        $template['country']=$this->Users_model->get_all_country();
        $template['bank'] =  $this->Membership_model->getall_bank();
        $template['payment_mode']=$this->Users_model->get_all_payment_mode();
        $template['bank_to'] =  $this->Membership_model->getall_bank_to();
        $template['page']='welcome/new_member';
        $template['load_page']='index';
        $this->load->view('templates',$template);
    }

    public function form_test()
    {
        $data = $this->input->post('user');
        print_r($data);
    }

    public function nmbmc()
    {
        $this->load->model('master/Users_model');
        $template['bank'] =  $this->Membership_model->getall_bank();
        $template['bank_to'] =  $this->Membership_model->getall_bank_to();
        $template['country']=$this->Users_model->get_all_country();
        $template['payment_mode']=$this->Users_model->get_all_payment_mode();
        $template['referral_code']= decrypt($_GET['rt']);
        $template['load_page']='';
        $template['page']='welcome/new_member';
        $this->load->view('templates',$template);
    }

    public function member_reg()
    {
        extract($_POST);

    $already_count = $this->db->where('Mobile',$member['Mobile'])->count_all_results('gc_membership');
    // $pmt=$this->input->post('payment_data_1');
            $pmt=$this->input->post('payment_data_1');

    if(!empty($pmt)){
    	    
    if ($already_count <=0 && $Total_amount > 0 && $pmt['Amount'] > 0) {

        $member['Company_id']   = 1;
        $member['Branch_id']    = 1;
        $member['Random_ID']="GC".rand(00000000,99999999);
        

        if(!empty($contract_data)){
            $member['Payout_ID']=$contract_data['Payout_ID'];
        }else{
            $member['Payout_ID']='';
        }

        $member['Membership_code']='GCI'.$this->generatePIN(8);

        $increment_code = $this->db->count_all_results('gc_membership')+1;
        $member['Member_no']="GRNC-MEM-0000".$increment_code;
        $member['Member_sequence']=$increment_code-1;
        $member['Status']=5;
        
        $member['Membership_type']=1;
        $member['Photo']='men.jpg';
        $member['Photo_path']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/users_image/';
        $member['Created_by']="";
        $member['Created_date']=date('Y-m-d H:i:s');
        $member['Reference_ID']=$ref_code;
        $member['Reference_code']=$ref_code_name;
        $member['Register_from']='member';
        $member['Payout_ID']=2;
        $member['Final_commission_per']=10;

        $this->db->insert('gc_membership',$member);
        $Membership_ID=$this->db->insert_id();

        
        $document_data['Company_id']   = 1;
        $document_data['Branch_id']    = 1;
        $document_data['Status']    = 5;
        $document_data['Folder_name'] = $member['Membership_code'];
        $document_data['Membership_ID'] = $Membership_ID;
        $document_data['File_path'] = "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$member['Membership_code'].'/';


    if (!empty($_FILES['aadhar']['name'])) {
      $profile_name = 'aadhar';
      $names = 'aadhar';
      $document_data['Document_no'] = $document['Aadhar_no'];
      $document_data['Document_type'] = 'Aadhar';
      $document_data['Document_name'] = $this->Membership_model->member_profile_attachments($member['Membership_code'],$profile_name,$names);
    }else{
      $document_data['Document_no'] =  $document['Passport_no'];
      $document_data['Document_type'] =  'Passport';
      $profile_name = 'passport';
      $names = 'passport';
      $document_data['Document_name'] = $this->Membership_model->member_profile_attachments($member['Membership_code'],$profile_name,$names);
    }
    $this->db->insert('gc_member_documents',$document_data);


    if(isset($_POST['unique_id'])){
    	$sales_point['Topup_for']=1;
    	$sales_point['Membership_ID']=$Membership_ID;
    	$sales_point['Wallet_amount_from']=1;
    	$sales_point['Wallet_flag']=1;
			$sales_point['Date']=date('Y-m-d');
			$sales_point['Currency']=1;
			$sales_point['Amount']=$this->input->post('Total_amount');
			$sales_point['Multiples']=1;
			$sales_point['Total_amount']=$sales_point['Amount'];
			$sales_point['Company_id']=$this->session->userdata('CompanyId');
			$sales_point['Branch_id']=$this->session->userdata('CompanyId');

			if($this->db->insert('gc_wallet_topup',$sales_point)){
		 	$wallet_id=$this->db->insert_id();
			}else{
				$wallet_id='';
			}
		
        $unique_id = $this->input->post('unique_id');
        $unique=explode(',',$unique_id);
        foreach($unique as $val1){
             $payment_data['payment_data_'.$val1] = $this->input->post('payment_data_'.$val1);
             $payment_data['payment_data_'.$val1]['Date']   = date('Y-m-d',strtotime($payment_data['payment_data_'.$val1]['Date']));

             $statement_name='state_ment_'.$val1;

             $doc_name = $this->Membership_model->member_profile_attachments($member['Membership_code'],$statement_name,'statement');
             $payment_data['payment_data_'.$val1]['Statement']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$member['Membership_code'].'/'.$doc_name;

              $payment_data['payment_data_'.$val1]['Service_point_ID']   = $wallet_id;
             $payment_data['payment_data_'.$val1]['Topup_for']   = $sales_point['Topup_for'];

            if(isset($sales_point['Membership_ID'])){ $payment_data['payment_data_'.$val1]['Membership_ID']= $sales_point['Membership_ID'];}else{ $payment_data['payment_data_'.$val1]['Membership_ID']= '';}

              if(isset($sales_point['Service_point'])){ $payment_data['payment_data_'.$val1]['Service_point']   =$sales_point['Service_point'];}else{ $payment_data['payment_data_'.$val1]['Service_point']   ='';}

             $payment_data['payment_data_'.$val1]['Wallet_amount_from']   =$sales_point['Wallet_amount_from'];

             if(isset($sales_point['Wallet_service_point'])){ $payment_data['payment_data_'.$val1]['Wallet_service_point']   = $sales_point['Wallet_service_point'];}else{ $payment_data['payment_data_'.$val1]['Wallet_service_point']   = '';}

             $payment_data['payment_data_'.$val1]['Currency']   = $sales_point['Currency'];
             $payment_data['payment_data_'.$val1]['Company_id']   = $this->session->userdata('CompanyId');
             $payment_data['payment_data_'.$val1]['Branch_id']   = $this->session->userdata('CompanyId');
             $payment_data['payment_data_'.$val1]['Created_date']=date('Y-m-d');
             $payment_data['payment_data_'.$val1]['Created_by']=$Membership_ID;

             $this->db->insert('gc_wallet_payments',$payment_data['payment_data_'.$val1]);

            }

            }

        $this->db->select('Members_count');
        $this->db->where('Membership_ID',$ref_code);
        $member_count = $this->db->get('gc_membership');
        $mem_count=$member_count->result_array();
        $tot_mem_count=$mem_count[0]['Members_count']+1;
        $count_Data = array('Members_count' => $tot_mem_count);
        $this->db->where('Membership_ID',$ref_code);
        $this->db->update('gc_membership',$count_Data);

        $address_data['Membership_ID']   = $Membership_ID;
        $address_data['Company_id']   = 1;
        $address_data['Branch_id']    = 1;

        if ($address['Country']==101) {
        $address_data['Area']         = $address['Area'];
        $address_data['City']         = $address['City'];
        $address_data['State']        = $address['State'];
        $address_data['Country']      = $address['Country'];
        $address_data['Address_1']    = $address['Address_1'];
        $address_data['Pincode']      = $address['Pincode'];
        }else{
        $address_data['City']         = $address['outside_City'];
        $address_data['Country']      = $address['Country'];
        $address_data['Address_1']    = $address['outside_Address_1'];
        $address_data['Pincode']      = $address['outside_Pincode'];
        }
        $this->db->insert('gc_member_address', $address_data);

// Start User Insert
       $user_data['user_id']         = $Membership_ID;
       $user_data['company_id']      = 1;
       $user_data['branch_id']       = 1;
       $user_data['firstname']       = $member['First_name'];
       $user_data['username']        = $member['Membership_code'];
       $user_data['password']        = md5($member['Membership_code']);
       $user_data['og_password']     = $member['Mobile'];
       $user_data['email_address']   = $member['Email'];
       $user_data['mobile_number']   = $member['Mobile'];
       $user_data['address_line_1']  = $address['Address_1'];
       $user_data['zipcode']         = $address['Pincode'];
       $user_data['country_id']      = $address['Country'];
       $user_data['state_id']        = $address['State'];
       $user_data['city_id']         = $address['City'];
       $user_data['user_type_id']    = 3;
       $user_data['status']          = 1;
       $user_data['mail_status']     = 1;
       $this->db->insert('gc_users', $user_data);
       $user_insert_id=$this->db->insert_id();
// End User Insert  

// Start User Insert
       $membership_upload_data['Created_by']   = $user_insert_id;
       $this->db->where('Membership_ID', $Membership_ID);
       $this->db->update('gc_membership', $membership_upload_data);
// End User Insert 

// Start User Insert
       $doc_profile_name = 'passbook_upload';
       $doc_names = 'passbook';
       $doc_name_up = $this->Membership_model->member_profile_attachments($member['Membership_code'],$doc_profile_name,$doc_names);
       $banks_data['Document_name'] = "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$member['Membership_code'].'/'.$doc_name_up;

       $banks_data['Membership_ID']   = $Membership_ID;
       $banks_data['Company_id']      = 1;
       $banks_data['Branch_id']       = 1;
       $banks_data['Status']          = 5;
       $banks_data['Created_date']    = date('Y-m-d H:i:s');
       $this->db->insert('gc_member_banks', $banks_data);
// End User Insert  
// 
//start Member Franchisee Member Relationship Insert
        $franchisee_relation['Child_ID']        = $Membership_ID;
        $franchisee_relation['Level_type_ID']   = 1;
        $franchisee_relation['Parent_id']   = $member['Reference_ID'];
        // $franchisee_relation['Position']   = 1;
        $this->db->where('Parent_ID',$member['Reference_ID']);  
        $member_seq=$this->db->count_all_results('gc_franchisee_member_relation')+1;

        $franchisee_relation['Position']   = $member_seq;
        if($franchisee_relation['Position'] % 2 == 0){ 
            $determin = "2";  
        }else{ 
            $determin = "1"; 
        }
        $franchisee_relation['Determination']   = $determin;
        $franchisee_relation['Company_id']   = 1;
        $franchisee_relation['Branch_id']   = 1;
        $franchisee_relation['Date']   = date('Y-m-d');
        $this->db->insert('gc_franchisee_member_relation', $franchisee_relation);
//end Member Franchisee Member Relationship Insert


$member_update['Members_count']   = $member_seq;
$this->db->where('Membership_ID', $member['Reference_ID']);
$this->db->update('gc_membership', $member_update);

// Gold Offer Start
	
	if(date('Y-m-d') >= '2019-05-01' && date('Y-m-d') <= '2019-08-08'){
		if($Total_amount >= 10500 || $Total_amount >= 25500 || $Total_amount >= 50250 ){
			if($Total_amount >= 10500 && $Total_amount < 25500){
				$investor_part   =8;
				$sponsor_part    =4;
				$coordinator_part=2;
				$manager_part    =1;
				$head_part       =1;
			}

			if($Total_amount >= 25500 && $Total_amount < 50250){
				$investor_part   =20;
				$sponsor_part    =10;
				$coordinator_part=5;
				$manager_part    =2;
				$head_part       =2;
			}


			if($Total_amount >= 50250){
				$investor_part   =45;
				$sponsor_part    =22;
				$coordinator_part=11;
				$manager_part    =5;
				$head_part       =5;
			}

				$gold=array(
							'Membership_ID'	    => $Membership_ID,
							'Child_ID'	        => $Membership_ID,
							'Level_ID'	        => 0,
							'Child_investment'	=> $Total_amount,
							'Offer_value'	      => $investor_part,
							'Created_date'	    => date('Y-m-d'));

				$gl=$this->db->insert('gc_gold_offer',$gold);
			}


		}

// Gold Offer End

//start Member binary Member Levels Insert
$ref_ID="";$level_insert_id="";
        for($i=1;$i<=9;$i++){ 
            if($i==1){
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$member['Reference_ID']);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            //var_dump($binary);
            $crnt_lvl=$binary[0]['Current_level'];
             $level['Level_ID']=$i;
            if($crnt_lvl<=$i){
            $member_level=$i;
            }
            else{
                $member_level=$crnt_lvl;
            }
            $ref_ID=$binary[0]['Reference_ID'];
 // Member Level Master Insert start
            $levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
            $levels_master['Company_id']       =  1;
            $levels_master['Branch_id']        =  1;
            $levels_master['Level_ID']         =  1;
            $levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
            $levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
            $levels_master['Payout_status']    =  $binary[0]['Payout_status'];
            $levels_master['Date']   = date('Y-m-d');
            $this->db->insert('gc_member_levels', $levels_master);
            $level_insert_id=$this->db->insert_id();

// Member Level Master Insert end         
// Member Level Details Insert start 
            $levels_data['Member_level_ID']  =  $level_insert_id;
            $levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
            $levels_data['Child_ID']         =  $Membership_ID;
            $levels_data['Company_id']       =  1;
            $levels_data['Branch_id']        =  1;
            $levels_data['Level_ID']         =  $level['Level_ID'];
            $levels_data['Position']         =  "";
            $levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
            $levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
            $levels_data['Payout_status']    =  $binary[0]['Payout_status'];
            $levels_data['Level_date']       = date('Y-m-d');
            $this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start
// Membership Current Level Insert start
      $mem_lvl['Member_grade']=NULL;
      $grade_count1=$this->db->where(array('Membership_ID'=>$binary[0]['Membership_ID'],'Level_ID'=>1))->count_all_results('gc_member_level_details');
			if($grade_count1>=6){
			$mem_lvl['Member_grade']=3;
			}
			$grade_count2=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count2>=6){
			$mem_lvl['Member_grade']=2;
			}
			$grade_count3=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count3>=6){
			$mem_lvl['Member_grade']=1;
			}
            $mem_lvl['Current_level']=$member_level;
            
            $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
            $this->db->update('gc_membership', $mem_lvl);

            if(date('Y-m-d') >= '2019-05-01' && date('Y-m-d') <= '2019-08-08'){
				
							if($Total_amount >= 10500 || $Total_amount >= 25500 || $Total_amount >= 50250 ){

									$gold_1=array(
												'Membership_ID'	    => $binary[0]['Membership_ID'],
												'Child_ID'	        => $Membership_ID,
												'Level_ID'	        => $level['Level_ID'],
												'Child_investment'	=> $Total_amount,
												'Offer_value'	      => $sponsor_part,
												'Created_date'	    => date('Y-m-d'));
					
									$gl_1=$this->db->insert('gc_gold_offer',$gold_1);


            	}

          	}

            $star=$this->set_green_star($binary[0]['Membership_ID']);
// Membership Current Level Insert end

        }
    }
    else{
            $this->db->select('*');
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$ref_ID);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            $crnt_lvl=$binary[0]['Current_level'];
            $level['Level_ID']=$i;
            if($crnt_lvl<=$i){
            $member_level=$i;
            }
            else{
                $member_level=$crnt_lvl;
            }
            $ref_ID=$binary[0]['Reference_ID'];

 // Member Level Master Insert start
            $levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
            $levels_master['Company_id']       =  1;
            $levels_master['Branch_id']        =  1;
            $levels_master['Level_ID']         =  $level['Level_ID'];
            $levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
            $levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
            $levels_master['Payout_status']    =  $binary[0]['Payout_status'];
            $this->db->insert('gc_member_levels', $levels_master);
            $levels_master['Date']             = date('Y-m-d');
            $level_insert_id=$this->db->insert_id();
// Member Level Master Insert end         
// Member Level Details Insert start 
            $levels_data['Member_level_ID']  =  $level_insert_id;
            $levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
            $levels_data['Child_ID']         =  $Membership_ID;
            $levels_data['Company_id']       =  1;
            $levels_data['Branch_id']        =  1;
            $levels_data['Level_ID']         =  $level['Level_ID'];
            $levels_data['Position']         =  "";
            $levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
            $levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
            $levels_data['Payout_status']    =  $binary[0]['Payout_status'];
            $levels_data['Level_date']       =  date('Y-m-d');
            $this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start

// Membership Current Level Insert start
            $mem_lvl['Member_grade']=NULL;
            $grade_count1=$this->db->where(array('Membership_ID'=>$binary[0]['Membership_ID'],'Level_ID'=>1))->count_all_results('gc_member_level_details');
			if($grade_count1>=6){
			$mem_lvl['Member_grade']=3;
			}
			$grade_count2=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count2>=6){
			$mem_lvl['Member_grade']=2;
			}
			$grade_count3=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count3>=6){
			$mem_lvl['Member_grade']=1;
			}
      $mem_lvl['Current_level']=$member_level;
      $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
      $this->db->update('gc_membership', $mem_lvl);


      if(date('Y-m-d') >= '2019-05-01' && date('Y-m-d') <= '2019-08-08'){
				 
				 if($Total_amount >= 10500 || $Total_amount >= 25500 || $Total_amount >= 50250 ){

					if($mem_lvl['Member_grade']==3 || $mem_lvl['Member_grade']==2 || $mem_lvl['Member_grade']==1 ){
						if($mem_lvl['Member_grade']==3){
							$offer=$coordinator_part;
						}elseif($mem_lvl['Member_grade']==2){
							$offer=$manager_part;
						}elseif($mem_lvl['Member_grade']==1){
							$offer=$head_part;						
						}

						$gold_2=array(
							'Membership_ID'	    => $binary[0]['Membership_ID'],
							'Child_ID'	        => $Membership_ID,
							'Level_ID'	        => $level['Level_ID'],
							'Child_investment'	=> $Total_amount,
							'Offer_value'	      => $offer,
							'Created_date'	    => date('Y-m-d'));

						$gl_2=$this->db->insert('gc_gold_offer',$gold_2);
					}	

				


            }

          }


      $star=$this->set_green_star($binary[0]['Membership_ID']);
// Membership Current Level Insert end            
            

                }

            }
        }
        redirect('Welcome/mail_verify/'.$Membership_ID);
      }else{
        redirect('Welcome');
      }
    }else{
        redirect('Welcome');
      }


       
       // redirect('Login');
       // redirect('Welcome/complete/'.$Membership_ID);
    }


 	public function set_green_star($Membership_ID){

	// $members=$this->db->select('Membership_ID,Created_date,Membership_mode')->get('gc_membership')->result_array();

// $Membership_ID=2727;
$members=$this->db->select('Membership_ID,Created_date,Membership_mode')->where('Membership_ID',$Membership_ID)->get('gc_membership')->result_array();
if(!empty($members)){
	$start_date=date('Y-m-d',strtotime($members[0]['Created_date']));

$cur_pyt=date('Y-m-d',strtotime($this->db->get_where('gc_member_franchisee_contract',array('Invest_type'=>1,'Membership_ID'=>$Membership_ID))->row('Payout_date')));

$py_days=15-1;
$cur_payout=date('Y-m-d', strtotime($cur_pyt. ' + '.$py_days.' days'));
$payout_date=$this->Membership_model->get_excat_next_payout($cur_payout);

	// foreach ($members as $key => $value) {
		

	// }

// find Star 1 start
$days1=30;
$level_ID1=1;
$end_sate1=date('Y-m-d', strtotime($start_date. ' + '.$days1.' days'));
$b_status1=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID1))->count_all_results('gc_green_star');
if($b_status1<=0){
	$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID1,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate1))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
	if($start_date < '2019-05-01'){
		$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
		$this->db->where('contract.Invest_type',2);
	}
		$green_count1=$this->db->count_all_results('gc_member_level_details as level');
	if($green_count1>=10){
		                    $str_update['Status']=6;
		                    $this->db->where('Membership_ID',$Membership_ID);     
												$this->db->update('gc_green_star',$str_update);
		$green1=array(
					'Membership_ID'=>$Membership_ID,
					'Star'         =>1,
					'Level'		   =>$level_ID1,
					'Members_count'=>$green_count1,
					'Created_date' =>date('Y-m-d'),
					'Payout_date'  =>$payout_date,
					'Status'       =>1,
					'Benefit'      =>140
					);
		
		$this->db->insert('gc_green_star',$green1);
	}
}


// find Star 1 end


// find Star 2 start
$days2=60;
$level_ID2=2;
$end_sate2=date('Y-m-d', strtotime($start_date. ' + '.$days2.' days'));
$b_status2=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID2))->count_all_results('gc_green_star');
if($b_status2<=0){
	$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID2,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
	if($start_date < '2019-05-01'){
		$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
		$this->db->where('contract.Invest_type',2);
	}
		$green_count2=$this->db->count_all_results('gc_member_level_details as level');
	if($green_count2>=50){
		          $str_update['Status']=6;
		                    $this->db->where('Membership_ID',$Membership_ID);     
												$this->db->update('gc_green_star',$str_update);
		$green2=array(
					'Membership_ID'=>$Membership_ID,
					'Star'         =>2,
					'Level'		   =>$level_ID2,
					'Members_count'=>$green_count2,
					'Created_date' =>date('Y-m-d'),
					'Payout_date'  =>$payout_date,
					'Status'       =>1,
					'Benefit'      =>700
					);
		
		$this->db->insert('gc_green_star',$green2);
	}
}


// find Star 2 end


// find Star 3 start
$days3=100;
$level_ID3=3;
$end_sate3=date('Y-m-d', strtotime($start_date. ' + '.$days3.' days'));
$b_status3=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID3))->count_all_results('gc_green_star');
if($b_status3<=0){
	$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID3,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
	if($start_date < '2019-05-01'){
		$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
		$this->db->where('contract.Invest_type',2);
	}
		$green_count3=$this->db->count_all_results('gc_member_level_details as level');
	if($green_count3>=250){
		                    $str_update['Status']=6;
		                    $this->db->where('Membership_ID',$Membership_ID);     
												$this->db->update('gc_green_star',$str_update);
		$green3=array(
					'Membership_ID'=>$Membership_ID,
					'Star'         =>3,
					'Level'		   =>$level_ID3,
					'Members_count'=>$green_count3,
					'Created_date' =>date('Y-m-d'),
					'Payout_date'  =>$payout_date,
					'Status'       =>1,
					'Benefit'      =>2150
					);
		
		$this->db->insert('gc_green_star',$green3);
	}
}


// find Star 3 end


// find Star 4 start
$days4=120;
$level_ID4=4;
$end_sate4=date('Y-m-d', strtotime($start_date. ' + '.$days4.' days'));
$b_status4=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID4))->count_all_results('gc_green_star');
if($b_status4<=0){
	$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID4,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate4))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
	if($start_date < '2019-05-01'){
		$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
		$this->db->where('contract.Invest_type',2);
	}
		$green_count4=$this->db->count_all_results('gc_member_level_details as level');
	if($green_count4>=550){
		                    $str_update['Status']=6;
		                    $this->db->where('Membership_ID',$Membership_ID);     
												$this->db->update('gc_green_star',$str_update);
		$green=array(
					'Membership_ID'=>$Membership_ID,
					'Star'         =>4,
					'Level'		   =>$level_ID4,
					'Members_count'=>$green_count4,
					'Created_date' =>date('Y-m-d'),
					'Payout_date'  =>$payout_date,
					'Status'       =>1,
					'Benefit'      =>4250
					);
		
		$this->db->insert('gc_green_star',$green4);
	}
}


// find Star 4 end

// find Star 5 start
$days5=150;
$level_ID5=5;
$end_sate5=date('Y-m-d', strtotime($start_date. ' + '.$days5.' days'));
$b_status5=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID5))->count_all_results('gc_green_star');
if($b_status5<=0){
	$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID5,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate5))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
	if($start_date < '2019-05-01'){
		$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
		$this->db->where('contract.Invest_type',2);
	}
		$green_count5=$this->db->count_all_results('gc_member_level_details as level');
	if($green_count5>=1200){
		                    $str_update['Status']=6;
		                    $this->db->where('Membership_ID',$Membership_ID);     
												$this->db->update('gc_green_star',$str_update);
		$green5=array(
					'Membership_ID'=>$Membership_ID,
					'Star'         =>5,
					'Level'		   =>$level_ID5,
					'Members_count'=>$green_count5,
					'Created_date' =>date('Y-m-d'),
					'Payout_date'  =>$payout_date,
					'Status'       =>1,
					'Benefit'      =>7000
					);
		
		$this->db->insert('gc_green_star',$green5);
	}
}


// find Star 5 end
}



	}   

public function mail_verify($id)
{

	$permitted_chars = 'rhp85423rt542r1h398pw9qyr1253r4tg2';
     
    function generate_string($input, $strength = 16) {
        $input_length = strlen($input);
        $random_string = '';
        for($i = 0; $i < $strength; $i++) {
            $random_character = $input[mt_rand(0, $input_length - 1)];
            $random_string .= $random_character;
        }
     
        return $random_string;
    }

     $pwd = generate_string($permitted_chars, 9);

        $user_data = array('password' => md5($pwd),'og_password' => $pwd);
        $this->db->where('user_id',$id);
        $this->db->update('gc_users',$user_data);

    $Userdetails  =  $this->Users_model->get_user_details($id);
    
$message="<!doctype html>
<html>
  <head>
    <meta name='viewport' content='width=device-width'>
    <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    <title>Simple Transactional Email</title>
    <style>
    /* -------------------------------------
        INLINED WITH htmlemail.io/inline
    ------------------------------------- */
    /* -------------------------------------
        RESPONSIVE AND MOBILE FRIENDLY STYLES
    ------------------------------------- */
    @media only screen and (max-width: 620px) {
      table[class=body] h1 {
        font-size: 28px !important;
        margin-bottom: 10px !important;
      }
      table[class=body] p,
            table[class=body] ul,
            table[class=body] ol,
            table[class=body] td,
            table[class=body] span,
            table[class=body] a {
        font-size: 16px !important;
      }
      table[class=body] .wrapper,
            table[class=body] .article {
        padding: 10px !important;
      }
      table[class=body] .content {
        padding: 0 !important;
      }
      table[class=body] .container {
        padding: 0 !important;
        width: 100% !important;
      }
      table[class=body] .main {
        border-left-width: 0 !important;
        border-radius: 0 !important;
        border-right-width: 0 !important;
      }
      table[class=body] .btn table {
        width: 100% !important;
      }
      table[class=body] .btn a {
        width: 100% !important;
      }
      table[class=body] .img-responsive {
        height: auto !important;
        max-width: 100% !important;
        width: auto !important;
      }
    }

    /* -------------------------------------
        PRESERVE THESE STYLES IN THE HEAD
    ------------------------------------- */
    @media all {
      .ExternalClass {
        width: 100%;
      }
      .ExternalClass,
            .ExternalClass p,
            .ExternalClass span,
            .ExternalClass font,
            .ExternalClass td,
            .ExternalClass div {
        line-height: 100%;
      }
      .apple-link a {
        color: inherit !important;
        font-family: inherit !important;
        font-size: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
        text-decoration: none !important;
      }
      .btn-primary table td:hover {
        background-color: #34495e !important;
      }
      .btn-primary a:hover {
        background-color: #34495e !important;
        border-color: #34495e !important;
      }
    }
    </style>
  </head>
  <body style='background-color: #f6f6f6; font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; line-height: 1.4; margin: 0; padding: 0; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;'>
    <table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background-color: #f6f6f6;'>
      <tr>
        <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;'>&nbsp;</td>
        <td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; Margin: 0 auto; max-width: 580px; padding: 10px; width: 580px;'>
          <div class='content' style='box-sizing: border-box; display: block; Margin: 0 auto; max-width: 580px; padding: 10px;'>

            <!-- START CENTERED WHITE CONTAINER -->
            <span class='preheader' style='color: transparent; display: none; height: 0; max-height: 0; max-width: 0; opacity: 0; overflow: hidden; mso-hide: all; visibility: hidden; width: 0;'></span>
            <table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #ffffff; border-radius: 3px;'>

              <!-- START MAIN CONTENT AREA -->
              <tr>
                <td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 20px;'>
                  <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
                    <tr>
                      <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;'>
                        <p style='font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;'>Hi " .$Userdetails[0]['First_name'].",</p>
                        <p style='font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;'></p>
                        <table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
                          <tbody>
                            <tr>
                              <td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;'>
                                <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
                                  <tbody>
                                    <tr>
                                      <td style='font-family: sans-serif; width:516px; font-size: 14px; vertical-align: top; background-color: #3498db; border-radius: 5px; text-align: center;'> <label style='display: inline-block; color: #ffffff; background-color: #3498db; border: solid 1px #3498db; border-radius: 5px; box-sizing: border-box; cursor: pointer; text-decoration: none; font-size: 14px; font-weight: bold; margin: 0; padding: 12px 25px; border-color: #3498db;'>UserName : ".$Userdetails[0]['username']." &nbsp;&nbsp; | &nbsp;&nbsp; Password : ".$Userdetails[0]['og_password']."</label> </td>
                                    </tr>
                                  </tbody>
                                </table>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                        <p style='font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;'>Good luck! Hope it works.</p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>

            <!-- END MAIN CONTENT AREA -->
            </table>

            <!-- START FOOTER -->
            <div class='footer' style='clear: both; Margin-top: 10px; text-align: center; width: 100%;'>
              <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
              </table>
            </div>
            <!-- END FOOTER -->

          <!-- END CENTERED WHITE CONTAINER -->
          </div>
        </td>
        <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;'>&nbsp;</td>
      </tr>
    </table>
  </body>
</html>
";


$config = Array(
  'protocol' => 'smtp',
  'smtp_host' => 'mail.gceco.in',
  'smtp_port' => 587,
  'smtp_user' => 'noreply@gceco.in', 
  'smtp_pass' => '7(-j_];S~B3@',
  'mailtype' => 'html',
  'charset' => 'iso-8859-1',
  'wordwrap' => TRUE
);

  $this->load->library('email', $config);
  $this->email->set_newline("\r\n");
  $this->email->from('noreply@gceco.in');
  $this->email->to($Userdetails[0]['Email']);
  $this->email->subject('User :: CREDENTIALS');
  $this->email->message($message);
  if($this->email->send())
    {
	redirect('Welcome/complete/'.$Userdetails[0]['Membership_ID']);
    }
    else
    {
     show_error($this->email->print_debugger());
    }
}

public function verify($id)
{
    // $code = rawurldecode($this->encrypt->decode($_GET['rt']));
    $data = array('Status' => 1 );
    $this->db->where('user_id',$_GET['rt']);
    $this->db->update('gc_users',$data);
    redirect('Login');
    
}
 public function do_upload()
    {
            $config['upload_path']          = './attachments/';
            $config['allowed_types']        = 'gif|jpg|png|pdf';
            // $config['max_size']             = 100;
            // $config['max_width']            = 1024;
            // $config['max_height']           = 768;

            $this->load->library('upload', $config);

            if ( ! $this->upload->do_upload('userfile'))
            {
                    $error = array('error' => $this->upload->display_errors());
                    print_r($error);
                    $this->load->view('upload_form', $error);
            }
            else
            {
                    $data = array('upload_data' => $this->upload->data());
                    $this->load->view('upload_success', $data);
            }
    }

    public function duplicate_check(){

        $this->load->model('master/Users_model');
        $data       = $this->input->post('data');
        $table_name = $this->input->post('table_name');
        $colum      = $this->input->post('colum');

        $data       = $this->Users_model->duplicate_check($data,$table_name,$colum);
         print_r($data);
    }

    public function duplicate_check_return_id(){

        $this->load->model('master/Users_model');
        extract($_POST);
        $data = $this->Users_model->duplicate_check_return_id($country,$city,$table_name,$colum);

        if ($data == 0) {
          echo '0';
        }else{
        echo $data;
    }
  }

    public function insert_city(){

        extract($_POST);

        $data = array('country_id' => $country,
                      'status' => 1,
                      'city_name' =>$city );

        $this->db->insert('gc_cities',$data);
        echo $this->db->insert_id();
    }


public function get_pincode_details()
        {
            $pincode         = $this->input->post("pincode");

        $this->db->select('area.id as taluk_id,area.area_name as taluk_name,city.id as City_id,city.city_name as City_name,state.id as State_id,state.state_name as State_name,country.id as Country_id,country.country_name as Country_name');

        $this->db->from('gc_areas as area');
        $this->db->join('gc_cities as city', 'city.id = area.city_id', 'left');
        $this->db->join('gc_states as state', 'state.id = area.state_id', 'left');
        $this->db->join('gc_countries as country', 'country.id = area.country_id', 'left');
        $this->db->where("area.Pincode",$pincode);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $temp['pincode'] = $query->result_array();
            $temp['value']= "Success";
        }else{
        $temp['pincode']= "";
        $temp['value']= "Failure";

    }
    $data['data'] = ['pincode'      => $temp['pincode'],
                     'value'        => $temp['value']];
        header('Content-Type: application/json');
        echo json_encode($data);
}


public function get_referer_by_code()
  {
  $referer = $this->input->post("referer");
  
  $data['referer'] =  $this->Membership_model->get_referer_by_code($referer);
  if($data['referer']!=0){

        $temp['data'] = ['value'  => 'Success', 'referer' => $data['referer']];
   }else{
        $temp['data'] = ['value'  => 'Failure', 'referer' => $data['referer']];
   }
  header('Content-Type: application/json');
  echo json_encode($temp);
}

public function generatePIN($digits){
    $i = 0; //counter
    $pin = ""; //our default pin is blank.
    while($i < $digits){
        //generate a random number between 0 and 9.
        $pin.= mt_rand(0, 9);
        $i++;
    }
    return $pin;
}


   public function get_mobile_id() {

    $id = $this->input->post('name');
    $data = $this->Users_model->get_country_code($id);
    echo $data;
    }

public function complete($id)
{
    $template['user']=$this->Users_model->get_user_member_by_id($id);
    $template['page']='welcome/reg_complete';
    $template['load_page']='index';
    $this->load->view('templates',$template);
}


public function reset_password()
{
    $id = $this->security->xss_clean($this->input->post('member_code'));

    $reset_details  =  $this->Users_model->reset_passcode($id);

    if (!empty($reset_details)) {  if (!empty($reset_details[0]['Email'])) { 

    $permitted_chars = 'rhp85423rt542r1h398pw9qyr1253r4tg2';
     
    function generate_string($input, $strength = 16) 
    {
        $input_length = strlen($input);
        $random_string = '';
        for($i = 0; $i < $strength; $i++) {
            $random_character = $input[mt_rand(0, $input_length - 1)];
            $random_string .= $random_character;
        }
     
        return $random_string;
    }

     $pwd = generate_string($permitted_chars, 9);

        $user_data = array('password' => md5($pwd),'og_password' => $pwd);
        $this->db->where('user_id',$reset_details[0]['Membership_ID']);
        $this->db->where('user_type_id',3);
        $this->db->update('gc_users',$user_data);

$Userdetails  =  $this->Users_model->get_user_details($reset_details[0]['Membership_ID']);

$message="<!doctype html>
<html>
  <head>
    <meta name='viewport' content='width=device-width'>
    <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    <title>GreenCrest International</title>
    <style>
    @media only screen and (max-width: 620px) {
      table[class=body] h1 {
        font-size: 28px !important;
        margin-bottom: 10px !important;
      }
      table[class=body] p,
            table[class=body] ul,
            table[class=body] ol,
            table[class=body] td,
            table[class=body] span,
            table[class=body] a {
        font-size: 16px !important;
      }
      table[class=body] .wrapper,
            table[class=body] .article {
        padding: 10px !important;
      }
      table[class=body] .content {
        padding: 0 !important;
      }
      table[class=body] .container {
        padding: 0 !important;
        width: 100% !important;
      }
      table[class=body] .main {
        border-left-width: 0 !important;
        border-radius: 0 !important;
        border-right-width: 0 !important;
      }
      table[class=body] .btn table {
        width: 100% !important;
      }
      table[class=body] .btn a {
        width: 100% !important;
      }
      table[class=body] .img-responsive {
        height: auto !important;
        max-width: 100% !important;
        width: auto !important;
      }
    }

    /* -------------------------------------
        PRESERVE THESE STYLES IN THE HEAD
    ------------------------------------- */
    @media all {
      .ExternalClass {
        width: 100%;
      }
      .ExternalClass,
            .ExternalClass p,
            .ExternalClass span,
            .ExternalClass font,
            .ExternalClass td,
            .ExternalClass div {
        line-height: 100%;
      }
      .apple-link a {
        color: inherit !important;
        font-family: inherit !important;
        font-size: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
        text-decoration: none !important;
      }
      .btn-primary table td:hover {
        background-color: #34495e !important;
      }
      .btn-primary a:hover {
        background-color: #34495e !important;
        border-color: #34495e !important;
      }
    }
    </style>
  </head>
  <body style='background-color: #f6f6f6; font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; line-height: 1.4; margin: 0; padding: 0; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;'>
    <table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background-color: #f6f6f6;'>
      <tr>
        <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;'>&nbsp;</td>
        <td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; Margin: 0 auto; max-width: 580px; padding: 10px; width: 580px;'>
          <div class='content' style='box-sizing: border-box; display: block; Margin: 0 auto; max-width: 580px; padding: 10px;'>

            <!-- START CENTERED WHITE CONTAINER -->
            <span class='preheader' style='color: transparent; display: none; height: 0; max-height: 0; max-width: 0; opacity: 0; overflow: hidden; mso-hide: all; visibility: hidden; width: 0;'></span>
            <table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #ffffff; border-radius: 3px;'>

              <!-- START MAIN CONTENT AREA -->
              <tr>
                <td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 20px;'>
                  <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
                    <tr>
                      <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;'>
                        <p style='font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;'>Hi " .$Userdetails[0]['First_name'].",</p>
                        <p style='font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;'></p>
                        <table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
                          <tbody>
                            <tr>
                              <td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;'>
                                <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
                                  <tbody>
                                    <tr>
                                      <td style='font-family: sans-serif; width:516px; font-size: 14px; vertical-align: top; background-color: #3498db; border-radius: 5px; text-align: center;'> <a style='display: inline-block; color: #ffffff; background-color: #3498db; border: solid 1px #3498db; border-radius: 5px; box-sizing: border-box; cursor: pointer; text-decoration: none; font-size: 14px; font-weight: bold; margin: 0; padding: 12px 25px; border-color: #3498db;'>UserName : ".$Userdetails[0]['username']." &nbsp;&nbsp; | &nbsp;&nbsp; Password : ".$Userdetails[0]['og_password']."</a> </td>
                                    </tr>
                                  </tbody>
                                </table>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                        <p style='font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;'>Good luck! Hope it works.</p>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>

            <!-- END MAIN CONTENT AREA -->
            </table>

            <!-- START FOOTER -->
            <div class='footer' style='clear: both; Margin-top: 10px; text-align: center; width: 100%;'>
              <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
              </table>
            </div>
            <!-- END FOOTER -->

          <!-- END CENTERED WHITE CONTAINER -->
          </div>
        </td>
        <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;'>&nbsp;</td>
      </tr>
    </table>
  </body>
</html>
";
$config = Array(
  'protocol' => 'smtp',
  'smtp_host' => 'mail.gceco.in',
  'smtp_port' => 587,
  'smtp_user' => 'noreply@gceco.in', 
  'smtp_pass' => '7(-j_];S~B3@',
  'mailtype' => 'html',
  'charset' => 'iso-8859-1',
  'wordwrap' => TRUE
);

  $this->load->library('email', $config);
  $this->email->set_newline("\r\n");
  $this->email->from('noreply@gceco.in');
  $this->email->to($Userdetails[0]['Email']);
  $this->email->subject('User :: CREDENTIALS');
  $this->email->message($message);
  if($this->email->send())
    {
    $data['value']=3;
    echo json_encode($data);
    }
    else
    {
     show_error($this->email->print_debugger());
    }

  }else if(empty($reset_details[0]['Email'])){

    $data['value']=4;
    echo json_encode($data);

  }}else{

    $data['value']=2;
    echo json_encode($data);
  }
}

}

