<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Tenant_model extends CI_Model {

    private $prop_tenant = 'prop_tenant_table';   

    public function get_all_tenant() {
        $this->db->select('tenant.*,country.country_name,state.state_name,city.city_name');
        $this->db->from('prop_tenant_table as tenant');
        $this->db->join('prop_cities as city', 'city.id = tenant.city_id', 'left');
        $this->db->join('prop_states as state', 'state.id = tenant.state_id', 'left');
        $this->db->join('prop_countries as country', 'country.id = tenant.country', 'left');
        $this->db->where('tenant.status!=',3);
        //$this->db->where('tenant.tenant_id', $this->session->userdata('tenant_id'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
                $tenant_base = $query->result_array(); 
                foreach ($tenant_base as $key => $value) {
                    // $delete_status = $this->check_delete_status($value['tenant_id']);
                    // $delete_status = 0;
                    if(isset($delete_status)){ 
                        $tenant_base[$key]['delete_status'] = 1; 
                    }
                    else{ 
                        $tenant_base[$key]['delete_status'] = 0;
                    }    
                }
            return $tenant_base;
        }
        return NULL;
    }

    // public function check_delete_status($tenant_id){
    //     $this->db->select('tenant.tenant_id');
    //     $this->db->from('prop_tenant_table as tenant');        
    //     $this->db->join('prop_hub_branch as region','region.tenant_id = tenant.tenant_id','left');
    //     $this->db->where('region.tenant_id',$tenant_id);  
    //     $this->db->where('tenant.tenant_id', $this->session->userdata('tenant_id'));
    //     $query = $this->db->get();        
    //     if ($query->num_rows() > 0) {
    //         return $query->result_array();
    //     }
    //     return NULL;
    // }

   public function get_all_tenant_group() {
        $this->db->select('*');
        $this->db->where('status!=',3);
        $this->db->where('company_id', $this->session->userdata('company_id'));
        $query = $this->db->get('prop_tenant_group');
        if ($query->num_rows() > 0) {
          return $query->result_array();
          $customer_base = $query->result_array(); 
          // var_dump($customer_base);
          die();
            foreach ($customer_base as $key => $value) {
                // $delete_status = $this->check_delete_status($value['Customer_id']);
                if(isset($delete_status)){ 
                    $customer_base[$key]['delete_status'] = 1; 
                }
                else{ 
                    $customer_base[$key]['delete_status'] = 0;
                }    
            }
            // var_dump($customer_base); die();
            return $customer_base;
        }   
        return NULL;
    }


    public function adding_tenant_group($adding_tenant_group_data)
    {
        $modify['module_name']="Tenant Group";
                $modify['data']=$adding_tenant_group_data['tenant_group_name'];
                $modify['action']="1";
                $modify['created_by']=$this->session->userdata('id');
                
                $this->db->insert('prop_modification_history', $modify);
                $adding_tenant_group_data['created_by']=$this->session->userdata('id');
                // $adding_tenant_group_data['company_id']=$this->session->userdata('company_id');
                // $adding_tenant_group_data['financial_yr_id']=$this->session->userdata('Financial_yr_id');
        if ($this->db->insert('prop_tenant_group', $adding_tenant_group_data)) {
            $this->session->set_flashdata('tenant_success', 'Added');
            return TRUE;
        }
        return FALSE;       
    }     

    public function editing_tenant_group($adding_tenant_group_data_edit,$id)
    {
        $modify['module_name']="Tenant Group";
                $modify['data']=$adding_tenant_group_data_edit['tenant_group_name'];
                $modify['action']="2";
                $modify['created_by']=$this->session->userdata('id');
                $this->db->insert('prop_modification_history', $modify);
                $adding_tenant_group_data_edit['updated_by']=$this->session->userdata('id');
        $gst_data_edit['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', $id);
        if ($this->db->update('prop_tenant_group', $adding_tenant_group_data_edit)) {
            $this->session->set_flashdata('tenant_success', 'Added');
            return TRUE;
        }
        return FALSE;       
    }    

       public function get_all_tenant_group_active() {
        $this->db->select('*');
        $this->db->where('status',1);
        $this->db->where('company_id', $this->session->userdata('company_id'));
        $query = $this->db->get('prop_tenant_group');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }   
        return NULL;
    }    

    public function get_edit_tenant_data($id)
    {
        $this->db->select('*');     
        $this->db->from('prop_tenant_table');
        $this->db->where('tenant_id', $id);
        //$this->db->where('tenant_id', $this->session->userdata('tenant_id'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

        public function get_all_tenant_data()
    {
        $this->db->select('*');     
        $this->db->from('prop_tenant_table');
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

   /**
     * tenant Data Add 
     */
    public function insert_tenant($adding_tenant_data)
    {
        $modify['module_name']="Tenant";
                $modify['data']=$adding_tenant_data['tenant_name'];
                $modify['action']="1";
                $modify['created_by']=$this->session->userdata('id');
                $this->db->insert('prop_modification_history', $modify);

        $adding_tenant_data['created_by']=$this->session->userdata('id');
        // $adding_tenant_data['financial_yr_id']=$this->session->userdata('Financial_yr_id');
        if ($this->db->insert('prop_tenant_table', $adding_tenant_data)) {
            $this->session->set_flashdata('tenant_success', 'Added');
            return $this->db->insert_id();
        }
        return FALSE;       
    }


    public function edit_tenant($editing_tenant_data,$id)
    {
        $modify['module_name']="Tenant";
                $modify['data']=$editing_tenant_data['tenant_name'];
                $modify['action']="2";
                $modify['created_by']=$this->session->userdata('id');
                $this->db->insert('prop_modification_history', $modify);

            $editing_tenant_data['updated_by']=$this->session->userdata('id');
        $editing_tenant_data['updated_on'] = date('Y-m-d H:i:s');
        // $editing_tenant_data['tenant_logo'] = $image_data;
        $this->db->where('tenant_id', $id);
        if ($this->db->update('prop_tenant_table', $editing_tenant_data)) {
            return TRUE;
        }
        return FALSE;       
    }


    public function delete($table_name,$id)
    {
        // echo "id is ".$id;
            $this->db->where('tenant_id', $id);
            $query = $this->db->get('prop_tenant_table');
            $get['data']=$query->result_array();
                $modify['module_name']="Tenant";
                $modify['data']=$get['data'][0]['tenant_name'];
                $modify['action']="3";
                $modify['created_by']=$this->session->userdata('id');
                $this->db->insert('prop_modification_history', $modify);
                $data['deleted_by']=$this->session->userdata('id');
        $data['status'] ="3";
        $this->db->where('tenant_id', $id);
        if ($this->db->update($table_name, $data)) {
            return TRUE;
           
        }
        return FALSE;  
        
    }

    // Inserting

    public function check_duplicate_function_tenant($name)
    {
        $this->db->select('tenant.tenant_name');
        $this->db->from('prop_tenant_table as tenant');
        $this->db->where('tenant.tenant_name', $name);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
}