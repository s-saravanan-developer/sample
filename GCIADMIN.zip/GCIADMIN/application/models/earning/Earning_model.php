<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Earning_model extends CI_Model { 



    public function get_earning() {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level.Level,commission.Status as Commission_status');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Commision_date',date('Y-m-d'));
        //$this->db->where('commission.Status',1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    public function get_earning1($commission_type,$payment_status,$s_date,$e_date,$mobile,$contract,$level) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level.Level,commission.Status as Commission_status,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');

        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');

        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');

        $this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Commision_date',date('Y-m-d'));
        //$this->db->where('commission.Status',1);

     if(!empty($commission_type)){
        $this->db->where("commission.Commision_type",$commission_type);
     }
     if(!empty($level)){
        $this->db->where("level.ID",$level);
     }
     if(!empty($payment_status)){
        $payment_status=explode(',',$payment_status);
        $this->db->where_in("commission.Status",$payment_status);
     }
    
     if(!empty($s_date)){
        $this->db->where("commission.Commision_date >=",$s_date);
     }

     if(!empty($e_date)){
        $this->db->where("commission.Commision_date <=",$e_date);
     }

     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

     //    if(!empty($topup)){
     //    $this->db->where("topup.ID",$topup);
     // }
     if(!empty($contract)){
        $this->db->where("contract.Contract_ID",$contract);
     }

     
     $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
     }
        return NULL;

    }

    public function get_binary_earning($payment_status,$mobile) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Mobile,commission.Status as Commission_status');
        $this->db->from('gc_binary_commisions as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        // $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        // $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');

        // $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');

        // $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');

        // $this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Commision_date',date('Y-m-d'));
        //$this->db->where('commission.Status',1);


     if(!empty($payment_status)){
        $payment_status=explode(',',$payment_status);
        $this->db->where_in("commission.Status",$payment_status);
     }
    
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    

    
       public function get_earning_summary() {

        $this->db->select('commission.*, sum(commission.Amount) as tot_amount,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level.Level,commission.Status as Commission_status');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Commision_date',date('Y-m-d'));
        //$this->db->where('commission.Commision_date',date('Y-m-d'));
        $this->db->group_by('commission.Membership_ID');
        // $this->db->group_by('level_det.Level_ID');
        $this->db->group_by('level.ID');
        // $this->db->group_by('commission.Commision_type');
        //$this->db->where('commission.Status',1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    public function get_earning_summary1($s_date,$e_date,$mobile) {
    // public function get_earning_summary1($commission_type,$payment_status,$s_date,$e_date,$mobile,$topup,$contract,$level) {

        $this->db->select('commission.*,sum(commission.Amount) as tot_amount,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level.Level,commission.Status as Commission_status');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');

        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');

        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');

        $this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Commision_date',date('Y-m-d'));
        //$this->db->where('commission.Status',1);
        $this->db->group_by('commission.Membership_ID');
        $this->db->group_by('level_det.Level_ID');
        //$this->db->group_by('level.ID');
        //$this->db->group_by('commission.Commision_type');

     //    if(!empty($commission_type)){
     //    $this->db->where("commission.Commision_type",$commission_type);
     // }
     // if(!empty($payment_status)){
     //    $payment_status=explode(',',$payment_status);
     //    $this->db->where_in("commission.Status",$payment_status);
     // }
    
     if(!empty($s_date)){
        $this->db->where("commission.Commision_date >=",$s_date);
     }
     if(!empty($e_date)){
        $this->db->where("commission.Commision_date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

     //    if(!empty($topup)){
     //    $this->db->where("topup.ID",$topup);
     // }
     // if(!empty($contract)){
     //    $this->db->where("contract.Contract_ID",$contract);
     // }
     if(!empty($level)){
        $this->db->where("level.ID",$level);
     }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_all_level_types() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_all_commission_types() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_commission');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_all_topups() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_member_topup');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_all_levels() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_level');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    

public function get_contracts($topup) {
    $this->db->select('*');
    $this->db->where("Contract_status",6);
    $this->db->where("Topup_id",$topup);
    $query = $this->db->get('gc_member_franchisee_contract');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    

}



