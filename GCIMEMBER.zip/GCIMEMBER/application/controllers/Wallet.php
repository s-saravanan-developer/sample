<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Wallet extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Users_model');
    }

	public function index()
	{
        
		$template['page']='wallet/view_level_earning';
        $this->load->view('template',$template);
		
	}

    public function wallet_credit()
    {
        
        $template['page']='wallet/view_wallet_credit';
        $this->load->view('template',$template);
        
    }

    public function wallet_debit()
    {
        
        $template['page']='wallet/view_wallet_debit';
        $this->load->view('template',$template);
        
    }

    public function trans_history()
    {
        
        $template['page']='wallet/view_trans_history';
        $this->load->view('template',$template);
        
    }

    public function withdraw_request()
    {
        
        $template['page']='wallet/view_withdraw_request';
        $this->load->view('template',$template);
        
    }

    public function payout_request()
    {
        
        $template['page']='wallet/view_payout_request';
        $this->load->view('template',$template);
        
    }

}
