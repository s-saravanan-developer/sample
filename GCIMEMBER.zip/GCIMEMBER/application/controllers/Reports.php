<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Reports extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Users_model');
        $this->load->model('payout_money/Payout_money_model');
        $this->load->model('Report_model');
    }

	public function manage_payouts()
	{
        
		 $template['page']                           ='reports/view_payout_report';
         $template['level']                          =  $this->Report_model->get_all_level_types();
         $template['commission']                     =  $this->Report_model->get_all_commission_types();
         $template['payout_type']                    =  $this->Report_model->get_all_payout_types();
        $template['payout']                          =  $this->Report_model->get_today_payout_history();
        $this->load->view('template',$template);
		
	}

        public function transaction_history()
    {
        
        $template['page']                            ='reports/view_transaction_history';
        $template['level']                           =  $this->Report_model->get_all_level_types();
        $template['commission']                      =  $this->Report_model->get_all_commission_types();
        $template['topup']                           =  $this->Report_model->get_all_topups();
        $template['transaction']                     =  $this->Report_model->get_transaction_history();
        $this->load->view('template',$template);
        
    }


    public function get_payout_history1()
    {
        
        $mobile                                      = $this->input->post("mobile");
        $date                                        =date("Y-m-d", strtotime($this->input->post("date")));
        $template['payout']                          =  $this->Report_model->get_payout_history1($mobile,$date);
        $this->load->view('reports/ajax_payout_history',$template);
        
    }
    public function get_payout_history2()
    {
        $mobile                                      = $this->input->post("mobile");
        $commission_type                             = $this->input->post("commission_type");  
        $level_type                                  = $this->input->post("level_type");
        $payout_list                                  = $this->input->post("payout_list");
        $payment_list                                  = $this->input->post("payment_list");

        $s_date                                      =date("Y-m-d", strtotime($this->input->post("s_date")));
        $e_date                                      =date("Y-m-d", strtotime($this->input->post("e_date")));
        $template['payout']                          =  $this->Report_model->get_payout_history2($commission_type,$level_type,$s_date,$e_date,$mobile,$payout_list,$payment_list);
        $this->load->view('reports/ajax_payout_history',$template);
        
    }
    public function get_transaction_history1()
    {
        
        $mobile                                      = $this->input->post("mobile");
        $date                                        =date("Y-m-d", strtotime($this->input->post("date")));
        $template['transaction']                     =  $this->Report_model->get_transaction_history1($mobile,$date);
        $this->load->view('reports/ajax_transaction_history',$template);
        
    }
    public function get_transaction_history2()
    {
        $mobile                                      = $this->input->post("mobile");
        $commission_type                             = $this->input->post("commission_type");  
        $topup_list                                  = $this->input->post("topup_list");  
        $transaction_type                            = $this->input->post("transaction_type");
        $contract                                    = $this->input->post("contract");
        $s_date                                      =date("Y-m-d", strtotime($this->input->post("s_date")));
        $e_date                                      =date("Y-m-d", strtotime($this->input->post("e_date")));
        $template['transaction']                     =  $this->Report_model->get_transaction_history2($commission_type,$topup_list,$transaction_type,$s_date,$e_date,$mobile,$contract);
        $this->load->view('reports/ajax_transaction_history',$template);
        
    }

    


}
