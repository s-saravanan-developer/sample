<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Sales_point extends CI_Controller {

	public function __construct() {

		parent::__construct();

		if ($this->session->userdata('is_logged_in') == '') {
			redirect('login');
			session_destroy();
		}
		$this->load->model('member/Membership_model');
		$this->load->model('topup/Topup_model');
		$this->load->model('sales_point/Sales_point_model');
	}
	public function index()
	{
		
		$template['page']='sales_point/sales_point'; 
		$template['sales_point']    =  $this->Sales_point_model->getall_service_entries();
		$this->load->view('template',$template);
		
	}

	public function Sales_point_topup()
	{
		
		$template['page']='sales_point/sales_point_topup';
		$template['sales_point']    =  $this->Sales_point_model->getall_sales_points();
		$template['bank']            =  $this->Membership_model->getall_bank();
        $template['payment_mode']    =  $this->Membership_model->getall_payment_modes();
		$this->load->view('template',$template);
		
	}

	public function Sales_point_credit()
	{
		
		$template['page']='sales_point/sales_point_credit'; 
		$template['sales_point']    =  $this->Sales_point_model->getall_service_entries_credit();
		$this->load->view('template',$template);
		
	}

	

	public function Sales_point_topup_view()
	{
		$service_point_id = $this->input->get("id");
		$template['service_point']    =  $this->Sales_point_model->getall_service_entries_by_id($service_point_id);
		$template['service_payment']    =  $this->Sales_point_model->getall_service_payments_by_id($service_point_id);
		
		$template['page']='sales_point/sales_point_topup_view';
		$template['sales_point']    =  $this->Sales_point_model->getall_sales_points();
		$template['bank']            =  $this->Membership_model->getall_bank();
        $template['payment_mode']    =  $this->Membership_model->getall_payment_modes();
		$this->load->view('template',$template);
		
	}

public function add_sales_point(){
	$sales_point = $this->input->post("sales_point");
	$unique_id = $this->input->post("unique_id");
	// var_dump($unique_id);
	// var_dump($sales_point);die();
		$sales_point['Wallet_flag']=$sales_point['Topup_for'];
		$sales_point['Date']=date('Y-m-d');
		$sales_point['Company_id']=$this->session->userdata('CompanyId');
		$sales_point['Branch_id']=$this->session->userdata('CompanyId');
		$inserted_id =  $this->Sales_point_model->insert_service_point1($sales_point);
		// $inserted =  $this->Sales_point_model->insert_service_wallet($sales_point);

		$unique=explode(',',$unique_id);
        foreach($unique as $val1){
             $payment_data['payment_data_'.$val1] = $this->input->post('payment_data_'.$val1);
             $payment_data['payment_data_'.$val1]['Service_point_ID']   = $inserted_id;
             $payment_data['payment_data_'.$val1]['Topup_for']   = $sales_point['Topup_for'];

            if(isset($sales_point['Membership_ID'])){ $payment_data['payment_data_'.$val1]['Membership_ID']= $sales_point['Membership_ID'];}else{ $payment_data['payment_data_'.$val1]['Membership_ID']= '';}

              if(isset($sales_point['Service_point'])){ $payment_data['payment_data_'.$val1]['Service_point']   =$sales_point['Service_point'];}else{ $payment_data['payment_data_'.$val1]['Service_point']   ='';}

             $payment_data['payment_data_'.$val1]['Wallet_amount_from']  = $sales_point['Wallet_amount_from'];

             if(isset($sales_point['Wallet_service_point'])){ $payment_data['payment_data_'.$val1]['Wallet_service_point']   = $sales_point['Wallet_service_point'];}else{ $payment_data['payment_data_'.$val1]['Wallet_service_point']   = '';}

             $payment_data['payment_data_'.$val1]['Currency']     = $sales_point['Currency'];
             $payment_data['payment_data_'.$val1]['Company_id']   = $this->session->userdata('CompanyId');
             $payment_data['payment_data_'.$val1]['Branch_id']    = $this->session->userdata('CompanyId');
             $payment_data['payment_data_'.$val1]['Date']   = date('Y-m-d',strtotime($payment_data['payment_data_'.$val1]['Date']));

             $statement_name='state_ment_'.$val1;
             if(isset($sales_point['Membership_ID'])){
             	$data=$this->db->get_where('gc_membership',array('Membership_ID' => $sales_point['Membership_ID']))->result_array();
				if(!empty($data)){
					$Membership_code=$data[0]['Membership_code'];
				}
			}else{
				$Membership_code='';
			}

             $payment_data['payment_data_'.$val1]['Statement']   = $this->member_statement_attachment_1($Membership_code,$statement_name,'statement');
             $payment_data['payment_data_'.$val1]['Payment_status']   = 6;
             $inserted_id1 =  $this->Sales_point_model->insert_service_point_payment($payment_data['payment_data_'.$val1]);
            }
            redirect('sales_point/Sales_point/Sales_point_topup');
}


    public function generatePIN($digits){
    $i = 0; //counter
    $pin = ""; //our default pin is blank.
    while($i < $digits){
        //generate a random number between 0 and 9.
        $pin .= mt_rand(0, 9);
        $i++;
    }
    return $pin;
}

    public function member_statement_attachment_1($ref_no,$profile_name,$name) {     
         // var_dump($profile_name);
         // var_dump($name);
    		if(!empty($ref_no)){


           if (!is_dir('./attachments/Members/'.$ref_no))
                  {
                      mkdir('./attachments/Members/'.$ref_no, 0777, true);
                  }
                  $dir_exist = true; // flag for checking the directory exist or not
                  if (!is_dir('./attachments/Members/'.$ref_no))
                  {
                      mkdir('./attachments/Members/'.$ref_no, 0777, true);
                      $dir_exist = false; // dir not exist
                  }

              

         $config['upload_path']          = './attachments/Members/'.$ref_no.'/';
         $config['allowed_types']        = 'gif|jpg|png';
         $new_name                       = $ref_no.'_'.$name;
     }else{
     	 $config['upload_path']          = './attachments/statements/';
         $config['allowed_types']        = 'gif|jpg|png';
         $new_name                       = $this->generatePIN(4).'_'.$name;
     }
         $config['file_name']            = $new_name;
         //var_dump($config['file_name']);
         
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ( ! $this->upload->do_upload($profile_name))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $file_name = '';
                        //print_r($error);
                         return $file_name;                 
                }
                else
                {   
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];
                        // die();
                        // return $file_name;
                        if(!empty($ref_no)){
                        	return "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$ref_no.'/'.$file_name;
                        }else{
                        	return "http://".$_SERVER['HTTP_HOST'].base_url().'attachments/statements/'.$file_name;
                        }
                        
                }

    }


public function get_sales_point_details()
    {
        $sales_point = $this->input->post("sales_point");
        $temp =  $this->Sales_point_model->get_sales_point_details($sales_point);
        if(!empty($temp)){
        	$data="Name : ".$temp[0]['firstname']." , ".$temp[0]['city_name']." , ".$temp[0]['state_name']." , ".$temp[0]['country_name']." , ".$temp[0]['zipcode']."..,\n Wallet Balance - ".$temp[0]['Wallet_balance']; 
        }else{
        	$data='Name : - ';
        }
                 
        echo json_encode($data);
    }

	public function Sales_point_summary()
	{
		$template['sales_point']    =  $this->Sales_point_model->getall_sales_points();
		$template['page']='sales_point/Sales_point_summary';
		$this->load->view('template',$template);
		
	}


public function getall_service_summary(){


	 $mobile = $this->input->post("mobile");
	 $s_date = $this->input->post("s_date");
	 $e_date = $this->input->post("e_date");
	 $topup_for = $this->input->post("Topup_for");
	  $sales_point = $this->input->post("sales_point");
	$template['service_point'] =  $this->Sales_point_model->getall_service_summary($mobile,$s_date,$e_date,$topup_for,$sales_point);
// var_dump($template['service_point']);die();
	$this->load->view('sales_point/ajax_service',$template);
}
	public function withdraw()
	{
		
		$template['page']='topup/view_member_withdraw';
		$this->load->view('template',$template);
		
	}

	 public function cancelled_withdraw()
	{
		
		$template['page']='topup/view_member_canceled_withdraw';
		$this->load->view('template',$template);
		
	}

	public function add_member_upgrade()
	{
		// extract($_POST);
		// var_dump($_POST);die();

		$agreement_data = $this->input->post("agreement_data");

		$contract_data = $this->input->post("contract_data");

		$unique_id = $this->input->post('unique_id');
		$unique=explode(',',$unique_id);
		foreach($unique as $val1){
			 $payment_data['payment_data_'.$val1] = $this->input->post('payment_data_'.$val1);
			}

		$inserted = $this->Membership_model->add_membership_upgrade($contract_data,$payment_data,$agreement_data);

		redirect('topup/Topup');
	}

	public function get_withdraw_details()
	{
		extract($_POST);
		
		$template['member_id'] =  $this->Membership_model->get_member_by_details($mobile);

		$dates=date("Y-m-d", strtotime($date));

		 $template['contract'] =  $this->Membership_model->get_contract_by($mobile,$dates);

		$this->load->view('contract/ajax_contract',$template);
	}

	public function get_withdraw_approved_details()
	{
		extract($_POST);

		$template['member_id'] =  $this->Membership_model->get_member_by_details($mobile);

		$dates=date("Y-m-d", strtotime($date));
		$template['contract'] =  $this->Membership_model->get_contract_by_success($mobile,$dates);

		$this->load->view('contract/ajax_contract',$template);
	}

		public function get_withdraw_canceled_details()
	{
		extract($_POST);

		$template['member_id'] =  $this->Membership_model->get_member_by_details($mobile);

		$dates=date("Y-m-d", strtotime($date));
		$template['contract'] =  $this->Membership_model->get_contract_by_failed($mobile,$dates);

		$this->load->view('contract/ajax_contract',$template);
	}

	public function withdraw_req_approve($value='')
	{
		$id = ( explode( ',', $this->input->post('id') ));
		$date =  $this->input->post('date');

		foreach ($id as  $value) {
				$this->Topup_model->process_withdraw_req($value,$date);
			 }
	}

public function cancel_withdraw_req(){
		$id = ( explode( ',', $this->input->post('id') ));
		$date =  $this->input->post('date');
		$reason =  $this->input->post('reason');
		//var_dump($id);die();
		foreach ($id as  $value) {
				$this->Topup_model->cancel_withdraw_req($value,$date,$reason);
			 }
	}
}


