                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                





(function($,undefined){
var arrowDirections={
south:'north',
north:'south',
east:'west',
west:'east'
};


var directions=['north','south','west','east'];

var defaults={
pos:'south',
arrowDirection:null,
arrowStyle:'outset',
closeOnWindowResize:true,
closeOnDocumentClick:true
};

function Tooltip(context,options){
$.proxyAll(this,'show','hide','toggle','pos','unhover','onWindowResize','onDocumentClick','onUiElementOpen');


this.context=$(context).addClass('rich-tooltip-context');


this.options=$.extend({},defaults,options||{});


this.content=$(this.options.content).eq(0).addClass('rich-tooltip-content');


if(this.content.length===0){
throw new Error('jquery.richTooltip: failed to find desired tooltip');
}


this.content.addClass('rich-tooltip-pos-'+this.options.pos);


this.context.attr('data-rel','tooltip');


if(this.options.action==='hover'){

if($.fn.hoverDelay){

this.context.hoverDelay(this.show,this.unhover,{delayOver:200,delayOut:500,addChildren:this.content});


this.content.hoverDelay(this.show,this.unhover,{delayOver:200,delayOut:500,addChildren:this.context});
}else{

this.context.hover(this.show,this.unhover);


this.content.hover(this.show,this.unhover);
}




this.context.on('press',$.proxy(function(event){

if(event.pointerType==='touch'){
event.preventClick();
this.toggle(event);
}
},this));
}else{

this.context.on('click',this.toggle);
}


this.container=this.options.container?$(this.options.container):null;


this.arrow=this.content.find('.rich-tooltip-arrow');


if(this.arrow.length===0){
this.arrow=$('<div class="rich-tooltip-arrow"></div>').appendTo(this.content);
}


this.content.on('click','[data-rel="close"]',this.hide);
}

Tooltip.prototype.unhover=function(){
this._clearHoverTimeout();
this.hoverTimeout=setTimeout(this.hide,250);
};

Tooltip.prototype._clearHoverTimeout=function(){
if(this.hoverTimeout){
clearTimeout(this.hoverTimeout);
this.hoverTimeout=null;
}
};



function findZIndex(elem){
var pos;
var zIndexVal;
var maxZIndexVal=0;
if(this.length){
while(elem.length&&elem[0]!==document){



pos=elem.css('position');
if(pos==='absolute'||pos==='relative'||pos==='fixed'){




zIndexVal=parseInt(elem.css('zIndex'),10);
if(!isNaN(zIndexVal)&&zIndexVal!==0){
if(zIndexVal>maxZIndexVal){
maxZIndexVal=zIndexVal;
}
}
}
elem=elem.parent();
}
}

return maxZIndexVal;
}

Tooltip.prototype.show=function(){
this._clearHoverTimeout();

if(this.visible){
return;
}

var zIndex=findZIndex(this.content.parent());


if(zIndex>0){
this.content.css('z-index',zIndex+1);
}


if(!this.content.parent().is('body')){
this.content.appendTo('body');
}


$(document).trigger('ui.element.open',this);

this.content.show();
this.pos();


this.visible=true;


this.context.addClass('rich-tooltip-open').trigger('richTooltip:open');

this.viewportSize={
height:$(window).height(),
width:$(window).width()
};


if(this.options.closeOnWindowResize){
$(window).on('resize',this.onWindowResize);
}


if(this.options.closeOnDocumentClick){
$(document).on('click',this.onDocumentClick);
}


$(document).one('ui.element.open',this.onUiElementOpen);
};

Tooltip.prototype.hide=function(){
this._clearHoverTimeout();

if(!this.visible){
return;
}

this.content.hide();


this.visible=false;


this.context.removeClass('rich-tooltip-open').trigger('richTooltip:close');


if(this.options.closeOnWindowResize){
$(window).off('resize',this.onWindowResize);
}

if(this.options.closeOnDocumentClick){
$(document).off('click',this.onDocumentClick);
}


$(document).off('ui.element.open',this.onUiElementOpen);
};

Tooltip.prototype.toggle=function(event){
if(event){
event.preventDefault();



event.stopPropagation();
}

if(this.visible){
this.hide();
}else{
this.show();
}
};

Tooltip.prototype.onUiElementOpen=function(event,item){
if(item!==this){
this.hide();
}
};





Tooltip.prototype.onWindowResize=function(){
if($(window).height()!=this.viewportSize.height||$(window).width()!=this.viewportSize.width){
this.hide();
}
};



Tooltip.prototype.onDocumentClick=function(e){
var target=$(e.target);
if(!target.is(this.content)&&!target.isChildOf(this.content)){
this.hide();
}
};


var PADDING=10;
var ARROW_WIDTH=15;

Tooltip.prototype.pos=function(){



var arrowSize=this.options.arrowStyle==='inset'||this.arrow.css('display')=='none'?0:ARROW_WIDTH;

var restrainedPos=$.calcRestrainedPos({
giveMeSomething:true,
direction:this.options.pos,
content:this.content.css('max-width','100%'),
context:this.context,
container:this.container,
reset:{
margin:0
},
offsets:{
viewport:PADDING,
vertical:arrowSize,
horizontal:arrowSize
}
});

var pos=restrainedPos.pos;

if(restrainedPos.direction!==this.options.pos){
this.content
.removeClass('rich-tooltip-pos-'+this.options.pos)
.addClass('rich-tooltip-pos-'+restrainedPos.direction);
}


var arrowDirection=this.options.arrowDirection||arrowDirections[restrainedPos.direction];

this.content.css(pos);

this.arrow

.removeClass(directions.join(' '))

.addClass(arrowDirection);
};

$.fn.tooltip=$.fn.richTooltip=function jQueryTooltip(options){
var el=$(this);
var tooltip=el.data('__tooltip');

if(!tooltip){
tooltip=new Tooltip(el,options);
el.data('__tooltip',tooltip);
}


if(typeof options==='string'&&options in tooltip){
tooltip[options]();
}

return this;
};

$.fn.isChildOf=function jQueryIsChildOf(filter_string){
var parents=$(this).parents();

for(var j=0;j<parents.length;j++){
if($(parents[j]).is(filter_string)){
return true;
}
}

return false;
};


$(function(){

function getOptionsFromData(context,content){
var data=context.data();

if(!content){
content=$(data.tooltip);
}

return{
content:content,
action:data.tooltipAction||'click',
pos:data.tooltipPos||'south',
container:data.tooltipContainer||undefined,
arrowDirection:data.tooltipArrowDirection||null,
arrowStyle:data.tooltipArrowStyle||null,
closeOnWindowResize:data.tooltipIgnoreWindowResize===undefined,
closeOnDocumentClick:data.tooltipIgnoreDocumentClick===undefined
};
}


$('[data-rel="tooltip"] + aside').each(function(i,el){
var content=$(el);
var context=content.prev();

context.richTooltip(getOptionsFromData(context,content));
});


$('[data-tooltip]').each(function(i,context){
context=$(context);
context.richTooltip(getOptionsFromData(context));
});
});
})(jQuery);
