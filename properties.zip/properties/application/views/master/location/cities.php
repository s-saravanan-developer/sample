<script>
   <?php
         if ($this->session->flashdata('city_success')) 
         {
            echo "var data = ' ".$this->session->flashdata('city_success')."';";
            echo "success(data);";
         }
         if ($this->session->flashdata('duplicate')) 
         {
            echo "var data = ' ".$this->session->flashdata('duplicate')."';";
            echo "duplicate(data);";
         }
   ?>
</script>
<div class="content-wrapper">
   <div class="content">
      <header class="page-header">
         <div class="d-flex align-items-center">
            <div class="mr-auto">
               <h1 class="separator">Cities</h1>
               <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i></a></li>
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard">Master</a></li>
                     <li class="breadcrumb-item" aria-current="page">Location</li>
                     <li class="breadcrumb-item active" aria-current="page">Cities</li>
                  </ol>
               </nav>
            </div>
            <ul class="actions top-right">
               <li class="dropdown">
                  <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                  <i class="la la-ellipsis-h"></i>
                  </a>
                  <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
                     <div class="dropdown-header">
                        Quick Actions
                     </div>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-clockwise"></i> Refresh
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-gear"></i> Manage Widgets
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-cloud-download"></i> Export
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-help"></i> Support
                     </a>
                  </div>
               </li>
            </ul>
         </div>
      </header>
      <section class="page-content container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="card">
                  <h5 class="card-header">
                     <div style="float: left;">
                        Manage Cities	
                     </div>
                     <div style="float: right;">
                        <?php $sectionpermission=$this->session->userdata('section_permission');
                              if (!empty($sectionpermission)) {
                                  foreach ($sectionpermission as $section_list) {
                                    if($section_list['section_id']=="6" && $section_list['acc_add']=="1"){
                                      ?>
                        <button type="button" class="btn btn-success  btn-floating" data-toggle="tooltip" data-placement="top" title="" data-original-title="Add New Cities" >
                           <p class="text-white" data-toggle="modal" data-target="#addusertype">Add New Cities</p>
                        </button><?php } } } ?>
                       
                     </div>
                  </h5>
                  <div class="card-body">
                     <table id="bs4-table" class="table table-striped table-bordered table-responsive" style="width:100%;">
                        <thead>
                           <tr>

                              
                               <th class="text-center" style="width: 2%">
                                                                 <input type="checkbox" name="checkbox" class="checkbox" id="select_all" /> 
                                                             </th>
                              
                              
                              <th style="width: 2%" class="text-center">S.No</th>
                              <?php $sectionpermission=$this->session->userdata('section_permission');
                              if (!empty($sectionpermission)) {
                                  foreach ($sectionpermission as $section_list) {
                                    if($section_list['section_id']=="6" &&($section_list['acc_view']=="1" || $section_list['acc_edit']=="1" || $section_list['acc_delete']=="1")){?>
                              <th class="text-center" style="width: 12%">Action</th><?php } } }?>
                              <th style="width: 24%">City Name</th>
                              <th style="width: 20%">Alias Name</th>
                              <th style="width: 22%">District Name</th>
                              <th style="width: 22%">State Name</th>
                              <th style="width: 22%">Country Name</th>
                              <th style="width: 10%">Status</th>
                              
                           </tr>
                        </thead>
                        <tbody>
                           <?php if (!empty($cities)) {$s = 1; foreach ($cities as $list) {?>
                           <tr>

                              
                               <td><input type="checkbox" name="checkbox" class="checkbox boxischecked" value="<?php echo ucfirst($list['cities_id']); ?>"  /></td>
                              
                              
                              <td class="text-center"><?php echo $s; ?></td>
                              <?php $sectionpermission=$this->session->userdata('section_permission');
                              if (!empty($sectionpermission)) {
                                  foreach ($sectionpermission as $section_list) {
                                    if($section_list['section_id']=="6" &&($section_list['acc_view']=="1" || $section_list['acc_edit']=="1" || $section_list['acc_delete']=="1")){?>
                              <td class="text-center"><?php $sectionpermission=$this->session->userdata('section_permission');
                              if (!empty($sectionpermission)) {
                                  foreach ($sectionpermission as $section_list) {
                                    if($section_list['section_id']=="6" && $section_list['acc_edit']=="1"){
                                      ?>
                                 <a id="usertypeedit" onclick="edit_city('<?php echo ucfirst($list['cities_id']); ?>','<?php echo ucfirst($list['c_id']); ?>','<?php echo ucfirst($list['state_id']); ?>','<?php echo ucfirst($list['cities_name']); ?>','<?php echo ucfirst($list['alias_name']); ?>','<?php echo ucfirst($list['citiess_id']); ?>')" class="btn btn-info btn-sm editusertype" data-toggle="modal" data-target="#editusertype"><i class="zmdi zmdi-edit zmdi-hc-fw" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"  style="
                                    font-size: 17px;
                                    color:  white;
                                    "></i></a><?php } } } if (!empty($sectionpermission)) {
                                  foreach ($sectionpermission as $section_list) {
                                    if($section_list['section_id']=="6" && $section_list['acc_delete']=="1"){?>

                                <?php if ($list['delete_status'] == 1) { ?> 

                                  <div class="btn btn-accent btn-sm">
                                  <i class="zmdi zmdi-delete zmdi-hc-fw" style="font-size: 17px;color:  white;" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"></i>
                                  </div>  

                              <?php }else{ ?>

                              
                                 <a href="" onclick="delete_coutry('<?php echo ucfirst($list['cities_id']); ?>','<?php echo ucfirst($table_name); ?>')" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deletemodel"><i class="zmdi zmdi-delete zmdi-hc-fw" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" style="font-size: 17px;color:  white;"></i></a> 
                                  <?php } ?>

                                  
                                  <?php } } }?>                                     
                              </td><?php } } }?>
                              <td class="s_no"><?php echo ucfirst($list['cities_name']); ?></td>
                               <td class="s_no"><?php echo ucfirst($list['alias_name']); ?></td>
                              <td class="s_no"><?php echo ucfirst($list['cityname']); ?></td>
                              <td class="s_no"><?php echo ucfirst($list['state_name']); ?></td>
                              <td class="s_no"><?php echo ucfirst($list['country_name']); ?></td>
                              <td><span class="badge badge-<?php echo ($list['status'] == 1) ? 'success' : 'danger'; ?>"><?php echo ($list['status'] == 1) ? 'Active' : 'In-Active'; ?></span></td>
                              
                           </tr>
                           <?php
                              $s++;
                              }
                              }
                              ?>
                        </tbody>
                     </table>
                  </div>
                   <div class="card-footer bg-light">
                               <button type="button" class="btn btn-danger delbtn"  data-toggle="modal" data-target="#deletemodel1">Delete</button>
                               <button type="" class="btn btn btn-success   delbtn"  data-toggle="modal" data-target="#active_all_model">Active</button>
                               <button type="" class="btn btn btn-info delbtn" data-toggle="modal" data-target="#deactive_all_model">In-Active
                               </button>
                               <button class="btn btn-primary region_input no-display" data-toggle="modal" data-target="#multiexport">Export Excel</button>
                              <button class="btn btn-primary region_input1" data-toggle="modal" data-target="#Export">Export Excel</button>
                               </div>
               </div>

                
               
               
            </div>
         </div>
      </section>
   </div>
</div>
</div>	
<!-- BASIC MODAL DEMO -->
<div class="modal fade" id="deletemodel" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Delete</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <form action="<?php echo base_url();?>master/location/cities_delete" method="POST">
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
               <input type="hidden" name="url" value=" ">
               <input type="hidden" name="url" value="city">
               <input class="delete_id" type="hidden" name="country_id">
               <input class="table_name" type="hidden" name="table_name">						
            </div>
            <div class="delete-footer">
               <button type="submit" class="btn btn-primary">Yes, delete it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>						
            </div>
         </form>
      </div>
   </div>
</div>


  
  <div class="modal fade" id="deletemodel1" tabindex="-1" role="dialog"  aria-hidden="true">
     <div class="modal-dialog" role="document">
        <div class="modal-content">
           <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel9">Delete</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true" class="zmdi zmdi-close"></span>
              </button>
           </div>
           
              <div class="modal-body">
                 <div class="swal2-header">
                    <ul class="swal2-progresssteps" style="display: none;"></ul>
                    <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                    <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                    <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                    <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                    <div class="swal2-icon swal2-success" style="display: none;">
                       <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                       <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                       <div class="swal2-success-ring"></div>
                       <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                       <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                    </div>
                    <img class="swal2-image" style="display: none;">
                    <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                    <button type="button" class="swal2-close" style="display: none;">×</button>
                 </div>
                 <!-- Hiiden Values -->
                        
  
              </div>
              <div class="delete-footer">
                 <button type="submit" id="del_all" class="btn btn-primary">Yes, delete it!</button>
                 <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
              </div>
          
        </div>
     </div>
  </div>
  
  
  <div class="modal fade" id="deactive_all_model" tabindex="-1" role="dialog"  aria-hidden="true">
     <div class="modal-dialog" role="document">
        <div class="modal-content">
           <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel9">In-Active</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true" class="zmdi zmdi-close"></span>
              </button>
           </div>
           
              <div class="modal-body">
                 <div class="swal2-header">
                    <ul class="swal2-progresssteps" style="display: none;"></ul>
                    <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                    <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                    <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                    <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                    <div class="swal2-icon swal2-success" style="display: none;">
                       <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                       <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                       <div class="swal2-success-ring"></div>
                       <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                       <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                    </div>
                    <img class="swal2-image" style="display: none;">
                    <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                    <button type="button" class="swal2-close" style="display: none;">×</button>
                 </div>
                 <!-- Hiiden Values -->
                        
  
              </div>
              <div class="delete-footer">
                 <button type="submit" id="deactive_all" class="btn btn-primary">Yes, In-Active it!</button>
                 <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
              </div>
          
        </div>
     </div>
  </div>
  
  
  <div class="modal fade" id="active_all_model" tabindex="-1" role="dialog"  aria-hidden="true">
     <div class="modal-dialog" role="document">
        <div class="modal-content">
           <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel9">Active</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true" class="zmdi zmdi-close"></span>
              </button>
           </div>
           
              <div class="modal-body">
                 <div class="swal2-header">
                    <ul class="swal2-progresssteps" style="display: none;"></ul>
                    <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                    <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                    <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                    <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                    <div class="swal2-icon swal2-success" style="display: none;">
                       <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                       <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                       <div class="swal2-success-ring"></div>
                       <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                       <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                    </div>
                    <img class="swal2-image" style="display: none;">
                    <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                    <button type="button" class="swal2-close" style="display: none;">×</button>
                 </div>
                 <!-- Hiiden Values -->
                        
  
              </div>
              <div class="delete-footer">
                 <button type="submit" id="active_all" class="btn btn-primary">Yes, Active it!</button>
                 <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
              </div>
          
        </div>
     </div>
  </div>
  
  
  <div class="modal fade" id="Export" tabindex="-1" role="dialog"  aria-hidden="true">
     <div class="modal-dialog" role="document">
        <div class="modal-content">
           <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel9">Export</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true" class="zmdi zmdi-close"></span>
              </button>
           </div>
           
              <div class="modal-body">
                 <div class="swal2-header">
                    <ul class="swal2-progresssteps" style="display: none;"></ul>
                    <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                    <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                    <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                    <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                    <div class="swal2-icon swal2-success" style="display: none;">
                       <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                       <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                       <div class="swal2-success-ring"></div>
                       <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                       <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                    </div>
                    <img class="swal2-image" style="display: none;">
                    <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                    <button type="button" class="swal2-close" style="display: none;">×</button>
                 </div>
                 <!-- Hiiden Values -->
                        
  
              </div>
              <div class="delete-footer">
                 <a  id="active_all" class="btn btn-primary export_link" data-dismiss="modal">Yes, Export it!</a>
                 <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
              </div>
        </div>
     </div>
  </div>
  
  <div class="modal fade" id="multiexport" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Export</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
                      

            </div>
            <div class="delete-footer">
               <a 
               type="submit" class="btn btn-primary multi_export" data-dismiss="modal">Yes, Export it!</a>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>                  
            </div>
      </div>
   </div>
</div>
  
    

<!-- LOCATION RIGHT SIDE -->
<div id="addusertype" class="modal modal-right-side fade" data-backdrop="static"  role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content" >
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel6">Cities</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <div class="modal-body" style="overflow-y: scroll;">
            <div class="row">
               <div class="col">
                  <div class="card">
                     <h5 class="card-header">Add Cities</h5>
                     
                     <div class="card-body">
                     <form action="<?php echo base_url(); ?>master/location/cities_insert_data" method="post" data-toggle="validator" role="form">
                        <div class="form-row">
                           <div class="form-group col-md-6">
                              <label for="exampleFormControlSelect1">Country <span style="color:red">*</span></label>
                              
                              <div class="form-group">
                                 <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                 <select class="form-control country_id" id="s2_demo1" name="city[country_id]" style="width: 85%;" required="">
                                    <option value="">Select Country</option>
                                 <?php
                                    foreach ($country as $value) {
                                    echo "<option value=".$value['id'].">".$value['country_name']."</option>";
                                    }
                                    ?>
                                 </select>
                              </div>
                              </div>
                           </div>
                           <div class="form-group col-md-6">
                              <label for="exampleFormControlSelect1">State <span style="color:red">*</span></label>
                              <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                              <select class="form-control state_id company_state" name="city[state_id]" id="region" style="width: 85%" required="">
                                    <option value="">Select State</option>

                              <?php
                                 foreach ($state as $value) {
                                 echo "<option value=".$value['state_id'].">".$value['state_name']."</option>";
                                 }
                                 ?>
                              </select>
                           </div>
                           </div>
                            <div class="form-group col-md-6">
                              <label for="exampleFormControlSelect1">District <span style="color:red">*</span></label>
                              <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                              <select class="form-control state_district area_c city_id" name="city[district_id]" id="exampleFormControlSelect1" style="width: 85%" required="">
                                    <option value="">Select District</option>

                              <?php
                                 foreach ($city as $value) {
                                 echo "<option value=".$value['city_id'].">".$value['city_name']."</option>";
                                 }
                                 ?>
                              </select>
                           </div>
                           </div>
                           <div class="form-group col-md-6">
                              <div class="form-group">
                                 <label for="inputName" class="control-label">City Name <span style="color:red">*</span></label>
                                 <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                 <input type="text" class="form-control check_data" id="inputName" autofocus placeholder="City Name" name="city[cities_name]" onkeyup="check_city_name()" required>
                              </div>
                              <div class="text-center duplicate-occur no-display">
                                       <code>This City Name Is Already Used in Some Page</code>
                                    </div>
                              </div>
                           </div>
                            <div class="form-group col-md-6">
                              <div class="form-group">
                                 <label for="inputName" class="control-label">Alias Name <span style="color:red">*</span></label>
                                 <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                 <input type="text" class="form-control check_data" id="inputName" autofocus placeholder="Alias Name" name="city[alias_name]" onkeyup="check_city_name()" required>
                              </div>
                              <div class="text-center duplicate-occur no-display">
                                       <code>This Alias Name Is Already Used in Some Page</code>
                                    </div>
                              </div>
                           </div>
                           <div class="form-group col-md-6">
                              <label for="exampleFormControlSelect1">Status</label>
                              <div class="input-group mb-3">
                                 <div class="input-group-prepend">
                                    <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-equalizer zmdi-hc-fw"></i></span>
                                 </div>
                              <select class="form-control" name="city[status]" id="exampleFormControlSelect1">
                                 <option value="1">Active</option>
                                 <option value="2">Inactive</option>
                              </select>
                           </div>
                           </div>
                        </div>
                        <!-- <div class="row">
                           <h5 class="card-header" style="Padding-left: 9px;">User Credential
                           </h5>
                           <div class="col-12">
                              
                              <div class="row">
                                 <div class="col-md-4">
                                    <div class="form-group">
                                       <label class="col-form-label-lg control-label" for="largeInput">UDF 1</label>
                                       <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                             <span class="input-group-text" id="basic-icon-addon1"><i class="icon dripicons-view-thumb"></i></span>
                                          </div>
                                          <div class="invalid-feedback">
                                             Please choose a Udf.
                                          </div>
                                          <input type="text" class="form-control" placeholder="Enter UDF 1" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="city[udf_1]" >
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                       <label class="col-form-label-lg control-label" for="largeInput">UDF 2</label>
                                       <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                             <span class="input-group-text" id="basic-icon-addon1"><i class="icon dripicons-view-thumb"></i></span>
                                          </div>
                                          <div class="invalid-feedback">
                                             Please choose a Udf.
                                          </div>
                                          <input type="text" class="form-control" placeholder="Enter UDF 2" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="city[udf_2]" >
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                       <label class="col-form-label-lg control-label" for="largeInput">UDF 3</label>
                                       <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                             <span class="input-group-text" id="basic-icon-addon1"><i class="icon dripicons-view-thumb"></i></span>
                                          </div>
                                          <div class="invalid-feedback">
                                             Please choose a Udf.
                                          </div>
                                          <input type="text" class="form-control" placeholder="Enter UDF 3" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="city[udf_3]" >
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           </div> -->
                  </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success submit" >Save changes</button>
         </div>
         </form>
      </div>
   </div>
</div>

<!-- Editing -->

<!-- Editing -->
<!-- LOCATION RIGHT SIDE -->
<div class="modal modal-right-side fade" id="editusertype" data-backdrop="static"  role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content" >
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel6">Cities</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <div class="modal-body" style="overflow-y: scroll;">
            <div class="row">
               <div class="col">
                  <div class="card">
                     <h5 class="card-header">Edit Cities</h5>                     
                     <div class="card-body">
                            <form action="<?php echo base_url(); ?>master/location/cities_update_data" method="post" data-toggle="validator" role="form">
                                <div class="form-row">
                                    <input class="city_ids" type="hidden" name="city_id" value=" ">
                                    <div class="form-group col-md-6">
                                        <label for="exampleFormControlSelect1">Country <span style="color:red">*</span></label>
                                        <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                        <select class="form-control country_id_old" id="" name="city[country_id]" style="width: 83%;" required="" disabled="">
                                          <option value="">Select Country</option>
                                 <?php
                                    foreach ($country as $value) {
                                    echo "<option value=".$value['id'].">".$value['country_name']."</option>";
                                    }
                                    ?>
                                 </select>
                              </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                       <label for="exampleFormControlSelect1">State <span style="color:red">*</span></label>
                                       <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                        <select class="form-control state_id_old" name="city[state_id]" id="" style="width: 83%;" required="" disabled="">
                                          <option value="">Select State</option>

                                          <?php
                                             foreach ($state as $value) {
                                             echo "<option value=".$value['state_id'].">".$value['state_name']."</option>";
                                             }
                                             ?>
                                          </select>
                                       </div>
                                    </div>
                                     <div class="form-group col-md-6">
                              <label for="exampleFormControlSelect1">District <span style="color:red">*</span></label>
                              <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                              <select class="form-control district_id_old" name="city[district_id]" id="exampleFormControlSelect1" style="width: 85%" required="" disabled="">
                                    <option value="">Select District</option>

                              <?php
                                 foreach ($city as $value) {
                                 echo "<option value=".$value['city_id'].">".$value['city_name']."</option>";
                                 }
                                 ?>
                              </select>
                           </div>
                           </div>
                                    <div class="form-group col-md-6">
                                        <label for="inputEmail4">Cities Name <span style="color:red">*</span></label>
                                        <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                        <input type="text" class="form-control city_name" id="inputEmail4" autofocus placeholder="Enter Cities Name" required="" value="" name="city[cities_name]">
                                     </div>
                                    </div>
                                     <div class="form-group col-md-6">
                                        <label for="inputEmail4">Alias Name <span style="color:red">*</span></label>
                                        <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                        <input type="text" class="form-control alis_name" id="inputEmail4" autofocus placeholder="Alias Name" value="" name="city[alias_name]" required="">
                                     </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="exampleFormControlSelect1">Status</label>
                                        <div class="input-group mb-3">
                                 <div class="input-group-prepend">
                                    <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-equalizer zmdi-hc-fw"></i></span>
                                 </div>
                                        <select class="form-control" id="exampleFormControlSelect1" name="city[status]">
                                          <option value="1">Active</option>
                                          <option value="2">Inactive</option>
                                       </select>
                                    </div>
                                    </div>
                                </div>
                                <!-- <div class="row">
                                    <div class="col-12">
                                        <h5 class="card-header" style="padding-left: 1px;">User Credential
                                        </h5>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="col-form-label-lg control-label" for="largeInput">UDF 1</label>
                                                    <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text" id="basic-icon-addon1"><i class="icon dripicons-view-thumb"></i></span>
                                                        </div>
                                                        <div class="invalid-feedback">
                                                            Please choose a Udf.
                                                        </div>
                                                        <input type="text" class="form-control" placeholder="Enter UDF 1" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="city[udf_1]" value="<?php echo $city_data[0]['udf_1']; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="col-form-label-lg control-label" for="largeInput">UDF 2</label>
                                                    <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text" id="basic-icon-addon1"><i class="icon dripicons-view-thumb"></i></span>
                                                        </div>
                                                        <div class="invalid-feedback">
                                                            Please choose a Udf.
                                                        </div>
                                                        <input type="text" class="form-control" placeholder="Enter UDF 2" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="city[udf_2]" value="<?php echo $city_data[0]['udf_2']; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="col-form-label-lg control-label" for="largeInput">UDF 3</label>
                                                    <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text" id="basic-icon-addon1"><i class="icon dripicons-view-thumb"></i></span>
                                                        </div>
                                                        <div class="invalid-feedback">
                                                            Please choose a Udf.
                                                        </div>
                                                        <input type="text" class="form-control" placeholder="Enter UDF 3" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="city[udf_3]" value="<?php echo $city_data[0]['udf_3']; ?>">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div> -->


                        </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success  submit">Update</button>
         </div>
         </form>  
      </div>
   </div>
</div>


<script type="text/javascript">

   function edit_city(val,val2,val3,val4,val5,val6){ //City_id , Country_id , State_id , city_name
      // alert(val);
      $('.city_ids').val(val);
      $('.country_id_old').val(val2);    
      $('.state_id_old').val(val3);
      $('.district_id_old').val(val6);
      $('.city_name').val(val4); 
       $('.alis_name').val(val5);    
      // $('.status').val(val2);
      
   
   }
  
   function delete_coutry(val,val1){
   	$('.delete_id').val(val);
   	$('.table_name').val(val1);
   	//alert($('.delete_id').val(val));
   }

      function check_city_name(){
     // To Check the State Name
      var check_data = $('.check_data').val();
      var result = '';
         $.ajax({
           type: "POST",
           url: "<?php echo base_url(); ?>master/location/duplicate_check",
           data: {data: check_data,table_name: 'mpro_cities',colum: 'city_name'},
           cache: true,
           async: false,
           success: function(data){
            // alert(data);
            result = data;
           }
         });
         if(result == 1){
            $('.duplicate-occur').removeClass('no-display');
            $("button[type=submit]").attr("disabled", "disabled");
            // return false;
        }
        if(result == 0){
            $('.duplicate-occur').addClass('no-display');
            $("button[type=submit]").removeAttr("disabled");
            // return true;
        } 
   }
</script>



<script type="text/javascript">

   // To check all the boxes

$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
});

// To pass the value to the Controller

   $(document).ready(function() {
        $("#del_all").click(function(){
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function(){            
                favorite.push($(this).val());
            });
            //alert("Selected Countries are: " + favorite.join(","));
             $.ajax({
                        url: '<?php echo base_url() ?>master/Location/delete_checkbox_cities',
                        type: 'post',
                        data: {id:favorite.join(",")},
                    }).done(function(data) {
                     
                       location.reload();



                    });
        });
    });

    $(document).ready(function() {
        $("#active_all").click(function(){
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function(){            
                favorite.push($(this).val());
            });
            //alert("Selected Countries are: " + favorite.join(","));
             $.ajax({
                        url: '<?php echo base_url() ?>master/Location/active_all_checkbox_cities',
                        type: 'post',
                        data: {id:favorite.join(",")},
                    }).done(function(data) {
                       location.reload();



                    });
        });
    });

     $(document).ready(function() {
        $("#deactive_all").click(function(){
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function(){            
                favorite.push($(this).val());
            });
            //alert("Selected Countries are: " + favorite.join(","));
             $.ajax({
                        url: '<?php echo base_url() ?>master/Location/deactivate_all_checkbox_cities',
                        type: 'post',
                        data: {id:favorite.join(",")},
                    }).done(function(data) {
                       location.reload();



                    });
        });
    });


$('.delbtn').prop('disabled', true);

$('.checkbox').change(function(){
    $('.delbtn').prop('disabled', $('.checkbox:checked').length == 0);
})


$('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;

            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
                
            });
        }
    });
$('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
             $('.region_input1').addClass('no-display');
             $('.region_input').removeClass('no-display');
        }else{
            $('#select_all').prop('checked',false);
             $('.region_input1').removeClass('no-display');
             $('.region_input').addClass('no-display');
        }
    });
$('.boxischecked').on('click',function(){

     if ($(this).prop('checked') == true) {
                $('.region_input1').addClass('no-display');
                $('.region_input').removeClass('no-display');
            } else {
                $('.region_input1').removeClass('no-display');
                $('.region_input').addClass('no-display');
            }

            
            checked_checkbox = Number($('input[type=checkbox].boxischecked:checked').length);
            // alert(checked_checkbox);
            if (checked_checkbox!=0) {
                $('.region_input1').addClass('no-display');
                $('.region_input').removeClass('no-display');
            } else {
                $('.region_input1').removeClass('no-display');
                $('.region_input').addClass('no-display');
            }


  });


$('.multi_export').click(function(){

             var favorite = [];
             $.each($("input[name='checkbox']:checked"), function(){            
                 favorite.push($(this).val());
             });

    window.location = "<?php echo base_url();?>export/multi_export_cities?url="+favorite;

});
    
    $('.export_link').click(function(){
            // alert();
             window.location ="<?php echo base_url();?>export/export_cities";
});
</script>

