<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Upload_model extends CI_Model {

	    public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
                $this->load->library('image_lib');
        }

	public function company_logo_upload_file() {			

		         $config['upload_path']          = './attachments/company_logo/';
                 $config['allowed_types']        = 'gif|jpg|png';
		         $config['max_size']      		 = 10000; 
		         // $config['max_width']     		 = 1024; 
		         // $config['max_height']    		 = 768;  

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('CompanyLogo'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $file_name = '';
                        //print_r($error);
                        //die();
                        return $file_name;  

                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
		         		$file_name =   $upload_data['file_name'];
		         		
		         		$configer =  array(
			              'image_library'   => 'gd2',
			              'source_image'    =>  $upload_data['full_path'],
			              'maintain_ratio'  =>  TRUE,
			              'width'           =>  150,
			              'height'          =>  150,
			            );
			            $this->image_lib->clear();
			            $this->image_lib->initialize($configer);
			            $this->image_lib->resize();
                        return $file_name;
                }

    }

  public function member_logo_upload_file() {      

             $config['upload_path']          = './attachments/Members/';
             $config['allowed_types']        = 'gif|jpg|png';
             $config['max_size']           = 10000; 
             // $config['max_width']         = 1024; 
             // $config['max_height']        = 768;  

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('CompanyLogo'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $file_name = '';
                        //print_r($error);
                        //die();
                        return $file_name;  

                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                $file_name =   $upload_data['file_name'];
                
                $configer =  array(
                    'image_library'   => 'gd2',
                    'source_image'    =>  $upload_data['full_path'],
                    'maintain_ratio'  =>  TRUE,
                    'width'           =>  150,
                    'height'          =>  150,
                  );
                  $this->image_lib->clear();
                  $this->image_lib->initialize($configer);
                  $this->image_lib->resize();
                        return $file_name;
                }

    }

    public function replace_image()
    {        
        $old_file_name = $this->input->post('old_file_name');  
        @chmod(FCPATH . "attachments/company_logo/".$old_file_name, 0777); 
        unlink(FCPATH . "attachments/company_logo/".$old_file_name);
        $file_name = $this->Upload_model->company_logo_upload_file();
        return $file_name;       
    }


    // Users Upload Module
    public function users_image_upload_file() {            

                 $config['upload_path']          = './attachments/users_image/';
                 $config['allowed_types']        = 'gif|jpg|png';
                 $config['max_size']             = 10000; 
                 $config['max_width']            = 1024; 
                 $config['max_height']           = 768;  

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('profile_image'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $file_name = '';
                        return $file_name;                        
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];
                        
                        $configer =  array(
                          'image_library'   => 'gd2',
                          'source_image'    =>  $upload_data['full_path'],
                          'maintain_ratio'  =>  TRUE,
                          'width'           =>  150,
                          'height'          =>  150,
                        );
                        $this->image_lib->clear();
                        $this->image_lib->initialize($configer);
                        $this->image_lib->resize();
                        return $file_name;
                }

    }

    public function users_replace_image()
    {        
        $old_file_name = $this->input->post('old_file_name');   
        unlink(FCPATH . "attachments/users_image/".$old_file_name);
        $file_name = $this->Upload_model->users_image_upload_file();
        return $file_name;       
    }


    // Product Upload Image

    public function product_image_upload_file() {            

                 $config['upload_path']          = './attachments/Products_image/';
                 $config['allowed_types']        = 'gif|jpg|png|jpeg|gif';
                 $config['max_size']             = 1000000; 
                 // $config['max_width']            = 1024; 
                 // $config['max_height']           = 768;  

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('Product_image'))
                {
                         $error = array('error' => $this->upload->display_errors());
                        $file_name = '';
                        return $file_name;                     
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];
                        
                        $configer =  array(
                          'image_library'   => 'gd2',
                          'source_image'    =>  $upload_data['full_path'],
                          'maintain_ratio'  =>  TRUE,
                          'width'           =>  150,
                          'height'          =>  150,
                        );
                        $this->image_lib->clear();
                        $this->image_lib->initialize($configer);
                        $this->image_lib->resize();
                        return $file_name;
                }

    }

    public function product_replace_image()
    {        

        $old_file_name = $this->input->post('old_file_name');   
        if($old_file_name != ''){
          unlink(FCPATH . "attachments/Products_image/".$old_file_name);
          $file_name = $this->Upload_model->product_image_upload_file();
        }else{
          $file_name = $this->Upload_model->product_image_upload_file();
        }
        return $file_name;       
    }

    // Customer Attachment

        public function customer_attachment($dir) { 

                  // create an album if not already exist in uploads dir
                  // wouldn't make more sence if this part is done if there are no errors and right before the upload ??
                  if (!is_dir('./attachments/customer/' .$dir))
                  {
                      mkdir('./attachments/customer/' .$dir, 0777, true);
                  }
                  $dir_exist = true; // flag for checking the directory exist or not
                  if (!is_dir('./attachments/customer/' .$dir))
                  {
                      mkdir('./attachments/customer/' .$dir, 0777, true);
                      $dir_exist = false; // dir not exist
                  }
                      
                 $config['upload_path']          = './attachments/customer/'.$dir.'/';
                 $config['allowed_types']        = 'gif|jpg|png|doc|pdf|docx';
                 $config['max_size']             = 10000; 

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('Attatchments'))
                {
                         $error = array('error' => $this->upload->display_errors());
                          $file_name = '';
                          return $error;                     
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];
                        
                        return $file_name;
                }
        }        

    public function customer_attachment_replace($dir)
    {        
        $old_file_name = $this->input->post('old_attachment');   
        unlink(FCPATH . './attachments/customer/' .$dir.'/'.$old_file_name);
        $file_name = $this->Upload_model->customer_attachment($dir);
        return $file_name;       
    }                


    // Customer Attachment

        public function member_profile_attachment($dir) { 

                  // create an album if not already exist in uploads dir
                  // wouldn't make more sence if this part is done if there are no errors and right before the upload ??
                  
                  if (!is_dir('./attachments/Members/' .$dir))
                  {
                      mkdir('./attachments/Members/' .$dir, 0777, true);
                  }
                  $dir_exist = true; // flag for checking the directory exist or not
                  if (!is_dir('./attachments/Members/' .$dir))
                  {
                      mkdir('./attachments/Members/' .$dir, 0777, true);
                      $dir_exist = false; // dir not exist
                  }
                      
                 $config['upload_path']          = './attachments/Members/'.$dir.'/';
                 $config['allowed_types']        = 'gif|jpg|png|doc|pdf|docx';
                 $config['max_size']             = 10000; 
                 $new_name                       = $dir.'_Profile';
                 $config['file_name']            = $new_name;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('Photo'))
                {
                         $error = array('error' => $this->upload->display_errors());
                          $file_name = '';
                          return $error;                     
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];
                        
                        return $file_name;
                }
        }        

    public function vendor_attachment_replace($dir)
    {        
        $old_file_name = $this->input->post('old_attachment');   
        unlink(FCPATH . './attachments/vendor/' .$dir.'/'.$old_file_name);
        $file_name = $this->Upload_model->customer_attachment($dir);
        return $file_name;       
    }     

    // Excel Upload File

    public function Upload_excel($directory)
    {
                 $config['upload_path']          = './attachments/'.$directory.'/';
                 $config['allowed_types']        = 'xlsx|xls|pdf|docx';
                 $config['max_size']             = 10000; 

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('upload_files'))
                {
                         $error = array('error' => $this->upload->display_errors());
                          $file_name = '';
                          return $error;                     
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];                        
                        return $file_name;
                }
    }


}

/* End of file Upload_model.php */
/* Location: ./application/models/Upload_model.php */