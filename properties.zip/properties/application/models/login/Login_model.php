<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

    public function validate($password,$username) {

        $this->db->select('*');
        $this->db->from('prop_users');
        $this->db->where('username', $username);
        $this->db->where('password', $password);
        $this->db->where('status', 1);
        $query = $this->db->get();
        return $query->row();
    }

    public function session($password,$username) {

        $this->db->select('*');
        $this->db->from('prop_users');
        $this->db->where('username', $username);
        $this->db->where('password', $password);
        $this->db->where('status', 1);
        $query = $this->db->get();
        return $query->row_array();
    }

}
