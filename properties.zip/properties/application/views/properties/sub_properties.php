<script>
   <?php
         if ($this->session->flashdata('sub_properties_success')) 
         {
            echo "var data = ' ".$this->session->flashdata('sub_properties_success')."';";
            echo "success(data);";
         }
   ?>
</script>
<div class="content-wrapper">
   <div class="content">
      <header class="page-header">
         <div class="d-flex align-items-center">
            <div class="mr-auto">
               <h1 class="separator">Sub Properties</h1>
               <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i></a></li>
                     <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard">Master</a></li>
                     <li class="breadcrumb-item active" aria-current="page">Sub Properties</li>
                  </ol>
               </nav>
            </div>
            <ul class="actions top-right">
               <li class="dropdown">
                  <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                  <i class="la la-ellipsis-h"></i>
                  </a>
                  <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
                     <div class="dropdown-header">
                        Quick Actions
                     </div>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-clockwise"></i> Refresh
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-gear"></i> Manage Widgets
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-cloud-download"></i> Export
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-help"></i> Support
                     </a>
                  </div>
               </li>
            </ul>
         </div>
      </header>


      <section class="page-content container-fluid">
         <div class="row">
            <div class="col-12">              
               <div class="card">
                  <h5 class="card-header">
                     <div style="float: left;">
                        Manage Sub Properties   
                     </div>
                     <div style="float: right;">
                         <a href="<?php echo base_url(); ?>properties/Properties/sub_add">
                        <button type="button" class="btn btn-success  btn-floating " data-toggle="tooltip" data-placement="top" data-original-title="Add new Sub Properties">
                        Add New Sub Properties 
                        </button>
                        </a>
                   
                     </div>
                  </h5>
                  <div class="card-body">
                     <div> 
                     <table id="bs4-table" class="table table-striped table-bordered table table-responsive" style="width:100%" >
                        <thead>
                           <tr>
                              <th style="width: 2%">S.No</th>
                              <?php // $sectionpermission=$this->session->userdata('section_permission');
                              //if (!empty($sectionpermission)) {
                                 // foreach ($sectionpermission as $section_list) {
                                    //if($section_list['section_id']=="2" &&($section_list['acc_view']=="1" || $section_list['acc_edit']=="1" || $section_list['acc_delete']=="1")){?>
                              <th style="width: 30%">Action</th><?php //} } }?>
                              <th style="width: 21%">Company</th>
                              <th style="width: 15%">Property</th>
                              <th style="width: 10%">Location </th>
                              <th style="width: 17%">Total Square feet</th>
                              <!-- <th>GSTIN</th> -->
                              <!-- <th>Website</th> -->
                              <th style="width: 5%">Status</th>                             
                              
                           </tr>
                        </thead>
                        <tbody>
                           <?php 
                              if (!empty($properties)) {
                                  $s = 1;
                                  foreach ($properties as $list) {
                                      ?>
                           <tr>
                              <td ><?php echo $s; ?></td>
                              
                              <td class="text-center"> 
                                <!--  <a href="#" id="viewtenant" onclick="view_tenant('<?php echo ucfirst($list['sub_property_id']); ?>','<?php echo ucfirst($list['tenant_name']); ?>','<?php echo ucfirst($list['email']); ?>','<?php echo ucfirst($list['mobile_number']); ?>','<?php echo ucfirst($list['phone_number']); ?>','<?php echo ucfirst($list['contact_person']); ?>','<?php echo ucfirst($list['address1'])."<br>".$list['address2']."<br>".$list['zip_code']; ?>','<?php echo ucfirst($list['country_name']); ?>','<?php echo ucfirst($list['state_name']); ?>','<?php echo ucfirst($list['city_name']); ?>','<?php echo ucfirst($list['tax_no1']); ?>','<?php echo ucfirst($list['tax_no2']); ?>','<?php echo ucfirst($list['website_link']); ?>','<?php echo $list['tenant_group']; ?>')" class="btn btn-primary btn-sm " data-toggle="modal" data-target=".viewtenant" ><i class="la la-eye" data-toggle="tooltip" data-placement="top" data-original-title="View"  style="color:  white;"></i></a> -->

                                 <a href="<?php echo base_url(); ?>properties/Properties/sub_edit?id=<?php echo encrypt($list['sub_property_id']); ?>" id="usertypeedit" class="btn btn-info btn-sm "><i class="zmdi zmdi-edit zmdi-hc-fw" style="color:  white; " data-toggle="tooltip" data-placement="top" data-original-title="Edit"></i></a>
                                 <?php if ($list['delete_status'] == 1) { ?> 

                                     <div class="btn btn-accent btn-sm">
                                     <i class="zmdi zmdi-delete zmdi-hc-fw" style="font-size: 17px;color:  white;" ></i>
                                     </div>  

                                 <?php }else{ ?>      

                                 <a href="" onclick="delete_tenant('<?php echo ucfirst($list['sub_property_id']); ?>','<?php echo ucfirst($teble_name); ?>')" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deletemodel" ><i class="zmdi zmdi-delete zmdi-hc-fw" style="color:  white;" data-toggle="tooltip" data-placement="top" data-original-title="Delete"></i></a>  
                                 <?php } ?>
                                 
                              </td>
                              <td class="s_no"><?php echo ucfirst($list['company_name']); ?></td>
                              <td class="s_no"><?php echo ucfirst($list['properties_name']); ?></td>
                              <td class="s_no"><?php echo ucfirst($list['location']); ?></td>
                              <td class="s_no"><?php echo ucfirst($list['total_sqm']); ?></td>
                              
                              
                              <td><span class="badge badge-<?php echo ($list['status'] == 1) ? 'success' : 'danger'; ?>"><?php echo ($list['status'] == 1) ? 'Active' : 'In-Active'; ?></span></td>
                              
                           </tr>
                           <?php
                              $s++;
                              }
                              }
                              ?>
                        </tbody>
                     </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   </div>
</div>
</div>  
<!-- Model Execution -->
<!-- LOCATION RIGHT SIDE -->
<div id="addusertype" class="modal modal-right-side fade" data-backdrop="static" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content" style="width: 506px;">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel6">Tenant</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <div class="modal-body">
            <div class="row">
               <div class="col">
                  <div class="card">
                     <h5 class="card-header">Add Tenant</h5>
                     <?php
                        $attributes = array('id' => 'login_form','data-toggle' => 'validator');
                        echo form_open('properties/Properties/tenant__add', $attributes);
                        ?> 
                     <div class="card-body">
                        <div class="form-body">
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="form-">
                                    <label class="col-form-label-lg control-label" for="largeInput">Company Name <span style="color:red">*</span></label>
                                    <input type="text" class="form-control" autofocus name="Company[tenant__name]" id="inputName" placeholder="Company  Name" required>
                                    <div class="invalid-feedback">
                                       Please choose a username.
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-">
                                    <label class="col-form-label-lg" for="largeInput">Status</label>
                                    <select class="form-control" name="Company[status]" id="defaultSelect" required="">
                                       <option value="1">Active</option>
                                       <option value="2">In-Active</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                                   <div class="form-">
                                       <label for="exampleFormControlTextarea1">Description</label>
                                       <textarea class="form-control" id="exampleFormControlTextarea1" name="Company[description]" rows="3"></textarea>
                                    </div>
                                                </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success  submit">Save changes</button>
         </div>
         </form>
      </div>
   </div>
</div>
<!-- Editing -->
<!-- LOCATION RIGHT SIDE -->



<!-- Start View Company Modal -->
         <div class="modal fade viewcompany" data-backdrop="static" tabindex="-1" role="dialog" aria-hidden="true">
         <div class="modal-dialog modal-lg">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title text-danger" id="ModalTitle2">View Company</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true" class="zmdi zmdi-close"></span>
                  </button>
               </div>
              <form action="#" method="POST">
               <div class="modal-body">
                  <div class="row" >
                                   
                                    <div class="col-md-4"></div>
                                    <div class="col-md-4" >
                                       <center>
                                        <a href="javascript:void(0);"><img id="imagePreview" src="<?php echo base_url(); ?>attachments/users_image/default_profile_image.png" style="width: 150px; height: 150px; border: 2px #ccc solid;margin-top:0px;margin-left:55px; " alt="User profile picture" default_src="<?php echo base_url(); ?>attachments/users_image/default_profile_image.png"></a>
                                        </center>
                                    </div>
                                    <div class="col-md-4"></div>

                                 </div>
                     <div class="card">
                     <div class="col-md-12">
                                 <div class="row" style="margin-top: 20px;">
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Company Id</label>
                                       </div>
                                       <div class="col-1">
                                           <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                           <label for="field-1" class="control-label tenant_code" id="label-tenant_code"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Company Name</label>
                                       </div>
                                       <div class="col-1">
                                            <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                          <label for="field-1" class="control-label tenant_name" id="label-tenant_name"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Email</label>
                                       </div>
                                       <div class="col-1">
                                          <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">                                          
                                       <label for="field-1" class="control-label email" id="label-email"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Mobile</label>
                                       </div>
                                       <div class="col-1">
                                           <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                           <label for="field-1" class="control-label mobile" id="label-mobile"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Phone</label>
                                       </div>
                                       <div class="col-1">
                                            <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                          <label for="field-1" class="control-label phone" id="label-phone"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Contact Person</label>
                                       </div>
                                       <div class="col-1">
                                            <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                          <label for="field-1" class="control-label contact_person" id="label-contact_person"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Address</label>
                                       </div>
                                       <div class="col-1">
                                            <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                          <label for="field-1" class="control-label address" id="label-address"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Country</label>
                                       </div>
                                       <div class="col-1">
                                            <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                          <label for="field-1" class="control-label country" id="label-country"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">State</label>
                                       </div>
                                       <div class="col-1">
                                            <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                          <label for="field-1" class="control-label state" id="label-state"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">City</label>
                                       </div>
                                       <div class="col-1">
                                            <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                          <label for="field-1" class="control-label city" id="label-city"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>


                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Tax No 1</label>
                                       </div>
                                       <div class="col-1">
                                            <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                          <label for="field-1" class="control-label tax_no1" id="label-tax_no1"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">GST No</label>
                                       </div>
                                       <div class="col-1">
                                            <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                          <label for="field-1" class="control-label tax_no2" id="label-tax_no2"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <div class="form-group">
                                           <div class="form-row">
                                       <div class="col-4">
                                         <label for="field-1" class="control-label text-danger">Website</label>
                                       </div>
                                       <div class="col-1">
                                            <label for="field-1" class="control-label">:</label>
                                       </div>
                                       <div class="col-7">
                                          <label for="field-1" class="control-label website" id="label-website"></label>
                                       </div>
                                    </div>
                                        </div>
                                    </div>


                                 </div> 
                     </div>
                     </div>            
                                   
               </div>
               <div class="modal-footer">
            
              <div class="form-group">
               <button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
               
              </div>  
         </div>
            </form>
            </div>
         </div>
      </div>
<!-- End View Company Modal -->
<!-- BASIC MODAL DEMO -->
<div class="modal fade" id="deletemodel" tabindex="-1" role="dialog"  aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel9">Delete</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="zmdi zmdi-close"></span>
            </button>
         </div>
         <form action="<?php echo base_url();?>properties/Properties/delete" method="POST">
            <div class="modal-body">
               <div class="swal2-header">
                  <ul class="swal2-progresssteps" style="display: none;"></ul>
                  <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span></div>
                  <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                  <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                  <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                  <div class="swal2-icon swal2-success" style="display: none;">
                     <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                     <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                     <div class="swal2-success-ring"></div>
                     <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                     <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                  </div>
                  <img class="swal2-image" style="display: none;">
                  <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                  <button type="button" class="swal2-close" style="display: none;">×</button>
               </div>
               <!-- Hiiden Values -->
               <input type="hidden" name="url" value="Tenant">
               <input class="delete_id" type="hidden" name="sub_property_id">
               <input class="table_name" type="hidden" name="table_name">           
            </div>
            <div class="delete-footer">
               <button type="submit" class="btn btn-primary">Yes, delete it!</button>
               <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>           
            </div>
         </form>
      </div>
   </div>
</div>
<script type="text/javascript">
   function edit_tenant(val,val1,val2,val3){
    $('.sub_property_id').val(val);
    $('.tenant_name').val(val1);    
      $('.status').val(val2);
    $('.description').val(val3);
   
   }
   
   function delete_tenant(val,val1){
    $('.delete_id').val(val);
    $('.table_name').val(val1);
    //alert($('.delete_id').val(val));
   }

   function view_tenant(val,val1,val2,val3,val4,val5,val6,val7,val8,val9,val10,val11,val12,val13,val14){
      var base_url = window.location.origin+'/'+window.location.pathname.split("/")[1];
      // alert(val13);
      // if(val13 != ''){
      //    $('#imagePreview').attr('src', base_url+'/attachments/tenant_logo/'+val13);           
      // }
      $('#label-tenant_code').text(val);
      $('#label-tenant_name').text(val1);     
      $('#label-email').text(val2);
      $('#label-mobile').text(val3);
      $('#label-phone').text(val4);
      $('#label-contact_person').text(val5);
      $('#label-address').text(val6);
      $('#label-country').text(val7);
      $('#label-state').text(val8);
      $('#label-city').text(val9);
      // if(val10==1){gst="GST Registered-Regular";}else if(val10==2){gst="GST Registered-Composite";}else if(val10==3){gst="GST Unregistered";}else if(val10==4){gst="Consumer";}
      $('#label-tax_no1').text(val10);
      $('#label-tax_no2').text(val11);
      $('#label-website').text(val12);
      // alert(val13);
      // $('#imagePreview').attr('src','asc');

      
   }
</script>