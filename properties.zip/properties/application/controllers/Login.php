<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Login extends CI_Controller {

  public function __construct() {

    parent::__construct();
    $this->load->model('login/Login_model');
    $this->load->model('master/Users_model');
    date_default_timezone_set("Asia/Kolkata");
  }

  public function index()
  {
    $this->load->view('login');
  }

  public function validate() {

    $username = $this->input->post('username');
    $password = md5($this->input->post('password'));
    $validate = $this->Login_model->validate($password,$username);

    if (empty($validate)) {

      $temp['value']        =  1;
      header('Content-Type: application/json');
      echo json_encode($temp);

      $login_error['username']    = $username;
      $login_error['password']    = $this->input->post('password');
      $login_error['user_ip']     = $_SERVER['REMOTE_ADDR'];
      $login_error['date']        = date('Y-m-d h:i:s');
      $user_agent                 = $_SERVER['HTTP_USER_AGENT']; 

      if (preg_match('/MSIE/i', $user_agent)) { 
        $login_error['user_browser']= "Internet Explorer";
      }elseif (preg_match('/Firefox/i', $user_agent)){ 
        $login_error['user_browser']= "FireFox";
      }elseif (strpos( $user_agent, 'Chrome') !== false){
        $login_error['user_browser']= "Google Chrome";
      }elseif (preg_match('/Opera/i', $user_agent)) { 
        $login_error['user_browser']= "Opera";
      }else{
        $login_error['user_browser']= "Not Saved";
      }

      $this->db->insert('prop_login_attempt', $login_error);


    } else {

      if ($this->db->count_all_results('prop_lease')<51) {

        $session_data   =  $this->Login_model->session($password,$username);

        $data_session = array(
          'id'           => $session_data['user_id'],
          'name'         => $session_data['username'],
          'address'      => $session_data['address1'].','.$session_data['address2'],
          'email'        => $session_data['email'],
          'user_type_id' => $session_data['user_type_id'],
          'mobile'       => $session_data['mobile'],
          'profile'      => $session_data['profile'],
          'company_id'   => 1,
          'is_logged_in' => true);
        ;
        $this->session->set_userdata($data_session);
        $this->session->set_flashdata('success', 'Login');

        $login_history['user_id']       = $session_data['user_id'];
        $login_history['user_name']     = $session_data['username'];
        $login_history['user_type_id']  = $session_data['user_type_id'];
        $login_history['company_id']    = 1;
        $login_history['branch_id']     = 1;
        $login_history['date_time']     = date('Y-m-d h:i:s');
        $login_history['user_ip']       = $_SERVER['REMOTE_ADDR'];
        $user_agent                     = $_SERVER['HTTP_USER_AGENT']; 

      if (preg_match('/MSIE/i', $user_agent)) { 
        $login_history['user_browser']= "Internet Explorer";
      }elseif (preg_match('/Firefox/i', $user_agent)){ 
        $login_history['user_browser']= "FireFox";
      }elseif (strpos( $user_agent, 'Chrome') !== false){
        $login_history['user_browser']= "Google Chrome";
      }elseif (preg_match('/Opera/i', $user_agent)) { 
        $login_history['user_browser']= "Opera";
      }else{
        $login_history['user_browser']= "Not Saved";
      }
        $login_history['login_logout']  = 'login'; 
        $this->db->insert('prop_login_history_table', $login_history);

        $temp['value']        =  "dashboard";
        header('Content-Type: application/json');
        echo json_encode($temp);
      }else{
      $temp['value']        =  2;
      header('Content-Type: application/json');
      echo json_encode($temp);
    }
    }
  }


  public function logout() {

    $login_history['user_id']       = $this->session->userdata('id');
    $login_history['user_name']     = $this->session->userdata('name');
    $login_history['user_type_id']  = $this->session->userdata('user_type_id');
    $login_history['company_id']    = 1;
    $login_history['branch_id']     = 1;
    $login_history['date_time']     = date('Y-m-d h:i:s');
    $login_history['user_ip']       = $_SERVER['REMOTE_ADDR'];
    $login_history['user_browser']  = $_SERVER['HTTP_USER_AGENT']; 
    $login_history['login_logout']  = 'logout'; 
    $this->db->insert('prop_login_history_table', $login_history);

    session_destroy();
    redirect('login');
  }

  public function change_password() {

    $id = $this->session->userdata('id');

    $this->db->select("password");
    $this->db->from("prop_users"); 
    $this->db->where("user_id=$id");
    $result = $this->db->get()->row();

    $oldpassword = $result->password;
    $pwsd = $this->input->post('n_password');
    $get_password = md5($this->input->post('password'));

    if ($oldpassword !== $get_password) {

      $value="1";
      echo json_encode($value);

    } else {

      $user_update = array('password'     => md5($this->input->post('n_password')), 
       'og_password'  => $this->input->post('n_password'));

      $this->db->where('user_id', $this->session->userdata('id'));
      $this->db->update('prop_users', $user_update);

      $value=base_url()."dashboard";
      echo json_encode($value);
    }

  }

  public function up($pre_name='hi')
  {  
   $this->load->dbforge();


   $this->dbforge->add_field(

    array(
      'id' => array(
        'type' => 'INT',
        'constraint' => 10,
        'unsigned' => TRUE,
        'auto_increment' => TRUE
      ),
      'username' => array(
        'type' => 'VARCHAR',
        'constraint' => '500',
      ),
      'password' => array(
        'type' => 'VARCHAR',
        'constraint' => '500',
      ),
      'user_ip' => array(
        'type' => 'VARCHAR',
        'constraint' => '500',
      ),
      'user_browser' => array(
        'type' => 'VARCHAR',
        'constraint' => '200',
      ),
      'date' => array(
        'type' => 'DATETIME',
      ),

    ));

   $this->dbforge->add_key('id', TRUE);  
   $this->dbforge->create_table($pre_name.'_login_attempt');

$fields = array(
        'preferences' => array('type' => 'TEXT')
);
$this->dbforge->add_column('table_name', $fields);

   $this->dbforge->add_field(

    array(
      'login_history_id' => array(
        'type' => 'INT',
        'constraint' => 11,
        'unsigned' => TRUE,
        'auto_increment' => TRUE
      ),
      'user_id' => array(
        'type' => 'INT',
        'constraint' => 11,
        'unsigned' => TRUE
      ),
      'user_type_id' => array(
        'type' => 'INT',
        'constraint' => 11,
        'unsigned' => TRUE
      ),
      'company_id' => array(
        'type' => 'INT',
        'constraint' => 11,
      ),
      'branch_id' => array(
        'type' => 'INT',
        'constraint' => 11,
      ),
      'user_name' => array(
        'type' => 'VARCHAR',
        'constraint' => '100',
      ),
      'date_time' => array(
        'type' => 'DATETIME',
      ),
      'user_browser' => array(
        'type' => 'VARCHAR',
        'constraint' => '50',
      ),
      'user_ip' => array(
        'type' => 'VARCHAR',
        'constraint' => '50',
      ),
      'login_logout' => array(
        'type' => 'VARCHAR',
        'constraint' => '50',
      ),
    ));

   $this->dbforge->add_key('login_history_id', TRUE);  
   $this->dbforge->create_table($pre_name.'_login_history');



   $this->dbforge->add_field(

    array(
      'user_type_id' => array(
        'type' => 'INT',
        'constraint' => 10,
        'unsigned' => TRUE,
        'auto_increment' => TRUE
      ),
      'user_type_name' => array(
        'type' => 'VARCHAR',
        'constraint' => '100',
      ),
      'user_mode' => array(
        'type' => 'TINYINT',
        'constraint' => '1',
      ),
      'description' => array(
        'type' => 'VARCHAR',
        'constraint' => '500',
      ),
      'status' => array(
        'type' => 'TINYINT',
        'constraint' => '1',
      ),
      'created_date' => array(
        'type' => 'DATETIME',
      ),
      'created_by' => array(
        'type' => 'TINYINT',
        'constraint' => '1',
      ),
      'updated_date' => array(
        'type' => 'DATETIME',
      ),
      'updated_by' => array(
        'type' => 'TINYINT',
        'constraint' => '1',
      ),
      'deleted_date' => array(
        'type' => 'DATETIME',
      ),
      'deleted_by' => array(
        'type' => 'TINYINT',
        'constraint' => '1',
      ),
    ));

   $this->dbforge->add_key('user_type_id', TRUE);  
   $this->dbforge->create_table($pre_name.'_user_type');



   $this->dbforge->add_field(

    array(
      'user_id' => array(
        'type' => 'INT',
        'constraint' => 10,
        'unsigned' => TRUE,
        'auto_increment' => TRUE
      ),
      'user_type_id' => array(
        'type' => 'INT',
        'constraint' => 10,
        'unsigned' => TRUE
      ),
      'firstname' => array(
        'type' => 'VARCHAR',
        'constraint' => '100',
      ),
      'username' => array(
        'type' => 'VARCHAR',
        'constraint' => '100',
      ),
      'password' => array(
        'type' => 'VARCHAR',
        'constraint' => '100',
      ),
      'og_password' => array(
        'type' => 'VARCHAR',
        'constraint' => '100',
      ),
      'dob' => array(
        'type' => 'VARCHAR',
        'constraint' => '30',
      ),
      'email' => array(
        'type' => 'VARCHAR',
        'constraint' => '100',
      ),
      'phone' => array(
        'type' => 'VARCHAR',
        'constraint' => '30',
      ),
      'mobile' => array(
        'type' => 'VARCHAR',
        'constraint' => '20',
      ),
      'street' => array(
        'type' => 'VARCHAR',
        'constraint' => '150',
      ),
      'address' => array(
        'type' => 'VARCHAR',
        'constraint' => '150',
      ),
      'city_id' => array(
        'type' => 'INT',
        'constraint' => '11',
      ),
      'state_id' => array(
        'type' => 'INT',
        'constraint' => '11',
      ),
      'country_id' => array(
        'type' => 'INT',
        'constraint' => '11',
      ),
      'pincode' => array(
        'type' => 'VARCHAR',
        'constraint' => '15',
      ),
      'user_mode' => array(
        'type' => 'TINYINT',
        'constraint' => '1',
      ),
      'profile' => array(
        'type' => 'VARCHAR',
        'constraint' => '150',
      ),
      'status' => array(
        'type' => 'TINYINT',
        'constraint' => '1',
      ),
      'created_date' => array(
        'type' => 'DATETIME',
      ),
      'created_by' => array(
        'type' => 'TINYINT',
        'constraint' => '1',
      ),
      'updated_date' => array(
        'type' => 'DATETIME',
      ),
      'updated_by' => array(
        'type' => 'TINYINT',
        'constraint' => '1',
      ),
      'deleted_date' => array(
        'type' => 'DATETIME',
      ),
      'deleted_by' => array(
        'type' => 'TINYINT',
        'constraint' => '1',
      ),
    ));

   $this->dbforge->add_key('user_id', TRUE);  
   $this->dbforge->create_table($pre_name.'_user');


 }


}
