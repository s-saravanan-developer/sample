<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Membership_model extends CI_Model { 

    function getall_bank() {

        $this->db->select('*');
        $this->db->where('Status',1);
        $this->db->order_by("Bank_name", "ASC");
        $query = $this->db->get('gc_bank');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function getall_bank_to() {

        $this->db->select('*');
        $this->db->where('Status',1);
        $this->db->where('Mode',2);
        $this->db->order_by("Bank_name", "ASC");
        $query = $this->db->get('gc_bank');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function getall_payouts_franchasie() {
        $this->db->select('*');
        $this->db->where('Status',1);
        $this->db->where('Level_type_id',1);
        $query = $this->db->get('gc_payout_type');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return 0;
    }

   function get_user_details($id) {

        $this->db->select('*');
        $this->db->where('Membership_ID', $id);
        $query = $this->db->get('gc_membership');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
    function get_member_detailbyid($id) {

        $this->db->select('gc_membership.Membership_ID');
        $where = '(Membership_code="'.$id.'" or Mobile = "'.$id.'")';
        $this->db->where($where);
        $query = $this->db->get('gc_membership');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

function get_referer_by_id($referer) {

        $this->db->select('Membership_ID,First_name,Last_name,Membership_code');
        $this->db->where('Membership_ID',$referer);
        $query = $this->db->get('gc_membership');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
function get_memcode_detail($id) {

        $this->db->select('gc_membership.Membership_Code');
        $this->db->where('Membership_ID',$id);
        $query = $this->db->get('gc_membership');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


function gettotal_investment($id) {

        $this->db->select('sum(Amount) as Amount');
        $this->db->where('Membership_ID',$id);
        $query = $this->db->get('gc_member_franchisee_contract');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

function get_self_investment($id) {

        $this->db->select('sum(Amount) as Amount');
        $this->db->where('Membership_ID',$id);
        $this->db->where('Commision_type',1);
        $query = $this->db->get('gc_member_commission_details');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
function get_level_investment($id) {

        $this->db->select('sum(Final_amount) as Amount');
        $this->db->where('Membership_ID',$id);
        $this->db->where('Commission_type',2);
        $query = $this->db->get('gc_member_payouts');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

function get_level_investment_level2t09($id) {

        $this->db->select('sum(Final_amount) as Amount');
        $this->db->where('Membership_ID',$id);
        $this->db->where('Commission_type',3);
        $query = $this->db->get('gc_member_payouts');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

function get_level_investment1($id) {

        $this->db->select('sum(Amount) as Amount');
        $this->db->where('Membership_ID',$id);
        $this->db->where('Commision_type!=',1);
        $query = $this->db->get('gc_member_commission_details');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
function get_next_payout($id) {

        $this->db->select('sum(Amount) as Amount');
        $this->db->where('Membership_ID',$id);
        $this->db->where('Commision_type!=',1);
        $query = $this->db->get('gc_member_commission_details');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

function get_direct_investment($id) {

        $this->db->select('sum(contract.Amount) as Amount');
        $this->db->from('gc_member_franchisee_contract as contract');
        $this->db->join('gc_member_level_details as level', 'level.Child_ID = contract.Membership_ID', 'left');
        $this->db->where('level.Membership_ID',$id);
        $this->db->where('level.Level_ID',1);
        $this->db->where('contract.Withdrawn_status',5);
        $this->db->where('contract.Contract_status',6);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function get_direct_investment1($id) {

        $this->db->select('sum(contract.Amount) as Amount');
        $this->db->from('gc_franchisee_member_relation as parent');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = parent.Child_ID', 'left');
        $this->db->where('parent.Parent_ID',$id);
        $this->db->where('contract.Withdrawn_status',5);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
        function getall_members_by_id($member) {
        $this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Status as bank_status,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name,users.email_address as loginemail,users.og_password as loginpassword,area.id as taluk_id,area.area_name as taluk_name,city.id as City_id,city.city_name as City_name,state.id as State_id,state.state_name as State_name,country.id as Country_id,country.country_name as Country_name');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_users as users', 'users.id = member.Membership_ID', 'left');
        $this->db->join('gc_areas as area','area.id = address.Area', 'left');
        $this->db->join('gc_cities as city', 'city.id = address.City', 'left');
        $this->db->join('gc_states as state', 'state.id = address.State', 'left');
        $this->db->join('gc_countries as country', 'country.id = address.Country', 'left');

        // $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
        $this->db->where_in("member.Membership_ID",$member);
        $this->db->group_by("member.Membership_ID");
        // if($status!=1){
        // $this->db->where_in("member.Status",$status);}
        // if($status1==10 || $status1==11){
        //     if($status1==10){
        //         $this->db->where("bank.Status",5);
        //     }elseif($status1==11){
        //         $this->db->where("documents.Status",5);
        //     }
        // }
        $this->db->group_by("payments.Membership_ID");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
function get_return_investment($id) {

        $this->db->select('sum(Amount) as Amount');
        $this->db->where('Membership_ID',$id);
        $this->db->where('Status',6);
        $query = $this->db->get('gc_member_commission_details');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
function get_return_investment_chart($id) {

        $this->db->select('sum(Amount) as Amount');
        $this->db->where('Membership_ID',$id);
        $this->db->where('Commision_type',1);
        $this->db->where('Status',6);
        $query = $this->db->get('gc_member_commission_details');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    function getall_payment_modes() {

        $this->db->select('*');
        $this->db->where('Status',1);
        $query = $this->db->get('gc_payment_mode');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function get_wallet_balance() {

        $this->db->select('Wallet_balance,Pay_date,Status');
        $this->db->where('Membership_ID',$this->session->userdata('UserCode'));
        $query = $this->db->get('gc_membership');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function get_daily_earnings() {

        $this->db->select('sum(Amount) as Amount');
        $this->db->where('Membership_ID',$this->session->userdata('UserCode'));
        $this->db->where('Status',1);
        $query = $this->db->get('gc_daily_member_commission_details');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    function get_payout_date() {

        $this->db->select('Pay_date,Payout_date,Contract_ref_no');
        $this->db->from('gc_member_franchisee_contract');
        // $this->db->join('gc_membership as member','member.Membership_ID = contract.Membership_ID', 'left');
        $this->db->where('Membership_ID',$this->session->userdata('UserCode'));
        $this->db->where('Pay_date >=',date('Y-m-d'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    

function get_doc_records($id) {

        $this->db->select('*');
        $this->db->where('Membership_ID',$id);
        $query = $this->db->get('gc_member_documents');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

function get_pays_records($id) {

        $this->db->select('*');
        $this->db->where('Membership_ID',$id);
        $query = $this->db->get('gc_member_payments');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    
    }

function getall_members($status,$status1) {

        $this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');

        // $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
        $this->db->group_by("member.Membership_ID");
        if($status!=1){
        $this->db->where("member.Status",$status);}
        if($status1==10 || $status1==11){
            if($status1==10){
                $this->db->where("bank.Status",5);
            }elseif($status1==11){
                $this->db->where("documents.Status",5);
            }
        }
        $this->db->group_by("payments.Membership_ID");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


function calculate_commission() {

        $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);
            $final_days=[];
            $final_days1=[];
            
            $date=new DateTime();
$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

    if($week_days[$i] == $search){
        $arr[$i] = $week_days[$i];
        $search = $week_days[$i] + 1;
    }else{
        $arr2[$i] = $week_days[$i];
    }
}

$action = array_merge($arr,$arr2);
$days = array(
     '1' => 'Monday',
     '2' => 'Tuesday',
     '3' => 'Wednesday',
     '4' => 'Thursday',
     '5' => 'Friday',
     '6' => 'Saturday',
     '7' => 'Sunday'
 );
$final_dt=[];

foreach($action as $da){
if (array_key_exists($da,$days))
  {
  array_push($final_dt,$days[$da]);
  }

}

var_dump($final_dt);
$final_dates=[];
for($i=1; $i<=52; $i++){
        foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
        array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
        }
    }
    var_dump($final_dates);


            if(in_array(date('Y-m-d'), $final_dates)){

            $this->db->where('Date',date('Y-m-d'));
            $query = $this->db->get('gc_individual_calendar');
            if ($query->num_rows() > 0) {
                //echo "not insert";
            }else{
               
                // Get Transaction Tabl
                $this->db->select('transaction.*');
                $this->db->from('gc_transaction as transaction');
                $this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
                $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');

                $this->db->where('transaction.Transaction_status',1);
                $this->db->where('member.Status',6);
                $this->db->where('contract.Withdrawn_status',5);
                $query1 = $this->db->get();
                if ($query1->num_rows() > 0) {
                    $transaction=$query1->result_array();
                    // var_dump($final_days);die();
                    foreach($transaction as $tran){

                    $commision_data=array(
                            'Company_id'       => $this->session->userdata('CompanyId'),
                            'Branch_id'        => $this->session->userdata('CompanyId'),
                            'Transaction_ID'   => $tran['Transaction_ID'],
                            'Membership_ID'    => $tran['Membership_ID'], 
                            'Contract_ID'      => $tran['Contract_ID'], 
                            'Transaction_type' => $tran['Transaction_ID'],
                            'Commision_date'  => date('Y-m-d'), 
                            'Remarks'          => '', 
                            'Created_by'       => $this->session->userdata('UserId')
                            );
                    $this->db->insert('gc_member_commission',$commision_data);
                    $commision_id=$this->db->insert_id();

                    // Get Transaction detail Table
                    $this->db->select('*');
                    $this->db->where('Status',1);
                    $this->db->where('Transaction_ID',$tran['Transaction_ID']);
                    $query2 = $this->db->get('gc_transaction_details');
                      if ($query2->num_rows() > 0) {
                        $transaction_detail=$query2->result_array();
                        foreach($transaction_detail as $tran_det){
                            $commision_detail_data=array(
                            'Company_id'               => $this->session->userdata('CompanyId'),
                            'Branch_id'                => $this->session->userdata('CompanyId'),
                            'Commission_ID'            => $commision_id,
                            'Transaction_ID'           => $tran_det['Transaction_ID'],
                            'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
                            'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
                            'Membership_ID'            => $tran_det['Membership_ID'], 
                            'Contract_ID'              => $tran_det['Contract_ID'], 
                            'Commision_type'           => $tran_det['Commision_type'],
                            'Payout_ID'                => $tran_det['Payout_ID'],
                            'Commision_date'           => date('Y-m-d'), 
                            'Amount'                   => $tran_det['Amount'], 
                            'Commision'                => $tran_det['Commision'],
                            'Remarks'                  => '', 
                            'Created_by'               => $this->session->userdata('UserId')
                            );
                            $this->db->insert('gc_member_commission_details',$commision_detail_data);

                        }

                      }
            }

          }
        }

        }

    }

}
    
public function getDays($y,$m,$d){ 
    $date = "$y-$m-01";
    $first_day = date('N',strtotime($date));
    $first_day = $d - $first_day + 1;
    $last_day =  date('t',strtotime($date));
    $days = array();
    for($i=$first_day; $i<=$last_day; $i=$i+7 ){
        $days[] = $y.'-'.$m.'-'.$i;
        //$days[] = implode(',',$days);
    }
    return $days;
}
    
public function getall_topups() {
        $this->db->select('*');
        $this->db->where('Status',1);
        $query = $this->db->get('gc_member_topup');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return 0;
    }

public function getall_payouts() {
        $this->db->select('*');
        $this->db->where('Status',1);
        $query = $this->db->get('gc_payout_type');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return 0;
    }


public function update_bank_status($data,$Membership_ID) {
    $id=$data['Member_bank_ID'];
    unset($data['Member_bank_ID']);
        $this->db->where('Member_bank_ID',$id);
        $this->db->update('gc_member_banks',$data);
        
        $data1['Status']=4;
        $this->db->where('Membership_ID',$Membership_ID);
        if($this->db->update('gc_membership',$data1)){
            return 1;
        }else{
            return 0;
        }
        
    }

public function update_document_status($data,$Membership_ID) {
    $id=$data['Document_ID'];
    unset($data['Document_ID']);
        $this->db->where('Document_ID',$id);
        $this->db->update('gc_member_documents',$data);

        $data1['Status']=4;
        $this->db->where('Membership_ID',$Membership_ID);
        if($this->db->update('gc_membership',$data1)){
            return 1;
            }else{
                return 0;
            }
    }

public function Activate_member_contract($Membership_ID,$Contract_ID) {
        $data['Status']=6;
        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->update('gc_membership',$data);

        $this->db->select('topup.Validity,Value,Return,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
        $this->db->from('gc_member_topup as topup');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');

        $this->db->where('contract.Contract_ID',$Contract_ID);
        $this->db->where('contract.Membership_ID',$Membership_ID);
        $query = $this->db->get();
        $contract=$query->result_array();
        if(!empty($contract)){
            $month=$contract[0]['Validity'];
            $Amount=$contract[0]['Value'];
            $Return=$contract[0]['Return'];
            if($contract[0]['Payout_status']==2){
                $payout_id=$contract[0]['New_payout_ID'];
            }else{
                $payout_id=$contract[0]['Old_payout_ID'];
            }
        }else{
            $month=0;
            $Amount=0;
            $Return=0;
        }
// Transaction Insert Start        
        $transaction=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $Membership_ID, 
                            'Contract_ID' => $Contract_ID, 
                            'Transaction_type' => 1,
                            'Transaction_date' => date('Y-m-d'), 
                            'Remarks' => '', 
                            'Created_by' => $this->session->userdata('UserId') 
                        );
        $this->db->insert('gc_transaction',$transaction);
        $transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
        $Comission_amount=$Amount*$Return/100;
        $transaction_detail=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $Membership_ID, 
                            'Contract_ID' => $Contract_ID,
                            'Member_level_detail_ID' => NULL, 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 1, 
                            'Payout_ID' => $payout_id,
                            'Amount' => $Comission_amount, 
                            'Commision' => $Return,
                            'Remarks' => '' 
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail);
// Transaction Detail (Top-up) Insert End   

// Transaction History (Debit) Insert start 
$history_data=array(
                 'Company_id'               => $this->session->userdata('CompanyId'),
                 'Branch_id'                => $this->session->userdata('CompanyId'), 
                 'Membership_ID' => $Membership_ID,
                 'Contract_ID'   => $Contract_ID,
                 'Payout_ID' => $payout_id,
                 'Date'  => date('Y-m-d'),
                 'History_for'   => ' Topup Amount of  '.$Amount,
                 'Credit_amount' => 0,
                 'Debit_amount' => $Amount,
                  );
            $this->db->insert('gc_transaction_history',$history_data);  

// Transaction History (Debit) Insert End  

// Transaction Details (Direct&Push-up) Insert Start
        $this->db->select('Reference_ID');
        $this->db->from('gc_membership');
        $this->db->where('Membership_ID',$Membership_ID);
        $query = $this->db->get();
        $membership=$query->result_array();


$ref_ID="";$level_insert_id="";
        for($i=1;$i<=9;$i++){ 
            if($i==1){
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$membership[0]['Reference_ID']);
            //$this->db->where('contract.Contract_status',6);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            $crnt_lvl=$binary[0]['Current_level'];
            if($crnt_lvl<=$i){
            $level['Level_ID']=$i;
            }
            else{
                $level['Level_ID']=$crnt_lvl;
            }
            $ref_ID=$binary[0]['Reference_ID'];

            $this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
            $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
            //$this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();


                        $Comission_amount1=$Amount*$level_details[0]['Return']/100;
                        if($level_details[0]['Payout_status']==2){
                        $payout_id1=$level_details[0]['New_payout_ID'];
                        }else{
                        $payout_id1=$level_details[0]['Old_payout_ID'];
                        }
// Transaction Details Insert start 
$transaction_detail1=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $binary[0]['Membership_ID'], 
                            'Contract_ID' => $binary[0]['Contract_ID'],
                            'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 2,
                            'Payout_ID' => $payout_id1, 
                            'Amount' => $Comission_amount1, 
                            'Commision' => $level_details[0]['Return'],
                            'Remarks' => '' 
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start


        }
    }
    else{
            $this->db->select('*');
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$ref_ID);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            $crnt_lvl=$binary[0]['Current_level'];
            if($crnt_lvl<=$i){
            $level['Level_ID']=$i;
            }
            else{
                $level['Level_ID']=$crnt_lvl;
            }
            $ref_ID=$binary[0]['Reference_ID'];

            $this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
            $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
            //$this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();
                        $Comission_amount1=$level_details[0]['Value']*$level_details[0]['Return']/100;
                        if($level_details[0]['Payout_status']==2){
                        $payout_id1=$level_details[0]['New_payout_ID'];
                        }else{
                        $payout_id1=$level_details[0]['Old_payout_ID'];
                        }
// Transaction Details Insert start 
$transaction_detail1=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $binary[0]['Membership_ID'], 
                            'Contract_ID' => $binary[0]['Contract_ID'],
                            'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 3,
                            'Payout_ID' => $payout_id1, 
                            'Amount' => $Comission_amount1, 
                            'Commision' => $level_details[0]['Return'],
                            'Remarks' => ''  
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
// Transaction Details (Direct&Push-up) Insert End        

                }

            }
        }

        $data1['Start_date']=date('Y-m-d');
        $data1['End_date']=date('Y-m-d', strtotime('+'.$month.'months'));
        $data1['Contract_status']=6;
        $data1['Contract_status_date']=date('Y-m-d');
        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->where('Contract_ID',$Contract_ID);
        if($this->db->update('gc_member_franchisee_contract',$data1)){
            return 1;
        }else{
            return 0;
        }
    }
    
function get_referer_by_code($referer) {

        $this->db->select('Membership_ID,First_name,Last_name,Membership_code');
        $this->db->where('Status!=',7);
        $this->db->where('Status!=',8);
        $where = '(Membership_code="'.$referer.'" or Mobile = "'.$referer.'")';
        $this->db->where($where);
        $query = $this->db->get('gc_membership');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return 0;
    }

function mobile_verify($mobile) {

        $this->db->select('Membership_ID,First_name,Last_name,Membership_code,Status');
        $this->db->where('Mobile',$mobile);
        $query = $this->db->get('gc_membership');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    

function get_topup_details($topup) {

        $this->db->select('ID,Value,Validity,Payout_type,Return');
        $this->db->where('ID',$topup);
        $this->db->where('Status',1);
        $query = $this->db->get('gc_member_topup');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return 0;
    }

    function getall_membershiptype() {

        $this->db->select('*');
        $this->db->where('Status',1);
        $query = $this->db->get('gc_membershiptype');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return 0;
    }




    function get_parent_referer($id) {

    $this->db->select('table.Membership_code');
    $this->db->where('table.Membership_ID',$id);
    $query = $this->db->get('gc_membership as table');
    if ($query->num_rows() > 0) {   
        return  $query->result_array();
    }
    return 0;
    }

  

  function get_parent_detail($id) {

    $this->db->select('table.Membership_ID,table.First_name,table.Last_name,table.Membership_code,table.Reference_ID,table.Current_level,table.Photo,table.Photo_path,table.Members_count,table1.Member_color,table.Members_count,table.Created_date'); //,table2.Position_type
    $this->db->join('gc_tree_color_setting as table1', 'table1.Member_type = table.Membership_type', 'left');
    // $this->db->join('gc_binary_member_relation as table2', 'table2.Child_ID = table.Membership_ID', 'left');
    $this->db->where('table.Membership_ID',$id);
    $this->db->where('table1.Member_level',1);
    $query = $this->db->get('gc_membership as table');
    if ($query->num_rows() > 0) {   
        return  $query->result_array();
    }
    return 0;
    }


function get_child_by_parent($id) { 

$this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Membership_code,member.Current_level,tree.Child_ID,table1.Member_color,member.Photo,member.Members_count,member.Created_date,tree.Parent_ID,member.Photo_path');
         $this->db->select('members.First_name as parentfname,members.Membership_code as parentmemcode,tree.Position');
         $this->db->from('gc_franchisee_member_relation as tree');
         $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
         $this->db->join('gc_membership as members', 'members.Membership_ID = tree.Parent_ID', 'left');
         $this->db->join('gc_tree_color_setting as table1', 'table1.Member_type = member.Membership_type', 'left');
         // $this->db->join('gc_member_franchisee_contract as table2', 'table2.Membership_ID = member.Membership_ID', 'left');
         // $this->db->join('gc_member_topup as table3', 'table3.ID = table2.Topup_id', 'left');

        $this->db->where('table1.Member_level',1);
        // $this->db->where('table2.Invest_type',1);
        $this->db->where('tree.Parent_ID',$id);
        $this->db->group_by('member.Membership_ID');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        // return 0;
    }


function get_child_by_parent_binary($id) {
        // var_dump($id);
         $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Membership_code,member.Current_level,tree.Child_ID,table1.Member_color,member.Photo,member.Photo_path,member.Created_date,tree.Position_type');
         $this->db->from('gc_binary_member_relation as tree');
         $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
         $this->db->join('gc_tree_color_setting as table1', 'table1.Member_type = member.Membership_type', 'left');
         
        $this->db->where('table1.Member_level',1);
        $this->db->where('tree.Parent_ID',$id);
        $query = $this->db->get()->result_array();
        // var_dump($query);
        if (count($query) > 0) {
            return  $query;
        }
        return 0;
    }
    

    function add_membership($member,$address_data,$nominee_data,$bank_data,$upload_data,$contract_data,$payment_data,$agreement_data) {
       
        // Start Membership Insert
        // var_dump($upload_data);
        $member['Company_id']   = $this->session->userdata('CompanyId');
        $member['Branch_id']   = $this->session->userdata('CompanyId');

        if(isset($contract_data)){
            $member['Membership_type']   = $contract_data['Membership_type'];
        }
        if(!empty($contract_data['Membership_type'])){
             $member['Membership_type']   = $contract_data['Membership_type'];
         }else{
             $member['Membership_type']   = 2;
         }
            
        // Membership Code
        $pan=$upload_data["upload_data_1"]["Document_no"];
        if(!empty($pan)){
        $newpan = substr($pan, -5);
        }
        $newmob = substr($member['Mobile'], -5);
        $member['Membership_code']=$newpan.$newmob;

        $profile_name = 'Photo';
        $names = 'Profile';
        $photo_name = $this->member_profile_attachment_1($member['Membership_code'],$profile_name,$names);

        $increment_code = $this->db->count_all_results('gc_membership')+1;
        $member['Member_no']="GRNC-MEM-0000".$increment_code;
        $member['Member_sequence']=$increment_code-1;
        $member['DOB']=date("Y-m-d", strtotime($member['DOB']));
        $member['Status']=5;
        $member['Photo']=$photo_name;
        $member['Created_by']=$this->session->userdata('UserId');


        if($this->db->insert('gc_membership', $member)){
            $Membership_ID=$this->db->insert_id();
        }


// end Membership Insert

//start Member upload_data Insert
        foreach($upload_data as $key =>$upld)
        {
            $upld['Membership_ID']   = $Membership_ID;
            $upld['Company_id']   = $this->session->userdata('CompanyId');
            $upld['Branch_id']   = $this->session->userdata('CompanyId');
            $upload_data[$key]=$upld;
        }
        foreach($upload_data as $upld_data)
        {   
            $this->db->insert('gc_member_documents', $upld_data);
           
        }
        
        // die();
//end Member upload_data Insert

//start Member Address Insert
        $address_data['Membership_ID']   = $Membership_ID;
        $address_data['Company_id']   = $this->session->userdata('CompanyId');
        $address_data['Branch_id']   = $this->session->userdata('CompanyId');
        $this->db->insert('gc_member_address', $address_data);
//end Member Address Insert

// start User Insert
       $user_data['user_id']         = $Membership_ID;
       $user_data['company_id']      = 1;
       $user_data['branch_id']       = 1;
       $user_data['firstname']       = $member['First_name'];
       $user_data['username']        = $member['Membership_code'];
       $user_data['password']        = md5($member['Mobile']);
       $user_data['og_password']     = $member['Mobile'];
       $user_data['email_address']   = $member['Email'];
       $user_data['mobile_number']   = $member['Mobile'];
       $user_data['address_line_1']  = $address_data['Address_1'];
       $user_data['address_line_2']  = $address_data['Address_2'];
       $user_data['zipcode']         = $address_data['Pincode'];
       $user_data['country_id']         = $address_data['Country'];
       $user_data['state_id']         = $address_data['State'];
       $user_data['city_id']         = $address_data['City'];
       $user_data['user_type_id']    = 3;
       $this->db->insert('gc_users', $user_data);

// end User Insert  

// Open Cart Table

    // $reg = array('firstname'         => $member['First_name'],
    //              'lastname'          => $member['Last_name'],
    //              'customer_group_id' => '1',
    //              'language_id'       => '1',
    //              'email'             => $member['Email'],
    //              'telephone'         => $member['Mobile'],
    //              'status'            => '1',
    //              'email'             => $member['Email'],                         
    //              'password'          => md5($member['Mobile']),                         
    //              'Member_id'         => $Membership_ID,                         
    //             );
        // $opencart = $this->load->database('opencart', TRUE);
        // opencart
        // if ($opencart->insert('greencrest_customer', $reg)) {
             // $opencart->insert_id();
        // } 

// End Open Cart Table


//start Member nominee_data Insert
        $nominee_data['Membership_ID']   = $Membership_ID;
        $nominee_data['Company_id']   = $this->session->userdata('CompanyId');
        $nominee_data['Branch_id']   = $this->session->userdata('CompanyId');
        $this->db->insert('gc_member_nominees', $nominee_data);
//end Member nominee_data Insert

//start Member bank_data Insert
        $bank_data['Membership_ID']   = $Membership_ID;
        $bank_data['Company_id']   = $this->session->userdata('CompanyId');
        $bank_data['Branch_id']   = $this->session->userdata('CompanyId');
        $this->db->insert('gc_member_banks', $bank_data);
//end Member bank_data Insert

//start Member contract_data Insert
        if(isset($contract_data)){
            $contract_data['Membership_ID']   = $Membership_ID;
            $increment_code1 = $this->db->count_all_results('gc_member_franchisee_contract')+1;
            $contract_data['Contract_ref_no']="GRNC-CNT-0000".$increment_code1;
            $contract_data['Company_id']   = $this->session->userdata('CompanyId');
            $contract_data['Branch_id']   = $this->session->userdata('CompanyId');
            if($this->db->insert('gc_member_franchisee_contract', $contract_data)){
                $Contract_ID=$this->db->insert_id();
            }
        }    
//end Member contract_data Insert

//start Member payment_data Insert
        if(isset($payment_data)){
            foreach($payment_data as $key =>$payment)
            {
                $payment['Membership_ID']   = $Membership_ID;
                $payment['Contract_ID']   = $Contract_ID;
                $payment['Company_id']   = $this->session->userdata('CompanyId');
                $payment['Branch_id']   = $this->session->userdata('CompanyId');
                $payment['Payment_status']   = 5;
                $payment_data[$key]=$payment;
            }
            $this->db->insert_batch('gc_member_payments', $payment_data);
        }    
//end Member payment_data Insert

//start Member agreement_data Insert
        if(isset($agreement_data)){
            $agreement_data['Membership_ID']   = $Membership_ID;
            $agreement_data['Contract_ID']   = $Contract_ID;
            $agreement_data['Company_id']   = $this->session->userdata('CompanyId');
            $agreement_data['Branch_id']   = $this->session->userdata('CompanyId');
            $this->db->insert('gc_member_agreement', $agreement_data);
        }
//end Member agreement_data Insert


//start Member Franchisee Member Relationship Insert
        $franchisee_relation['Child_ID']        = $Membership_ID;
        $franchisee_relation['Level_type_ID']   = 1;
        $franchisee_relation['Parent_id']   = $member['Reference_ID'];
        // $franchisee_relation['Position']   = 1;
        $this->db->where('Parent_ID',$member['Reference_ID']);  
        $member_seq = $this->db->count_all_results('gc_franchisee_member_relation')+1;

        $franchisee_relation['Position']   = $member_seq;
        if($franchisee_relation['Position'] % 2 == 0){ 
            $determin = "2";  
        }else{ 
            $determin = "1"; 
        }
        $franchisee_relation['Determination']   = $determin;
        $franchisee_relation['Company_id']   = $this->session->userdata('CompanyId');
        $franchisee_relation['Branch_id']   = $this->session->userdata('CompanyId');
        $this->db->insert('gc_franchisee_member_relation', $franchisee_relation);
//end Member Franchisee Member Relationship Insert

//start Member binary Member Relationship Insert
        // $binary_relation['Child_ID']        = $Membership_ID;
        // $binary_relation['Level_type_ID']   = 2;
        // // $binary_relation['Refer_parent_ID']   = 1;
        // $binary_relation['Refer_parent_ID']   = $member['Reference_ID'];
        // // $binary_relation['Position']   = 1;
        // $binary_relation['Position']   = $member_seq;
        // if($binary_relation['Position'] % 2 == 0){ 
        //     $determin = "2";
        //     $p_type ="2" ; 
        // $this->db->select('*');
        // $this->db->where('Position_type',$p_type);
        // $this->db->where('Parent_ID',$binary_relation['Refer_parent_ID']);
        // $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
        // $query1 = $this->db->get('gc_binary_member_relation');
        // if ($query1->num_rows() > 0) {
        //     $binary=$query1->result_array();
        //     $parent=$binary[0]["Child_ID"];
        //     $new_p_type=$binary[0]['Ex_position_type'];
        // }else{
        //     $parent=$binary_relation['Refer_parent_ID'];
        //     $this->db->select('*');
        //     $this->db->where('Child_ID',$binary_relation['Refer_parent_ID']);
        //     $query5 = $this->db->get('gc_binary_member_relation');
        //     $binary5=$query5->result_array();
        //     $new_p_type=$binary5[0]['Ex_position_type'];
        // }
        // }else{ 
        //     $this->db->select('*');
        //     $this->db->where('Child_ID',$binary_relation['Refer_parent_ID']);
        //     $query3 = $this->db->get('gc_binary_member_relation');
        //     $binary2=$query3->result_array();
        //     $new_p_type=$binary2[0]['Ex_position_type'];
        //     $determin = "1";
        //     $p_type ="1"; 
        // $this->db->select('*');
        // $this->db->where('Position_type',$p_type);
        // $this->db->where('Parent_ID',$binary_relation['Refer_parent_ID']);
        // $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
        // $query = $this->db->get('gc_binary_member_relation');
        // if($query->num_rows() > 0) {
        //     $binary=$query->result_array();
        //     $this->db->select('*');
        //     $this->db->where('Position_type',$p_type);
        //     $this->db->where('Ex_position_type',$binary[0]['Ex_position_type']);
        //     $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
        //     $query4 = $this->db->get('gc_binary_member_relation');
        //     $binary4=$query4->result_array();
        //     $parent=$binary4[0]["Child_ID"];
        //     $new_p_type=$binary4[0]['Ex_position_type'];
        // }else{
        //     $parent=$binary_relation['Refer_parent_ID'];
        //     $this->db->select('*');
        //     $this->db->where('Child_ID',$binary_relation['Refer_parent_ID']);
        //     $query3 = $this->db->get('gc_binary_member_relation');
        //     $binary1=$query3->result_array();
        //     $new_p_type=$binary1[0]['Ex_position_type'];
        // }
        // }
        // $binary_relation['Determination']   = $determin;
        // $binary_relation['Position_type']   = $p_type;
        
        // $this->db->select('*');
        // $query1 = $this->db->get('gc_binary_member_relation');
        // $row=$query1->num_rows();
        // if($row==0){
        //     $binary_relation['Position_type']   = "";
        //     $binary_relation['Ex_position_type']   = "";
        // }elseif($row==1){
        //     $binary_relation['Ex_position_type']   = $p_type;
        // }elseif($row==2){
        //     $binary_relation['Ex_position_type']   = $p_type;
        // }else{
        //     $binary_relation['Ex_position_type']   = $new_p_type;
        // }

        // $binary_relation['Parent_id']    =  $parent;
        // $binary_relation['Company_id']   =  $this->session->userdata('CompanyId');
        // $binary_relation['Branch_id']    =  $this->session->userdata('CompanyId');
        // $this->db->insert('gc_binary_member_relation', $binary_relation);
//end Member binary Member Relationship Insert

//start Member binary Member Levels Insert

$ref_ID="";$level_insert_id="";
        for($i=1;$i<=9;$i++){ 
            if($i==1){
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$member['Reference_ID']);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            $crnt_lvl=$binary[0]['Current_level'];
            if($crnt_lvl<=$i){
            $level['Level_ID']=$i;
            }
            else{
                $level['Level_ID']=$crnt_lvl;
            }
            $ref_ID=$binary[0]['Reference_ID'];
 // Member Level Master Insert start
            $levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
            $levels_master['Company_id']       =  $this->session->userdata('CompanyId');
            $levels_master['Branch_id']        =  $this->session->userdata('CompanyId');
            $levels_master['Level_ID']         =  1;
            $levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
            $levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
            $levels_master['Payout_status']    =  $binary[0]['Payout_status'];
            $this->db->insert('gc_member_levels', $levels_master);
            $level_insert_id=$this->db->insert_id();
// Member Level Master Insert end         
// Member Level Details Insert start 
            $levels_data['Member_level_ID']  =  $level_insert_id;
            $levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
            $levels_data['Child_ID']         =  $Membership_ID;
            $levels_data['Company_id']       =  $this->session->userdata('CompanyId');
            $levels_data['Branch_id']        =  $this->session->userdata('CompanyId');
            $levels_data['Level_ID']         =  $level['Level_ID'];
            $levels_data['Position']         =  $binary_relation['Ex_position_type'];
            $levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
            $levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
            $levels_data['Payout_status']    =  $binary[0]['Payout_status'];
            $this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start
// Membership Current Level Insert start
            $mem_lvl['Member_grade']=NULL;
            $grade_count1=$this->db->where(array('Membership_ID'=>$binary[0]['Membership_ID'],'Level_ID'=>1))->count_all_results('gc_member_level_details');
			if($grade_count1>=6){
			$mem_lvl['Member_grade']=3;
			}
			$grade_count2=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count2>=6){
			$mem_lvl['Member_grade']=2;
			}
			$grade_count3=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count3>=6){
			$mem_lvl['Member_grade']=1;
			}
            $mem_lvl['Current_level']=$level['Level_ID'];
            $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
            $this->db->update('gc_membership', $mem_lvl);
// Membership Current Level Insert end

        }
    }
    else{
            $this->db->select('*');
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$ref_ID);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            $crnt_lvl=$binary[0]['Current_level'];
            if($crnt_lvl<=$i){
            $level['Level_ID']=$i;
            }
            else{
                $level['Level_ID']=$crnt_lvl;
            }
            $ref_ID=$binary[0]['Reference_ID'];

 // Member Level Master Insert start
            $levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
            $levels_master['Company_id']       =  $this->session->userdata('CompanyId');
            $levels_master['Branch_id']        =  $this->session->userdata('CompanyId');
            $levels_master['Level_ID']         =  $level['Level_ID'];
            $levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
            $levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
            $levels_master['Payout_status']    =  $binary[0]['Payout_status'];
            $this->db->insert('gc_member_levels', $levels_master);
            $level_insert_id=$this->db->insert_id();
// Member Level Master Insert end         
// Member Level Details Insert start 
            $levels_data['Member_level_ID']  =  $level_insert_id;
            $levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
            $levels_data['Child_ID']         =  $Membership_ID;
            $levels_data['Company_id']       =  $this->session->userdata('CompanyId');
            $levels_data['Branch_id']        =  $this->session->userdata('CompanyId');
            $levels_data['Level_ID']         =  $level['Level_ID'];
            $levels_data['Position']         =  $binary_relation['Ex_position_type'];
            $levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
            $levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
            $levels_data['Payout_status']    =  $binary[0]['Payout_status'];
            $this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start
// Membership Current Level Insert start
            $mem_lvl['Member_grade']=NULL;
            $grade_count1=$this->db->where(array('Membership_ID'=>$binary[0]['Membership_ID'],'Level_ID'=>1))->count_all_results('gc_member_level_details');
			if($grade_count1>=6){
			$mem_lvl['Member_grade']=3;
			}
			$grade_count2=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count2>=6){
			$mem_lvl['Member_grade']=2;
			}
			$grade_count3=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count3>=6){
			$mem_lvl['Member_grade']=1;
			}
            $mem_lvl['Current_level']=$level['Level_ID'];
            $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
            $this->db->update('gc_membership', $mem_lvl);
// Membership Current Level Insert end
                }
            }
        }
    }
 
 public function add_membership_upgrade($contract_data,$membership)
 {  

     //start Member contract_data Insert
        if(isset($contract_data)){
            // $mem=$this->db->get_where('gc_membership',array('Membership_ID' => $contract_data['Membership_ID']))->row();

        $mem=$this->db->get_where('gc_membership',array('Membership_ID' => $membership))->row();


            // $reg_date=$contract_data['Reg_date'];
            $reg_date=date('Y-m-d');
            $payout=$mem->Payout_ID;
            $increment_code1                                   = $this->db->count_all_results('gc_member_franchisee_contract')+1;
            $contract_data['Contract_ref_no']                  ="GRNC-CNT-0000".$increment_code1;
            $contract_data['Company_id']                       = $this->session->userdata('CompanyId');
            $contract_data['Branch_id']                        = $this->session->userdata('CompanyId');
            $contract_data['Membership_ID']                    = $membership;
            $contract_data['Payout_ID']                        = $payout;
            $count=$this->db->where('Membership_ID',$membership)->count_all_results('gc_member_franchisee_contract');
            if ($count>0) {
               $contract_data['Invest_type']                      = 2;
            }else{
                $contract_data['Invest_type']                     = 1;
            }
            
            $contract_data['Date']                             = date('Y-m-d',strtotime($reg_date));
            $contract_data['Payment_status_date']              = date('Y-m-d',strtotime($reg_date));
            $contract_data['Payment_status']                   = 6;
            $contract_data['Created_date']                     = date('Y-m-d');
            if($this->db->insert('gc_member_franchisee_contract', $contract_data)){
                $Contract_ID=$this->db->insert_id();
            }
        }    
//end Member contract_data Insert

        $wallet_balance  =  $this->get_wallet_balance($membership);
        $wallet_data=array('Wallet_balance' => $wallet_balance[0]['Wallet_balance']-$contract_data['Amount']);
        $this->db->where('Membership_ID', $membership);
        $this->db->update('gc_membership', $wallet_data);
//start Member payment_data Insert

$mem_qry = $this->db->get_where('gc_membership', array('Membership_ID' => $contract_data['Membership_ID']))->result_array();
if(!empty($mem_qry)){

    $activate=$this->topup_activate($contract_data['Membership_ID'],$Contract_ID,$mem_qry[0]['Commission_mode'],$mem_qry[0]['Final_commission_per'],$mem_qry[0]['Membership_type'],$mem_qry[0]['Payout_ID'],$contract_data['Amount'],$contract_data['Date']);
}


        // if(isset($payment_data)){
        //     foreach($payment_data as $key =>$payment)
        //     {
        //         $payment['Membership_ID']   = $membership;
        //         $payment['Contract_ID']   = $Contract_ID;
        //         $payment['Company_id']   = $this->session->userdata('CompanyId');
        //         $payment['Branch_id']   = $this->session->userdata('CompanyId');
        //         $payment['Payment_status']   = 5;
        //         $payment['Invest_type']   = 2;

        //         $payment_data[$key]=$payment;
        //     }
        //     $this->db->insert_batch('gc_member_payments', $payment_data);
        // }    
//end Member payment_data Insert
//
//start Member agreement_data Insert
        // if(isset($agreement_data)){
        //     $agreement_data['Membership_ID']   = $contract_data['Membership_ID'];
        //     $agreement_data['Contract_ID']   = $Contract_ID;
        //     $agreement_data['Company_id']   = $this->session->userdata('CompanyId');
        //     $agreement_data['Branch_id']   = $this->session->userdata('CompanyId');
        //     $this->db->insert('gc_member_agreement', $agreement_data);
        // }
//end Member agreement_data Insert
 }


public function topup_activate($Membership_ID,$Contract_ID,$Commission_mode,$cmsn_per,$Memberhip_type,$Membership_payout,$contract_amount,$reg_date){
    $this->db->select('topup.Validity,topup.Value,topup.Return,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Multiples,contract.Amount');
        $this->db->from('gc_member_topup as topup');
        

        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');
        // $this->db->join('gc_membership as member', 'member.Payout_ID = topup.ID', 'left');

        $this->db->where('contract.Contract_ID',$Contract_ID);
        $this->db->where('contract.Membership_ID',$Membership_ID);
        $query = $this->db->get();
        $contract=$query->result_array();

        $tp=$this->db->get_where('gc_member_topup',array('Status' => 1))->result_array();
        $contract=$this->db->get_where('gc_member_franchisee_contract',array('Contract_ID' => $Contract_ID,'Membership_ID' => $Membership_ID))->result_array();
// var_dump($contract);die();
        if(!empty($tp)){
            $month=$tp[0]['Validity'];
            // $Amount=$contract[0]['Value']*$contract[0]['Multiples'];
            
            // $Return=$tp[0]['Return'];
            // $pay_flag=$contract[0]['Pay_flag'];

            // if($contract[0]['Payout_status']==2){
            //     $payout_id=$contract[0]['New_payout_ID'];
            // }else{
            //     $payout_id=$contract[0]['Old_payout_ID'];
            // }
        }else{
            $month=0;
            
            // $Return=0;
            // $pay_flag=1;
        }

        // if(!empty($contract)){
        //  $Amount=$contract[0]['Amount'];
        // }else{
        //  $Amount=0;
        // }

        $Return=$cmsn_per;
        $Amount=$contract_amount;
        // $mem_qry = $this->db->select('Membership_ID,Payout_ID,Membership_type')->get_where('gc_membership', array('Membership_ID' => $Membership_ID))->result_array();
        // if(!empty($mem_qry[0]['Payout_ID'])){
        //     $payout_id=$mem_qry[0]['Payout_ID'];
        // }else{
            $payout_id=$Membership_payout;
        //}

        $py_qry = $this->db->select('Pay_flag,Days')->get_where('gc_payout_type', array('id' => $payout_id))->result_array();
        if(!empty($py_qry)){
            $pay_flag=$py_qry[0]['Pay_flag'];
            $py_days=$py_qry[0]['Days']-1;
        }else{
            $pay_flag=2;
            $py_days=15-1;
        }

        // if($Commission_mode==2){
        //     $new_pay=$Return+($cmsn_per/$pay_flag);
        // }else{
        //     $new_pay=$Return;
        // }
        $new_pay=$Return;

// Memberhsip Update end
        $data['Status']=6;
        $data['Commission_mode']=$Commission_mode;
        $data['Final_commission_per']=$new_pay;
        $data['Payout_ID']=$payout_id;
        
      //   if($Commission_mode==2){
      //     $data['Commission_per']=$cmsn_per;  
      // }else{
      //       $data['Commission_per']=0;
      // }
      $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime($reg_date. ' + '.$py_days.' days')));
      // $Pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
      $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
      $lvl_py_days=15-1;
      $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime($reg_date. ' + '.$lvl_py_days.' days')));
      // $Lvl_pay_date=$this->get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$lvl_py_days.' days')));
      $data['Lvl_pay_date']=date('Y-m-d',strtotime($Lvl_pay_date));
      // if($pay_flag==1){
      //   $py_days=30;
      //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
      //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
      // }else{
      //   $py_days=15;
      //   $Pay_date=get_pay_date(date('Y-m-d', strtotime(date('Y-m-d'). ' + '.$py_days.' days')));
      //   $data['Pay_date']=date('Y-m-d',strtotime($Pay_date));
      // }
        
      // var_dump($data);die();
        // $data['Activated_date']=date('Y-m-d H:i:s');
        // $this->db->where('Membership_ID',$Membership_ID);
        // $this->db->update('gc_membership',$data);


// Membership Update end 
// Transaction Insert Start        
        $transaction=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $Membership_ID, 
                            'Contract_ID' => $Contract_ID, 
                            'Transaction_type' => 1,
                            'Transaction_date' => $reg_date, 
                            'Remarks' => '', 
                            'Created_by' => $this->session->userdata('UserId') 
                        );
        $this->db->insert('gc_transaction',$transaction);
        $transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
        $Comission_amount=$Amount*$new_pay/100;
        $transaction_detail=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $Membership_ID, 
                            'Contract_ID' => $Contract_ID,
                            'Member_level_detail_ID' => NULL, 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 1, 
                            'Payout_ID' => $payout_id,
                            'Amount' => $Comission_amount, 
                            'Commision' => $Return,
                            'New_pay_percent' => $new_pay,
                            'Remarks' => '' 
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail);
// Transaction Detail (Top-up) Insert End   

// Transaction History (Debit) Insert start 
$history_data=array(
                 'Company_id'               => $this->session->userdata('CompanyId'),
                 'Branch_id'                => $this->session->userdata('CompanyId'), 
                 'Membership_ID' => $Membership_ID,
                 'Contract_ID'   => $Contract_ID,
                 'Payout_ID' => $payout_id,
                 'Date'  => $reg_date,
                 'History_for'   => ' Topup Amount of  '.$Amount,
                 'Credit_amount' => 0,
                 'Debit_amount' => $Amount,
                  );
            $this->db->insert('gc_transaction_history',$history_data);  

// Transaction History (Debit) Insert End  

// Transaction Details (Direct&Push-up) Insert Start
        $this->db->select('Reference_ID');
        $this->db->from('gc_membership');
        $this->db->where('Membership_ID',$Membership_ID);
        $query = $this->db->get();
        $membership=$query->result_array();

if($Commission_mode==1){ // Level Commission OR Self Commission is Start
    $ref_ID="";$level_insert_id="";
        for($i=1;$i<=9;$i++){ 
            if($i==1){
            $this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$membership[0]['Reference_ID']);
            $this->db->where('member.Commission_mode',1);
            $this->db->where('member.Membership_type',1);
            //$this->db->where('contract.Contract_status',6);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            if($binary[0]['Commission_mode']==1){
            $crnt_lvl=$binary[0]['Current_level'];
            //if($crnt_lvl<=$i){
            $level['Level_ID']=$i;
            //}
            //else{
               //$level['Level_ID']=$crnt_lvl;
            //}
            $ref_ID=$binary[0]['Reference_ID'];

            $this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
            // $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
            //$this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();


            $Comission_amount1=$Amount*$level_details[0]['Return']/100;
            $this->db->select('Payout_type');
            $this->db->from('gc_level');
            $this->db->where('ID',$level['Level_ID']);
            $query_lvl= $this->db->get();
            if($query_lvl->num_rows() > 0) {
            $level_payout=$query_lvl->result_array();
            $payout_id1=$level_payout[0]['Payout_type'];
            }else{
                $payout_id1=1;
                // if($level_details[0]['Payout_status']==2){
                // $payout_id1=$level_details[0]['New_payout_ID'];
                // }else{
                // $payout_id1=$level_details[0]['Old_payout_ID'];
                //         }
                    }
// Transaction Details Insert start 
$transaction_detail1=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $binary[0]['Membership_ID'], 
                            'Contract_ID' => $binary[0]['Contract_ID'],
                            'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 2,
                            'Payout_ID' => $payout_id1, 
                            'Amount' => $Comission_amount1, 
                            'Commision' => $level_details[0]['Return'],
                            'Remarks' => '' 
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start

            }
        }
    }
    else{
            $this->db->select('*');
            $this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$ref_ID);
            $this->db->where('member.Commission_mode',1);
            $this->db->where('member.Membership_type',1);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            if($binary[0]['Commission_mode']==1){

            $crnt_lvl=$binary[0]['Current_level'];
            $level['Level_ID']=$i;
           //  if($crnt_lvl<=$i){
            
           //  }
           //  else{
           //     $level['Level_ID']=$crnt_lvl;
           // }
            $ref_ID=$binary[0]['Reference_ID'];

            $this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Amount as Value,contract.Payout_ID');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
            // $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
            //$this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();
                        $Comission_amount1=$level_details[0]['Value']*$level_details[0]['Return']/100;
            $this->db->select('Payout_type');
            $this->db->from('gc_level');
            $this->db->where('ID',$level['Level_ID']);
            $query_lvl= $this->db->get();
            if($query_lvl->num_rows() > 0) {
            $level_payout=$query_lvl->result_array();
            $payout_id1=$level_payout[0]['Payout_type'];
            }else{
                 $payout_id1=1;
                        // if($level_details[0]['Payout_status']==2){
                        // $payout_id1=$level_details[0]['New_payout_ID'];
                        // }else{
                        // $payout_id1=$level_details[0]['Old_payout_ID'];
                        // $payout_id1=$level_payout[0]['Payout_type'];
                        // }
                    }
// Transaction Details Insert start 
$transaction_detail1=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $binary[0]['Membership_ID'], 
                            'Contract_ID' => $binary[0]['Contract_ID'],
                            'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 3,
                            'Payout_ID' => $payout_id1, 
                            'Amount' => $Comission_amount1, 
                            'Commision' => $level_details[0]['Return'],
                            'Remarks' => ''  
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
// Transaction Details (Direct&Push-up) Insert End        
                    }
                }

            }
        }
} // Level Commission OR Self Commission is End
        // $user_data = array('status' => 1 );
        // $this->db->where('user_id',$Membership_ID);
        // $this->db->update('gc_users',$user_data);

        $data1['Start_date']=date('Y-m-d',strtotime($reg_date));
        $data1['End_date']=date('Y-m-d', strtotime($reg_date. ' + '.$month.' months'));
        // $data1['End_date']=date('Y-m-d', strtotime('+'.$month.'months'));
        $data1['Contract_status']=6;
        $data1['Commission_mode']=$Commission_mode;
        $data1['Final_commission_per']=$new_pay;
        $data1['Pay_date']=$Pay_date;
        $data1['Lvl_pay_date']=$Lvl_pay_date;
        $data1['Payout_date']=$this->get_excat_next_payout($Pay_date);
      //   if($Commission_mode==2){
      //     $data1['Commission_per']=$cmsn_per;  
      // }else{
      //       $data1['Commission_per']=0;
      // }
        $data1['Contract_status_date']=date('Y-m-d',strtotime($reg_date));
        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->where('Contract_ID',$Contract_ID);
        $this->db->update('gc_member_franchisee_contract',$data1);
        

}


public function get_excat_next_payout($cl_dt){
	//$cl_dt='2019-05-08';
	$com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
                	if(!empty($com_pay_date)){
                		$commission_pay_date=$com_pay_date[0]['Pay_dates'];
                	}else{
                		$commission_pay_date='7,14,21,28';
                	}
                	$commission_pay_date=explode(',',$commission_pay_date);

                      	//$cl_dt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $tran['Membership_ID'],'Contract_ID' => $tran['Contract_ID']))->row()->Pay_date;
					$per_date=date('d',strtotime($cl_dt));
                      	$temp_date=date('Y-m',strtotime($cl_dt));
							foreach($commission_pay_date as $val){
								if($per_date <= $val){
									$exct_day= $val;
									break;
								}else{
									$exct_day=$commission_pay_date[0];
								}

							}
							if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
									$final_payout_date=date($temp_date.'-'.$exct_day);
								}else{
									// $samp_dy=date('Y-m-'.$exct_day);
									$samp_dy=date($temp_date.'-'.$exct_day);
									$final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
									
								}

							// return $payout_date=$this->fet_exact_payout_date($final_payout_date);
							return $payout_date=date('Y-m-d',strtotime($final_payout_date));
}

public function fet_exact_payout_date($final_payout_date)
{
	$Cal_date=date('Y-m-d',strtotime($final_payout_date));
$final_dates=[];
$yrl_dates_0=[];
		$this->db->select('Weeks');
		$this->db->where('Status',1);
		$this->db->where('ID',1);
		$query = $this->db->get('gc_leveltype');
		if ($query->num_rows() > 0) {
		    $days=$query->result_array();
		    $week_days=explode(',',$days[0]['Weeks']);
		    $final_days=[];
		    $final_days1=[];


		$yr=[date('Y')-1,date('Y')+0,date('Y')+1];
		foreach($yr as $key => $y){
		$yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
		}
		$final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
		

		        $this->db->select('Date');
		        $query = $this->db->get('gc_individual_calendar');
		        if ($query->num_rows() > 0) {
		            $db_leave=$query->result_array();
		        }else{
		            $db_leave=[];
		        }

		        $empt_leave=[];
		        foreach($db_leave as $lv){
		            array_push($empt_leave,$lv['Date']);

		        }
		        $final_dates=array_values(array_diff($final_dates,$empt_leave));
		    if(in_array($Cal_date, $final_dates)){

		    	return $Cal_date;
		    }else{
		    	return $this->get_next_pay_date($Cal_date);
		    }
		}
}

    public function get_next_pay_date($cur_date){
$final_dates=[];
$yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

         $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));

    foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
    
    $keyval= $key;
    if(isset($final_dates[$keyval])){
        return $final_dates[$keyval];
    }
    
    break;
}else{
    $keyval=$key;
    $final_dates[$keyval];
}
    }
}

    }    


public function get_pay_date($Cal_date){
    $Cal_date=date('Y-m-d',strtotime($Cal_date));
    $final_dates=[];
    $yrl_dates_0=[];
            $this->db->select('Weeks');
            $this->db->where('Status',1);
            $this->db->where('ID',1);
            $query = $this->db->get('gc_leveltype');
            if ($query->num_rows() > 0) {
                $days=$query->result_array();
                $week_days=explode(',',$days[0]['Weeks']);
                $final_days=[];
                $final_days1=[];


            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
            foreach($yr as $key => $y){
            $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
            }
            $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
            

                    $this->db->select('Date');
                    $query = $this->db->get('gc_individual_calendar');
                    if ($query->num_rows() > 0) {
                        $db_leave=$query->result_array();
                    }else{
                        $db_leave=[];
                    }

                    $empt_leave=[];
                    foreach($db_leave as $lv){
                        array_push($empt_leave,$lv['Date']);

                    }
                    $final_dates=array_values(array_diff($final_dates,$empt_leave));
                }
                if(in_array($Cal_date, $final_dates)){
                    $pay_date=$Cal_date;
                }else{
                    $pay_date=$this->get_next_paydate($Cal_date);
                }

            return $pay_date;
}

public function get_next_paydate($cur_date){
$final_dates=[];
$yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

        $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));

    foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
    
    $keyval= $key;
    if(isset($final_dates[$keyval])){
        return $final_dates[$keyval];
    }else{
        return date('Y-01-01');
    }
    
    break;
}else{
    $keyval=$key;
    return $final_dates[$keyval];
}
    }
}

    }

public function get_three_yrs_holidays($year,$week_days){

//$week_days=['6','7'];
            //var_dump($week_days);
$date=new DateTime();
//$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

    if($week_days[$i] == $search){
        $arr[$i] = $week_days[$i];
        $search = $week_days[$i] + 1;
    }else{
        $arr2[$i] = $week_days[$i];
    }
}

$action = array_merge($arr,$arr2);
$days = array(
     '1' => 'Monday',
     '2' => 'Tuesday',
     '3' => 'Wednesday',
     '4' => 'Thursday',
     '5' => 'Friday',
     '6' => 'Saturday',
     '7' => 'Sunday'
 );
$final_dt=[];
//var_dump($action);
foreach($action as $da){
if (array_key_exists($da,$days))
  {
    //$sim=array('N' => $days[$da], 'A' => $da);
  array_push($final_dt,$days[$da]);
  }

}
//var_dump($final_dt);

$final_dates=[];
for($i=1; $i<=52; $i++){
        foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
        array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
        }
    }
    return $final_dates;
}

     public function member_profile_attachment($dir) { 

                  // create an album if not already exist in uploads dir
                  // wouldn't make more sence if this part is done if there are no errors and right before the upload ??
                  //var_dump($dir);
                  if (!is_dir('./attachments/Members/' .$dir))
                  {
                      mkdir('./attachments/Members/' .$dir, 0777, true);
                  }
                  $dir_exist = true; // flag for checking the directory exist or not
                  if (!is_dir('./attachments/Members/' .$dir))
                  {
                      mkdir('./attachments/Members/' .$dir, 0777, true);
                      $dir_exist = false; // dir not exist
                  }
                      
                 $config['upload_path']          = './attachments/Members/'.$dir.'/';
                 $config['allowed_types']        = 'gif|jpg|png|doc|pdf|docx';
                 $config['max_size']             = 10000; 
                 $new_name                       = $dir.'_Profile';
                 $config['file_name']            = $new_name;
                  

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('Photo'))
                {
                         $error = array('error' => $this->upload->display_errors());
                          $file_name = '';
                          return $error;                     
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];
                        
                        return $file_name;
                }
        }        


function get_child_by_parent_cont($id) { 

         $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Membership_code,member.Current_level,tree.Child_ID,member.Photo,member.Members_count,member.Created_date,tree.Parent_ID,table2.Amount as initialamt');
         $this->db->select('members.First_name as parentfname,members.Membership_code as parentmemcode');
         $this->db->from('gc_franchisee_member_relation as tree');
         $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
         $this->db->join('gc_membership as members', 'members.Membership_ID = tree.Parent_ID', 'left');
         // $this->db->join('gc_tree_color_setting as table1', 'table1.Member_type = member.Membership_type', 'left');
         $this->db->join('gc_member_franchisee_contract as table2', 'table2.Membership_ID = member.Membership_ID', 'left');
         // $this->db->join('gc_member_topup as table3', 'table3.ID = table2.Topup_id', 'left');

        // $this->db->where('table1.Member_level',1);
        $this->db->where('table2.Invest_type',1);
        $this->db->where('tree.Parent_ID',$id);
        $this->db->group_by('table2.Membership_ID');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        // return 0;
    }

function get_child_by_parent_contract($id) { 
    // var_dump($id);die();    
         $this->db->select('sum(table2.Amount) as contract');
         $this->db->from('gc_franchisee_member_relation as tree');
         $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
         $this->db->join('gc_membership as members', 'members.Membership_ID = tree.Parent_ID', 'left');
         $this->db->join('gc_member_franchisee_contract as table2', 'table2.Membership_ID = member.Membership_ID', 'left');
         // $this->db->join('gc_member_topup as table3', 'table3.ID = table2.Topup_id', 'left');
        $this->db->where('table2.Invest_type',2);
        $this->db->where('member.Membership_ID',$id);
        // $this->db->where('tree.Parent_ID',$id);
        // $this->db->group_by('table2.Membership_ID');
        // $this->db->group_by('table3.Value');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        // return 0;
    }


function get_child_by_parent_contract_initial($id) { 
    // var_dump($id);die();    
         $this->db->select('sum(table2.Amount) as contract_initial');
         $this->db->from('gc_franchisee_member_relation as tree');
         $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
         $this->db->join('gc_membership as members', 'members.Membership_ID = tree.Parent_ID', 'left');
         $this->db->join('gc_member_franchisee_contract as table2', 'table2.Membership_ID = member.Membership_ID', 'left');

        $this->db->where('table2.Invest_type',1);
        $this->db->where('member.Membership_ID',$id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
    }

    public function member_profile_attachment_1($ref_no,$profile_name,$name) {     

           if (!is_dir('./attachments/Members/'.$ref_no))
                  {
                      mkdir('./attachments/Members/'.$ref_no, 0777, true);
                  }
                  $dir_exist = true; 
                  if (!is_dir('./attachments/Members/'.$ref_no))
                  {
                      mkdir('./attachments/Members/'.$ref_no, 0777, true);
                      $dir_exist = false; // dir not exist
                  }

         $config['upload_path']          = './attachments/Members/'.$ref_no.'/';
         $config['allowed_types']        = 'gif|jpg|png|pdf';
         $new_name                       = $ref_no.'_'.$name;
         $config['file_name']            = $new_name;

         
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ( ! $this->upload->do_upload($profile_name))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $file_name = '';
                        //print_r($error);
                         return $file_name;                 
                }
                else
                {   
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];
                        // die();
                        return $file_name;
                }

    }


    public function member_profile_attachments($ref_no,$profile_name,$name) {     

        mkdir('./attachments/Members/'.$ref_no, 0777, true);

         $config['upload_path']          = './attachments/Members/'.$ref_no.'/';
         $config['allowed_types']        = 'gif|jpg|png|pdf';
         $new_name                       = $ref_no.'_'.$name;
         $config['file_name']            = $new_name;

         
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                if ( ! $this->upload->do_upload($profile_name))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $file_name = '';
                         return $file_name;                 
                }
                else
                {   
                        $data = array('upload_data' => $this->upload->data());
                        $upload_data = $this->upload->data(); 
                        $file_name =   $upload_data['file_name'];
                        return $file_name;
                }

    }

}



