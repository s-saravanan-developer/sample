<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Report_model extends CI_Model { 



       public function get_today_payout_history($mobile) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',1);
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_payout_history1($mobile,$date) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
     if(!empty($date)){
        $this->db->where("commission.Recieved_date",$date);
     }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_payout_history2($commission_type,$level_type,$s_date,$e_date,$mobile,$payout_list,$payment_list) {
    // var_dump($mobile);

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_member_commission_details as cmsn', 'cmsn.Commision_detail_ID = commission.Commision_detail_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Generated_date',date('Y-m-d'));
        //$this->db->where('commission.Payout_status',1);

        if(!empty($commission_type)){
        $this->db->where("commission.Commission_type",$commission_type);
     }
     // if(!empty($level_type)){
     //    $this->db->where("contract.Topup_id",$level_type);
     // }
     if(!empty($payout_list)){
        $this->db->where("cmsn.Payout_ID ",$payout_list);
     }

    if(!empty($payment_list)){
        $this->db->where("commission.Payout_status ",$payment_list);
     }

     if(!empty($s_date)){
        $this->db->where("commission.Recieved_date >=",$s_date);
     }
     if(!empty($e_date)){
        $this->db->where("commission.Recieved_date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    public function get_all_level_types() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_all_commission_types() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_commission');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_all_payout_types() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_payout_type');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    

    public function get_all_topups() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_member_topup');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    public function get_all_withdraw_req() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_withdraw');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_transaction_history($mobile) {
    $this->db->select('history.*,member.First_name,member.Last_name,member.Mobile,member.Membership_code,payout.payout_type as Payout_type,commision.Commission as Commission_name');
    $this->db->from('gc_transaction_history as history');
        $this->db->join('gc_membership as member', 'member.Membership_ID = history.Membership_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = history.Payout_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = history.Contract_ID', 'left');
        $this->db->join('gc_member_payouts as pays', 'pays.Payout_ID = history.Payout', 'left');
        $this->db->join('gc_commission as commision', 'commision.ID = pays.Commission_type', 'left');
     $this->db->where("history.Status",1);
     $this->db->where("history.Date",date('Y-m-d'));
       $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);
    $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_transaction_history1($mobile,$date) {
    $this->db->select('history.*,member.First_name,member.Last_name,member.Mobile,member.Membership_code,payout.payout_type as Payout_type');
    $this->db->from('gc_transaction_history as history');
        $this->db->join('gc_membership as member', 'member.Membership_ID = history.Membership_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = history.Payout_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = history.Contract_ID', 'left');
     $this->db->where("history.Status",1);
     //$this->db->where("history.Date",date('Y-m-d'));
     // if(!empty($commission_type)){
     //    $this->db->where("history.Date",date('Y-m-d'))
     // }
    if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
     if(!empty($date)){
        $this->db->where("history.Date",$date);
     }
    $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
public function get_transaction_history2($commission_type,$topup_list,$transaction_type,$s_date,$e_date,$mobile,$contract) {
    $this->db->select('history.*,member.First_name,member.Last_name,member.Mobile,member.Membership_code,payout.payout_type as Payout_type,commision.Commission as Commission_name');
    $this->db->from('gc_transaction_history as history');
        $this->db->join('gc_membership as member', 'member.Membership_ID = history.Membership_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = history.Payout_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = history.Contract_ID', 'left');
        $this->db->join('gc_member_payouts as pays', 'pays.Payout_ID = history.Payout', 'left');
        $this->db->join('gc_commission as commision', 'commision.ID = pays.Commission_type', 'left');
     $this->db->where("history.Status",1);
     //$this->db->where("history.Date",date('Y-m-d'));
     if(!empty($commission_type)){
        $this->db->where("pays.Commission_type",$commission_type);
     }
     if(!empty($topup_list)){
        $this->db->where("contract.Topup_id",$topup_list);
     }
     if(!empty($contract)){
        $this->db->where("contract.Contract_ID",$contract);
     }
     if(!empty($transaction_type)){
        $transaction_type=explode(',',$transaction_type);
        $this->db->where_in("history.Type",$transaction_type);
     }
     if(!empty($s_date)){
        $this->db->where("history.Date >=",$s_date);
     }
     if(!empty($e_date)){
        $this->db->where("history.Date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
    $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
    

}