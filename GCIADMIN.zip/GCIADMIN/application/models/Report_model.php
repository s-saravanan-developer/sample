<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Report_model extends CI_Model { 



       public function get_today_payout_history() {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

   public function get_today_payouts() {
        // $pre_date=$this->get_previous_date1(date('Y-m-d')); 
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no,member.Register_from');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       
        // $this->db->where('commission.Commision_date',$pre_date);
        $this->db->where('commission.Payout_date',date('Y-m-d'));
        $this->db->where('commission.Status',1);
        $this->db->where('bank.Membership_ID IS NOT NULL');
        $this->db->where('commission.Amount!=',0);
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
        	// echo '<pre>';
        	// print_r($query->result_array());die();
            $result=$query->result_array();
            // return  $query->result_array();
            // var_dump($query->result_array());die();
            foreach ($result as $key => $value) {

            	$total_invest=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->row()->Amount;
            	// echo '<br>';

            	$total_earned=$this->db->select('sum(Amount) as Amount')->where(array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->get('gc_member_commission_details')->row()->Amount;
if(!empty($value['Membership_ID']) && !empty($value['Contract_ID'])){
	if($value['Register_from']=='member'){
            		$pay_modes=$this->db->get_where('gc_wallet_payments',array('Membership_ID' => $value['Membership_ID']))->result_array();
            		if(!empty($pay_modes)){
            			$pay_mode=$pay_modes[0]['Payment_type_ID'];
            		}else{
            			$pay_mode=7;
            		}
            	}else{
            		$pay_modes=$this->db->get_where('gc_member_payments',array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->result_array();
            		if(!empty($pay_modes)){
            			$pay_mode=$pay_modes[0]['Payment_type_ID'];
            		}else{
            			$pay_mode=7;
            		}
            	}
            }else{
            	$pay_mode=7;
            }
            	
            	
            	// die();
            	if($pay_mode==12){
            		if(($total_earned-$value['Amount'])<=$total_invest){
            		$result[$key]['Member_status']=1;
            	}else{
            		$result[$key]['Member_status']=0;
            	}
            	}else{
            		$result[$key]['Member_status']=0;
            	}
            	// if(($total_earned-$value['Amount'])<=$total_invest){
            	// 	$result[$key]['Member_status']=1;
            	// }else{
            	// 	$result[$key]['Member_status']=0;
            	// }
            }
            return $result;
        }
        return NULL;
    }

function sam(){
	return 'saravanan';
}

  public  function get_curent_payout_date($Membership_ID,$cr_date){
  	$cr_date=date('Y-m-d',strtotime($cr_date));
    	$ctrt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->result_array();
    	if(!empty($ctrt)){
    		// $cr_date='2019-03-20';
    		$start=new DateTime(date('d-m-Y',strtotime($ctrt[0]['Start_date'])));
    		$end=new DateTime(date('d-m-Y',strtotime($ctrt[0]['End_date'])));

          	$daterange = new DatePeriod($start, new DateInterval('P14D'), $end);
          	foreach($daterange as $key_1=> $date){ 
          		$k=date('d-m-Y', strtotime($date->format("d-m-Y"). ' + 14 days'));
          		if($key_1==0){
    								$l=$this->Membership_model->get_excat_next_payout($k);
    							}else{
    								$l=$this->Membership_model->get_excat_next_payout(date('d-m-Y', strtotime($l. ' + 14 days')));
    							}

    							if($l >= $cr_date){
    								$n=$l;
    								break;
    							}

			}
			return $n;
    	}
    	
    }


public function get_payout_details_condensed($date) {
        // $pre_date=$this->get_previous_date1($date);
        $this->db->select('commission.Payout_date,commission.Commision_date,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no,member.Register_from,contract.Date as Contract_date,contract.Amount as Contract_amount');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
       
        // $this->db->where('commission.Commision_date',$pre_date);
        $this->db->where('commission.Payout_date',$date);
        // $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Membership_ID');
        // $this->db->group_by('commission.Commision_date');
        $this->db->where('bank.Membership_ID IS NOT NULL');
        $this->db->where('commission.Amount!=',0);
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
        	// echo '<pre>';
        	// print_r($query->result_array());die();
            $result=$query->result_array();
            // return  $query->result_array();
            // var_dump($query->result_array());die();
            foreach ($result as $key => $value) {

            	$total_invest=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $value['Membership_ID']))->row()->Amount;
            	// $total_invest=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->row()->Amount;
            	// echo '<br>';

            	$total_earned=$this->db->select('sum(Amount) as Amount')->where(array('Membership_ID' => $value['Membership_ID']))->get('gc_member_commission_details')->row()->Amount;

            	// $total_earned=$this->db->select('sum(Amount) as Amount')->where(array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->get('gc_member_commission_details')->row()->Amount;
				if(!empty($value['Membership_ID']) && !empty($value['Contract_ID'])){
			if($value['Register_from']=='member'){
            		$pay_modes=$this->db->get_where('gc_wallet_payments',array('Membership_ID' => $value['Membership_ID']))->result_array();
            		if(!empty($pay_modes)){
            			$pay_mode=$pay_modes[0]['Payment_type_ID'];
            		}else{
            			$pay_mode=7;
            		}
            	}else{
            		$pay_modes=$this->db->get_where('gc_member_payments',array('Membership_ID' => $value['Membership_ID']))->result_array();
            		// $pay_modes=$this->db->get_where('gc_member_payments',array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->result_array();
            		if(!empty($pay_modes)){
            			$pay_mode=$pay_modes[0]['Payment_type_ID'];
            		}else{
            			$pay_mode=7;
            		}
            	}
            }else{
            	$pay_mode=7;
            }
            	
            	
            	// die();
            	if($pay_mode==12){
            		if(($total_earned-$value['Amount'])<=$total_invest){
            		$result[$key]['Member_status']=1;
            	}else{
            		$result[$key]['Member_status']=0;
            	}
            	}else{
            		$result[$key]['Member_status']=0;
            	}
            	// if(($total_earned-$value['Amount'])<=$total_invest){
            	// 	$result[$key]['Member_status']=1;
            	// }else{
            	// 	$result[$key]['Member_status']=0;
            	// }
            }
            return $result;
        }
        return NULL;
    } 


 
public function get_downline_payout_details($date,$mobile) {

	$where = '(Membership_code="'.$mobile.'" or Mobile = "'.$mobile.'")';
	$membership_id=$this->db->where($where)->get('gc_membership')->row('Membership_ID');

	$final_array=[];
	$final_left_tree=[];
    $membership_id=[$membership_id];
    if(!empty($membership_id)){
    			$limit=1;
                        for($i=1;$i<=$limit;$i++){

                            $this->db->select('tree.Child_ID,member.Membership_code,CONCAT(member.First_name,member.Last_name) as Name,member.Mobile,member.Current_level,commission.Contract_ID,commission.Payout_date,py.Payment_mode');
            				$this->db->from('gc_franchisee_member_relation as tree');
            				$this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
            				$this->db->join('gc_member_commission_details as commission', 'commission.Membership_ID = tree.Child_ID', 'left');
            				$this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
            				$this->db->join('gc_payment_mode as py', 'py.ID = contract.Payment_mode', 'left');
            				$this->db->where_in('tree.Parent_ID',$membership_id);
            				$this->db->where('commission.Payout_date',$date);
            				$this->db->group_by('member.Membership_ID');
            				$query4 = $this->db->get();

                            if($query4->num_rows() > 0){
                                $binary4=$query4->result_array();
                                $membership_id=[];
                                foreach ($binary4 as $key => $value) {
                                	$tmp=[];
                                	array_push($membership_id,$value['Child_ID']);
                					$tmp=array('Membership_ID'=>$value['Child_ID'],
            								'Membership_code'=>$value['Membership_code'],
            								'Name'=>$value['Name'],
            								'Level'=>$value['Current_level'],
            								'Mobile'=>$value['Mobile'],
            								'Contract_ID'=>$value['Contract_ID'],
            								'Payout_date'=>$value['Payout_date'],
            								'Payment_mode'=>$value['Payment_mode']);
                					array_push($final_array,$tmp);
                                }
                                // echo "<pre>";
                                // print_r($membership_id);
                                $limit++;
                            }else{
                            	$membership_id=[];
                            }
            
                        }
    }
						
                        // echo "<pre>";
                        // print_r($final_left_tree);
                        // print_r($final_array);
                        return $final_array;


}   

public function get_payout_details_condensed1($date) {
        // $pre_date=$this->get_previous_date1($date);
        $this->db->select('commission.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no,contract.Amount as Contract_amount,contract.Date as Contract_date');
        $this->db->from('gc_member_commission_details as commission');
        
        // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        // $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
        $this->db->where('commission.Payout_date',$date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Membership_ID');
        // $this->db->where('commission.Payout_ID',1);
        // if(!empty($mobile)){
        // $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        // $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    } 


public function get_today_membership($from_date,$to_date,$membership_ID,$invest) {
        $this->db->select('member.Activated_date,member.Membership_ID,member.Reference_ID,member.Reference_code,member.First_name,member.Last_name,member.Register_from,paymode.Payment_mode,member.Created_date as Member_created_date,member.F_f_name,member.Mobile,member.Gender,member.Members_count,member.Membership_code,member.Status as Member_status,type.Membership_type,bank.Status as Bank_status,payments.Payment_status,bank.Bank_ID as Bank_Bank_ID,contract.Contract_ID,contract.Contract_status_date,bank.Status as Bank_status,contract.Date as Contract_date,contract.Start_date,contract.Amount,contract.End_date,contract.Contract_ref_no,contract.Invest_type,document.Document_type,document.Document_no,address.Address_1,address.Pincode,area.area_name,city.city_name,state.state_name,payout.payout_type,users.firstname,users1.og_password');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_payment_mode as paymode', 'payments.Payment_type_ID = paymode.ID', 'left');
        $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_users as users', 'users.id = member.Created_by', 'left');
        $this->db->join('gc_users as users1', 'users1.user_id = member.Membership_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = member.Payout_ID', 'left');
        $this->db->join('gc_areas as area', 'area.id = address.Area', 'left');
        $this->db->join('gc_cities as city', 'city.id = address.City', 'left');
        $this->db->join('gc_states as state', 'state.id = address.State', 'left');
        $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
        $this->db->group_by("member.Membership_ID");
        $this->db->group_by("contract.Contract_ID");
        if(!empty($from_date)){
        	// $this->db->where("member.Created_date >=",$from_date);
        	$where1='(DATE(member.Created_date)>="'.$from_date.'")';
        	$this->db->where($where1);
        	// $this->db->where("contract.Date >=",$from_date);
    	}

    	if(!empty($to_date)){
    		if($from_date!=$to_date){
        	// $this->db->where("member.Created_date <=",$to_date);
    		$where2='(DATE(member.Created_date)<="'.$to_date.'")';
        	$this->db->where($where2);
        	// $this->db->where("contract.Date <=",$to_date);
        }
    	}
        
        if(!empty($membership_ID)){
        	$where='(member.Membership_code="'.$membership_ID.'" or member.Mobile = "'.$membership_ID.'")';
        	$this->db->where($where);
    	}

        if(!empty($invest)){
            $this->db->where('contract.Invest_type',$invest);
        }  
        // $this->db->group_by("payments.Membership_ID");
        // $this->db->limit(250);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            // var_dump($query->result_array());die();
            return  $query->result_array();
        }
        return NULL;
}


public function get_payment_details($from_date,$to_date,$mobile){
	$this->db->select('commission.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        // $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
        // $this->db->where('commission.Commision_date',$pre_date);
        if(!empty($from_date)){
        	$this->db->where('commission.Payout_date >=',$from_date);
        }
        if(!empty($to_date)){
        	$this->db->where('commission.Payout_date <=',$to_date);
        }
        $this->db->where('commission.Status',6);
        $this->db->group_by('commission.Membership_ID');
        $this->db->group_by('commission.Payout_date');
        // $this->db->where('commission.Payout_ID',1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
        	return $result=$query->result_array();
        }else{
        	return NULL;
        }
}


public function get_payout_summary($mobile){
	$this->db->select('commission.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        // $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        // $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
        // $this->db->where('commission.Commision_date',$pre_date);
        // if(!empty($from_date)){
        // 	$this->db->where('commission.Payout_date >=',$from_date);
        // }
        // if(!empty($to_date)){
        // 	$this->db->where('commission.Payout_date <=',$to_date);
        // }
        // $this->db->where('commission.Status',6);
        $this->db->group_by('commission.Membership_ID');
        $this->db->group_by('commission.Payout_date');
        // $this->db->where('commission.Payout_ID',1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
        	return $result=$query->result_array();
        }else{
        	return NULL;
        }
}



public function get_level_details($membership_code){
	$where = '(Membership_code="'.$membership_code.'" or Mobile = "'.$membership_code.'")';
	$membership_id=$this->db->where($where)->get('gc_membership')->row('Membership_ID');

	$final_array=[];
	$limit=1;
        for($i=1;$i<=$limit;$i++){
            $this->db->select('tree.Parent_ID,member.Membership_code,CONCAT(member.First_name,member.Last_name) as Name,member.Mobile,member.Current_level');
            $this->db->from('gc_franchisee_member_relation as tree');
            $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Parent_ID', 'left');
            $this->db->where('tree.Child_ID',$membership_id);
            
            $query = $this->db->get();
            if($query->num_rows() > 0){
            	$tmp=[];
                $binary4=$query->result_array();
                $membership_id=$binary4[0]['Parent_ID'];
                $tmp=array('Membership_ID'=>$binary4[0]['Parent_ID'],
            			'Membership_code'=>$binary4[0]['Membership_code'],
            			'Name'=>$binary4[0]['Name'],
            			'Level'=>$binary4[0]['Current_level'],
            			'Mobile'=>$binary4[0]['Mobile']);
                array_push($final_array,$tmp);
                $limit++;
            }
        
        }

return $final_array;

}

public function get_initial($Membership_ID){
return $this->db->select('sum(Amount) as initial,Date')->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->get('gc_member_franchisee_contract')->result_array();
}

public function get_topup($Membership_ID){
return $this->db->select('sum(Amount) as topup')->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>2))->get('gc_member_franchisee_contract')->result_array();
}


public function get_downline_contract($membership_code){
	$where = '(Membership_code="'.$membership_code.'" or Mobile = "'.$membership_code.'")';
	$membership_id=$this->db->where($where)->get('gc_membership')->row('Membership_ID');
	return $this->db->get_where('gc_member_franchisee_contract',array('Membership_ID'=>$membership_id,'Contract_status'=>6,'Withdrawn_status'=>5))->result_array();
}

public function get_downline_details($membership_code){
	$where = '(Membership_code="'.$membership_code.'" or Mobile = "'.$membership_code.'")';
	$membership_id=$this->db->where($where)->get('gc_membership')->row('Membership_ID');

	$final_array=[];
	$final_left_tree=[];
    $membership_id=[$membership_id];
    if(!empty($membership_id)){
    			$limit=1;
                        for($i=1;$i<=$limit;$i++){

                            $this->db->select('tree.Child_ID,member.Membership_code,CONCAT(member.First_name,member.Last_name) as Name,member.Mobile,member.Current_level');
            				$this->db->from('gc_franchisee_member_relation as tree');
            				$this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
            				$this->db->where_in('tree.Parent_ID',$membership_id);
            				$query4 = $this->db->get();

                            if($query4->num_rows() > 0){
                                $binary4=$query4->result_array();
                                $membership_id=[];
                                foreach ($binary4 as $key => $value) {
                                	$tmp=[];
                                	array_push($membership_id,$value['Child_ID']);
                					$tmp=array('Membership_ID'=>$value['Child_ID'],
            								'Membership_code'=>$value['Membership_code'],
            								'Name'=>$value['Name'],
            								'Level'=>$value['Current_level'],
            								'Mobile'=>$value['Mobile']);
                					array_push($final_array,$tmp);
                                }
                                // echo "<pre>";
                                // print_r($membership_id);
                                $limit++;
                            }else{
                            	$membership_id=[];
                            }
            
                        }
    }
						
                        // echo "<pre>";
                        // print_r($final_left_tree);
                        // print_r($final_array);
                        return $final_array;

}


public function get_payout_details($mobile,$date) {
        $pre_date=$this->get_previous_date1($date);
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
        // $this->db->where('commission.Commision_date',$pre_date);
        $this->db->where('commission.Payout_date',$date);
        $this->db->where('commission.Status',1);
        // $this->db->where('commission.Payout_ID',1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
        	$result=$query->result_array();
            // return  $query->result_array();
            // var_dump($query->result_array());die();
            foreach ($result as $key => $value) {
            	$total_invest=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->row()->Amount;
            	// echo '<br>';

            	$total_earned=$this->db->select('sum(Amount) as Amount')->where(array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->get('gc_member_commission_details')->row()->Amount;

            	$pay_mode=$this->db->get_where('gc_member_payments',array('Membership_ID' => $value['Membership_ID'],'Contract_ID' => $value['Contract_ID']))->result_array();
            	// die();
            	if($pay_mode==12){
            		if(($total_earned-$value['Amount'])<=$total_invest){
            		$result[$key]['Member_status']=1;
            	}else{
            		$result[$key]['Member_status']=0;
            	}
            	}else{
            		$result[$key]['Member_status']=0;
            	}
            	// if(($total_earned-$value['Amount'])<=$total_invest){
            	// 	$result[$key]['Member_status']=1;
            	// }else{
            	// 	$result[$key]['Member_status']=0;
            	// }
            }
            return $result;
        }
        return NULL;
    }

public function get_payout_topup1($Membership_Id,$date,$Commision_type,$contract_ID){
        $this->db->select('sum(Amount) as Amount,Status');
        $this->db->from('gc_member_commission_details');
        $this->db->where('Membership_ID',$Membership_Id);
        $this->db->where('Payout_date',$date);
        $this->db->where('Contract_ID',$contract_ID);
        $this->db->where('Commision_type',$Commision_type);
        // $this->db->where('Payout_ID',1);
        // $this->db->group_by('Contract_ID');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
}


public function get_payout_topup2($Membership_Id,$s_date,$e_date,$Commision_type){
        $this->db->select('sum(Amount) as Amount');
        $this->db->from('gc_member_commission_details');
        $this->db->where('Membership_ID',$Membership_Id);
        $this->db->where('Commision_type',$Commision_type);
        $this->db->where('Status',6);
            if(!empty($s_date)){
    			$s_date=date('Y-m-d',strtotime($s_date));
        		$this->db->where("Payout_date >=",$s_date);
     		}
     		if(!empty($e_date)){
     			$e_date=date('Y-m-d',strtotime($e_date));
        		$this->db->where("Payout_date <=",$e_date);
     		}

        $query = $this->db->get()->result_array();
    	   if(!empty($query)){
    	   	if(!empty($query[0]['Amount'])){
				return $query[0]['Amount'];
    	   	}else{
    	   		return 0;
    	   	}
			}else{
				return 0;
			}
}
  
   public function get_payout_topup3($Membership_Id,$s_date,$e_date,$Commision_type,$Contract_ID){
        $this->db->select('sum(Amount) as Amount');
        $this->db->from('gc_member_commission_details');
        $this->db->where('Membership_ID',$Membership_Id);
        $this->db->where('Commision_type',$Commision_type);
        $this->db->where('Contract_ID',$Contract_ID);
        $this->db->where('Status',6);
            if(!empty($s_date)){
    			$s_date=date('Y-m-d',strtotime($s_date));
        		$this->db->where("Payout_date >=",$s_date);
     		}
     		if(!empty($e_date)){
     			$e_date=date('Y-m-d',strtotime($e_date));
        		$this->db->where("Payout_date <=",$e_date);
     		}

        $query = $this->db->get()->result_array();
    	   if(!empty($query)){
    	   	if(!empty($query[0]['Amount'])){
				return $query[0]['Amount'];
    	   	}else{
    	   		return 0;
    	   	}
			}else{
				return 0;
			}
}

public function get_roi($Membership_Id,$contract_ID){
	if(!empty($contract_ID)){
	return $this->db->select('sum(Amount) as ROI')->where(array('Membership_ID'=>$Membership_Id,'Contract_ID'=>$contract_ID,'Commision_type'=>1,'Status'=>6))->get('gc_member_commission_details')->result_array();
	}else{
		return NULL;
	}
}

public function get_investment_record($mobile,$s_date,$e_date){

	$this->db->select('member.Membership_ID,member.Membership_code,CONCAT(member.First_name,member.Last_name) as Name,member.Created_date,contract.Contract_ID,contract.Contract_ref_no,contract.Amount,contract.Date,contract.Start_date,contract.End_date');
	$this->db->select('SUM(commission.Amount) as ROI');
	$this->db->from('gc_membership as member');
	$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=member.Membership_ID','left');
	$this->db->join('gc_member_commission_details as commission','commission.Contract_ID=contract.Contract_ID','left');
	$this->db->where(array('contract.Contract_status'=>6,'contract.Withdrawn_status'=>5,'commission.Commision_type'=>1,'commission.Status'=>6));
	$this->db->group_by('commission.Contract_ID');

	if(!empty($s_date)){
		$s_date=date('Y-m-d',strtotime($s_date));
        $this->db->where("contract.Date >=",$s_date);
     }
     if(!empty($e_date)){
     	$e_date=date('Y-m-d',strtotime($e_date));
        $this->db->where("contract.Date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;

} 

public function get_investment_record1($mobile,$s_date,$e_date){

	$this->db->select('member.Membership_ID,member.Membership_code,CONCAT(member.First_name,member.Last_name) as Name,member.Created_date,contract.Contract_ID,contract.Contract_ref_no,contract.Amount,contract.Date,contract.Start_date,contract.End_date');
	// $this->db->select('SUM(commission.Amount) as ROI');
	$this->db->from('gc_membership as member');
	$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=member.Membership_ID','left');
	// $this->db->join('gc_member_commission_details as commission','commission.Contract_ID=contract.Contract_ID','left');
	// $this->db->where(array('contract.Contract_status'=>6,'contract.Withdrawn_status'=>5,'commission.Commision_type'=>1,'commission.Status'=>6));
	// $this->db->group_by('commission.Contract_ID');

	if(!empty($s_date)){
		$s_date=date('Y-m-d',strtotime($s_date));
        $this->db->where("DATE(member.Created_date) >=",$s_date);
     }
     if(!empty($e_date)){
     	$e_date=date('Y-m-d',strtotime($e_date));
        $this->db->where("DATE(member.Created_date) <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;

}  

public function get_level_investment_record($mobile,$s_date,$e_date){

	$this->db->select('member.Membership_ID,member.Membership_code,member.First_name,member.Last_name,contract.Contract_ID,SUM(contract.Amount) as Initial');
	// $this->db->select('SUM(commission.Amount) as ROI');
	$this->db->from('gc_membership as member');
	$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=member.Membership_ID','left');
	// $this->db->join('gc_member_commission_details as commission','commission.Contract_ID=contract.Contract_ID','left');
	// $this->db->where(array('contract.Contract_status'=>6,'contract.Withdrawn_status'=>5,'commission.Commision_type'=>1,'commission.Status'=>6));
	$this->db->where('member.Status',6);
	$this->db->where('contract.Invest_type',1);
	$this->db->group_by('member.Membership_ID');
	if(!empty($s_date)){
		$s_date=date('Y-m-d',strtotime($s_date));
        $this->db->where("DATE(member.Created_date) >=",$s_date);
     }
     if(!empty($e_date)){
     	$e_date=date('Y-m-d',strtotime($e_date));
        $this->db->where("DATE(member.Created_date) <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;

}




public function get_payout_topup($Membership_Id,$date,$Commision_type){
        $this->db->select('sum(Amount) as Amount');
        $this->db->from('gc_member_commission_details');
        $this->db->where('Membership_ID',$Membership_Id);
        $this->db->where('Payout_date',$date);
        // $this->db->where('Commision_date',$commision_date);
        $this->db->where('Commision_type',$Commision_type);
        // $this->db->where('Payout_ID',1);
        // $this->db->group_by('Contract_ID');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
}    

public function get_benefit($Membership_Id,$date){
	return $this->db->get_where('gc_green_star',array('Membership_ID'=>$Membership_Id,'Payout_date'=>$date,'Status'=>1))->result_array();
}


public function get_lvl_pays($Membership_Id,$date,$level){
        $this->db->select('sum(commission.Amount) as Amount');
        $this->db->from('gc_member_commission_details as commission');
        $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
$this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
        $this->db->where('commission.Membership_ID',$Membership_Id);
        $this->db->where('commission.Payout_date',$date);
        // $this->db->where('commission.Commision_date',$commision_date);
        $this->db->where('level_det.Level_ID',$level);
        // $this->db->where('Commision_type',$Commision_type);
        // $this->db->where('Payout_ID',1);
        // $this->db->group_by('Contract_ID');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
}

public function get_lvl_pays1($Membership_Id,$date,$level,$contract_ID){
        $this->db->select('sum(commission.Amount) as Amount');
        $this->db->from('gc_member_commission_details as commission');
        $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
$this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
        $this->db->where('commission.Membership_ID',$Membership_Id);
        $this->db->where('commission.Payout_date',$date);
        $this->db->where('commission.Contract_ID',$contract_ID);
        $this->db->where('level_det.Level_ID',$level);
        // $this->db->where('Commision_type',$Commision_type);
        // $this->db->where('Payout_ID',1);
        // $this->db->group_by('Contract_ID');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
}

public function get_direct_investment($Membership_Id,$date,$level){
        $this->db->select('sum(contract.Amount) as Amount,member.Members_count,member.Membership_ID,count(level_det.Child_ID) as Mem_count');
        $this->db->from('gc_member_commission_details as commission');
        $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level_det.Child_ID', 'left');
		$this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
		$this->db->join('gc_membership as member', 'member.Membership_ID = '.$Membership_Id, 'left');
        $this->db->where('commission.Membership_ID',$Membership_Id);
        $this->db->where('commission.Payout_date',$date);
        // $this->db->where('commission.Commision_date',$commision_date);
        $this->db->where('level_det.Level_ID',$level);
        // $this->db->where('Commision_type',$Commision_type);
        // $this->db->where('Payout_ID',1);
        // $this->db->group_by('member.Membership_ID');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
}


function get_direct_investment1($id) {

        $this->db->select('sum(contract.Amount) as Amount,member.Members_count');
        $this->db->from('gc_member_franchisee_contract as contract');
        $this->db->join('gc_member_level_details as level', 'level.Child_ID = contract.Membership_ID', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = '.$id, 'left');
        $this->db->where('level.Membership_ID',$id);
        $this->db->where('level.Level_ID',1);
        $this->db->where('contract.Withdrawn_status',5);
        $this->db->where('contract.Contract_status',6);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_payout_history1($mobile,$date) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,contract.Contract_ref_no');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
     if(!empty($date)){
        $this->db->where("commission.Recieved_date",$date);
     }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


public function get_payout_history2($commission_type,$s_date,$e_date,$mobile,$payment_list) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,contract.Contract_ref_no');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',1);
        //$this->db->where('commission.Generated_date',date('Y-m-d'));
        //$this->db->where('commission.Payout_status',1);


     // if(!empty($level_type)){
     //    $this->db->where("contract.Topup_id",$level_type);
     // }
     // if(!empty($payout_list)){
     //    $this->db->where("cmsn.Payout_ID ",$payout_list);
     // }

    // if(!empty($payment_list)){
    //     $this->db->where("commission.Payout_status ",$payment_list);
    //  }

     if(!empty($commission_type)){
        $this->db->where("commission.Commission_type",$commission_type);
     }
if(!empty($s_date)){
        $this->db->where("commission.Recieved_date >=",$s_date);
     }
     if(!empty($e_date)){
        $this->db->where("commission.Recieved_date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    public function get_gold_members($s_date,$e_date,$mobile){
    	$this->db->select('gold.Gold_ID,gold.Membership_ID,sum(gold.Offer_value) as Offer_value,member.First_name,member.Last_name,member.Membership_code,member.Mobile,member.Member_grade');
        $this->db->from('gc_gold_offer as gold');
        
        $this->db->join('gc_membership as member', 'member.Membership_ID = gold.Membership_ID', 'left');

   		if(!empty($s_date)){
   		    $this->db->where("gold.Created_date >=",$s_date);
   		 }
   		 if(!empty($e_date)){
   		    $this->db->where("gold.Created_date <=",$e_date);
   		 }
   		 if(!empty($mobile)){
   		    $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
   		    $this->db->where($where);}

   		    $this->db->group_by('member.Membership_ID');

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    public function get_paid_mambers($s_date,$e_date,$mobile){
    $this->db->select('member.Membership_ID,member.Membership_code,CONCAT(member.First_name,member.Last_name) as Name,contract.Contract_ID,contract.Amount');
    $this->db->from('gc_membership as member');
    $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
    $this->db->where(array("contract.Contract_status"=>6,"contract.Invest_type"=>1));	
    if(!empty($mobile)){
   		    $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
   		    $this->db->where($where);
   		}

	$this->db->group_by('member.Membership_ID');
	$query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;

	}

	public function get_investment_paid_mambers($s_date,$e_date,$mobile){
    $this->db->select('member.Membership_ID,member.Membership_code,CONCAT(member.First_name,member.Last_name) as Name,contract.Contract_ID,contract.Amount,contract.Invest_type,contract.Contract_ref_no');
    $this->db->from('gc_membership as member');
    $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
    $this->db->where(array("contract.Contract_status"=>6));	
    if(!empty($mobile)){
   		    $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
   		    $this->db->where($where);
   		}

	$this->db->group_by('contract.Contract_ID');
	$this->db->order_by('member.Membership_ID');
	$query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;

	}




  public function get_star_members($mobile){
  	$where = '(Membership_code="'.$mobile.'" or Mobile = "'.$mobile.'")';
  	$query=$this->db->where($where)->get('gc_membership');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
  }


    public function get_star_member_details($Membership_ID){
  	$query=$this->db->where('Membership_ID',$Membership_ID)->get('gc_green_star');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
  }


    public function get_gold_member_details($mobile,$s_date,$e_date){
    $this->db->select('gold.Gold_ID,gold.Membership_ID,gold.Child_ID,gold.Offer_value,gold.Child_investment,gold.Level_ID,gold.Created_date,CONCAT(member.First_name,member.Last_name) as Name,member.Membership_code,member.Mobile,member.Member_grade');
        $this->db->from('gc_gold_offer as gold');
        
        $this->db->join('gc_membership as member', 'member.Membership_ID = gold.Child_ID', 'left');

    if(!empty($s_date)){
    	$s_date=date('Y-m-d',strtotime($s_date));
        $this->db->where("gold.Created_date >=",$s_date);
     }
     if(!empty($e_date)){
     	$e_date=date('Y-m-d',strtotime($e_date));
        $this->db->where("gold.Created_date <=",$e_date);
     }
     if(!empty($mobile)){
     	$this->db->where("gold.Membership_ID",$mobile);
        // $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        // $this->db->where($where);
     }

        $this->db->group_by('member.Membership_ID');

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }else{
        	return NULL;
        }
        

    }
public function get_payout_history3($commission_type,$s_date,$e_date,$mobile,$payment_list) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_member_commission_details as cmsn', 'cmsn.Commision_detail_ID = commission.Commision_detail_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Generated_date',date('Y-m-d'));
        //$this->db->where('commission.Payout_status',1);

        if(!empty($commission_type)){
        $this->db->where("commission.Commission_type",$commission_type);
     }
     // if(!empty($level_type)){
     //    $this->db->where("contract.Topup_id",$level_type);
     // }
     // if(!empty($payout_list)){
     //    $this->db->where("cmsn.Payout_ID ",$payout_list);
     // }

    if(!empty($payment_list)){
        $this->db->where("commission.Payout_status ",$payment_list);
     }

     if(!empty($s_date)){
        $this->db->where("commission.Recieved_date >=",$s_date);
     }
     if(!empty($e_date)){
        $this->db->where("commission.Recieved_date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    public function get_all_level_types() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

   public function get_all_levels() {
    $this->db->select('ID,Level,Alias_name');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_level');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    public function get_payment_mode_admin($id) 
    {
        $this->db->select('payments.*,mode.Payment_mode,from_bank.Bank_name as frombank,to_bank.Bank_name as tobank,member_bank.Account_no,member_bank.Branch,member_bank.IFSC');
        $this->db->from('gc_member_payments as payments');
        $this->db->join('gc_membership as member', 'member.Membership_ID = payments.Membership_ID', 'left');
        $this->db->join('gc_payment_mode as mode', 'mode.ID = payments.Payment_type_ID', 'left');
        $this->db->join('gc_bank as from_bank', 'from_bank.ID = payments.Bank_ID', 'left');
        $this->db->join('gc_bank as to_bank', 'to_bank.ID = payments.Deposit_Bank_ID', 'left');
        $this->db->join('gc_member_banks as member_bank', 'member_bank.membership_ID = member.Membership_ID', 'left');
        $this->db->where('payments.Membership_ID', $id);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }


    public function get_payment_mode_member($id) 
    {
        $this->db->select('payments.*,mode.Payment_mode,from_bank.Bank_name as frombank,to_bank.Bank_name as tobank,member_bank.Account_no,member_bank.Branch,member_bank.IFSC');
        $this->db->from('gc_wallet_payments as payments');
        $this->db->join('gc_membership as member', 'member.Membership_ID = payments.Membership_ID', 'left');
        $this->db->join('gc_payment_mode as mode', 'mode.ID = payments.Payment_type_ID', 'left');
        $this->db->join('gc_bank as from_bank', 'from_bank.ID = payments.Bank_ID', 'left');
        $this->db->join('gc_bank as to_bank', 'to_bank.ID = payments.Deposit_Bank_ID', 'left');
        $this->db->join('gc_member_banks as member_bank', 'member_bank.membership_ID = member.Membership_ID', 'left');
        $this->db->where('payments.Membership_ID', $id);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

   public function get_pay_modes($membership_ID,$date) {
    $this->db->select('mode.Payment_mode,topup.Total_amount,payment.Payment_status');
    $this->db->from('gc_wallet_topup as topup');
    $this->db->join('gc_wallet_payments as payment', 'payment.Service_point_ID = topup.Wallet_topup_ID', 'left');
    $this->db->join('gc_payment_mode as mode', 'mode.ID = payment.Payment_type_ID', 'left');
    $this->db->where("topup.Membership_ID",$membership_ID);
    $this->db->where("topup.Date",date('Y-m-d',strtotime($date)));
    // $this->db->where("Status",1);
    $pay_md=[];
    $query = $this->db->get('gc_level');
        if ($query->num_rows() > 0) {
        	$py_mode=[];
		if ($query->num_rows() > 0) {
			$data=$query->result_array();
			foreach ($data as $key => $value) {
				array_push($py_mode,$value['Payment_mode']);
			}
			array_push($pay_md,$data[0]['Total_amount']);
			array_push($pay_md,implode(',',array_unique($py_mode)));
			array_push($pay_md,$data[0]['Payment_status']);
			return $pay_md;
			// return number_format($data[0]['Total_amount'],2).' - '.implode(',',array_unique($py_mode));
			//return  $query->result_array();
		}
            // return  $query->result_array();
        }
        return $pay_md=[];
    }


       public function get_earning1($commission_type,$payment_status,$s_date,$e_date,$mobile,$contract,$level) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level.Level,commission.Status as Commission_status');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_member_level_details as level_det', 'level_det.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');

        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');

        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');

        $this->db->join('gc_level as level', 'level.ID = level_det.Level_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Commision_date',date('Y-m-d'));
        //$this->db->where('commission.Status',1);

        if(!empty($commission_type)){
        $this->db->where("commission.Commision_type",$commission_type);
     }
     if(!empty($payment_status)){
        $payment_status=explode(',',$payment_status);
        $this->db->where_in("commission.Status",$payment_status);
     }
    
     if(!empty($s_date)){
        $this->db->where("commission.Commision_date >=",$s_date);
     }
     if(!empty($e_date)){
        $this->db->where("commission.Commision_date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}

     //    if(!empty($topup)){
     //    $this->db->where("topup.ID",$topup);
     // }
     if(!empty($contract)){
        $this->db->where("contract.Contract_ID",$contract);
     }
     if(!empty($level)){
        $this->db->where("level.ID",$level);
     }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }



public function get_all_commission_types() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_commission');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_all_payout_types() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_payout_type');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    

    public function get_all_topups() {
    $this->db->select('*');
    $this->db->where("Status",1);
    $query = $this->db->get('gc_member_topup');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    

public function get_transaction_history() {
    $this->db->select('history.*,member.First_name,member.Last_name,member.Mobile,member.Membership_code,payout.payout_type as Payout_type,commision.Commission as Commission_name');
    $this->db->from('gc_transaction_history as history');
        $this->db->join('gc_membership as member', 'member.Membership_ID = history.Membership_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = history.Payout_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = history.Contract_ID', 'left');
        $this->db->join('gc_member_payouts as pays', 'pays.Payout_ID = history.Payout', 'left');
        $this->db->join('gc_commission as commision', 'commision.ID = pays.Commission_type', 'left');
     $this->db->where("history.Status",1);
     $this->db->where("history.Date",date('Y-m-d'));
    $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_transaction_history1($mobile,$date) {
    $this->db->select('history.*,member.First_name,member.Last_name,member.Mobile,member.Membership_code,payout.payout_type as Payout_type');
    $this->db->from('gc_transaction_history as history');
        $this->db->join('gc_membership as member', 'member.Membership_ID = history.Membership_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = history.Payout_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = history.Contract_ID', 'left');
     $this->db->where("history.Status",1);
     //$this->db->where("history.Date",date('Y-m-d'));
     // if(!empty($commission_type)){
     //    $this->db->where("history.Date",date('Y-m-d'))
     // }
    if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
     if(!empty($date)){
        $this->db->where("history.Date",$date);
     }
    $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
public function get_transaction_history2($commission_type,$topup_list,$transaction_type,$s_date,$e_date,$mobile,$contract) {
    $this->db->select('history.*,member.First_name,member.Last_name,member.Mobile,member.Membership_code,payout.payout_type as Payout_type,commision.Commission as Commission_name');
    $this->db->from('gc_transaction_history as history');
        $this->db->join('gc_membership as member', 'member.Membership_ID = history.Membership_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = history.Payout_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = history.Contract_ID', 'left');
        $this->db->join('gc_member_payouts as pays', 'pays.Payout_ID = history.Payout', 'left');
        $this->db->join('gc_commission as commision', 'commision.ID = pays.Commission_type', 'left');
     $this->db->where("history.Status",1);
     //$this->db->where("history.Date",date('Y-m-d'));
     if(!empty($commission_type)){
        $this->db->where("pays.Commission_type",$commission_type);
     }
     if(!empty($topup_list)){
        $this->db->where("contract.Topup_id",$topup_list);
     }
     if(!empty($contract)){
        $this->db->where("contract.Contract_ID",$contract);
     }
     if(!empty($transaction_type)){
        $transaction_type=explode(',',$transaction_type);
        $this->db->where_in("history.Type",$transaction_type);
     }
     if(!empty($s_date)){
        $this->db->where("history.Date >=",$s_date);
     }
     if(!empty($e_date)){
        $this->db->where("history.Date <=",$e_date);
     }
     if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
    $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
    



    


}



