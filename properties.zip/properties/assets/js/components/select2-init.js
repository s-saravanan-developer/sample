(function(window, document, $, undefined) {
	  "use strict";
	$(function() {

		// basic
		$("#s2_demo1").select2();

		// basic
		$(".region").select2();
		// basic
		$("#scheme_product").select2();

		// basic
		$("#Scheme_type").select2();

		// basic
		$("#s2_demo2").select2();

		// basic
		$("#s2_demo7").select2();

		// basic
		$(".area_c").select2();

		// basic
		$(".area_s").select2();

		// basic
		$(".area_city").select2();

				// basic
		$(".e_area_c").select2();

		// basic
		$(".e_area_s").select2();

		// basic
		$(".e_area_city").select2();

		// basic
		$(".state_select").select2();
		

		// basic
		$(".company_country").select2();

		
		// basic
		$(".bill_id").select2();

		// Product Select
		$(".product_select_pack_1").select2();

		// basic
		$(".company_state").select2();

		// basic
		$("#member_topup").select2();
		

		// basic
		$(".company_city").select2();

		// basic
		$(".product_country").select2();

		// basic
		$(".product_state").select2();

		// basic
		$(".product_city").select2();

		// basic
		$("#Material_id_add").select2();


		$(".sales_point").select2();

		// $('.division').select2({
		// 	placeholder: "Select a Bank"
		// });

		// $(".country_billing").select2();

		$('.country_billing').select2({
			placeholder: "Select a state"
		});

		// basic
		$("#Batch_id").select2();

		// basic
		$("#category_id_add").select2();
		
		// basic
		$("#sub_category_id_add").select2();

		// basic
		$(".Material_type_id").select2();

		// basic
		$(".Material_type_id").select2();

		// basic
		$(".Category_id").select2();

		// Vendor Billing Address
		$(".vbilling_country").select2();

		// Vendor Billing Address Edit
		$(".vbilling_country_e").select2();

		// basic
		$(".Sub_cat_id").select2();

		// basic
		$("#test1").select2();

		// basic
		$("#test2").select2();

		// basic
		$("#test3").select2();

		// basic
		$(".test1").select2();

		// basic
		$(".test2").select2();

		// basic
		$(".test3").select2();

		// basic
		$("#Order_id").select2();
		
		// nested
		// $('#s2_demo2').select2({
		// 	placeholder: "Select a state"
		// });

		$(".team1").select2({
			placeholder: "Select a Team"			
		});

		$(".team2").select2({
			placeholder: "Select a Team"			
		});

		// multi select
		$('#s2_demo3').select2({
			placeholder: "Select a state"
		});

		// multi select
		$('#s2_demoo').select2({
			placeholder: "Select a Region"
		});

		// multi select
		$('#s2_demod').select2({
			placeholder: "Select a Region"
		});

		// multi select
		$('#product_units').select2({
			placeholder: "Select a Units"
		});

		// multi select
		$('#Units_id').select2({
			placeholder: "Select a state"
		});

		// multi select
		$('#prefered_supplier').select2({
			placeholder: "Select a Supplier"
		});

		// multi select
		$('#division').select2({
			placeholder: "Select a Division"
		});

		// multi select
		$('.advice_multi').select2({
			placeholder: "Select a Advice Number"
		});

		// multi select for GST
		$('.select2_gstcode').select2({
			placeholder: "Select a State Code"
		});

		// multi select for GST
		$('#select2_gstcode_edit').select2({
			placeholder: "Select a State Code"
		});


		// placeholder
		$("#s2_demo4").select2({
			placeholder: "Select a Supplier",
			allowClear: true
		});

		// Minimum Input
		$("#s2_demo5").select2({
			minimumInputLength: 2,
			placeholder: "Select a Item",
		});

		// Minimum Input
		$("#s2_demo6").select2({
			minimumInputLength: 2,
			placeholder: "Select a Region",
		});

		// Minimum Input
		$(".product_select").select2({
			// minimumInputLength: 2,
			placeholder: "Select a Product",
		});

		 $("#product_units").select2({
			placeholder: "Select a Unit",
			allowClear: true
			});

		 $("#batch_id").select2({
			placeholder: "Select a Batch",
			allowClear: true
			});

		 $("#scheme_product").select2({
			minimumInputLength: 1,
			placeholder: "Select a Item",
		});

		 $("#Sales_id").select2({
			minimumInputLength: 1,
			placeholder: "Select Invoice",
		});


	});

})(window, document, window.jQuery);
