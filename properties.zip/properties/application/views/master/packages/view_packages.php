<script>
    <?php
         if ($this->session->flashdata('country_success')) 
         {
            echo "var data = ' ".$this->session->flashdata('country_success')."';";
            echo "success(data);";
         }
         if ($this->session->flashdata('duplicate')) 
         {
            echo "var data = ' ".$this->session->flashdata('duplicate')."';";
            echo "duplicate(data);";
         }
   ?>
</script>
<div class="content-wrapper">
    <div class="content">
        <header class="page-header">
            <div class="d-flex align-items-center">
                <div class="mr-auto">
                    <h1 class="separator">Packages</h1>
                    <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard"><i class="icon dripicons-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo base_url();?>dashboard/dashboard">Master</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Master</li>
                            <li class="breadcrumb-item active" aria-current="page">Packages</li>
                        </ol>
                    </nav>
                </div>
                <ul class="actions top-right">
                    <li class="dropdown">
                        <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                            <i class="la la-ellipsis-h"></i>
                        </a>
                        <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
                            <div class="dropdown-header">
                                Quick Actions
                            </div>
                            <a href="#" class="dropdown-item">
                                <i class="icon dripicons-clockwise"></i> Refresh
                            </a>
                            <a href="#" class="dropdown-item">
                                <i class="icon dripicons-gear"></i> Manage Widgets
                            </a>
                            <a href="#" class="dropdown-item">
                                <i class="icon dripicons-cloud-download"></i> Export
                            </a>
                            <a href="#" class="dropdown-item">
                                <i class="icon dripicons-help"></i> Support
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </header>
        <section class="page-content container-fluid">
            <?php
            // echo "<pre>";
            //    print_r($area);
            // echo "</pre>";
         ?>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <h5 class="card-header">
                     <div style="float: left;">
                        Manage Packages 
                     </div>
                     <div style="float: right;">

                        <button type="button" class="btn btn-success  btn-floating" data-toggle="tooltip" data-placement="top" title="" data-original-title="Add New Package" >
                        <p class="text-white" data-toggle="modal" data-target="#areaaddmodel">Add New Package</p>
                        </button>

                     </div>
                  </h5>
                            <div class="card-body">
                                <?php
                          // echo "<pre>";
                          //  print_r($city);
                          // echo "</pre>";
                        ?>
            <table id="bs4-table" class="table table-striped table-bordered table-responsive" style="width:100%">
                <thead>
                    <tr>

                        <th class="text-center" style="width: 2%">
                            <input type="checkbox" name="checkbox" class="checkbox" id="select_all" />
                        </th>
                        <th class="text-center" style="width: 2%">S.No</th>
                        <th class="text-center" style="width: 12%">Action</th>
                        <th style="width: 20%">Package</th>
                        <th style="width: 20%">Level Type</th>
                        <th style="width: 10%">Grade</th>
                        <th style="width: 10%">Value</th>
                        <!-- <th style="width: 20%">Description</th> -->
                        <th class="text-center" style="width: 8%">Status</th>

                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($packages)) {$s = 1; foreach ($packages as $list) {?>
                        <tr>

                            <td>
                                <input type="checkbox" name="checkbox" class="checkbox boxischecked" value="<?php echo ucfirst($list['ID']); ?>" />
                            </td>

                            <td class="text-center">
                                <?php echo $s; ?>
                            </td>
                            <td class="text-center">
                        <a id="usertypeedit" class="btn btn-info btn-sm editusertype" onclick="package_edit(
                            '<?php echo ucfirst($list['ID']); ?>',
                            '<?php echo ucfirst($list['Package']); ?>',
                            '<?php echo ucfirst($list['Alias_name']); ?>',
                            '<?php echo ucfirst($list['Level_type_id']); ?>',
                            '<?php echo ucfirst($list['Grade_id']); ?>',
                            '<?php echo ucfirst($list['Expiry_day']); ?>',
                            '<?php echo ucfirst($list['Validity']); ?>',
                            '<?php echo ucfirst($list['Value']); ?>',
                            '<?php echo ucfirst($list['Adult']); ?>',
                            '<?php echo ucfirst($list['Child']); ?>',
                            '<?php echo ucfirst($list['Description']); ?>',
                            '<?php echo ucfirst($list['Status']); ?>')" data-toggle="modal" data-target="#areaeditmodel"><i class="zmdi zmdi-edit zmdi-hc-fw" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"   style="
            font-size: 17px;
            color:  white;
            "></i>
         </a>                   
         <!-- <?php if ($list['delete_status'] == 1) { ?>
             <a href="" class="btn btn-danger btn-sm disabled"  data-toggle="modal" data-target="#deletemodel<?php echo $list['ID']; ?>"><i class="zmdi zmdi-delete zmdi-hc-fw" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" style="font-size: 17x;color:  white;"></i></a>
          <?php }else{ ?>
            <a href="" onclick="delete_package('<?php echo ucfirst($list['ID']); ?>')" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deletemodel<?php echo $list['ID']; ?>"><i class="zmdi zmdi-delete zmdi-hc-fw" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" style="font-size: 17x;color:  white;"></i></a>
          <?php } ?> -->
          <a href="" onclick="delete_package('<?php echo ucfirst($list['ID']); ?>')" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deletemodel<?php echo $list['ID']; ?>"><i class="zmdi zmdi-delete zmdi-hc-fw" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" style="font-size: 17x;color:  white;"></i></a>
                              
                            </td>
                            <td class="s_no">
                                <?php echo ucfirst($list['Package']); ?>
                            </td>
                            <td class="s_no">
                                <?php echo ucfirst($list['Level_type_name']); ?>
                            </td>
                            <td class="s_no"> 
                                <?php echo ucfirst($list['Grade_name']); ?>
                            </td>
                            <td class="s_no float-right">
                                <i class="la la-rupee"></i><?php echo ucfirst($list['Value']); ?>
                            </td>
                             <!-- <td class="s_no">
                                <?php echo ucfirst($list['Description']); ?>
                            </td> -->
                            <td class="text-center" style="width: 8%"><span class="badge badge-<?php echo ($list['Status'] == 1) ? 'success' : 'danger'; ?>"><?php echo ($list['Status'] == 1) ? 'Active' : 'In-Active'; ?></span></td>

                        </tr>
                        <?php
      $s++;
      }
      }
      ?>
                </tbody>
            </table>
                            </div>
                            <div class="card-footer bg-light">
                                <button type="button" class="btn btn-danger delbtn" data-toggle="modal" data-target="#deletemodel1">Delete</button>
                                <button type="" class="btn btn btn-success   delbtn" data-toggle="modal" data-target="#active_all_model">Active</button>
                                <button type="" class="btn btn btn-info delbtn" data-toggle="modal" data-target="#deactive_all_model">In-Active
                                </button>
                                <button class="btn btn-primary region_input no-display" data-toggle="modal" data-target="#multiexport">Export Excel</button>
                                <button class="btn btn-primary region_input1" data-toggle="modal" data-target="#Export">Export Excel</button>
                            </div>

                        </div>
                    </div>
                </div>
        </section>
    </div>
</div>
</div>

<!-- ADD AREA -->
<div id="areaaddmodel" class="modal modal-right-side fade" data-backdrop="static" role="dialog" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel6">Packages</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true" class="zmdi zmdi-close"></span>
</button>
</div>
<div class="modal-body" style="overflow-y: scroll;">
<div class="row">
<div class="col">
<div class="card">
<h5 class="card-header">Add Packages</h5>
<div class="card-body">
<div class="form-body">
<div class="row">
<div>
<div>
<div class="card-body">
<form action="<?php echo base_url(); ?>master/Packages/add_package" method="post" data-toggle="validator" role="form">
<div class="form-row">
    <div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Level Type</label> <span class="text-danger">*</span>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-arrow-right-top zmdi-hc-fw"></i></span>
</div>
<select class="form-control " name="package[Level_type_id]" required="" id="Level_id_add">
<option value="">Select Level Type</option>
<?php if(!empty($level)){foreach ($level as $key => $value) { ?>
<option value="<?php echo $value['ID'] ?>"><?php echo $value['Level_type'] ?></option>
<?php } }?>
</select>
</div>

</div>
</div>
<div class="form-group col-md-6">
<div class="form-group">
<label for="inputName" class="control-label">Grade</label> <span class="text-danger">*</span>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-google-glass zmdi-hc-fw"></i></span>
</div>
<select class="form-control " name="package[Grade_id]" required="" id="Grade_id_add">
<option value="">Select Grade</option>
<?php if(!empty($grade)){foreach ($grade as $key => $value) { ?>
<option value="<?php echo $value['ID'] ?>"><?php echo $value['Grade_name'] ?></option>
<?php } }?>
</select>
</div>

</div>
</div>
    <div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Package Title <span class="text-danger">*</span></label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-ticket-star zmdi-hc-fw"></i></span>
</div>
<input type="text" class="form-control check_data " onkeyup="check_area_name()" id="Title_add" autofocus placeholder="Package Name" name="package[Package]" required>
</div>
<div class="text-center duplicate-occur no-display">
<code>This Package Is Already Used</code>
</div>
</div>
</div>

<!-- <div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Alias Name<span class="text-danger">*</span></label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
</div>
<input type="text" class="form-control check_data"  id="Alias_name_add" autofocus placeholder="Alias Name" name="package[Alias_name]" required>
</div>
</div>
</div> -->
<!-- 
<div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Expiry Days <span class="text-danger">*</span></label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
</div>
<input type="text" class="form-control check_data " id="Expiry_day_add" autofocus placeholder="Expiry Days" name="package[Expiry_day]" required>
</div>
</div>
</div> -->

<div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Validity<span class="text-danger">*</span></label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-border-color zmdi-hc-fw"></i></span>
</div>
<input type="text" class="form-control check_data" id="Validity_add" autofocus placeholder="Validity" name="package[Validity]" required>
</div>
</div>
</div>
<div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Package Value<span class="text-danger">*</span></label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="la la-inr"></i></span>
</div>
<input type="text" class="form-control check_data" onkeypress="return isNumber(event)" id="Value_add" autofocus placeholder="Package Value" name="package[Value]" required>
</div>
</div>
</div>
<div class="form-group col-md-6">
<div class="form-group">
<label for="inputName" class="control-label">Adult</label> <span class="text-danger">*</span>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-male-female zmdi-hc-fw"></i></span>
</div>
<select class="form-control " name="package[Adult]" required="" id="Adult_add">
<option value="">Select No.of Adults</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
</div>

</div>
</div>

<div class="form-group col-md-6">
<div class="form-group">
<label for="inputName" class="control-label">Child</label> 
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-male zmdi-hc-fw"></i></span>
</div>
<select class="form-control " name="package[Child]"  id="Child_add">
<option value="">Select No.of children</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
</div>
</div>
</div>

<div class="form-group col-md-6">
<div class="form-group">
<label for="inputName" class="control-label">Status</label> 
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-equalizer zmdi-hc-fw"></i></span>
</div>
<select class="form-control " name="package[Status]"  id="Status_add">
<option value="">Select Status</option>
<option value="1" selected>Active</option>
<option value="2">In-Active</option>
</select>
</div>
</div>
</div>

<div class="form-group col-md-12">
<div class="form-group" >  
<label for="inputName" class="control-label">Description</label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-iridescent zmdi-hc-fw"></i></span>
</div>
<textarea type="text" class="form-control description" id="Description_add" autofocus placeholder="Enter Description" name="package[Description]"></textarea>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
<button type="submit" class="btn btn-success  submit">Save changes</button>
</div>
</form>
</div>
</div>
</div>
<!-- AREA END -->

<!-- EDIT AREA -->
<div id="areaeditmodel" class="modal modal-right-side fade" data-backdrop="static" role="dialog" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel6">Package</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true" class="zmdi zmdi-close"></span>
</button>
</div>
<div class="modal-body" style="overflow-y: scroll;">
<div class="row">
<div class="col">
<div class="card">

<div class="card-body">
<div class="form-body">
<div class="row">
<div class="col-md-12">

<h5 class="card-header">Edit Package</h5>
<div class="card-body">
<form action="<?php echo base_url(); ?>master/Packages/edit_package" method="post" data-toggle="validator" role="form">
<div class="form-row">
    <div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Level type</label> <span class="text-danger">*</span>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-arrow-right-top zmdi-hc-fw"></i></span>
</div>
<select class="form-control " name="package[Level_type_id]" required="" id="Level_id_edit">
<option value="">Select Level Type</option>
<?php if(!empty($level)){foreach ($level as $key => $value) { ?>
<option value="<?php echo $value['ID'] ?>"><?php echo $value['Level_type'] ?></option>
<?php } }?>
</select>
</div>

</div>
</div>
<div class="form-group col-md-6">
<div class="form-group">
<label for="inputName" class="control-label">Grade</label> <span class="text-danger">*</span>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-google-glass zmdi-hc-fw"></i></span>
</div>
<select class="form-control " name="package[Grade_id]" required="" id="Grade_id_edit">
<option value="">Select Grade</option>
<?php if(!empty($grade)){foreach ($grade as $key => $value) { ?>
<option value="<?php echo $value['ID'] ?>"><?php echo $value['Grade_name'] ?></option>
<?php } }?>
</select>
</div>
</div>
</div>
    <div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Package Title <span class="text-danger">*</span></label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-ticket-star zmdi-hc-fw"></i></span>
</div>
<input type="text" class="form-control check_data1 " onkeyup="check_area_name_edit()" id="Title_edit" autofocus placeholder="Package Name" name="package[Package]" required>
<input type="hidden" class="check_id" id="ID"name="ID">
</div>
<div class="text-center duplicate-occur1 no-display">
<code>This Package Is Already Used</code>
</div>
</div>
</div>

<!-- <div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Alias Name<span class="text-danger">*</span></label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-border-color zmdi-hc-fw"></i></span>
</div>
<input type="text" class="form-control check_data"  id="Alias_name_edit" autofocus placeholder="Alias Name" name="package[Alias_name]" required>
</div>
</div>
</div> -->

<!-- <div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Expiry Days <span class="text-danger">*</span></label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-border-color zmdi-hc-fw"></i></span>
</div>
<input type="text" class="form-control check_data " id="Expiry_day_edit" autofocus placeholder="Expiry Days" name="package[Expiry_day]" required>
</div>
</div>
</div> -->

<div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Validity<span class="text-danger">*</span></label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-border-color zmdi-hc-fw"></i></span>
</div>
<input type="text" class="form-control check_data" id="Validity_edit" autofocus placeholder="Validity" name="package[Validity]" required>
</div>
</div>
</div>
<div class="form-group col-md-6">
<div class="form-group" >
<label for="inputName" class="control-label">Package Value<span class="text-danger">*</span></label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="la la-inr"></i></span>
</div>
<input type="text" class="form-control check_data" onkeypress="return isNumber(event)" id="Value_edit" autofocus placeholder="Package Value" name="package[Value]" required>
</div>
</div>
</div>
<div class="form-group col-md-6">
<div class="form-group">
<label for="inputName" class="control-label">Adult</label> <span class="text-danger">*</span>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-male-female zmdi-hc-fw"></i></span>
</div>
<select class="form-control " name="package[Adult]" required="" id="Adult_edit">
<option value="">Select No.of Adults</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
</div>

</div>
</div>

<div class="form-group col-md-6">
<div class="form-group">
<label for="inputName" class="control-label">Child</label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-male zmdi-hc-fw"></i></span>
</div>
<select class="form-control " name="package[Child]"  id="Child_edit">
<option value="">Select No.of children</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
</div>
</div>
</div>

<div class="form-group col-md-6">
<div class="form-group">
<label for="inputName" class="control-label">Status</label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-equalizer zmdi-hc-fw"></i></span>
</div>
<select class="form-control " name="package[Status]"  id="Status_edit">
<option value="">Select Status</option>
<option value="1">Active</option>
<option value="2">In-Active</option>
</select>
</div>
</div>
</div>
<div class="form-group col-md-12">
<div class="form-group" >  
<label for="inputName" class="control-label">Description</label>
<div class="input-group mb-3">
<div class="input-group-prepend">
<span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-iridescent zmdi-hc-fw"></i></span>
</div>
<textarea type="text" class="form-control description" id="Description_edit" autofocus placeholder="Enter Description" name="package[Description]"></textarea>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger " data-dismiss="modal">Close</button>
<button type="submit" class="btn btn-success  submit">Update</button>
</div>
</form>
</div>
</div>
</div>
<!-- AREA END -->

<!-- BASIC MODAL DEMO -->
 <?php if (!empty($packages)) {$s = 1; foreach ($packages as $list) {?> 

<div class="modal fade" id="deletemodel<?php echo $list['ID']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel9">Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="zmdi zmdi-close"></span>
                </button>
            </div>
            <form action="<?php echo base_url();?>master/Packages/delete_package/<?php echo $list['ID']; ?>" method="POST">
                <div class="modal-body">
                    <div class="swal2-header">
                        <ul class="swal2-progresssteps" style="display: none;"></ul>
                        <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span>
                        </div>
                        <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                        <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                        <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                        <div class="swal2-icon swal2-success" style="display: none;">
                            <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                            <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                            <div class="swal2-success-ring"></div>
                            <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                            <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                        </div>
                        <img class="swal2-image" style="display: none;">
                        <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                        <button type="button" class="swal2-close" style="display: none;">×</button>
                    </div>
                    <!-- Hiiden Values -->

                    <input type="hidden" name="url" value="<?php echo $this->router->method; ?>">
                    <input class="delete_id" type="hidden" name="country_id">
                    <input class="table_name" type="hidden" name="table_name">
                </div>
                <div class="delete-footer">
                    <button type="submit" class="btn btn-primary">Yes, delete it!</button>
                    <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
  
<?php }} ?>
<div class="modal fade" id="deletemodel1" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel9">Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="zmdi zmdi-close"></span>
                </button>
            </div>

            <div class="modal-body">
                <div class="swal2-header">
                    <ul class="swal2-progresssteps" style="display: none;"></ul>
                    <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span>
                    </div>
                    <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                    <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                    <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                    <div class="swal2-icon swal2-success" style="display: none;">
                        <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                        <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                        <div class="swal2-success-ring"></div>
                        <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                        <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                    </div>
                    <img class="swal2-image" style="display: none;">
                    <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                    <button type="button" class="swal2-close" style="display: none;">×</button>
                </div>
                <!-- Hiiden Values -->

            </div>
            <div class="delete-footer">
                <button type="submit" id="del_all" class="btn btn-primary">Yes, delete it!</button>
                <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="deactive_all_model" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel9">In-Active</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="zmdi zmdi-close"></span>
                </button>
            </div>

            <div class="modal-body">
                <div class="swal2-header">
                    <ul class="swal2-progresssteps" style="display: none;"></ul>
                    <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span>
                    </div>
                    <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                    <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                    <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                    <div class="swal2-icon swal2-success" style="display: none;">
                        <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                        <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                        <div class="swal2-success-ring"></div>
                        <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                        <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                    </div>
                    <img class="swal2-image" style="display: none;">
                    <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                    <button type="button" class="swal2-close" style="display: none;">×</button>
                </div>
                <!-- Hiiden Values -->

            </div>
            <div class="delete-footer">
                <button type="submit" id="deactive_all" class="btn btn-primary">Yes, In-Active it!</button>
                <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="active_all_model" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel9">Active</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="zmdi zmdi-close"></span>
                </button>
            </div>

            <div class="modal-body">
                <div class="swal2-header">
                    <ul class="swal2-progresssteps" style="display: none;"></ul>
                    <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span>
                    </div>
                    <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                    <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                    <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                    <div class="swal2-icon swal2-success" style="display: none;">
                        <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                        <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                        <div class="swal2-success-ring"></div>
                        <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                        <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                    </div>
                    <img class="swal2-image" style="display: none;">
                    <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                    <button type="button" class="swal2-close" style="display: none;">×</button>
                </div>
                <!-- Hiiden Values -->

            </div>
            <div class="delete-footer">
                <button type="submit" id="active_all" class="btn btn-primary">Yes, Active it!</button>
                <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="Export" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel9">Export</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="zmdi zmdi-close"></span>
                </button>
            </div>

            <div class="modal-body">
                <div class="swal2-header">
                    <ul class="swal2-progresssteps" style="display: none;"></ul>
                    <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span>
                    </div>
                    <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                    <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                    <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                    <div class="swal2-icon swal2-success" style="display: none;">
                        <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                        <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                        <div class="swal2-success-ring"></div>
                        <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                        <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                    </div>
                    <img class="swal2-image" style="display: none;">
                    <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                    <button type="button" class="swal2-close" style="display: none;">×</button>
                </div>
                <!-- Hiiden Values -->

            </div>
            <div class="delete-footer">
                <a id="active_all" class="btn btn-primary export_link" data-dismiss="modal">Yes, Export it!</a>
                <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="multiexport" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel9">Export</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="zmdi zmdi-close"></span>
                </button>
            </div>

            <div class="modal-body">
                <div class="swal2-header">
                    <ul class="swal2-progresssteps" style="display: none;"></ul>
                    <div class="swal2-icon swal2-error" style="display: none;"><span class="swal2-x-mark"><span class="swal2-x-mark-line-left"></span><span class="swal2-x-mark-line-right"></span></span>
                    </div>
                    <div class="swal2-icon swal2-question" style="display: none;"><span class="swal2-icon-text">?</span></div>
                    <div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>
                    <div class="swal2-icon swal2-info" style="display: none;"><span class="swal2-icon-text">i</span></div>
                    <div class="swal2-icon swal2-success" style="display: none;">
                        <div class="swal2-success-circular-line-left" style="background-color: rgb(255, 255, 255);"></div>
                        <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>
                        <div class="swal2-success-ring"></div>
                        <div class="swal2-success-fix" style="background-color: rgb(255, 255, 255);"></div>
                        <div class="swal2-success-circular-line-right" style="background-color: rgb(255, 255, 255);"></div>
                    </div>
                    <img class="swal2-image" style="display: none;">
                    <h2 class="swal2-title text-center" id="swal2-title">Are you sure?</h2>
                    <button type="button" class="swal2-close" style="display: none;">×</button>
                </div>
                <!-- Hiiden Values -->

            </div>
            <div class="delete-footer">
                <a type="submit" class="btn btn-primary multi_export" data-dismiss="modal">Yes, Export it!</a>
                <button type="button" class="btn btn-secondary btn-outline" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

$('#Level_id_add').on('change', function() {
level=$('#Level_id_add').val();
$.ajax({
type: "POST",
url: "<?php echo base_url(); ?>master/Packages/get_grades",
data: {level: level},
cache: true,
dataType:'html',
async: false,
success: function(data){
        $('#Grade_id_add').empty();
        $('#Grade_id_add').append(data);
}
});
});


// for Edit

$('#Level_id_edit').on('change', function() {
level=$('#Level_id_edit').val();
$.ajax({
type: "POST",
url: "<?php echo base_url(); ?>master/Packages/get_grades",
data: {level: level},
cache: true,
dataType:'html',
async: false,
success: function(data){
        $('#Grade_id_edit').empty();
        $('#Grade_id_edit').append(data);
}
});
});

    function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }

    function delete_package(val, val1) {
        $('.delete_id').val(val);
        $('.table_name').val(val1);
        //alert($('.delete_id').val(val));
    }

    function package_edit(ID,Title, Alias_name, Level_id, Grade_id, Expiry_day, Validity,Value, Adult, Child, Description,Status) {
// alert(val);
$('#ID').val(ID);
$('#Title_edit').val(Title);
// $('#Alias_name_edit').val(Alias_name);
$('#Level_id_edit').val(Level_id);
$.ajax({
type: "POST",
url: "<?php echo base_url(); ?>master/Packages/get_grades",
data: {level: Level_id},
cache: true,
dataType:'html',
async: false,
success: function(data){
//  // alert(data);
// result = data;
        $('#Grade_id_edit').empty();
        $('#Grade_id_edit').append(data);
        $("#Grade_id_edit").val(val4);
}
});
$('#Grade_id_edit').val(Grade_id);
// $('#Expiry_day_edit').val(Expiry_day);
$('#Validity_edit').val(Validity);
$('#Value_edit').val(Value);
$('#Adult_edit').val(Adult);
$('#Child_edit').val(Child);
$('#Status_edit').val(Status);
$('#Description_edit').val(Description);

        
    }

    function check_area_name() {
        // To Check the State Name
        // alert($('.check_data').val());        
        var check_data = $('.check_data').val();
        var result = '';
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>master/location/duplicate_check",
            data: {
                data: check_data,
                table_name: 'gc_packages',
                colum: 'Package'
            },
            cache: true,
            async: false,
            success: function(data) {
                // alert(data);
                result = data;
            }
        });
        if (result == 1) {
            $('.duplicate-occur').removeClass('no-display');
            $("button[type=submit]").attr("disabled", "disabled");
            // return false;
        }
if (result == 0) {
    $('.duplicate-occur').addClass('no-display');
    $("button[type=submit]").removeAttr("disabled");
    // return true;
}

    }

      function check_area_name_edit() {  

        var check_data = $('.check_data1').val();
        var result = '';

        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>master/location/duplicate_checkedit",
            data: {
                data: check_data,
                table_name: 'gc_packages',
                colum: 'Package',
                id: $('.check_id').val()
            },
            cache: true,
            async: false,
            success: function(data) {
                // alert(data);
                result = data;
            }
        });
        if (result == 1) {

            $('.duplicate-occur1').removeClass('no-display');
            $("button[type=submit]").attr("disabled", "disabled");
            }
            if (result == 0) {
                $('.duplicate-occur1').addClass('no-display');
                $("button[type=submit]").removeAttr("disabled");
                
            }

    }
</script>

<script type="text/javascript">
    // To check all the boxes

    $(document).ready(function() {
        $('#select_all').on('click', function() {
            if (this.checked) {
                $('.checkbox').each(function() {
                    this.checked = true;
                });
            } else {
                $('.checkbox').each(function() {
                    this.checked = false;
                });
            }
        });

        $('.checkbox').on('click', function() {
            if ($('.checkbox:checked').length == $('.checkbox').length) {
                $('#select_all').prop('checked', true);
            } else {
                $('#select_all').prop('checked', false);
            }
        });
    });

    // To pass the value to the Controller

    $(document).ready(function() {
        $("#del_all").click(function() {
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function() {
                favorite.push($(this).val());
            });
            // alert("Selected Countries are: " + favorite.join(","));
            $.ajax({
                url: '<?php echo base_url() ?>master/Location/delete_checkbox',
                type: 'post',
                data: {
                    table_name: 'gc_packages',
                    id: favorite.join(",")
                },
            }).done(function(data) {
                location.reload();

            });
        });
    });

    $(document).ready(function() {
        $("#active_all").click(function() {
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function() {
                favorite.push($(this).val());
            });
            // alert("Selected Countries are: " + favorite.join(","));
            $.ajax({
                url: '<?php echo base_url() ?>master/Location/active_all_checkbox',
                type: 'post',
                data: {
                    table_name: 'gc_packages',
                    id: favorite.join(",")
                },
            }).done(function(data) {
                location.reload();

            });
        });
    });

    $(document).ready(function() {
        $("#deactive_all").click(function() {
            var favorite = [];
            $.each($("input[name='checkbox']:checked"), function() {
                favorite.push($(this).val());
            });
            // alert("Selected Countries are: " + favorite.join(","));
            $.ajax({
                url: '<?php echo base_url() ?>master/Location/deactivate_all_checkbox',
                type: 'post',
                data: {
                    id: favorite.join(","),
                    table_name: 'gc_packages'
                },
            }).done(function(data) {
                // alert(data);
                location.reload();

            });
        });
    });

    $('.delbtn').prop('disabled', true);

    $('.checkbox').change(function() {
        $('.delbtn').prop('disabled', $('.checkbox:checked').length == 0);
    })

    $('#select_all').on('click', function() {
        if (this.checked) {
            $('.checkbox').each(function() {
                this.checked = true;

            });
        } else {
            $('.checkbox').each(function() {
                this.checked = false;

            });
        }
    });
    $('.checkbox').on('click', function() {
        if ($('.checkbox:checked').length == $('.checkbox').length) {
            $('#select_all').prop('checked', true);
            $('.region_input1').addClass('no-display');
            $('.region_input').removeClass('no-display');
        } else {
            $('#select_all').prop('checked', false);
            $('.region_input1').removeClass('no-display');
            $('.region_input').addClass('no-display');
        }
    });
    $('.boxischecked').on('click', function() {

        if ($(this).prop('checked') == true) {
            $('.region_input1').addClass('no-display');
            $('.region_input').removeClass('no-display');
        } else {
            $('.region_input1').removeClass('no-display');
            $('.region_input').addClass('no-display');
        }

        checked_checkbox = Number($('input[type=checkbox].boxischecked:checked').length);
        // alert(checked_checkbox);
        if (checked_checkbox != 0) {
            $('.region_input1').addClass('no-display');
            $('.region_input').removeClass('no-display');
        } else {
            $('.region_input1').removeClass('no-display');
            $('.region_input').addClass('no-display');
        }

    });

    $('.multi_export').click(function() {

        var favorite = [];
        $.each($("input[name='checkbox']:checked"), function() {
            favorite.push($(this).val());
        });

        window.location = "<?php echo base_url();?>export/multi_export_areas?url=" + favorite;

    });

    $('.export_link').click(function() {
        // alert();
        window.location = "<?php echo base_url();?>export/export_areas";
    });


</script>