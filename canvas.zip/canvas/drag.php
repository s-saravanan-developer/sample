<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" 
        content="width=device-width, 
        initial-scale=1.0, 
        user-scalable=no" />

  <title>Editor </title>
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <link rel="stylesheet" href="./css/iEdit.css">
  <link rel="stylesheet" href="https://unpkg.com/font-awesome@4.7.0/css/font-awesome.min.css">
  <style>
    #container {
      width: 100%;
      height: 400px;
      background-color: #333;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      border-radius: 7px;
      touch-action: none;
      /*object-fit: cover;*/
      background-image: url(./image/sample2.png);
      background-size: 899.33px 399px;

    }
    #item {
      width: 100px;
      height: 100px;
      background-color: rgb(245, 230, 99);
      border: 10px solid rgba(136, 136, 136, .5);
      border-radius: 50%;
      touch-action: none;
      user-select: none;
    }
    #item:active {
      background-color: rgba(168, 218, 220, 1.00);
    }
    .item:hover {
      cursor: pointer;
      border-width: 20px;
    }
    #image:hover {
      cursor: pointer;
      border-width: 20px;
    }
  </style>
</head>

<body>
<div class="card">
  <div class="row">
    <div class="col-md-2"><button class="btn btn-success" type="button" style="margin-top:182px;margin-left:48px;" id="container-back">Change Background</button></div>
    <div class="col-md-8">
        <div id="canvas_div" style="display:inline">
          <div id="container" >
            <!-- <div id="item" class="item"> -->
            <!-- </div> -->
            <?php 
                $path = './image/preview_img.png';
                $type = pathinfo($path, PATHINFO_EXTENSION);
                $data = file_get_contents($path);
                $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

              ?>
            <div id="image" style="margin-left:-107px;">
              <img src="<?php echo $base64; ?>" id="result" style="width:318px;height:318px;" >
            </div>
            
              <h1 class="item" id="text" style="color:yellow;transform: translate3d(202px, -151px, 0px);" >Draggable text</h1>
            
            
              <h1 class="item" id="text1" style="color:red;" >sample text</h1>
            
          </div>
        </div>
    </div>
    <div class="col-md-2"><button class="btn btn-success" type="button" style="margin-top:182px;" id="btn_preview">preview</button></div>
  </div>
</div>
<input type="file" id="imgupload" style="display:none"/>
<input type="file" id="imgupload1" style="display:none"/>


<div class="card" id="apend_div"></div>



<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
</div>

<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal1">Open Modal</button>

<div id="myModal1" class="modal fade" role="dialog">
     <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Image Editor</h4>
      </div>
        <div class="modal-body" style="height:450px;">
          <div id="app"></div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<script src="https://code.jquery.com/jquery.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"  ></script>
        <script src="html2canvas.js"  ></script>
        <script src="html2canvas.min.js"  ></script>
        <script src="html2canvas.esm.js"  ></script>
        <script src="canvas2image.js"  ></script>
        <script src="./js/iEdit.js"  ></script>
        <script src="./js/main.js"  ></script>
        <script type="text/javascript">

          $(document).ready(function(){
             $('#image').click(function(){ $('#imgupload').trigger('click'); });
             $('#container-back').click(function(){ $('#imgupload1').trigger('click'); });

                 $("#imgupload").change(function(e){
                    // alert();
                    var img = e.target.files[0];

                    if(!iEdit.open(img, true, function(res){
                       // alert(res);
                        $("#result").attr("src", res);          
                    })){
                        swal("Whoops! That is not an image!");
                        $("#imgupload").val('');
                    }

                });

                 $("#imgupload1").change(function(e){
                    // alert();
                    var img1 = e.target.files[0];

                    if(!iEdit.open(img1, true, function(res){
                       // alert(res);
                        // $("#result").attr("src", res);
                         $("#container").css("background-image","url("+res+")");         
                    })){
                        swal("Whoops! That is not an image!");
                        $("#imgupload1").val('');
                    }

                });
          });
            $(document).on('click', '#btn_preview', function(e) {
                var elm=$('#canvas_div').get(0);
                var lebar = '600';
                var tinggi  = '400';
                var type = 'png';
                var filename = 'htmltocanvas';
                // alert();
                html2canvas(document.querySelector("#canvas_div")).then(canvas => {
                    // document.body.appendChild(canvas);

                    var canWidth=canvas.width;
                    var canHeight=canvas.height;
                    var img = Canvas2Image.convertToImage(canvas,canWidth,canHeight);
                    console.log(img.src);
                    // alert(img.src);
                    // $('#preview').empty();
                    // alert(1);
                    // $('#preview').after(img);
                    get_preview(img);

                    // Canvas2Image.saveAsImage(canvas,lebar,tinggi,type,filename);
                })
            });
        </script>

<script type="text/javascript">
          
function get_preview(img){
    // alert('in');
        var canvas = document.createElement('canvas'),
        ctx = canvas.getContext('2d'),
        parts = [];
        // img = new Image();

    
    img.onload = split_4;
    function split_4() {
      
      var w2 = img.width / 3,
          h2 = img.height/1.8;
          // alert(w2);
      for(var i=0; i<3; i++) {
        var x = (-w2*i) % (w2*3),
            y = (h2*0)<=h2 ? 0 : -h2 ;
            console.log(x,y);
        canvas.width = w2;
        canvas.height = h2;
        ctx.drawImage(this, x, y, w2*3, h2*1);
        parts.push( canvas.toDataURL() );
        // for test div
        var slicedImage = document.createElement('img')
        slicedImage.src = parts[i];
        var div = document.getElementById('test');
        // div.appendChild( slicedImage );
      }
      console.log(parts);

          $.ajax({
                  type: "POST",
                  url: "./apend_image.php",
                  data: {data: parts},
                  cache: true,
                  async: false,
                  dataType:'html',
                  success: function(data){
                   // alert(data);
                  // result = data;
                  // 
                  $('#myModal').modal('show').empty().append(data);
                  // $('#apend_div').empty().append(data);
                  }
                  });
    }
    // img.src=document.getElementById("canvasimg").getAttribute('src');
             }
        </script>
  <script>
  // $(document).on('click', '.item', function(e) {
    // id=$(this).attr('id');
  // var dragItem = document.querySelector("#"+id);
  //   //alert(dragItem.id);
    // get_start('#text1');
  // });
  //
   // function get_start(id){
    // alert("#"+id);
    var dragItem = document.querySelector('.item');
    var container = document.querySelector("#container");

    var active = false;
    var currentX;
    var currentY;
    var initialX;
    var initialY;
    var xOffset = 0;
    var yOffset = 0;

    container.addEventListener("touchstart", dragStart, false);
    container.addEventListener("touchend", dragEnd, false);
    container.addEventListener("touchmove", drag, false);

    container.addEventListener("mousedown", dragStart, false);
    container.addEventListener("mouseup", dragEnd, false);
    container.addEventListener("mousemove", drag, false);

  // });

    function dragStart(e) {

      if (e.type === "touchstart") {
        initialX = e.touches[0].clientX - xOffset;
        initialY = e.touches[0].clientY - yOffset;
      } else {
        initialX = e.clientX - xOffset;
        initialY = e.clientY - yOffset;
      }
      // dragItem=document.querySelector('#'+id);
      if (e.target === dragItem) {
        active = true;
      }
    }

    function dragEnd(e) {
      initialX = currentX;
      initialY = currentY;

      active = false;
    }

    function drag(e) {
      if (active) {
      
        e.preventDefault();
      
        if (e.type === "touchmove") {
          currentX = e.touches[0].clientX - initialX;
          currentY = e.touches[0].clientY - initialY;
        } else {
          currentX = e.clientX - initialX;
          currentY = e.clientY - initialY;
        }

        xOffset = currentX;
        yOffset = currentY;

        setTranslate(currentX, currentY, dragItem);
      }
    }

    function setTranslate(xPos, yPos, el) {
      el.style.transform = "translate3d(" + xPos + "px, " + yPos + "px, 0)";
    }

  </script>
</body>

</html>