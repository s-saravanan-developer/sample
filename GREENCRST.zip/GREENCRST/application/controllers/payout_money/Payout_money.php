<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Payout_money extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Users_model');
        $this->load->model('payout_money/Payout_money_model');
    }

	public function index()
	{
        
		$template['page']='payout_money/view_active_payout';
        $template['payout']    =  $this->Payout_money_model->get_today_payouts();
        $template['payout_week']    =  $this->Payout_money_model->get_week_payouts($mobile='',date('Y-m-d'));
        $template['payout_month']    =  $this->Payout_money_model->get_month_payouts($mobile='',date('Y-m-d'));
        $template['first_monday']    =  $this->Payout_money_model->get_1st_monday_payouts($mobile='',date('Y-m-d'));
        $template['third_monday']    =  $this->Payout_money_model->get_3rd_monday_payouts($mobile='',date('Y-m-d'));
        //$template['binary_commission']    =  $this->Payout_money_model->get_binary_commission($mobile='',date('Y-m-d'));
        $template['pre_date']=$this->get_previous_date1(date('Y-m-d'));
        $this->load->view('template',$template);
		
	}

        public function active_payouts_ready()
    {
        
        $template['page']='payout_money/view_active_payout_ready';
        $template['payout']    =  $this->Payout_money_model->get_today_processed_payouts();
        $this->load->view('template',$template);
        
    }

        public function pay_later()
    {
        
        $template['page']='payout_money/view_payout_later';
        $template['payout']    =  $this->Payout_money_model->get_today_pay_later();
        $this->load->view('template',$template);
        
    }
        public function payout_history()
    {
        
        $template['page']='payout_money/view_payout_history';
        $template['payout']    =  $this->Payout_money_model->get_today_payout_history();
        $this->load->view('template',$template);
        
    }

    public function process_payout(){
        $id = ( explode( ',', $this->input->post('id') ));
        //var_dump($id);die();
        $payout_mode = $this->input->post('payout_mode');

        $date =  date('Y-m-d',strtotime($this->input->post('date')));
        //var_dump($id);die();
        foreach ($id as  $value) {
                $this->Payout_money_model->process_payout($value,$date,$payout_mode);
             }
    }

public function cancel_payout(){
        $id = ( explode( ',', $this->input->post('id') ));
        $payout_mode = $this->input->post('payout_mode');
        $date =  date('Y-m-d',strtotime($this->input->post('date')));
        //var_dump($id);die();
        foreach ($id as  $value) {
                $this->Payout_money_model->cancel_payout($value,$date,$payout_mode);
             }
    }
public function payout_later(){
        $id = ( explode( ',', $this->input->post('id') ));
        $date =  date('Y-m-d',strtotime($this->input->post('date')));
        //var_dump($id);die();
        foreach ($id as  $value) {
                $this->Payout_money_model->payout_later($value,$date);
             }
    }

public function mark_as_paid(){
        $id = ( explode( ',', $this->input->post('id') ));
        $date =  date('Y-m-d',strtotime($this->input->post('date')));
        //var_dump($id);die();
        foreach ($id as  $value) {
                $this->Payout_money_model->mark_as_paid($value,$date);
             }
    }

    public function payout_remittance()
    {
        
        $template['page']='payout_money/view_payout_remittance';
        $this->load->view('template',$template);
        
    }

    public function completed_payments()
    {
        
        $template['page']='payout_money/view_completed_payments';
        $this->load->view('template',$template);
        
    }

    public function withdraw()
    {
        
        $template['page']='payout_money/view_member_withdraw';
        $this->load->view('template',$template);
        
    }
    public function get_payout_details()
    {
        
        $mobile = $this->input->post("mobile");  
        $Payout_mode = $this->input->post("Payout_mode");  
        //$date = $this->input->post("date");
        $date=date("Y-m-d", strtotime($this->input->post("date")));
        $this->load->model('payout_money/Payout_money_model');
        if($Payout_mode==1){
        // $template['payout'] =  $this->Payout_money_model->get_payout_details($mobile,$date);
        // $template['payout_week']    =  $this->Payout_money_model->get_week_payouts($mobile,$date);
        // $template['payout_month']    =  $this->Payout_money_model->get_month_payouts($mobile,$date);
        // $template['first_monday']    =  $this->Payout_money_model->get_1st_monday_payouts($mobile,$date);
        // $template['third_monday']    =  $this->Payout_money_model->get_3rd_monday_payouts($mobile,$date);
        $template['binary_commission']    =  $this->Payout_money_model->get_binary_commission($mobile,$date);
        $template['pre_date']=$this->get_previous_date1($date);
    }else{
        $template['payout'] =  $this->Payout_money_model->get_payout_details_condensed($mobile,$date);
        $template['payout_week']    =  $this->Payout_money_model->get_week_payouts_condensed($mobile,$date);

        $template['payout_month']    =  $this->Payout_money_model->get_month_payouts_condensed($mobile,$date);
        // $template['first_monday']    =  $this->Payout_money_model->get_1st_monday_payouts_condensed($mobile,$date);
        // $template['third_monday']    =  $this->Payout_money_model->get_3rd_monday_payouts_condensed($mobile,$date);
        $template['pre_date']=$this->get_previous_date1($date);
    }

        $this->load->view('payout_money/ajax_payout_money',$template);
    
        
    }
    public function get_payout_processed_details()
    {
        
        $mobile = $this->input->post("mobile");  
        //$date = $this->input->post("date");
        $date=date("Y-m-d", strtotime($this->input->post("date")));
        $this->load->model('payout_money/Payout_money_model');
        $template['payout'] =  $this->Payout_money_model->get_payout_processed_details($mobile,$date);
        $this->load->view('payout_money/ajax_payout_money',$template);
        
    }

    public function get_pay_later_details()
    {
        
        $mobile = $this->input->post("mobile");  
        //$date = $this->input->post("date");
        $date=date("Y-m-d", strtotime($this->input->post("date")));
        $this->load->model('payout_money/Payout_money_model');
        $template['payout'] =  $this->Payout_money_model->get_pay_later_details($mobile,$date);
        $this->load->view('payout_money/ajax_payout_money',$template);
        
    }

    public function get_payout_history_details()
    {
        
        $mobile = $this->input->post("mobile");  
        //$date = $this->input->post("date");
        $date=date("Y-m-d", strtotime($this->input->post("date")));
        $this->load->model('payout_money/Payout_money_model');
        $template['payout'] =  $this->Payout_money_model->get_payout_history_details($mobile,$date);
        $this->load->view('payout_money/ajax_payout_money',$template);
        
    }

    public function get_previous_date($cur_date){
//$cur_date=date('Y-m-d');
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);
            //var_dump($week_days);
$date=new DateTime();
$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

    if($week_days[$i] == $search){
        $arr[$i] = $week_days[$i];
        $search = $week_days[$i] + 1;
    }else{
        $arr2[$i] = $week_days[$i];
    }
}

$action = array_merge($arr,$arr2);
$days = array(
     '1' => 'Monday',
     '2' => 'Tuesday',
     '3' => 'Wednesday',
     '4' => 'Thursday',
     '5' => 'Friday',
     '6' => 'Saturday',
     '7' => 'Sunday'
 );
$final_dt=[];

foreach($action as $da){
if (array_key_exists($da,$days))
  {
  array_push($final_dt,$days[$da]);
  }

}

//var_dump($final_dt);
$final_dates=[];
for($i=1; $i<=52; $i++){
        foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
        array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
        }
    }
   $cur_date=date("Y-m-d", strtotime($cur_date));
    
    //var_dump($final_dates);
    foreach($final_dates as $key=> $fin){
if($cur_date==$fin){
    $keyval= $key-1;
    return $final_dates[$keyval];
}else{
    $keyval=$key;
    $final_dates[$keyval];
}
    }
    //echo $serch_date=$final_dates[$keyval];
}

    }

    public function check5(){
        $check_date=date('Y-m-d');
        $type=$this->db->select('*')->from('gc_payout_type')->where('id',3)->where('status',1)->get()->row();
        $pay_d=$type->Days;
        // $pay_d=3;

        $days = array(
                    '1' => 'Monday',
                    '2' => 'Tuesday',
                    '3' => 'Wednesday',
                    '4' => 'Thursday',
                    '5' => 'Friday',
                    '6' => 'Saturday',
                    '7' => 'Sunday'
                        );
$pay_day=$days[$pay_d];
echo $mnth_date=date("Y-m-d", strtotime("first ".$pay_day." of this month"));echo '<br/>';
$cur_day=ucfirst(date('l',strtotime($check_date)));

//echo $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
if(date('Y-m-d')==$mnth_date){
//echo "matched";echo '<br/>';
    $final_dates=[];
    $yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
         $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));

        if(in_array($mnth_date, $final_dates)){
            
                //echo 'get values';
                $prev_date=date("Y-m-d", strtotime("first ".$pay_day." of previous month"));
                //echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
                $end_date=$this->get_previous_date1($mnth_date);
                $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
       

        $this->db->where('commission.Commision_date>=',$prev_date);
        $this->db->where('commission.Commision_date<=',$end_date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',3);
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            //echo 'null';
        return NULL;
    }
                //echo $prev_date=date('Y-m')
                
            
            
        }else{
            //echo 'today leave';
        }
    }
    
}else{
    $cms_start=$this->get_advance_date1(date('Y-m-d',strtotime($mnth_date)));
    //echo "not Match";
    if(date('Y-m-d')==$cms_start){
        //echo "Match Next Day";

        $prev_date=date("Y-m-d", strtotime("first ".$pay_day." of previous month"));
        //echo $prev_date=date('Y-m-d', strtotime('-1 months', strtotime($mnth_date)));
        
                $end_date=$this->get_previous_date1($cms_start);
                $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
       

        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Status',1);
        $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',3);
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }else{
            //echo 'null';
        return NULL;
    }

    }else{
        return NULL;
        //echo "Not Match Next Day";
    }
}
// $cur_day='Wednesday';
//echo $cur_day;die();
}

public function get_previous_date1($cur_date){
$final_dates=[];
$yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

         $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));

    foreach($final_dates as $key=> $fin){
if($cur_date==$fin){

    
    if($key>=1){
    $keyval= $key-1;
    return  $final_dates[$keyval];
}else{
    //$keyval= date("Y",strtotime("-1 year")).'-12-31';
    return  date("Y",strtotime("-1 year")).'-12-31';
}
    

}else{
    $keyval=$key;
    $final_dates[$keyval];
}
    }
}

    }

    
    public function get_advance_date1($cur_date){
$final_dates=[];
$yrl_dates_0=[];
    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);

            $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
        $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
    
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

         $this->db->select('Date');
                $query = $this->db->get('gc_individual_calendar');
                if ($query->num_rows() > 0) {
                    $db_leave=$query->result_array();
                }else{
                    $db_leave=[];
                }
                $empt_leave=[];
                foreach($db_leave as $lv){
                    array_push($empt_leave,$lv['Date']);

                }
                
                //print_r($db_leave);die();
                $final_dates=array_values(array_diff($final_dates,$empt_leave));

    foreach($final_dates as $key=> $fin){
if($cur_date < $fin){
    
    $keyval= $key;
    if(isset($final_dates[$keyval])){
        return $final_dates[$keyval];
    }else{
        return date('Y-01-01');
    }
    
    break;
}else{
    $keyval=$key;
    $final_dates[$keyval];
}
    }
}

    }

    public function get_three_yrs_holidays($year,$week_days){

//$week_days=['6','7'];
            //var_dump($week_days);
$date=new DateTime();
//$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

    if($week_days[$i] == $search){
        $arr[$i] = $week_days[$i];
        $search = $week_days[$i] + 1;
    }else{
        $arr2[$i] = $week_days[$i];
    }
}

$action = array_merge($arr,$arr2);
$days = array(
     '1' => 'Monday',
     '2' => 'Tuesday',
     '3' => 'Wednesday',
     '4' => 'Thursday',
     '5' => 'Friday',
     '6' => 'Saturday',
     '7' => 'Sunday'
 );
$final_dt=[];
//var_dump($action);
foreach($action as $da){
if (array_key_exists($da,$days))
  {
    //$sim=array('N' => $days[$da], 'A' => $da);
  array_push($final_dt,$days[$da]);
  }

}
//var_dump($final_dt);

$final_dates=[];
for($i=1; $i<=52; $i++){
        foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
        array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
        }
    }
    return $final_dates;
}

function sample(){

     //$pre_date=$this->get_previous_date1(date('Y-m-d')); 
       $check_date='2018-07-02';
        $type=$this->db->select('*')->from('gc_payout_type')->where('id',2)->where('status',1)->get()->row();
        $pay_d=$type->Days;
        // $pay_d=3;
        $days = array(
                    '1' => 'Monday',
                    '2' => 'Tuesday',
                    '3' => 'Wednesday',
                    '4' => 'Thursday',
                    '5' => 'Friday',
                    '6' => 'Saturday',
                    '7' => 'Sunday'
                        );
$pay_day=$days[$pay_d];
$cur_day=ucfirst(date('l',strtotime($check_date)));
// $cur_day='Wednesday';

if($pay_day===$cur_day){
     //echo '';
     $prev_date= date('Y-m-d', strtotime('previous '.$pay_day, strtotime($check_date)));
      $end_date=$this->get_previous_date1($check_date);
        $this->db->select('sum(commission.Amount) as Tot_week_amount');
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile,level_details.Level_ID,contract.Contract_ref_no,pyt.payout_type');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_level_details as level_details', 'level_details.Member_level_detail_ID = commission.Member_level_detail_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = commission.Contract_ID', 'left');

        $this->db->join('gc_payout_type as pyt', 'pyt.id = commission.Payout_ID', 'left');
       

        $this->db->where('commission.Commision_date >=',$prev_date);
        $this->db->where('commission.Commision_date <=',$end_date);
        $this->db->where('commission.Status',1);
        // $this->db->group_by('commission.Commision_type');
        $this->db->group_by('commission.Membership_ID');
        $this->db->where('commission.Payout_ID',2);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();  
        if ($query->num_rows() > 0) {
            //var_dump($query->result_array());
            $wk=$query->result_array();
            
            for($i=0;$i<count($wk);$i++){
                $wk[$i]['Prev_date']=$prev_date;
                $wk[$i]['End_date']=$end_date;

            }
              
        }else{
           return NULL; 
        }


    }else{
        return NULL;
    }
    
}

}
