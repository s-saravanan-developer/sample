
<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Properties </title>

	<!-- ================== GOOGLE FONTS ==================-->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500" rel="stylesheet">
	<!-- ======================= GLOBAL VENDOR STYLES ========================-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/vendor/bootstrap.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/metismenu/dist/metisMenu.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/switchery-npm/index.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css">
	<!-- ======================= LINE AWESOME ICONS ===========================-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/icons/line-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/icons/simple-line-icons.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/tooltip/tooltip.css">
	<!-- ======================= DRIP ICONS ===================================-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/icons/dripicons.min.css">
	<!-- ======================= MATERIAL DESIGN ICONIC FONTS =================-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/icons/material-design-iconic-font.min.css">
	<!-- ======================= PAGE VENDOR STYLES ===========================-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/datatables.net-bs4/css/dataTables.bootstrap4.css">

	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/fullcalendar/dist/fullcalendar.css">
	

	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/select2/select2.min.css">
	<!-- ======================= GLOBAL COMMON STYLES ============================-->
	<?php if($this->uri->uri_string()=='master/Calendar_setting'){?>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/common/main.bundle1.css">
	<?php }else{ ?>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/common/main.bundle.css">
	<?php } ?>
	<!-- ======================= LAYOUT TYPE ===========================-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/layouts/vertical/core/main.css">
	<!-- ======================= MENU TYPE ===========================-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/layouts/vertical/menu-type/default.css">
	<!-- ======================= THEME COLOR STYLES ===========================-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/layouts/vertical/themes/theme-a.css">
		<!-- ======================= PAGE LEVEL VENDOR STYLES ========================-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/bootstrap-datepicker/bootstrap-datepicker.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/bootstrap-daterangepicker/daterangepicker.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/custom.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/iEdit.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/toggle/style.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/notify/toastr.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/multiselect/bootstrap-multiselect.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/autocomplete/jquery.auto-complete.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/autocomplete/jquery.typeahead.css">
	<!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/toggle/css/bootstrap-toggle.min.css"> -->
<script src="<?php echo base_url(); ?>assets/vendor/jquery/dist/jquery.min.js"></script>  	
<script src="<?php echo base_url(); ?>/assets/vendor/jquery-validation/jquery.validate.min.js"></script>

<script src="<?php echo base_url(); ?>assets/js/autocomplete/jquery.auto-complete.min.js"></script>  	
<!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
<script src="<?php echo base_url(); ?>assets/js/autocomplete/jquery.typeahead.js"></script>

<script src="<?php echo base_url(); ?>/assets/vendor/jquery-steps/jquery.steps.min.js"></script>

<script src="<?php echo base_url(); ?>/assets/js/components/horizontal-wizard-init.js"></script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/select2/css/select2.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/select2/css/select2.min.css">



<div class="qt-block-ui"></div>





	<script type="text/javascript">

function preloading(){
			$(".qt-block-ui").show().delay(100).fadeOut();
		}



		$(document).ready(function(){

preloading();

			$(document).ajaxStart(function(){
			    preloading();
			  });

			// focus
			$( "input" ).focus(function() {
		    	$(this).css("background-color", "#ffff0073");	     	
		    	$(this).prop("autocomplete", "off");	     	
		  	});

		  	$( "textarea" ).focus(function() {
		    	$(this).css("background", "#ffff0073");	     	
		  	});

			// Unfocus
			$( "input" ).focusout(function() {
			   	$(this).css("background-color", "");
		    	$(this).prop("autocompleted", "off");	 
			});

			$( "textarea" ).focusout(function() {
		    	$(this).css("background", "white");	     	
		  	});

		  	if('<?php echo $this->uri->segment(1); ?>' =='transaction' || '<?php echo $this->uri->segment(1); ?>' =='Transaction' || '<?php echo $this->uri->segment(1); ?>' =='report' || '<?php echo $this->uri->segment(1); ?>' =='Report' ){
		  		$("body").addClass('pace-done mini-sidebar');
		  	}

		  	// For Disable the Delete Option in Bottom Button
    		$('.btn-accent').closest('tr').find('td input.checkbox').prop("disabled", true);
    		$('.btn-accent').closest('tr').find('td input.checkbox').removeClass('checkbox');


			  // $(".only_number").keypress(function (e) {
			  	$(document).on('keypress', '.only_number', function(e) {
			  // $(".only_number").keypress(function (e) {
			     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			               return false;
			    }
			   });

			  // 	$(document).on('change', '.only_number', function(e) {
			  // // $('.only_number').change(function(){
			  // 	 if($('.only_number').val() == 0 || $('.only_number').val() == ''){
			  // 	 	$('.only_number').val('1');
			  	 	
			  // 	 }
			  // });

			  $(".only_letters").keypress(function (e) {
			     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			               return false;
			    }
			   });

		});

		function get_current_stock(region_id_data,product_id_data,batch_id_data,class_for_change_data){
		     $.ajax({
		             type: "POST",
		             url: "<?php echo base_url(); ?>transaction/Quarantine_entry/get_stock_avail",
		             data: {region_id: region_id_data,product_id: product_id_data,batch_id: batch_id_data},
		             cache: true,
		             async: false,
		             success: function(data){
		                $(''+class_for_change_data+'').val(data);
		             }
		           });
		}
function flag_qty(){
var sum = 0;
        $(".flag_qty").each(function() {

            var value = $(this).val();
            // add only if the value is number
            if(!isNaN(value) && value.length != 0 && value !=0) {
                sum+=0;
            }else{
              sum+=1;
            }
            if(sum!=0){
                $('.sub_but').attr('disabled','disabled');
              }else{
              $('.sub_but').removeAttr('disabled');
            }

        });
}
		
	  
	</script>
	<script type="text/javascript">
function upperCaseF(a){
    setTimeout(function(){
        a.value = a.value.toUpperCase();
    }, 1);
	}
</script>
		<script src="<?php echo base_url(); ?>assets/js/notification.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/valiadation.js"></script>
