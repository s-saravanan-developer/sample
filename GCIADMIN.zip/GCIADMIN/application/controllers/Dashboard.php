<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            session_destroy();
            redirect('login');
        }    
        $this->load->model('master/Users_model');
    }

	public function index()
	{
        $template['active_bank']      =   $this->Users_model->getall_bankactive();
		$template['page']             =   'dashboard/dashboard';
        $this->load->view('template',$template);
	}

    public function get_filter()
    {
        extract($_POST);
        $template['active_bank']      =   $this->Users_model->getall_bankactiveby($date);
        $this->load->view('dashboard/ajax_dashboard',$template);
    }

    public function activate_bank()
    {
        extract($_POST);
        $data['Status']     = 6;

        $id = explode(',', $id);
        $this->db->where_in('Member_bank_ID',$id);
        $this->db->update('gc_member_banks',$data);

        $member_data['Bank_verify'] = 6;
        $this->db->where_in('Membership_ID',$member_id);
        $this->db->update('gc_membership',$member_data);

            date_default_timezone_set('Asia/Kolkata');
            $remark='-[Bank_verify_unique@'.date('Y-m-d H:i:s').']';
            $this->db->where_in('Membership_ID',$member_id);
            $this->db->set('Update_history', "CONCAT(Update_history,'$remark')", FALSE);     
            $this->db->update('gc_membership');

        $this->session->set_flashdata('success', 'Activated');
        redirect('Dashboard');
    }

    public function activate_bank_all()
    {
        extract($_POST);
        $data['Status']     = 6;

        $id = explode(',', $id);
        $this->db->where_in('Member_bank_ID',$id);
        $this->db->update('gc_member_banks',$data);

        $member_id=$this->db->select('Membership_ID')->where_in('Member_bank_ID',$id)->get('gc_member_banks')->result_array();

        foreach ($member_id as $key => $value) {
            $member_data['Bank_verify'] = 6;
            $this->db->where('Membership_ID',$value['Membership_ID']);
            $this->db->update('gc_membership',$member_data);

            date_default_timezone_set('Asia/Kolkata');
            $remark='-[Bank_verify_all@'.date('Y-m-d H:i:s').']';
            $this->db->where('Membership_ID',$value['Membership_ID']);
            $this->db->set('Update_history', "CONCAT(Update_history,'$remark')", FALSE);     
            $this->db->update('gc_membership');
        }

        $this->session->set_flashdata('success', 'Activated');
        redirect('Dashboard');
    }

    //  public function activate_bank_swal()
    // {
    //    	$id=$this->input->get('id');
    //     $data['Status']     = 6;

    //     $id = explode(',', $id);
    //     $this->db->where_in('Member_bank_ID',$id);
    //     $this->db->update('gc_member_banks',$data);
    //     $this->session->set_flashdata('success', 'Activated');
    //     redirect('Dashboard');

    // }

         public function processing_members()
    {
       $this->load->model('member/Membership_model');
        $template['page']='membership/view_processing';
        $this->load->model('Report_model');

        $template['bank']            =  $this->Membership_model->getall_bank();
        $template['payout']          =  $this->Membership_model->getall_payouts_franchasie();
        $status=4;
        $status1='';
        $template['increment_code'] = $this->db->count_all_results('gc_membership');
        $this->db->where('Status',6);
        $template['bank_status'] =  $this->db->count_all_results('gc_member_banks');

        $this->db->where('Status',6);
        $this->db->group_by('Membership_ID');
        $template['document_status'] =  $this->db->count_all_results('gc_member_documents');

        $this->db->where('Payment_status',6);
        $this->db->group_by('Membership_ID');
        $template['payment_status'] =  $this->db->count_all_results('gc_member_payments');
        // $template['document_status'] =  $this->Membership_model->getall_members();
        // $template['payment_status'] =  $this->Membership_model->getall_members();

        $this->db->join('gc_membership as members', 'members.Membership_ID = gc_member_banks.Membership_ID', 'left');
        $this->db->where('gc_member_banks.Status',5);
        $this->db->where('members.Status',4);
        $this->db->from('gc_member_banks');
        $template['bank_status1'] =  $this->db->count_all_results();


        $this->db->select('members.*');
        $this->db->from('gc_membership members');
        $this->db->join('gc_member_documents', 'gc_member_documents.Membership_ID = members.Membership_ID', 'left');
        $this->db->where('gc_member_documents.Status',5);
        $this->db->where('members.Status',4);
        $this->db->group_by('gc_member_documents.Membership_ID');
        $template['document_status1'] =  $this->db->count_all_results();

        // var_dump($template['membership_type']);die();
        $this->load->view('template',$template);
    }

public function delete_member($Membership_ID='')
{
  $count = $this->db->select('Register_from')->where(array('Membership_ID'=>$Membership_ID))->count_all_results('gc_membership');

  if ($count != 0) 
  {
    $this->db->where(array('Membership_ID'=>$Membership_ID))->delete('gc_member_address');
    $this->db->where(array('Membership_ID'=>$Membership_ID))->delete('gc_member_agreement');
    $this->db->where(array('Membership_ID'=>$Membership_ID))->delete('gc_member_banks');
    $this->db->where(array('Membership_ID'=>$Membership_ID))->delete('gc_member_documents');
    $this->db->where(array('Membership_ID'=>$Membership_ID))->delete('gc_member_franchisee_contract');
    $this->db->where(array('Child_ID'=>$Membership_ID))->delete('gc_franchisee_member_relation');

    $level_details = $this->db->select('Member_level_ID,Member_level_detail_ID')->where(array('Child_ID'=>$Membership_ID))->get('gc_member_level_details')->result_array();

    foreach ($level_details as $key => $value) {
        $this->db->where(array('Member_level_ID'=>$level_details[$key]['Member_level_ID']))->delete('gc_member_levels');
    }

    $this->db->where(array('Child_ID'=>$Membership_ID))->delete('gc_member_level_details');
    $this->db->where(array('Membership_ID'=>$Membership_ID))->delete('gc_member_nominees');
    $this->db->where(array('Membership_ID'=>$Membership_ID))->delete('gc_member_payments');

    $this->db->where(array('Membership_ID'=>$Membership_ID))->delete('gc_wallet_payments');
    $this->db->where(array('Membership_ID'=>$Membership_ID))->delete('gc_wallet_topup');

    $this->db->where(array('Membership_ID'=>$Membership_ID))->delete('gc_membership');
    $this->db->where(array('user_id'=>$Membership_ID))->delete('gc_users');
    echo "success";
  }else{
    echo "No data Found";
  }

}

public function change_member_amount($Membership_ID='',$amount)
{
  $member = $this->db->select('Register_from,Membership_mode')->where(array('Membership_ID'=>$Membership_ID))->get('gc_membership')->result_array();
    echo "<pre>";
    print_r($member);
    echo "<br>";

  if ($member[0]['Register_from'] == 'admin') 
  {

    $member_payments = $this->db->select('*')->where(array('Membership_ID'=>$Membership_ID))->count_all_results('gc_member_payments');
    echo "<pre>";
    print_r('No of Rows in Member Payments - '.$member_payments);
    echo "<br><br><br>";

  }elseif ($member[0]['Register_from'] == 'member'){

    $wallet_payments = $this->db->select('*')->where(array('Membership_ID'=>$Membership_ID))->count_all_results('gc_wallet_payments');

    echo "<pre>";
    print_r('No of Rows in Wallet Payments - '.$wallet_payments);
    echo "<br><br><br>";
  }
  if ($member[0]['Register_from'] == 'admin') 
  {
    echo "<a href=".site_url('dashboard/change_amount_sure/'.$Membership_ID.'/'.$amount).">Proceed to change all</a>";
    echo "<br><br><br>";

    echo "<a href=".site_url('dashboard/change_amount_sure_initial/'.$Membership_ID.'/'.$amount).">Initial</a>";
    }
}

public function get_membershipID_by_membershipCode($Membership_code='')
{
	$Membership_code = explode('-', $Membership_code);
	  $member = $this->db->select('Membership_ID,Membership_code,Membership_mode,First_name')->where_in('Membership_code ', $Membership_code )->get('gc_membership')->result_array();
	  echo "<pre>";
	  print_r($member);
}

public function get_membershipCode_by_membershipID($Membership_ID='')
{
	$Membership_ID = explode('-', $Membership_ID);
	  $member = $this->db->select('Membership_ID,Membership_code,Membership_mode,First_name')->where_in('Membership_ID ', $Membership_ID )->get('gc_membership')->result_array();
	  echo "<pre>";
	  print_r($member);
}

public function total_change( $Membership_code){

	$Membership_code = explode('-', $Membership_code);
	
	foreach ($Membership_code as $key => $value) {
		$value = explode('_', $value);

		$member = $this->db->select('Membership_ID')->where_in('Membership_code ', $value[0] )->get('gc_membership')->result_array();
		$this->change_amount_sure($member[0]['Membership_ID'],$value[1]);
	}
	echo "success";
}

public function total_delete_member( $Membership_code){

	$Membership_code = explode('-', $Membership_code);
	
	foreach ($Membership_code as $key => $value) {
		$value = explode('_', $value);

		$member = $this->db->select('Membership_ID')->where_in('Membership_code ', $value[0] )->get('gc_membership')->result_array();
		$this->delete_member($member[0]['Membership_ID']);
	}
	echo "success";
}

public function change_amount_sure($Membership_ID='',$amount)
{	
  $member = $this->db->select('Register_from,Membership_mode')->where(array('Membership_ID'=>$Membership_ID))->get('gc_membership')->result_array();

  if ($member[0]['Register_from'] == 'admin') 
  {
    $member_payment_count = $this->db->select('*')->where(array('Membership_ID'=>$Membership_ID))->count_all_results('gc_member_payments');
    if ($member[0]['Membership_mode'] == 1) 
    {
    if ($member_payment_count==1) {
    $data = array('Amount' => $amount );
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_franchisee_contract',$data);
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_payments',$data);
    }else{
    $data = array('Amount' => $amount );
    $payment_data = array('Amount' => ($amount/$member_payment_count) );
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_franchisee_contract',$data);
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_payments',$payment_data);
    }   
    }elseif ($member[0]['Membership_mode'] == 2) 
    {
    if ($member_payment_count==1) {

        $payment_data  = array('Amount' => $amount/70 );
        $contract_data = array('Investment' => $amount, 'Amount' => ($amount/70));
        $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_franchisee_contract',$contract_data);
        $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_payments',$payment_data);

    }else{
        $payment_data  = array('Amount' => ($amount/$member_payment_count) );
        $contract_data = array('Investment' => $amount, 'Amount' => ($amount/70));
        $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_franchisee_contract',$contract_data);
        $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_payments',$payment_data);
    }

    }


  }elseif ($member[0]['Register_from'] == 'member'){


    $wallet_payments_count = $this->db->select('*')->where(array('Membership_ID'=>$Membership_ID))->count_all_results('gc_wallet_payments');
    if ($wallet_payments_count==1) {

    $data = array('Amount' => $amount );
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_franchisee_contract',$data);
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_wallet_payments',$data);
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_wallet_topup',$data);

  }else{

    $contract_data = array('Amount' => ($amount));
    $data = array('Amount' => ($amount/$wallet_payments_count));
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_wallet_topup',$contract_data);
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_franchisee_contract',$contract_data);
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_wallet_payments',$data);

  }
}

}


public function change_amount_sure_initial($Membership_ID='',$amount)
{
  $member = $this->db->select('Register_from,Membership_mode')->where(array('Membership_ID'=>$Membership_ID))->get('gc_membership')->result_array();

  if ($member[0]['Register_from'] == 'admin') 
  {
    $member_payment_count = $this->db->select('*')->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->count_all_results('gc_member_payments');
    if ($member[0]['Membership_mode'] == 1) 
    {
    if ($member_payment_count==1) {
    $data = array('Amount' => $amount );
    $this->db->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->update('gc_member_franchisee_contract',$data);
    $this->db->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->update('gc_member_payments',$data);
    }else{
    $data = array('Amount' => $amount );
    $payment_data = array('Amount' => ($amount/$member_payment_count) );
    $this->db->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->update('gc_member_franchisee_contract',$data);
    $this->db->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->update('gc_member_payments',$payment_data);
    }   
    }elseif ($member[0]['Membership_mode'] == 2) 
    {
    if ($member_payment_count==1) {

        $payment_data  = array('Amount' => $amount );
        $contract_data = array('Investment' => $amount, 'Amount' => ($amount/70));
        $this->db->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->update('gc_member_franchisee_contract',$contract_data);
        $this->db->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->update('gc_member_payments',$payment_data);

    }else{
        $payment_data  = array('Amount' => ($amount/$member_payment_count) );
        $contract_data = array('Investment' => $amount, 'Amount' => ($amount/70));
        $this->db->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->update('gc_member_franchisee_contract',$contract_data);
        $this->db->where(array('Membership_ID'=>$Membership_ID,'Invest_type'=>1))->update('gc_member_payments',$payment_data);
    }

    }

  }elseif ($member[0]['Register_from'] == 'member'){

    $wallet_payments_count_contract = $this->db->select('*')->where(array('Membership_ID'=>$Membership_ID))->count_all_results('gc_member_franchisee_contract');
    $wallet_payments_count = $this->db->select('*')->where(array('Membership_ID'=>$Membership_ID))->count_all_results('gc_wallet_payments');
    if ($wallet_payments_count_contract==0) {
    if ($wallet_payments_count==1) {

    $data = array('Amount' => $amount );
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_franchisee_contract',$data);
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_wallet_payments',$data);
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_wallet_topup',$data);

  }else{

    $contract_data = array('Amount' => ($amount));
    $data = array('Amount' => ($amount/$wallet_payments_count));
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_wallet_topup',$contract_data);
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_member_franchisee_contract',$contract_data);
    $this->db->where(array('Membership_ID'=>$Membership_ID))->update('gc_wallet_payments',$data);

  }

}else{
    echo "You're activated.. Go to Database to change";
}

}

}


public function get_excat_next_payout($cl_dt){

    // $cl_dt='2019-05-08';
    $com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
    if(!empty($com_pay_date)){
        $commission_pay_date=$com_pay_date[0]['Pay_dates'];
    }else{
        $commission_pay_date='7,14,21,28';
    }
    $commission_pay_date=explode(',',$commission_pay_date);


        $per_date=date('d',strtotime($cl_dt));
        $temp_date=date('Y-m',strtotime($cl_dt));

            foreach($commission_pay_date as $key => $val){
                if($per_date < $val){
                if($key != 0){
                    $exct_day= $commission_pay_date[$key-1];
                    break;
                }elseif($per_date==7){
                    $exct_day=$val;
                    break;
                }else{
                    $exct_day=$commission_pay_date[3];
                    break;
                }
            }

                if($per_date == 28){
                    $exct_day=28;
                    break;
                }elseif($per_date >= 28){
                    $exct_day=28;
                    break;
                }
            }

            if($per_date>=$exct_day){

                    $final_payout_date=date($temp_date.'-'.$exct_day);

                }else{

                    $samp_dy=date($temp_date.'-'.$exct_day);
                    $final_payout_date=date('Y-m-d', strtotime($samp_dy. ' -1 months'));
                    
                }

            echo $payout_date=date('Y-m-d',strtotime($final_payout_date));
}


public function date($cl_dt){

$commission_pay_date='7,14,21,28';

$commission_pay_date=explode(',',$commission_pay_date);

$per_date=date('d',strtotime($cl_dt));

    foreach($commission_pay_date as $key => $val){

        if($per_date <= $val){

            if ($key==0) {
                $exct_day= $val;
                break;
            }else{
                $exct_day= $commission_pay_date[$key-1];
                break;
            }

        }else{
                $exct_day=$commission_pay_date[0];
            }

    }
    echo $exct_day;
}


public function get_level()
{

	$this->load->model('member/Membership_model');

	$Membership_ID = $this->db->get('gc_membership')->result_array();

	foreach ($Membership_ID as $key => $value) {

$Membership_ID=$value['Membership_ID'];
$Register_date=$value['Created_date'];
$member['Reference_ID']=$value['Reference_ID'];
$Company_ID=1;


$ref_ID="";$level_insert_id="";
		for($i=1;$i<=9;$i++){ 
			if($i==1){
			$this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$member['Reference_ID']);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			//var_dump($binary);
			$crnt_lvl=$binary[0]['Current_level'];
			 $level['Level_ID']=$i;
			if($crnt_lvl<=$i){
			$member_level=$i;
			}
			else{
				$member_level=$crnt_lvl;
			}
			$ref_ID=$binary[0]['Reference_ID'];
 // Member Level Master Insert start
			$levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_master['Company_id']       =  $Company_ID;
			$levels_master['Branch_id']        =  $Company_ID;
			$levels_master['Level_ID']         =  1;
			$levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_master['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_master['Date']             = $Register_date;
			$this->db->insert('gc_member_levels', $levels_master);
			$level_insert_id=$this->db->insert_id();

// Member Level Master Insert end         
// Member Level Details Insert start 
			$levels_data['Member_level_ID']  =  $level_insert_id;
			$levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_data['Child_ID']         =  $Membership_ID;
			$levels_data['Company_id']       =  $Company_ID;
			$levels_data['Branch_id']        =  $Company_ID;
			$levels_data['Level_ID']         =  $level['Level_ID'];
			// $levels_data['Position']         =  $binary_relation['Ex_position_type'];
			$levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_data['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_data['Level_date']       = $Register_date;
			$this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start
// Membership Current Level Insert start
			$mem_lvl['Member_grade']=NULL;
			$grade_count1=$this->db->where(array('Membership_ID'=>$binary[0]['Membership_ID'],'Level_ID'=>1))->count_all_results('gc_member_level_details');
			// echo $grade_count1;
			if($grade_count1>=6){
			$mem_lvl['Member_grade']=3;
			}
			$grade_count2=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count2>=6){
			$mem_lvl['Member_grade']=2;
			}
			$grade_count3=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count3>=6){
			$mem_lvl['Member_grade']=1;
			}

			$mem_lvl['Current_level']=$member_level;
			// var_dump($mem_lvl);
			$this->db->where('Membership_ID',$binary[0]['Membership_ID']);
			$this->db->update('gc_membership', $mem_lvl);

			if($Register_date >= '2019-05-01' && $Register_date <= '2019-08-08'){
			  if($contract_data['Amount'] >= 10500 || $contract_data['Amount'] >= 25500 || $contract_data['Amount'] >= 50250 ){ 

				$gold_1=array(
							'Membership_ID'	    => $binary[0]['Membership_ID'],
							'Child_ID'	        => $Membership_ID,
							'Level_ID'	        => $level['Level_ID'],
							'Child_investment'	=> $contract_data['Amount'],
							'Offer_value'	    => $sponsor_part,
							'Created_date'	    => $Register_date);

				$gl_1=$this->db->insert('gc_gold_offer',$gold_1);

			 }
            }

            $star=$this->Membership_model->set_green_star($binary[0]['Membership_ID']);
// Membership Current Level Insert end

		}
	}
	else{
			$this->db->select('*');
			$this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
			$this->db->from('gc_membership as member');
			$this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
			$this->db->where('member.Membership_ID',$ref_ID);
			$query= $this->db->get();
			if($query->num_rows() > 0) {
			$binary=$query->result_array();
			$crnt_lvl=$binary[0]['Current_level'];
			$level['Level_ID']=$i;
			if($crnt_lvl<=$i){
			$member_level=$i;
			}
			else{
				$member_level=$crnt_lvl;
			}
			$ref_ID=$binary[0]['Reference_ID'];

 // Member Level Master Insert start
			$levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_master['Company_id']       =  $Company_ID;
			$levels_master['Branch_id']        =  $Company_ID;
			$levels_master['Level_ID']         =  $level['Level_ID'];
			$levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_master['Payout_status']    =  $binary[0]['Payout_status'];
			$this->db->insert('gc_member_levels', $levels_master);
			$levels_master['Date']             = $Register_date;
			$level_insert_id=$this->db->insert_id();
// Member Level Master Insert end         
// Member Level Details Insert start 
			$levels_data['Member_level_ID']  =  $level_insert_id;
			$levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
			$levels_data['Child_ID']         =  $Membership_ID;
			$levels_data['Company_id']       =  $Company_ID;
			$levels_data['Branch_id']        =  $Company_ID;
			$levels_data['Level_ID']         =  $level['Level_ID'];
			// $levels_data['Position']         =  $binary_relation['Ex_position_type'];
			$levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
			$levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
			$levels_data['Payout_status']    =  $binary[0]['Payout_status'];
			$levels_data['Level_date']       = $Register_date;
			$this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start

// Membership Current Level Insert start
			$mem_lvl['Member_grade']=NULL;
			$grade_count1=$this->db->where(array('Membership_ID'=>$binary[0]['Membership_ID'],'Level_ID'=>1))->count_all_results('gc_member_level_details');
			// echo $grade_count1;
			if($grade_count1>=6){
			$mem_lvl['Member_grade']=3;
			}
			$grade_count2=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count2>=6){
			$mem_lvl['Member_grade']=2;
			}
			$grade_count3=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
			if($grade_count3>=6){
			$mem_lvl['Member_grade']=1;
			}

			// var_dump($mem_lvl);
			$mem_lvl['Current_level']=$member_level;
			$this->db->where('Membership_ID',$binary[0]['Membership_ID']);
			$this->db->update('gc_membership', $mem_lvl);

			if($Register_date >= '2019-05-01' && $Register_date <= '2019-08-08'){
			  if($contract_data['Amount'] >= 10500 || $contract_data['Amount'] >= 25500 || $contract_data['Amount'] >= 50250 ){ 
				if($mem_lvl['Member_grade']==3 || $mem_lvl['Member_grade']==2 || $mem_lvl['Member_grade']==1 ){
					if($mem_lvl['Member_grade']==3){
						$offer=$coordinator_part;
					}elseif($mem_lvl['Member_grade']==2){
						$offer=$manager_part;
					}elseif($mem_lvl['Member_grade']==1){
						$offer=$head_part;						
					}
					$gold_2=array(
							'Membership_ID'	    => $binary[0]['Membership_ID'],
							'Child_ID'	        => $Membership_ID,
							'Level_ID'	        => $level['Level_ID'],
							'Child_investment'	=> $contract_data['Amount'],
							'Offer_value'	    => $offer,
							'Created_date'	    => $Register_date);

				$gl_2=$this->db->insert('gc_gold_offer',$gold_2);
				}	

				


              }

        	}


			$star=$this->Membership_model->set_green_star($binary[0]['Membership_ID']);


				}

			}
		}

//////    end of for



	}
}

}
