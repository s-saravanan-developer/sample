<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Help extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();

        }
        $this->load->helper(array('form', 'url'));
        $this->load->model('master/Help_model');
        $this->load->model('master/Users_model');
    }

	public function index()
	{
        
		$template['page']='help/view_ticket';
        $template['request'] = $this->Help_model->getallrequest();
        $template['ticket'] = $this->Help_model->getallticket();
        // var_dump($template['ticket']);die();
        $this->load->view('template',$template);
		
	}

    public function feedback()
    {
        
        $template['page']='help/view_feedback';
        $template['feedback'] = $this->Help_model->getallfeedback();
        $this->load->view('template',$template);
        
    }

    public function reset_pwd()
    {
        
        $template['page']='help/view_reset_pwd';
        $this->load->view('template',$template);
        
    }

    public function get_all_details()
    {
        
        $template['page']='help/view_get_all_details';
        $this->load->view('template',$template);
        
    }

    public function calendar()
    {
        
        $template['page']           =   'help/view_calendar';
        $template['table_name']     =   "gc_company_table";
        $template['weeks']          =   $this->Calendar_setting_model->get_weeks();
        $template['holiday']        =   $this->Calendar_setting_model->get_holidays();
        $this->load->view('template',$template);
        
    }

public function add_ticket()
{
    extract($_POST);

    $Ref_no = ($this->db->count_all_results('gc_ticket')+1);
    $member_id = $this->session->userdata('UserCode');

    $name = "ticket_image";
    $common = "Service";
    // $ticket_image = $this->Help_model->uploads($Ref_no,$member_id,$name,$common);

    $data = array('Ref_no' => 'GC-TKT-'.$Ref_no, 
                  'Membership_ID' => $member_id,
                  // 'Ticket_image' => $ticket_image,
                  'Member_request' => $member_request,
                  'Created_on' => date('Y-m-d'),
                  'Desc' => $desc
                );
// var_dump($data);die();
    $this->db->insert('gc_ticket',$data);
    $this->session->set_flashdata('message',  array('message' => 'Added Successfully','class' => 'success'));
    redirect('Help');
}

public function get_ticket_details()
{   

$id = $this->input->post("mobile");
$dates = $this->input->post("date");
$date = date('Y-m-d',strtotime($dates));

$membership_id = $this->Help_model->getmembershipby($id);

$template['ticket'] = $this->Help_model->getallticketby($id,$membership_id[0]['Membership_ID'],$date);

$this->load->view('help/ajax_help',$template);
}

public function get_feedback_details()
{   

$id = $this->input->post("mobile");
$dates = $this->input->post("date");
$date = date('Y-m-d',strtotime($dates));

$membership_id = $this->Help_model->getmembershipby($id);

$template['feedback'] = $this->Help_model->getallfeedbackby($id,$membership_id[0]['Membership_ID'],$date);
// print_r($template['feedback']);die();
$this->load->view('help/ajax_help',$template);
}

public function get_reset_details()
{   

$id = $this->input->post("mobile");

$template['membership'] = $this->Help_model->getmembershipall($id);
$this->load->view('help/ajax_help',$template);
}

public function update_password($id)
{   
$member_details = $this->Help_model->getuserdetails($id);

$users_data = array('password' => md5($member_details[0]['Membership_code']),'og_password' => $member_details[0]['Membership_code']  );

$this->db->where('user_id',$id);
$this->db->where('user_type_id',3);
$this->db->update('gc_users',$users_data);
redirect('Help/reset_pwd');
}

}



        