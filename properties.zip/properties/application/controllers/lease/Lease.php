<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lease extends CI_Controller {

	public function __construct() {

    parent::__construct();
    if ($this->session->userdata('is_logged_in') == '') {            
      redirect('login');
      session_destroy();
    }
    $this->load->helper(array('form', 'url'));
    $this->load->model('Lease_model');
  }

  public function index()
  {  
    $template['lease']      =   $this->Lease_model->get_lease();
    $template['page']       =   'lease/view_lease';
    $this->load->view('template',$template);
  }

  public function lease_expiry()
  {  
    $template['page']       =   'lease/view_lease_expiry';
    $template['customer']   =   $this->Lease_model->get_customer();
    $template['area']       =   $this->Lease_model->get_area();
    $this->load->view('template',$template);
  }

  public function report_lease()
  {  
    $template['customer']   =   $this->Lease_model->get_customer();
    $template['area']       =   $this->Lease_model->get_area();
    $template['page']       =   'lease/view_lease_report';
    $this->load->view('template',$template);
  }

  public function addlease()
  {       
    $template['page']       =   'lease/view_add_lease';
    $template['customer']   =   $this->Lease_model->get_customer();
    $template['area']       =   $this->Lease_model->get_area();
    $this->load->view('template',$template);
  }

  public function editlease()
  { 
    $lease = $this->input->post('id');
    $template['customer']   =   $this->Lease_model->get_customer();
    $template['area']       =   $this->Lease_model->get_area();
    $template['lease']      =   $this->Lease_model->get_lease($lease);      
    $template['page']       =   'lease/view_edit_lease';
    $this->load->view('template',$template);
  }

  public function get_area_by_areaid() 
  {
    $id = $this->input->post('area');
    $data = $this->Lease_model->get_area_by_areaid($id);
    echo json_encode($data);
  }

  public function add_lease()
  {
    extract($_POST);

// check area already inserted, if not then insert and return area id
    if ($this->db->where(array('area_name' => $area['area_name']))->get('prop_area')->result_array()) {
      $lease['area_id']=$this->db->select('area_id')->where(array('area_name' => $area['area_name']))->get('prop_area')->row('area_id');
    }else{
      $this->db->insert('prop_area',$area);
      $lease['area_id']=$this->db->insert_id();
    }

// check Customer already inserted, if not then insert and return Customer id
    if ($this->db->where(array('customer_name' => $customer['customer_name']))->get('prop_customer')->result_array()) {
      $lease['customer_id']=$this->db->select('customer_id')->where(array('customer_name' => $customer['customer_name']))->get('prop_customer')->row('customer_id');
    }else{
      $this->db->insert('prop_customer',$customer);
      $lease['customer_id']=$this->db->insert_id();
    }

    $lease['start_date']    = date('Y-m-d',strtotime(str_replace('/', '-',$lease['start_date'])));
    $lease['end_date']      = date('Y-m-d', strtotime($lease['start_date']. ' + '.$lease['lease_tenure'].' years'));

    $lease['created_date']  = date('Y-m-d H:i:s');
    $lease['created_by']    = $this->session->userdata('UserId'); 
    $this->db->insert('prop_lease',$lease);
    $member_id=$this->db->insert_id();

    foreach ($lease_data as $value) {
      $value['lease_id']      = $member_id;
      $this->db->insert('prop_lease_details',$value);
    }

    $this->session->set_flashdata('success', 'Added');
    redirect('lease/lease');
    // redirect('lease/lease/mail/'.$member_id);

  }

  public function edit_lease()
  {
    extract($_POST);

    $lease['lease_total']   = $lease['escalation']+$lease['area_total']+$lease['parking']+$lease['aircondition']+$lease['management_fees'];

    $lease['start_date']    = date('Y-m-d',strtotime(str_replace('/', '-',$lease['start_date'])));
    $lease['end_date']      = date('Y-m-d',strtotime(str_replace('/', '-',$lease['end_date'])));

    $lease['updated_date']  = date('Y-m-d H:i:s');
    $lease['updated_by']    = $this->session->userdata('UserId'); 
    $this->db->where('lease_id',decrypt($lease_id));
    $this->db->update('prop_lease',$lease);
    $this->session->set_flashdata('success', 'Updated');
    redirect('lease/lease');

  }

  public function get_lease_report()
  {   
    $template['lease']    =   $this->Lease_model->get_lease_report();
    $this->load->view('lease/ajax_lease',$template);
  }

  public function get_lease_expiry_report()
  {   
    $template['lease']    =   $this->Lease_model->get_lease_expiry_report();
    $this->load->view('lease/ajax_lease',$template);
  }

  public function get_lease_report_excel()
  {   
    $template['lease']    =   $this->Lease_model->get_lease_report();

    if (!empty($template['lease'])) 
    {
     echo $template=1;
   }else{
    echo $template=2;
  }
}

public function get_lease_expiry_report_excel()
{   
  $template['lease']    =   $this->Lease_model->get_lease_expiry_report();

  if (!empty($template['lease'])) 
  {
   echo $template=1;
 }else{
  echo $template=2;
}
}
public function get_lease_excel_report($start=NULL,$end,$area=NULL,$customer=NULL)
{   
  $template['lease']    =   $this->Lease_model->get_lease_excel_report($start,$end,$area,$customer);
  $this->load->view('lease/excel_lease',$template);

}

public function get_lease_expiry_excel_report($start=NULL,$end,$area=NULL,$customer=NULL)
{   
  $template['lease']    =   $this->Lease_model->get_lease_expiry_excel_report($start,$end,$area,$customer);
  $this->load->view('lease/excel_lease',$template);

}

public function delete_lease()
{
  extract($_POST);
  $data['status'] = 3;
  $data['deleted_date'] = date('Y-m-d H:i:s');
  $data['deleted_by'] = $this->session->userdata('UserId'); 
  $this->db->where('lease_id',$lease_id);
  $this->db->update('prop_lease',$data);
  $this->session->set_flashdata('success', 'Deleted');
  redirect('lease/lease');
}


public function mail($id)
{
  $lease     =   $this->Lease_model->get_lease($id);
  $lease_details     =   $this->Lease_model->get_lease_detail_by($id);

  $for='';
  foreach ($lease_details as $key => $value) { 
    $for.='
    <tr>
    <td data-label="Account">'.$value['category_type'].'</td>
    <td data-label="Account">'.$value['category_amount_type'].'</td>
    <td data-label="Account">'.$value['category_percentage'].'</td>
    <td data-label="Account">'.$value['category_value'].'</td>
    </tr>';
  }



  $promoter_name='sarath';
  $date=date('d-m-Y');
  $mobile='999999999';
  $email='test@gmail.com';

  $total_amount=$lease[0]['detail_total']+$lease[0]['area_total'];              
  $date1   = $lease[0]['start_date'];
  $date2   = $lease[0]['end_date'];
  $diff    = abs(strtotime($date2) - strtotime($date1));
  $years   = floor($diff / (365*60*60*24));
  $months  = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
  $days    = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

  $msg='
  <style>
  body {
    font-family: "ROBOTO", sans-serif;
    line-height: 1.25;
  }

  table {
    border: 1px solid #ccc;
    border-collapse: collapse;
    margin: 0;
    padding: 0;
    width: 100%;
    table-layout: fixed;
  }

  table caption {
    font-size: 1.5em;
    margin: .5em 0 .75em;
  }

  table tr {
    background-color: #f8f8f8;
    border: 1px solid #ddd;
    padding: .35em;
  }

  table th,
  table td {
    padding: .625em;
    text-align: center;
  }

  table th {
    font-size: .85em;
    letter-spacing: .1em;
    text-transform: uppercase;
  }

  @media screen and (max-width: 600px) {
    table {
      border: 0;
    }

    table caption {
      font-size: 1.3em;
    }

    table thead {
      border: none;
      clip: rect(0 0 0 0);
      height: 1px;
      margin: -1px;
      overflow: hidden;
      padding: 0;
      position: absolute;
      width: 1px;
    }

    table tr {
      border-bottom: 3px solid #ddd;
      display: block;
      margin-bottom: .625em;
    }

    table td {
      border-bottom: 1px solid #ddd;
      display: block;
      font-size: .8em;
      text-align: right;
    }

    table td::before {
      content: attr(aria-label);

      content: attr(data-label);
      float: left;
      font-weight: bold;
      text-transform: uppercase;
    }

    table td:last-child {
      border-bottom: 0;
    }
  }
  </style>
  <![endif]-->
  </head>
  <body style="background-color: #f4f4f4;">


  <table>
  <caption>Property Summary</caption>
  <thead>
  <tr>
  <th scope="col">Tenent Origin</th>
  <th scope="col">Tenent Type</th>
  <th scope="col">Customer</th>
  <th scope="col">Lease Type</th>
  <th scope="col">Area</th>
  <th scope="col">Area Sqm</th>
  <th scope="col">Amount</th>
  <th scope="col">Period</th>
  <th scope="col">Start Date</th>
  <th scope="col">End Date</th>
  </tr>
  </thead>
  <tbody>
  <tr>
  <td data-label="Account">'.$lease[0]['tenant_origin'].'</td>
  <td data-label="Account">'.$lease[0]['tenant_type'].'</td>
  <td data-label="Account" style="color:#db3236; font-weight:bold">'.$lease[0]['customer_name'].'</td>
  <td data-label="Account">'.$lease[0]['lease_type'].'</td>
  <td data-label="Account">'.$lease[0]['area_name'].'</td>
  <td data-label="Account">'.$lease[0]['area_sqm'].'</td>
  <td data-label="Account" style="color:#db3236; font-weight:bold">'.number_format($total_amount,2).'</td>
  <td data-label="Account">'.$lease[0]['lease_tenure'].' years</td>
  <td data-label="Account">'.date('d-m-Y',strtotime($lease[0]['start_date'])).'</td>
  <td data-label="Account">'.date('d-m-Y',strtotime($lease[0]['end_date'])).'</td>
  </tr>
  </tbody>
  </table>
  <table>
  <caption>Extra Summary</caption>
  <tbody>
  <tr>
  <td data-label="Account">Category Type</td>
  <td data-label="Account">Category Amount Type</td>
  <td data-label="Account">Category Percentage</td>
  <td data-label="Account">Category Value</td>
  </tr>
  '.$for.'

  </tbody>
  </table>
  </td>
  </tr>
  </table>

  </td></tr></table>

  </center>
  </body>
  </html>
  ';
  
  $config = Array(
    'protocol' => 'smtp',
    'smtp_host' => 'ssl://smtp.googlemail.com',
    'smtp_port' => 465,
    'smtp_user' => 'linktomequals@gmail.com', 
    'smtp_pass' => 'Welcome123@',
    'mailtype' => 'html',
    'charset' => 'iso-8859-1',
    'wordwrap' => TRUE
  );


  $this->load->library('email', $config);
  $this->email->from('linktomequals@gmail.com'); 
  $this->email->to('ragulthangaraju@gmail.com');
  $this->email->subject('New Property Entry');
  $this->email->message($msg);
  $this->email->set_newline("\r\n");
  if($this->email->send())
  {
    $this->session->set_flashdata('success', 'Added & Mail Sent');
    redirect('lease/lease');
  }
  else
  {
    // $this->session->set_flashdata('success', 'Added & Mail Sent');
    // redirect('lease/lease');
   show_error($this->email->print_debugger());
 }

}

public function date_change(){
  extract($_POST);
  // var_dump($start_date);
  // var_dump($lease_year);
  // var_dump($lease_month);die();
  $start_date    = date('Y-m-d',strtotime(str_replace('/', '-',$start_date)));
  $end_date     = date('d-m-Y', strtotime($start_date. ' + '.$lease_year.' years'));
  $end_date     = date('d-m-Y', strtotime($end_date. ' + '.$lease_month.' months'));
  $end_date     = date('d-m-Y', strtotime($end_date. ' -1 day'));
  echo $end_date;

}


}