<?php extract($_POST);
// print_r($data);
//echo $data[3];


 ?>

   <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Preview Image</h4>
      </div>
      <div class="modal-body">
        <div class="row">
        	 <!-- <div class="card"> -->
 	<div class="col-md-12">
      <div class="col-md-4" style="margin-left:-13px;"><img src="./cup/cup_right.jpg" style="display:inline-block;width:285px;height:200px;"><span><img src="<?php echo $data[0]; ?>" style="margin-top: -229px; margin-left: 100px; width: 178px; height: 160px;"></span></div>

      <div class="col-md-4" style=""><img src="./cup/cup_front.jpg" style="display:inline-block;width:285px;height:200px;"><span><img src="<?php echo $data[1]; ?>" style="margin-top: -229px; margin-left: 53px; width: 180px; height: 160px;"></span></div>

      <div class="col-md-4" style=""><img src="./cup/cup_left.jpg" style="display:inline-block;width:285px;height:200px;"><span><img src="<?php echo $data[2]; ?>" style="margin-top: -229px; margin-left: 7px; width: 178px; height: 160px;"></span></div>

    </div>
 <!-- </div> -->
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>

