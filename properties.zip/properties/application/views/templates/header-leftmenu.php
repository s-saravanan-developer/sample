<aside class="sidebar sidebar-left">
	<div class="sidebar-content">
		<div class="aside-toolbar">
			<ul class="site-logo">
				<li>
					<a href="<?php echo base_url(); ?>dashboard">
						<div class="logo"></div>
						<span class="brand-text">Properties Pro</span>
					</a>
				</li>
			</ul>
			<ul class="header-controls">
				<li class="nav-item">
					<button type="button" class="btn btn-link btn-menu" data-toggle-state="mini-sidebar">
						<i class="la la-dot-circle-o"></i>
					</button>
				</li>
			</ul>
		</div>
		<nav class="main-menu">
			<ul class="nav metismenu">

				<li class="<?php if($this->uri->uri_string()=='dashboard'){echo 'active';}?>">
					<a class="" href="<?php echo base_url(); ?>dashboard" aria-expanded="false"><i class="icon dripicons-meter"></i><span>Dashboard</span></a>
				</li>
				
				<li class="nav-dropdown <?php if($this->uri->uri_string()=='master/company' || $this->uri->uri_string()=='master/company/company_add' || $this->uri->uri_string()=='master/company/company_edit' || $this->uri->uri_string()=='master/location' || $this->uri->uri_string()=='master/location/state' || $this->uri->uri_string()=='master/location/city' || $this->uri->uri_string()=='master/company/advanced_setting' || $this->uri->uri_string()=='master/Properties' || $this->uri->uri_string()=='master/Lease' || $this->uri->uri_string()=='master/Categories' || $this->uri->uri_string()=='master/Tenant'){echo 'active';}?>">

				<a class="has-arrow " href="#" aria-expanded="<?php if($this->uri->uri_string()=='master/company' || $this->uri->uri_string()=='master/location' || $this->uri->uri_string()=='master/location/state' || $this->uri->uri_string()=='master/location/city' || $this->uri->uri_string()=='master/company/advanced_setting' || $this->uri->uri_string()=='master/Properties' || $this->uri->uri_string()=='master/Lease' || $this->uri->uri_string()=='master/Categories' || $this->uri->uri_string()=='master/Tenant'){echo 'true';}else{ echo 'false';}?>"><i class="icon dripicons-view-thumb"></i>
						<span>Master </span>
					</a>
					<ul class="collapse nav-sub" aria-expanded="false">

						<li class="nav-dropdown <?php if($this->uri->uri_string()=='master/company'|| $this->uri->uri_string()=='master/company/company_edit' || $this->uri->uri_string()=='master/company/company_add'){echo 'active';}?>">
							<a class="has-arrow " href="#" aria-expanded="<?php if($this->uri->uri_string()=='master/company' || $this->uri->uri_string()=='master/company/prefix_setting' || $this->uri->uri_string()=='master/company/advanced_setting'){echo 'true';}else{ echo 'false';}?>"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
								Company
							</a>
							<ul class="nav-sub" aria-expanded="false">
								<li class="<?php if($this->uri->uri_string()=='master/company' || $this->uri->uri_string()=='master/company/company_add' || $this->uri->uri_string()=='master/company/company_edit'){echo 'active';}?>">
									<a class="" href="<?php echo base_url(); ?>master/company/"><i class="zmdi zmdi-caret-right zmdi-hc-fw"></i>
										Manage Companies
									</a>
								</li>
								<li class="">
									<a href="#"><i class="zmdi zmdi-caret-right zmdi-hc-fw"></i>
										Prefix Setting
									</a>
								</li>
								<li class="<?php if($this->uri->uri_string()=='master/company/advanced_setting'){echo 'active';}?>">
												<a href="<?php echo base_url(); ?>master/company/advanced_setting"><i class="zmdi zmdi-caret-right zmdi-hc-fw"></i>
													Advanced Setting
												</a>
								</li>
							</ul>
						</li>

						<li class="<?php if($this->uri->uri_string()=='master/Properties'){echo 'active';}?>">				
							<a href="<?php echo base_url(); ?>master/Properties" aria-expanded="false"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i> <span>Properties Type</span></a>
						</li>

						<li class="<?php if($this->uri->uri_string()=='master/Categories'){echo 'active';}?>">
							<a href="<?php echo base_url(); ?>master/Categories" aria-expanded="false"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i> <span>Categories</span></a>						
						</li>
						
						

							<li class="<?php if($this->uri->uri_string()=='master/Lease'){echo 'active';}?>">
								<a href="<?php echo base_url(); ?>master/Lease" aria-expanded="false"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i> <span>Lease Type</span></a>
							</li>

							<li class="<?php if($this->uri->uri_string()=='master/Tenant'){echo 'active';}?>">
								<a href="<?php echo base_url(); ?>master/Tenant" aria-expanded="false"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i> <span>Tenant Type</span></a>
							</li>
							<li class=""><a href="#" aria-expanded="false"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i> <span>SMS Settings</span></a></li>


							<li class="nav-dropdown <?php if($this->uri->uri_string()=='master/location' || $this->uri->uri_string()=='master/location/state' || $this->uri->uri_string()=='master/location/city' ||$this->uri->uri_string()=='master/location/area' ||$this->uri->uri_string()=='master/location/Cities'){echo 'active';}?>">
								<a class="has-arrow" href="#" aria-expanded="<?php if($this->uri->uri_string()=='master/location' || $this->uri->uri_string()=='master/location/state' || $this->uri->uri_string()=='master/location/city' ||$this->uri->uri_string()=='master/location/area'){echo 'true';}else{ echo 'false';}?>"> <i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
									Locations
								</a>
								<ul class="collapse nav-sub" aria-expanded="false">
											<li class="<?php if($this->uri->uri_string()=='master/location'){echo 'active';}?>">
												<a href="<?php echo base_url(); ?>master/location/"><i class="zmdi zmdi-caret-right zmdi-hc-fw"></i>
													Countries
												</a>
											</li>
											<li class="<?php if($this->uri->uri_string()=='master/location/state'){echo 'active';}?>">
												<a href="<?php echo base_url(); ?>master/location/state"><i class="zmdi zmdi-caret-right zmdi-hc-fw"></i>
													States
												</a>
											</li>
											<!-- <li class="<?php if($this->uri->uri_string()=='master/location/city'){echo 'active';}?>">
												<a href="<?php echo base_url(); ?>master/location/city"><i class="zmdi zmdi-caret-right zmdi-hc-fw"></i>
													District
												</a>
											</li> -->
											<li class="<?php if($this->uri->uri_string()=='master/location/Cities'){echo 'active';}?>">
												<a href="<?php echo base_url(); ?>master/location/Cities"><i class="zmdi zmdi-caret-right zmdi-hc-fw"></i>
													Cities
												</a>
											</li>
											<!-- <li class="<?php if($this->uri->uri_string()=='master/location/area'){echo 'active';}?>">
												<a href="<?php echo base_url(); ?>master/location/area"><i class="zmdi zmdi-caret-right zmdi-hc-fw"></i>
													Taluk
												</a>
											</li> -->
									</ul>
							</li>
						</ul>
					</li>
					<li class="nav-dropdown <?php if($this->uri->uri_string()=='master/Users/user' || $this->uri->uri_string()=='master/Users/add_user' || $this->uri->uri_string()=='master/Users' || $this->uri->uri_string()=='master/Users/edit_user' || $this->uri->uri_string()=='master/Users/user_permission') {echo 'active';}?>">
						<a class="has-arrow" href="#" aria-expanded="<?php if($this->uri->uri_string()=='master/Users/user' || $this->uri->uri_string()=='master/Users'){echo 'true';}else{ echo 'false';}?>"><i class="con dripicons-user"></i>Users
						</a>

						<ul class="collapse nav-sub" aria-expanded="false">
							<li class="<?php if($this->uri->uri_string()=='master/Users/user' || $this->uri->uri_string()=='master/Users/edit_user' || $this->uri->uri_string()=='master/Users/add_user'){echo 'active';}?>">
								<a href="<?php echo base_url(); ?>master/Users/user"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
									Manage Users
								</a>
							</li>
							<li class="<?php if($this->uri->uri_string()=='master/Users' || $this->uri->uri_string()=='master/Users/user_permission'){echo 'active';}?>">
								<a href="<?php echo base_url(); ?>master/Users"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
									Manage User Types
								</a>
							</li>
						</ul>
					</li>
					<li class="nav-dropdown <?php if($this->uri->uri_string()=='properties/Properties' || $this->uri->uri_string()=='properties/Properties/add' || $this->uri->uri_string()=='properties/Properties/edit' || $this->uri->uri_string()=='properties/Properties/sub_properties'){echo 'active';}?>">
						<a class="has-arrow" href="#" aria-expanded="<?php if($this->uri->uri_string()=='properties/Properties' || $this->uri->uri_string()=='properties/Properties/add' || $this->uri->uri_string()=='properties/Properties/edit' || $this->uri->uri_string()=='properties/Properties/sub_properties'){echo 'true';}else{ echo 'false';}?>"><i class="con dripicons-document"></i>Properties
						</a>

						<ul class="collapse nav-sub" aria-expanded="false">
							 <li class="<?php if($this->uri->uri_string()=='properties/Properties' || $this->uri->uri_string()=='properties/Properties/add' || $this->uri->uri_string()=='properties/Properties/edit'){echo 'active';}?>">
								<a href="<?php echo base_url(); ?>properties/Properties"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
									Manage Properties
								</a>
							</li> 
							<li class="<?php if($this->uri->uri_string()=='properties/Properties/sub_properties'){echo 'active';}?>">
								<a href="<?php echo base_url(); ?>properties/Properties/sub_properties"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
									Manage Sub Properties
								</a>
							</li>
						</ul>
					</li>

					<li class="nav-dropdown <?php if($this->uri->uri_string()=='tenant/Tenant/group' || $this->uri->uri_string()=='tenant/Tenant/group'){echo 'active';}?>">
						<a class="has-arrow" href="#" aria-expanded="<?php if($this->uri->uri_string()=='tenant/Tenant/group' || $this->uri->uri_string()=='tenant/Tenant/group'){echo 'true';}else{ echo 'false';}?>"><i class="con dripicons-user-group"></i>Tenants
						</a>
						<ul class="collapse nav-sub" aria-expanded="false">
							<li class="<?php if($this->uri->uri_string()=='tenant/Tenant/group'){echo 'active';}?>">
								<a href="<?php echo base_url(); ?>tenant/Tenant/group"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
									Manage Tenant Groups
								</a>
							</li>
							<li class="<?php if($this->uri->uri_string()=='tenant/Tenant'){echo 'active';}?>">
								<a href="<?php echo base_url(); ?>tenant/Tenant"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
									Manage Tenants
								</a>
							</li>
						</ul>
					</li>
					<li class="nav-dropdown  <?php if($this->uri->uri_string()=='lease/lease/addlease' || $this->uri->uri_string()=='lease/lease') {echo 'active';}?>"> <a class="has-arrow" href="#" aria-expanded="false"><i class="con dripicons-contract-2"></i>Lease Management
					</a>

					<ul class="collapse nav-sub" aria-expanded="false">
						<li class="<?php if($this->uri->uri_string()=='lease/lease/addlease'){echo 'active';}?>">
							<a href="<?php echo base_url(); ?>lease/lease/addlease"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
								Add New Lease
							</a>
						</li>
						<li class="<?php if($this->uri->uri_string()=='lease/lease'){echo 'active';}?>">
							<a href="<?php echo base_url(); ?>lease/lease"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
								Manage Lease
							</a>
						</li>
						
					</ul>
				</li>
				<li class="nav-dropdown <?php if($this->uri->uri_string()=='lease/lease/lease_expiry' ) {echo 'active';}?>">
					<a class="has-arrow" href="#" aria-expanded="false"><i class="con dripicons-conversation"></i>Notifications
					</a>

					<ul class="collapse nav-sub" aria-expanded="false">
						<li class="<?php if($this->uri->uri_string()=='lease/lease/lease_expiry'){echo 'active';}?>">
							<a href="<?php echo base_url(); ?>lease/lease/lease_expiry"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
								Contract Expiry
							</a>
						</li>
						<li class="">
							<a href="#"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
								Contract Payment
							</a>
						</li>
					</ul>
				</li>
				<li class="nav-dropdown <?php if($this->uri->uri_string()=='lease/lease/report_lease' ) {echo 'active';}?>">
					<a class="has-arrow" href="#" aria-expanded="false"><i class="icon dripicons-graph-bar"></i>Reports
					</a>
					<ul class="collapse nav-sub" aria-expanded="false">
						<li class="<?php if($this->uri->uri_string()=='lease/lease/report_lease'){echo 'active';}?>">
							<a href="<?php echo base_url(); ?>lease/lease/report_lease"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
								Lease Contract Filter
							</a>
						</li>
						<li class="">
							<a href="#"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
								Transaction IN / OUT
							</a>
						</li>
					</ul>
				</li>
				<li class="nav-dropdown ">
					<a class="has-arrow" href="#" aria-expanded="false"><i class="con dripicons-gear"></i>Settings
					</a>

					<ul class="collapse nav-sub" aria-expanded="false">
						<li class="">
							<a href="#" data-toggle="modal" data-target="#exampleModal"><i class="icon dripicons-gear" ></i> Change Password</a>
						</li>
						<li class="">
							<a href="<?php echo base_url(); ?>login/logout"><i class="zmdi zmdi-dot-circle-alt zmdi-hc-fw"></i>
								Logout
							</a>
						</li>
					</ul>
				</li>
			</ul>
		</nav>
	</div>
</aside>