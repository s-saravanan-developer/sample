<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Export extends CI_Controller {

        public function __construct() {
        parent::__construct();
        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();
        $this->load->helper(array('form', 'url'));
        $this->load->helper('download');
        $this->load->library('PHPReport');
        $this->load->model('common_model');

        }
    }

    
    public function download($h1,$a1,$empInfo,$name)
    {

        // create file name
        // $fileName = '$name-'.time().'.xls';  
        $fileName = $name.'.xls';  
        // load excel library
        $this->load->library('excel');
        // $this->load->model('master/Units_model');
        // $empInfo = $this->Units_model->get_all_units_name();
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0);

        // set Header
        $cnt = 0;
        for ($i=0; $i < count($h1['h1']); $i++) { 
             
        $objPHPExcel->getActiveSheet()->SetCellValue($h1['h1'][$cnt], $h1['h2'][$cnt]);
        $cnt++;
        }
       
        // set Row
       $rowCount = 2;
        
        if(!empty($empInfo)){
        foreach ($empInfo as $element) {
            $cnt_2 = 0;
             for ($i=0; $i < count($a1['a1']); $i++) {
                $objPHPExcel->getActiveSheet()->SetCellValue($a1['a1'][$cnt_2]. $rowCount, $element[$a1['a2'][$cnt_2]]);
                $cnt_2++;
            }
          
            $rowCount++;
        } }

        //Save as an Excel BIFF (xls) file
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$fileName.'"');
        header('Cache-Control: max-age=0');

        $objWriter->save('php://output');
        //exit();
    }

    public function excelColumnRange($lower, $upper) {
            ++$upper;
            for ($i = $lower; $i !== $upper; ++$i) {
                yield $i;
            }
        }

public function download1($h1,$a1,$empInfo,$name)
    {

        // create file name
        // $fileName = '$name-'.time().'.xls';  
        $fileName = $name.'.xls';  
        // load excel library
        $this->load->library('excel');
        // $this->load->model('master/Units_model');
        // $empInfo = $this->Units_model->get_all_units_name();
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0);

        // set Header
        $cnt = 0;
        for ($i=0; $i < count($h1['h1']); $i++) { 
             
        $objPHPExcel->getActiveSheet()->SetCellValue($h1['h1'][$cnt], $h1['h2'][$cnt]);
        $cnt++;
        }
       
        // set Row
        $rowCount = 2;
        foreach ($empInfo as $element) {
            $cnt_2 = 0;
             for ($i=0; $i < count($a1['a1']); $i++) {
                $objPHPExcel->getActiveSheet()->SetCellValue($a1['a1'][$cnt_2]. $rowCount, $element[$a1['a2'][$cnt_2]]);
                $cnt_2++;
            }
          
            $rowCount++;
        }

        //Save as an Excel BIFF (xls) file
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel5');

        // header('Content-Type: application/vnd.ms-excel');
        // header('Content-Disposition: attachment;filename="'.$fileName.'"');
        // header('Cache-Control: max-age=0');

            header("Pragma: public");
            header("Expires: 0");
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            header("Content-Type: application/force-download");
            header("Content-Type: application/octet-stream");
            header("Content-Type: application/download");
            header('Content-Disposition: attachment;filename="'.$fileName.'"');

        $objWriter->save('php://output');
        exit();
    }

    




    // Branch

public function export_branch()
    {      
        $name = 'name';$name = 'Region';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

        $this->load->model('master/Branch_model');
        
        $empInfo = $this->Branch_model->get_all_branch();

        $header =array(
            'ID',
            'Region Name',
            'Branch Code',
            'Hub Code',
            'Mobile',
            'Email',
            'GST No',
            'Address 1',
            'Address 2',
            'Pincode',
        );
        $table_attrb = array(
            'id',
            'type_name',
            'branch_code',
            'hub_code',
            'mobile',
            'email',
            'gst_no',
            'address',
            'address2',
            'pincode',
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }


// Units

public function export_membertype()
    {      
        $name = 'Membership Type';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Master_model');
        $empInfo = $this->Master_model->getall_membershiptype();
         
        $header =array(
            'ID',
            'Membership Type',
            'Alias Name',
        );
        $table_attrb = array(
            'ID',
            'Membership_type',
            'Alias_name',
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }

public function multi_export_membertype()
    { 
         $id = $this->input->get('url');
        
        $name = 'Membership Type';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Master_model');
       $empInfo = $this->Master_model->getall_membershiptypeby($id);


        $header =array(
            'ID',
            'Membership Type',
            'Alias Name',
        );
        $table_attrb = array(
            'ID',
            'Membership_type',
            'Alias_name',
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
       
    }


public function export_memberreqtype()
    {      
        $name = 'Membership Request Type';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Master_model');
        $empInfo = $this->Master_model->getall_membership_reqtype();
         
        $header =array(
            'ID',
            'Membership Request Type',
            'Alias Name',
        );
        $table_attrb = array(
            'ID',
            'Membership_reqtype',
            'Alias_name',
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }

public function multi_export_memberreqtype()
    { 
         $id = $this->input->get('url');
        
        $name = 'Membership Request Type';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Master_model');
       $empInfo = $this->Master_model->getall_membership_reqtypeby($id);


        $header =array(
            'ID',
            'Membership Type',
            'Alias Name',
        );
        $table_attrb = array(
            'ID',
            'Membership_reqtype',
            'Alias_name',
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
       
    }

public function export_grade()
    {      
        $name = 'Membership Grade';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Master_model');
        $empInfo = $this->Master_model->getallgrade();
         
        $header =array(
            'ID',
            'Grade Name',
            'Alias Name',
            'Level Type',
            'Direct Member',
            'Indirect Member',
            'Direct Value',
            'Indirect Value',
        );
        $table_attrb = array(
            'ID',
            'Grade_name',
            'Alias_name',
            'Level_type',
            'Direct_member',
            'Indirect_member',
            'Direct_value',
            'Indirect_value',
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }

        $this->download($h_array1,$a_array1,$empInfo,$name);
        
    }

public function multi_export_grade()
    { 
         $id = $this->input->get('url');
        
        $name = 'Membership Grade';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Master_model');
       $empInfo = $this->Master_model->getallgradeby($id);
       // var_dump($empInfo);die();

        $header =array(
            'ID',
            'Grade Name',
            'Alias Name',
            'Level Type',
            'Direct Member',
            'Indirect Member',
            'Direct Value',
            'Indirect Value',
        );
        $table_attrb = array(
            'ID',
            'Grade_name',
            'Alias_name',
            'Level_type',
            'Direct_member',
            'Indirect_member',
            'Direct_value',
            'Indirect_value',
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
       
    }


public function export_countries()
    {      
$name = 'Countries';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Location_model');
        $empInfo = $this->Location_model->get_location_country();

        $header =array(
            'ID',
            'Country Name',
            'Alias Name',
         
        );
        $table_attrb = array(
            'id',
            'country_name',
            'alis_name',
           
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }




public function multi_export_countries()
    {      
        $id = $this->input->get('url');
$name = 'Countries';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }
        // var_dump($id); die();
       $this->load->model('master/Location_model');
        $empInfo = $this->Location_model->get_location_country_export($id);

        $header =array(
            'ID',
            'Country Name',
            'Alias Name',
         
        );
        $table_attrb = array(
            'id',
            'country_name',
            'alis_name',
           
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }


public function export_calendar()
    {      
        //$id = $this->input->get('url');
$name = 'Calendar';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }
        // var_dump($id); die();
       $this->load->model('master/Calendar_setting_model');
        $empInfo = $this->Calendar_setting_model->get_calendar_export();

        $header =array(
            'Event',
            'Date',
            'Description',
         
        );
        $table_attrb = array(
            'Event',
            'Date',
            'Description',
           
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }

public function export_payout()
    {      
        $id = ( explode( ',', $this->input->get('id') ));
        $payout_mode =$this->input->get('payout_mode');
        //$id = $this->input->get('url');
       //var_dump($id);die();
$name = 'Payout';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }
        // var_dump($id); die();
       $this->load->model('payout_money/Payout_money_model');
        $empInfo = $this->Payout_money_model->get_export_payouts($id,$payout_mode);
        //var_dump($empInfo);die();
        $header =array(
                'Name',   
                'Membership Code',   
                'Mobile',   
                'Commission_type',
                'Generated_date',
                'Bank',        
                'Acc.Holder',        
                'Acc.Number',        
                'Branch',        
                'IFSC',        
                'Actual_amount',       
                'Final_amount'
                );
        $table_attrb = array(
                'First_name',   
                'Membership_code',   
                'Mobile',   
                'Commission_type_name',
                'Commision_date', 
                'Bank_name',       
                'Account_holder',       
                'Account_no',       
                'Branch',       
                'IFSC',       
                'Amount',    
                'Amount'  
                );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }


public function export_payout_ready()
    {      
        $id = ( explode( ',', $this->input->get('id') ));
        //$id = $this->input->get('url');
        
$name = 'Payout_ready';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }
        // var_dump($id); die();
       $this->load->model('payout_money/Payout_money_model');
        $empInfo = $this->Payout_money_model->get_export_payouts_ready($id);
        //var_dump($empInfo);die();
        $header =array(
                'Membership',   
                'Commission_type',
                'Generated_date',
                'Bank',        
                'Actual_amount',       
                'Final_amount'
                );
        $table_attrb = array(
                'First_name',   
                'Commission_type_name',
                'Generated_date', 
                'Bank_name',       
                'Final_amount',    
                'Final_amount'  
                );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }

    public function export_payout_report()
    {      
        $this->load->model('Report_model');
        //$id = ( explode( ',', $this->input->get('id') ));

        $mobile                                      = $this->input->get("mobile");
        $commission_type                             = $this->input->get("commission_type");  
        $level_type                                  = $this->input->get("level_type");
        $payout_list                                  = $this->input->get("payout_list");
        $payment_list                                  = $this->input->get("payment_list");

        $s_date                                      =date("Y-m-d", strtotime($this->input->get("s_date")));
        $e_date                                      =date("Y-m-d", strtotime($this->input->get("e_date")));
$name = 'Payout Report';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }
        // var_dump($id); die();
       
        $empInfo = $this->Report_model->get_payout_history2($commission_type,$level_type,$s_date,$e_date,$mobile,$payout_list,$payment_list);
        //var_dump($empInfo);die();
        $header =array(
                'Membership',   
                'Commission_type',
                'Generated_date',
                'Bank',        
                'Actual_amount',       
                'Final_amount'
                );
        $table_attrb = array(
                'First_name',   
                'Commission_type_name',
                'Generated_date', 
                'Bank_name',       
                'Final_amount',    
                'Final_amount'  
                );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }

    public function export_transaction_history()
    {      
        $this->load->model('Report_model');
        //$id = ( explode( ',', $this->input->get('id') ));

        $mobile                                      = $this->input->get("mobile");
        $commission_type                             = $this->input->get("commission_type");  
        $topup_list                                  = $this->input->get("topup_list");  
        $transaction_type                            = $this->input->get("transaction_type");
        $contract                                    = $this->input->get("contract");
        $s_date                                      =date("Y-m-d", strtotime($this->input->get("s_date")));
        $e_date                                      =date("Y-m-d", strtotime($this->input->get("e_date")));
        
        
$name = 'Transaction History';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }
        // var_dump($id); die();
       
        $empInfo = $this->Report_model->get_transaction_history2($commission_type,$topup_list,$transaction_type,$s_date,$e_date,$mobile,$contract);
        
        //var_dump($empInfo);die();
        $header =array(
                'Membership',   
                'Commission_type',
                'Generated_date',
                //'Bank',        
                'Credit_amount',       
                'Debit_amount'
                );
        $table_attrb = array(
                'First_name',   
                'Commission_name',
                'Date', 
                //'Bank_name',       
                'Credit_amount',    
                'Debit_amount'  
                );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }
    


public function export_payout_later()
    {      
        $mobile = $this->input->get('mobile');
        $date=date("Y-m-d", strtotime($this->input->get('date')));
        
        $name = 'Payout_later';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }
        // var_dump($mobile);var_dump($date); 


       $this->load->model('payout_money/Payout_money_model');
        $empInfo = $this->Payout_money_model->get_pay_later_details($mobile,$date);
        // var_dump($empInfo);die();
        $header =array(
                'Membership',   
                'Commission_type',
                'Generated_date',
                'Bank',        
                'Actual_amount',       
                'Final_amount'
                );
        $table_attrb = array(
                'First_name',   
                'Commission_type_name',
                'Generated_date', 
                'Bank_name',       
                'Final_amount',    
                'Final_amount'  
                );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }


public function export_payout_history()
    {      
        $mobile = $this->input->get('mobile');
        $date=date("Y-m-d", strtotime($this->input->get('date')));
        
        $name = 'Payout_history';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }
        // var_dump($mobile);var_dump($date); 


       $this->load->model('payout_money/Payout_money_model');
        $empInfo =$this->Payout_money_model->get_payout_history_details($mobile,$date);
        // var_dump($empInfo);die();
        $header =array(
                'Membership',   
                'Commission_type',
                'Generated_date',
                'Bank',        
                'Actual_amount',       
                'Final_amount'
                );
        $table_attrb = array(
                'First_name',   
                'Commission_type_name',
                'Generated_date', 
                'Bank_name',       
                'Final_amount',    
                'Final_amount'  
                );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }


public function export_states()
    {      
$name = 'States';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Location_model');
        $empInfo = $this->Location_model->get_location_state();

        $header =array(
            'ID',
            'State Name',
            'Alias Name',
            'State Code',
           
         
        );
        $table_attrb = array(
            'state_id',
            'state_name',
            'alis_name',
            'state_code',
            
           
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }

public function multi_export_states()
    {      
        $id = $this->input->get('url');

        $name = 'States';

        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Location_model');
        $empInfo = $this->Location_model->get_location_state_export($id);

        $header =array(
            'ID',
            'State Name',
            'Alias Name',
            'State Code',
        );
        $table_attrb = array(
            'state_id',
            'state_name',
            'alis_name',
            'state_code',
            
           
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }



public function export_cities()
    {      
$name = 'Cities';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Location_model');
        $empInfo = $this->Location_model->get_location_city();

        $header =array(
            'ID',
            'City Name',
            'Alias Name',
            'City Code',
           
        );
        $table_attrb = array(
            'city_id',
            'city_name',
            'alis_name',
            'city_code',
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }



public function multi_export_cities()
    {      
        $id = $this->input->get('url');

        $name = 'Cities';

        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Location_model');
        $empInfo = $this->Location_model->get_location_city_export($id);

        $header =array(
            'ID',
            'City Name',
            'Alias Name',
            'City Code',
           
        );
        $table_attrb = array(
            'city_id',
            'city_name',
            'alis_name',
            'city_code',
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }



public function export_areas()
    {      
$name = 'Areas';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

       $this->load->model('master/Location_model');
        $empInfo = $this->Location_model->get_location_area();

        $header =array(
            'ID',
            'Area Name',
            'Alias Name',
        );
        $table_attrb = array(
            'area_id',
            'area_name',
            'alis_name'
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }






public function multi_export_areas()
    {      
        $id = $this->input->get('url');
$name = 'Areas';
        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }
// var_dump($id); die();
       $this->load->model('master/Location_model');
        $empInfo = $this->Location_model->get_location_area_export($id);

        $header =array(
            'ID',
            'Area Name',
            'Alias Name',
        );
        $table_attrb = array(
            'area_id',
            'area_name',
            'alis_name'
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }


    
    
    public function export_manage_user()
        {      
    $name = 'User';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Users_model');
            $empInfo = $this->Users_model->get_all_users1();
    
            $header =array(
                'ID',
                'User ID',
                'Company Name',
                'Branch Name',
                'Name',
                // 'User Name',
                // 'Password',
                // 'Original Password',
                'DOB',
                'Email',
                'Mobile Number',
                'Address 1',
                'Address 2',
                'Country',
                'State',
                'City',
                'zipcode',
               
             
            );
            $table_attrb = array(
                'id',
                'user_id',
                'CompanyName',
                'type_name',
                'firstname',
                // 'username',
                // 'password',
                // 'og_password',
                'dob',
                'email_address',
                'mobile_number',
                'address_line_1',
                'address_line_2',
                'country_name',
                'state_name',
                'city_name',
                'zipcode',
                
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
     public function multi_export_manage_user()
        {      
            $id = $this->input->get('url');

            $name = 'User';

            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Users_model');
            $empInfo = $this->Users_model->get_all_users_multi($id);
    
             $header =array(
                'ID',
                'User ID',
                'Company Name',
                'Branch Name',
                'Name',
                // 'User Name',
                // 'Password',
                // 'Original Password',
                'DOB',
                'Email',
                'Mobile Number',
                'Address 1',
                'Address 2',
                'Country',
                'State',
                'City',
                'zipcode',
               
             
            );
            $table_attrb = array(
                'id',
                'user_id',
                'CompanyName',
                'type_name',
                'firstname',
                // 'username',
                // 'password',
                // 'og_password',
                'dob',
                'email_address',
                'mobile_number',
                'address_line_1',
                'address_line_2',
                'country_name',
                'state_name',
                'city_name',
                'zipcode',
                
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    
    public function export_user_types()
        {      
    $name = 'User Type';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
          $this->load->model('master/Users_model');
            $empInfo = $this->Users_model->get_all_user_types();
    
            $header =array(
                'ID',
                'User Type Name',
                'Description',
                
            );
            $table_attrb = array(
                'id',
                'user_type_name',
                'description',
               
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    
    
    public function export_item_type()
        {      
    $name = 'Item Type';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->get_super_categories();
    
            $header =array(
                'ID',
                'Item Type',
                'Alias Name',
                
            );
            $table_attrb = array(
                'id',
                'super_cat_name',
                'alis_name',
                
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    public function multi_export_item_type()
        {      
            $id = $this->input->get('url');
    $name = 'Item Type';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->get_super_categories_multi_export($id);
    
            $header =array(
                'ID',
                'Item Type',
                'Alias Name',
                
            );
            $table_attrb = array(
                'id',
                'super_cat_name',
                'alis_name',
                
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    public function export_cat()
        {      
    $name = 'Categories';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->get_all_categories();
    
           $header =array(
                'ID',
                'Category Name',
                'Alias Name',
                
            );
            $table_attrb = array(
                'id',
                'category_name',
                'alis_name',
                
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
      
    public function multi_export_cat()
        {      
            $id = $this->input->get('url');
    $name = 'Categories';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->get_all_categories_multi_export($id);
    
           $header =array(
                'ID',
                'Category Name',
                'Alias Name',
                
            );
            $table_attrb = array(
                'id',
                'category_name',
                'alis_name',
                
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    
    public function export_products()
        {      
    $name = 'Product';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->get_all_Products();
    
            $header =array(
                'ID',
                'Product Type',
                'Inventory Tracking',
                'Item Code',
                'Item Name',
                'Barcode',
                'Parent Product',
                'Parent Product Name',
                'HSN',
                'Description',
                'Division',
                'STR',
                'PTR',
            );
            $table_attrb = array(
                'Product_id',
                'Product_type',
                'Inventory_tracking',
                'Item_code',
                'Item_name',
                'Bar_code',
                'Parent_product',
                'Parent_product_name',
                'Hsn_code',
                'Description',
                'Division',
                'Str_persent',
                'Ptr_persent',
                
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    

    
    
    public function multi_export_products()
        {      
            $id = $this->input->get('url');
            $name = 'Product';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->get_all_Products_multi_export($id);
    
            $header =array(
                'ID',
                'Product Type',
                'Inventory Tracking',
                'Item Code',
                'Item Name',
                'Barcode',
                'Parent Product',
                'Parent Product Name',
                'HSN',
                'Description',
                'Division',
                'STR',
                'PTR',
            );
            $table_attrb = array(
                'Product_id',
                'Product_type',
                'Inventory_tracking',
                'Item_code',
                'Item_name',
                'Bar_code',
                'Parent_product',
                'Parent_product_name',
                'Hsn_code',
                'Description',
                'Division',
                'Str_persent',
                'Ptr_persent',
                
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    
    
    public function export_sub_cat()
        {      
    $name = 'Sub Categories';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->get_sub_categories();
    
            $header =array(
                'ID',
                'Sub Category Name',
                'Alias Name',
                
            );
            $table_attrb = array(
                'id',
                'sub_cat_name',
                'alis_name',
                
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    

    public function multi_export_sub_cat()
        {      
            $id = $this->input->get('url');
            $name = 'Sub Categories';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->get_sub_categories_multi_export($id);
    
            $header =array(
                'ID',
                'Sub Category Name',
                'Alias Name',
                
            );
            $table_attrb = array(
                'id',
                'sub_cat_name',
                'alis_name',
                
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    

    
    
    public function export_ventor()
        {      
    $name = 'Vendor / Suppliers';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Ventors_model');
            $empInfo = $this->Ventors_model->get_all_ventors();
    
            $header =array(
                'ID',
                'Vendor Code',
                'Supplier Type ID',
                'Customer Group ID',
                'Ventor Name',
                'Display Name',
                'Company Name',
                'Mobile Number',
                'Email',
                'Division ID',
                'Billing Address 1',
                'Billing Address 2',
                'Billing Country ID',
                'Billing State ID',
                'Billing City ID',
                'Billing Pincode',
                'Shipping Address 1',
                'Shipping Address 2',
                'Shipping Country ID',
                'Shipping State ID',
                'Shipping City ID',
                'Shipping Pincode',
                'Notes',
                // 'Attachments',
                // 'Bank Name',
                // 'Account Holder',
                // 'Account Number',
                // 'Account Type',
                // 'Ifsc Code',
                // 'Branch Address',
            );
            $table_attrb = array(
                'id',
                'Ventor_code',
                'Supplier_type_id',
                'Customer_group_id',
                'Ventor_name',
                'Display_name',
                'Company_name',
                'Mobile_number',
                'Email_id',
                'Division_id',
                'B_address1',
                'B_address2',
                'B_country_id',
                'B_state_id',
                'B_city_id',
                'B_pincode',
                'S_address1',
                'S_address2',
                'S_country_id',
                'S_state_id',
                'S_city_id',
                'S_pincode',
                'Notes',
                // 'Attachments',
                // 'Bank_name',
                // 'Account_holder',
                // 'Account_number',
                // 'Account_type',
                // 'Ifsc_code',
                // 'Branch_address',
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    public function multi_export_ventor()
        {      
            $id = $this->input->get('url');
    $name = 'Vendor / Suppliers';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Ventors_model');
            $empInfo = $this->Ventors_model->get_all_ventors_multi_export($id);
    
            $header =array(
                'ID',
                'Vendor Code',
                'Supplier Type ID',
                'Customer Group ID',
                'Ventor Name',
                'Display Name',
                'Company Name',
                'Mobile Number',
                'Email',
                'Division ID',
                'Billing Address 1',
                'Billing Address 2',
                'Billing Country ID',
                'Billing State ID',
                'Billing City ID',
                'Billing Pincode',
                'Shipping Address 1',
                'Shipping Address 2',
                'Shipping Country ID',
                'Shipping State ID',
                'Shipping City ID',
                'Shipping Pincode',
                'Notes',
                // 'Attachments',
                // 'Bank Name',
                // 'Account Holder',
                // 'Account Number',
                // 'Account Type',
                // 'Ifsc Code',
                // 'Branch Address',
            );
            $table_attrb = array(
                'id',
                'Ventor_code',
                'Supplier_type_id',
                'Customer_group_id',
                'Ventor_name',
                'Display_name',
                'Company_name',
                'Mobile_number',
                'Email_id',
                'Division_id',
                'B_address1',
                'B_address2',
                'B_country_id',
                'B_state_id',
                'B_city_id',
                'B_pincode',
                'S_address1',
                'S_address2',
                'S_country_id',
                'S_state_id',
                'S_city_id',
                'S_pincode',
                'Notes',
                // 'Attachments',
                // 'Bank_name',
                // 'Account_holder',
                // 'Account_number',
                // 'Account_type',
                // 'Ifsc_code',
                // 'Branch_address',
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    
    
    public function export_customer()
        {      
    $name = 'Customer';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Customer_model');
            $empInfo = $this->Customer_model->get_all_customers1();
    
            $header =array(
                // 'Customer ID',
                'Customer_code',
                'customer_group_name',
                'Customer_name',
                'Display_name',
                'Company_name',
                'Mobile_number',
                'Email_id',
                'Gstin',
            );
            $table_attrb = array(
                // 'Customer_id',
                'Customer_code',
                'customer_group_name',
                'Customer_name',
                'Display_name',
                'Company_name',
                'Mobile_number',
                'Email_id',
                'Gstin',
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            // redirect("master/customer/customer")
           // $this->load->view("master/customer/customer");
    
        }
    
    
    
    public function multi_export_customer()
        {      
            $id = $this->input->get('url');
    $name = 'Customer';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Customer_model');
            $empInfo = $this->Customer_model->get_all_customers_multi_export($id);
    
            $header =array(
                'Customer ID',
                'Customer Code',
                'Customer Group ID',
                'Customer Name',
                'Display Name',
                'Company Name',
                'Mobile Number',
                'Email ID',
                'GST',
            );
            $table_attrb = array(
                'Customer_id',
                'Customer_code',
                'Customer_group_id',
                'Customer_name',
                'Display_name',
                'Company_name',
                'Mobile_number',
                'Email_id',
                'Gstin',
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }

public function multi_export_grn()
        {      
            $id = $this->input->get('url');
    $name = 'GRN';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('transaction/GRN_model');
            $empInfo = $this->GRN_model->get_all_grn_multi_export($id);
            // var_dump($empInfo);die();
    
            $header =array(
                'GRN NO',
                'GRN Date',
                'Region',
                'Supplier',
                'Invoice No',
                'Recieved_date',
                'Item Name',
                'Unit',
                'Batch No',
                'Expiry Date',
                'Quantity',
                'Rate',
                'Discount Percentage',
                'Discount Quantity',
                'Discount Value',
                'Sub Total',
                'CGST',
                'SGST',
                'IGST',
                'Total Amount',
                'MRP',
                'Discount Type',
                'Discount',
                'Total Amount',
                'Net Total',
            );
            $table_attrb = array(
                'Grn_no',
                'Grn_date',
                'type_name',
                'Ventor_name',
                'Invoice_no',
                'Recieved_date',
                'Item_name',
                'unit_name',
                'Batch_no',
                'Exp_date',
                'Quantity',
                'Rate',
                'Discount_percentage',
                'Discount_qty',
                'Discount_value',
                'Sub_total',
                'Cgst',
                'Sgst',
                'Igst',
                'Net_value',
                'Mrp',
                'Discount_type',
                'Discount',
                'Net_amount',
                'Net_amount',
            );
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }

public function export_grn()
        {      
            $id = $this->input->get('url');
    $name = 'GRN';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('transaction/GRN_model');
            $empInfo = $this->GRN_model->get_all_grn_export();
            // var_dump($empInfo);die();
    
            $header =array(
                'GRN NO',
                'GRN Date',
                'Region',
                'Supplier',
                'Invoice No',
                'Invoice Date',
                'Recieved date',
                'Item Name',
                'Unit',
                'Batch No',
                'Expiry Date',
                'Quantity',
                'Rate',
                'Discount Percentage',
                'Discount Quantity',
                'Discount Value',
                'Sub Total',
                'CGST',
                'SGST',
                'IGST',
                'Total Amount',
                'MRP',
                'Discount Type',
                'Discount',
                'Total Amount',
                'Net Total',
            );
            $table_attrb = array(
                'Grn_no',
                'Grn_date',
                'type_name',
                'Ventor_name',
                'Invoice_no',
                'Invoice_date',
                'Recieved_date',
                'Item_name',
                'unit_name',
                'Batch_no',
                'Exp_date',
                'Quantity',
                'Rate',
                'Discount_percentage',
                'Discount_qty',
                'Discount_value',
                'Sub_total',
                'Cgst',
                'Sgst',
                'Igst',
                'Net_value',
                'Mrp',
                'Discount_type',
                'Discount',
                'Net_amount',
                'Net_amount',
            );
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
        
    

    
    public function export_customer_group()
        {      
    $name = 'Customer Group';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Customer_model');
            $empInfo = $this->Customer_model->get_all_customer_group();
    
            $header =array(
                'ID',
                'Customer Group Name',
                'Description',
            );
            $table_attrb = array(
                'id',
                'customer_group_name',
                'description',
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    
    
    public function multi_export_customer_group_multi()
        {      
            $id = $this->input->get('url');
    $name = 'Customer Group';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Customer_model');
            $empInfo = $this->Customer_model->get_all_customer_group_multi($id);
    
            $header =array(
                'ID',
                'Customer Group Name',
                'Description',
            );
            $table_attrb = array(
                'id',
                'customer_group_name',
                'description',
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    public function export_batch_card()
        {      
    $name = 'Batch Card';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->batch_view();
    
            $header =array(
                'Batch ID',
                'Batch Rate Status',
                'Refernce Nubmer',
                'Product ID',
                'Units ID',
                'Company ID',
                'Batch NO',
                'Supplier ID',
                'Expiry Date',
                'Expiry Month',
                'UDF 1',
                'UDF 2',
                'UDF 3',
            );
            $table_attrb = array(
                'Batch_setting_id',
                'batch_rate_status',
                'reference_number',
                'Product_id',
                'Units_id',
                'Company_id',
                'Batch_no',
                'Supplier_id',
                'Exp_date',
                'Exp_month',
                'UDF_1',
                'UDF_2',
                'UDF_3',
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    
    
    public function export_batch_card_setting()
        {      
    $name = 'Batch Card Setting';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->batch_card_setting_view();
    
            $header =array(
                'id',
                'Company ID',
                'Product ID',
                'Division',
                'Str Percent',
                'Ptr Percent',
                'Tax',
            );
            $table_attrb = array(
                'id',
                'company_id',
                'Product_id',
                'Division',
                'Str_percent',
                'Ptr_percent',
                'tax',
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    
    
    public function export_batch_rate_setting()
        {      
    $name = 'Batch Rate Setting';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->batch_rates();
    
            $header =array(
                'Batch Rate ID',
                'Product ID',
                'Item Type',
                'MRP Rate',
                'Product Name',
                'Company ID'
            );
            $table_attrb = array(
                'Batch_rate_id',
                'Product_id',
                'Item_type',
                'MRP_rate',
                'product_name',
                'Company_id'
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    // Multi

         // Branch

public function multi_export_branch()
    {      
        $id = $this->input->get('url');
         // var_dump($id); die();

         $name = 'Region';

        foreach ($this->excelColumnRange('A', 'Z') as $value) {
            $alpha[] = $value;
        }

        $this->load->model('master/Branch_model');
        
        $data = $this->Branch_model->get_all_branch_specific_export($id);

        // var_dump($data); die();

        //$empInfo = $data;

        $empInfo = $data;

        $header =array(
            'ID',
            'Region Name',
            'Branch Code',
            'Hub Code',
            'Mobile',
            'Email',
            'GST No',
            'Address 1',
            'Address 2',
            'Pincode',
        );
        $table_attrb = array(
            'id',
            'type_name',
            'branch_code',
            'hub_code',
            'mobile',
            'email',
            'gst_no',
            'address',
            'address2',
            'pincode',
        );

        for ($head=0; $head < sizeof($header) ; $head++) {   
            // Header 
            $h_array1['h1'][$head] = $alpha[$head].'1'; 
            $h_array1['h2'][$head] = $header[$head]; 
            // attr
            $a_array1['a1'][$head] = $alpha[$head]; 
            $a_array1['a2'][$head] = $table_attrb[$head]; 
        }


        $this->download($h_array1,$a_array1,$empInfo,$name);
        

    }


// Units



// GST


    
    
    
    public function multi_export_user_types()
        {      
            $id = $this->input->get('url');
           // print_r($id); die();
    $name = 'User Type';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
          $this->load->model('master/Users_model');
            $empInfo = $this->Users_model->get_all_user_types_multi($id);
    
            $header =array(
                'ID',
                'User Type Name',
                'Description',
                
            );
            $table_attrb = array(
                'id',
                'user_type_name',
                'description',
               
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    

    
    
    
    
    
    
    
    
    public function multi_export_batch_card()
        {      
            $id = $this->input->get('url');
    $name = 'Batch Card';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->batch_view();
    
            $header =array(
                'Batch ID',
                'Batch Rate Status',
                'Refernce Nubmer',
                'Product ID',
                'Units ID',
                'Company ID',
                'Batch NO',
                'Supplier ID',
                'Expiry Date',
                'Expiry Month',
                'UDF 1',
                'UDF 2',
                'UDF 3',
            );
            $table_attrb = array(
                'Batch_setting_id',
                'batch_rate_status',
                'reference_number',
                'Product_id',
                'Units_id',
                'Company_id',
                'Batch_no',
                'Supplier_id',
                'Exp_date',
                'Exp_month',
                'UDF_1',
                'UDF_2',
                'UDF_3',
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    
    
    public function multi_export_batch_card_setting()
        {      
            $id = $this->input->get('url');
    $name = 'Batch Card Setting';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->batch_card_setting_view();
    
            $header =array(
                'id',
                'Company ID',
                'Product ID',
                'Division',
                'Str Percent',
                'Ptr Percent',
                'Tax',
            );
            $table_attrb = array(
                'id',
                'company_id',
                'Product_id',
                'Division',
                'Str_percent',
                'Ptr_percent',
                'tax',
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
    
    
    
    public function multi_export_batch_rate_setting()
        {      
            $id = $this->input->get('url');
    $name = 'Batch Rate Setting';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Categories_model');
            $empInfo = $this->Categories_model->batch_rates();
    
            $header =array(
                'Batch Rate ID',
                'Product ID',
                'Item Type',
                'MRP Rate',
                'Product Name',
                'Company ID'
            );
            $table_attrb = array(
                'Batch_rate_id',
                'Product_id',
                'Item_type',
                'MRP_rate',
                'product_name',
                'Company_id'
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }


        public function export_team_setting()
        {      
            $id = $this->input->get('url');
    $name = 'Batch Rate Setting';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
    
           $this->load->model('master/Team_model');
            $empInfo = $this->Team_model->team_details_view();
    
            $header =array(
                'ID',
                // 'Product ID',
                // 'Item Type',
                // 'MRP Rate',
                // 'Product Name',
                // 'Company ID's
            );
            $table_attrb = array(
                'id',
                // 'Product_id',
                // 'Item_type',
                // 'MRP_rate',
                // 'product_name',
                // 'Company_id'
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }


         public function multi_export_team_setting()
        {      
            $id = $this->input->get('url');
    $name = 'Batch Rate Setting';
            foreach ($this->excelColumnRange('A', 'Z') as $value) {
                $alpha[] = $value;
            }
            //echo $id; die();
    
           $this->load->model('master/Team_model');
            $empInfo = $this->Team_model->team_details_view_export($id);
    
            $header =array(
                'ID',
                // 'Company Name',
                'Region Name',
                'Team Detail',
                'Month',
                'Year'
            );
            $table_attrb = array(
                'Tid',
                // 'type_name',
                'type_name',
                'team_name',
                'month',
                'year'
            );
    
            for ($head=0; $head < sizeof($header) ; $head++) {   
                // Header 
                $h_array1['h1'][$head] = $alpha[$head].'1'; 
                $h_array1['h2'][$head] = $header[$head]; 
                // attr
                $a_array1['a1'][$head] = $alpha[$head]; 
                $a_array1['a2'][$head] = $table_attrb[$head]; 
            }
    
    
            $this->download($h_array1,$a_array1,$empInfo,$name);
            
    
        }
    
}