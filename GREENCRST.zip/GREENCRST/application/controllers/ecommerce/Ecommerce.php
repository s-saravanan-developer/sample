<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Ecommerce extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Users_model');
        $this->load->model('ecommerce/Ecommerce_model');
    }

	public function index()
	{
        
		$template['page']='ecommerce/view_order_details';
        $template['orders']    =  $this->Ecommerce_model->getall_orders();
        $this->load->view('template',$template);
		
	}

    
    public function get_order_member_details(){
        $mobile = $this->input->post('mobile');
        $s_date = $this->input->post('s_date');
        $e_date = $this->input->post('e_date');


        $template['orders']    =  $this->Ecommerce_model->get_order_member_details($mobile,$s_date,$e_date);
        $this->load->view('ecommerce/ajax_orders',$template);

    }
    public function get_order_details(){
        $Transaction_ID = $this->input->post('Transaction_ID');
        $template['orders']    =  $this->Ecommerce_model->getall_order_details_by_id($Transaction_ID);
        $this->load->view('ecommerce/ajax_orders',$template);

    }

    public function bv_transaction()
    {
        
        $template['page']='ecommerce/view_bv_transaction';
        $this->load->view('template',$template);
        
    }

}
