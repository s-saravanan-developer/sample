<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Draggable - Default functionality</title>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

  <!-- <link rel="stylesheet" href="/resources/demos/style.css"> -->
  <style>

  #draggable { width: 150px; height: 150px; padding: 0.5em; }
  body {
  font-family: Arial, Helvetica, sans-serif;
}

table {
  font-size: 1em;
}

.ui-draggable, .ui-droppable {
  background-position: top;
}
  </style>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#draggable" ).draggable();
    $( "#droppable" ).droppable({
      drop: function( event, ui ) {
        $( this )
          .addClass( "ui-state-highlight" )
          .find( "p" )
            .html( "Dropped!" );
      }
    });
  } );
  </script>
</head>
<body>
 
<!--  <div class="card">
  <div class="card-header">Draggable</div>
   <div  class="card-body " >
    <img src="./rose-blue-flower-rose-blooms-67636.jpeg" class="ui-widget-content" id="draggable">
  
</div>
 </div> -->

 <!-- <div id="draggable" style="width: 50px; height: 50px; border: solid 1px #000;">Drag me!</div> -->
<!--  <img src="./rose-blue-flower-rose-blooms-67636.jpeg" class="ui-widget-content" id="draggable">
<div id="droppable" style="width: 500px; height: 350px; border: solid 1px #000;">Drop here!</div> -->

 <div class="card">
  <div class="card-header">Draggable</div>
   <div  class="card-body " >
    <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-4" id="canvas_div">
        <iframe src="./default.html"  style="width: 500px; height: 350px; border: solid 1px #000;">
  
      </iframe>
      </div>
      <div class="col-md-4">
        <button class="btn-btn-success" type="button" id="click_canas">click</button>
        <p id="preview">pre</p>
      </div>
    </div>
  
   </div>
 </div>


<script src="html2canvas.js"  ></script>
    <script src="html2canvas.min.js"  ></script>
    <script src="html2canvas.esm.js"  ></script>
    <script src="canvas2image.js"  ></script>
<script type="text/javascript">
 // $( "#draggable" ).draggable({ revert: true });
 $( "#droppable" ).droppable({
  accept: "#draggable",
  drop: function( event, ui ) {
   // the draggable is dropped
  }
 });
</script>
<script type="text/javascript">
      $(document).on('click', '#click_canas', function(e) {
        var elm=$('#canvas_div').get(0);
        var lebar = '600';
        var tinggi  = '400';
        var type = 'png';
        var filename = 'htmltocanvas';
        alert();
        html2canvas(document.querySelector("#canvas_div")).then(canvas => {
            // document.body.appendChild(canvas);

            var canWidth=canvas.width;
            var canHeight=canvas.height;
            var img = Canvas2Image.convertToImage(canvas,canWidth,canHeight);
            $('#preview').empty();
            alert(1);
            $('#preview').after(img);

            // Canvas2Image.saveAsImage(canvas,lebar,tinggi,type,filename);
        })
      });
    </script>
 
 
</body>
</html>