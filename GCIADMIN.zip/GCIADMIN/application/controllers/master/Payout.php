<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Payout extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Payout_model');
        $this->load->model('master/Master_model');
        // Load form helper
        $this->load->helper('form');
        // Load encryption library
        $this->load->library('encrypt');
        
    }

	public function index()
	{
    	$template['page']='master/payout/viewpayout';
        $template['leveltype'] =  $this->Master_model->getall_leveltype();
        $template['week'] =  $this->Master_model->get_weeks();
        $template['payout'] =  $this->Payout_model->getallpayout();
        // var_dump($template['payout']);die();
        $this->load->view('template',$template);
	}

    public function add_payout()
    {
        extract($_POST);

        $data = array('payout_type' => $payout_type,
                      'alias_name' => $alias_name,
                      'Level_type_id' => $Level_type_id,
                      'Days' => $Days,
                      'Description' => $Description,
                      'status' => $status
                     );
        $this->db->insert('gc_payout_type',$data);
        $this->session->set_flashdata('country_success', 'Added');
        redirect('master/Payout');
    }

    public function edit_payout()
    {
        extract($_POST);

        $data = array('payout_type' => $payout_type,
                      'alias_name' => $alias_name,
                      'Level_type_id' => $Level_type_id,
                      'Days' => $Days,
                      'Description' => $Description,
                      'status' => $status
                     );
        

        $this->db->where('id',$ID);
        $this->db->update('gc_payout_type',$data);
        $this->session->set_flashdata('country_success', 'Updated');
        redirect('master/Payout');
    }

    public function delete_payout($id)
    {

        $data = array('status' => 3);
        
        $this->db->where('id',$id);
        $this->db->update('gc_payout_type',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Payout');
    }



public function edit() {
    $this->load->view('master/payout/edit');
}

// Encode message
public function key_encoder() 
{

    // Check for validation
    $this->form_validation->set_rules('key', 'Message', 'trim|required|xss_clean');
    if ($this->form_validation->run() == TRUE) {
    $this->load->view('master/payout/edit');
    } else {
    $key = $this->input->post('key');
    // Encoding message
    $data['encrypt_value'] = $this->encrypt->encode($key);
    $this->load->view('master/payout/edit', $data);
    }
}

// Decode encrypted message
public function key_decoder() 
    {
        $encrypt_key = $this->input->post('encrypt_key');
        $data['decrypt_value'] = $this->encrypt->decode($encrypt_key);
        $this->load->view('master/payout/edit', $data);
    }

    public function delete_checkbox(){
             $id = ( explode( ',', $this->input->get_post('id') ));             
             foreach ($id as  $value) {
                $table = 'gc_payout_type';
                $success = 'duplicate';
                $this->Master_model->delete_checkbox($value,$table,$success);
             }
    }

    public function active_all_checkbox(){
             $id = ( explode( ',', $this->input->get_post('id') ));             
             foreach ($id as  $value) {
                $this->Master_model->active_all_checkbox($value);
             }
    }

    public function deactivate_all_checkbox(){
             $id = ( explode( ',', $this->input->get_post('id') ));             
             foreach ($id as  $value) {
                $this->Master_model->deactivate_all_checkbox($value);
             }
    }

    public function Level_type_days()
    {

        $id = $this->input->post('Level_type_id');
        $data = $this->Payout_model->Level_type_days($id);
        $weekdays = $this->Payout_model->get_weeks();
        
        $select = $data[0]['ID'];
        $days = explode(',', $data[0]['Weeks']);
        var_dump($days);

        if(isset($data)){

            echo '<option value="">Select Days</option>';      
            echo '<option value="'.$data[0]['Weeks'].'">All days</option>';
            
            foreach ($data as $value) { foreach ($days as $key => $valuedays) {

            echo '<option value="'.$valuedays.'">'.$weekdays[$key]['Week'].'</option>';
                
            }}}else{

            echo '<option value="">Select Days</option>';            
          }
    }

    public function Level_type_days_edit()
    {

        $id = $this->input->post('Level_type_id');
        $data = $this->Payout_model->Level_type_days($id);
        $weekdays = $this->Payout_model->get_weeks();
        
        $select = $data[0]['ID'];
        $days = explode(',', $data[0]['Weeks']);

        if(isset($data)){

            echo '<option value="">Select Days</option>';      
            echo '<option value="'.$data[0]['Weeks'].'">All days</option>';
           
            foreach ($data as $value) { $i==1; foreach ($days as $key => $valuedays) {

            echo '<option value="'.$valuedays.'">'.$weekdays[$valuedays-1]['Week'].'</option>';
                
            }$i++;}}else{

            echo '<option value="">Select Days</option>';            
          }
    }

}
