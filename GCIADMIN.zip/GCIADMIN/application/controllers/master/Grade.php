<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Grade extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
    }

    public function index()
    {
        $template['page']='master/grade/viewgrade';
        $template['grade'] =  $this->Master_model->getallgrade();
        $template['leveltype'] =  $this->Master_model->getall_leveltype();
        $this->load->view('template',$template);
    }

    public function add_grade()
    {
        extract($_POST);
        $data=$this->input->post('grade');
        //var_dump($data);die();
        // $data = array('Level_type_id' => $Level_type_id,
        //               'Grade_name' => $Grade_name,
        //               'Alias_name' => $Alias_name,
        //               'Direct_member' => $Direct_member,
        //               'Indirect_member' => $Indirect_member,
        //               'Direct_value' => $Direct_value,
        //               'Indirect_value' => $Indirect_value,
        //               'Description' => $Description,  0
        //               'Status' => $Status
        //              );
      
        $this->db->insert('gc_grade',$data);
        $this->session->set_flashdata('country_success', 'Added');
        redirect('master/grade');
    }

    public function edit_grade()
    {
        extract($_POST);
      $data=$this->input->post('grade');
        // $data = array('Level_type_id' => $Level_type_id,
                     //  'Grade_name' => $Grade_name,
                     //  'Alias_name' => $Alias_name,
                     //  'Direct_member' => $Direct_member,
                     //  'Indirect_member' => $Indirect_member,
                     //  'Direct_value' => str_replace(',', '', $Direct_value),
                     //  'Indirect_value' => str_replace(',', '', $Indirect_value),
                     //  'Description' => $Description,  
                     //  'Status' => $Status
                     // );
        // var_dump($data);die();

        $this->db->where('ID',$ID);
        $this->db->update('gc_grade',$data);
        $this->session->set_flashdata('country_success', 'Updated');
        redirect('master/grade');
    }

    public function delete_grade($id)
    {

        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_grade',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/grade');
    }
}
