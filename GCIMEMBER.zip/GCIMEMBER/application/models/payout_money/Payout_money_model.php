<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Payout_money_model extends CI_Model { 

   public function get_today_payouts() {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Commision_date',date('Y-m-d'));
        $this->db->where('commission.Status',1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

       public function get_payout_details($mobile,$date) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Commision_date',$date);
        $this->db->where('commission.Status',1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

public function get_payout_processed_details($mobile,$date) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',$date);
        $this->db->where('commission.Payout_status',2);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


public function get_pay_later_details($mobile,$date) {
        $status=['3','4'];
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',$date);
        $this->db->where_in("commission.Payout_status",$status);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    public function get_payout_history_details($mobile,$date) {
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',$date);
        $this->db->where("commission.Payout_status",1);
        if(!empty($mobile)){
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);}
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    

   public function get_export_payouts($id) {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        //$this->db->where('commission.Commision_date',date('Y-m-d'));
        $this->db->where_in('commission.Commision_detail_ID',$id);
        $this->db->where('commission.Status',1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    

       public function get_today_processed_payouts() {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',2);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

       public function get_today_pay_later() {
        $status=['3','4'];
        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where_in("commission.Payout_status",$status);
        // $this->db->where('commission.Payout_status',4);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

       public function get_today_payout_history() {

        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_payouts as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commission_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Generated_date',date('Y-m-d'));
        $this->db->where('commission.Payout_status',1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    
    



    public function process_payout($id){
        $data_status['Status']=2;
        $this->db->where('Commision_detail_ID',$id);
        if($this->db->update('gc_member_commission_details',$data_status)){


        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Commision_date',date('Y-m-d'));
        $this->db->where('commission.Status',2);
        $this->db->where('commission.Commision_detail_ID',$id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                'Company_id'                  => $this->session->userdata('CompanyId'),
                'Branch_id'                   => $this->session->userdata('CompanyId'),
                'Commision_detail_ID'         => $commission[0]['Commision_detail_ID'],
                'Membership_ID'               => $commission[0]['Membership_ID'],
                'Contract_ID'                 => $commission[0]['Contract_ID'],
                'Commission_type'             => $commission[0]['Commision_type'],
                'Generated_date'              => date('Y-m-d'),
                'Recieved_date  '             => '',
                'Payment_mode'                => 'Bank',
                'Bank_ID'                     => $commission[0]['Bank_ID'],
                'Actual_amount'               => $commission[0]['Amount'],
                'Charges'                     => 0,
                'Final_amount'                => $commission[0]['Amount'],
                'Payout_status'               => 2,
                ); 
            

            $this->db->insert('gc_member_payouts',$payout_data);

            // $history_data=array(
            //      'Company_id'               => $this->session->userdata('CompanyId'),
            //      'Branch_id'                => $this->session->userdata('CompanyId'), 
            //      'Membership_ID' => $commission[0]['Membership_ID'],
            //      'Contract_ID'   => $commission[0]['Contract_ID'],
            //      'Payout_ID' => $commission[0]['Payout_ID'],
            //      'Date'  => date('Y-m-d'),
            //      'History_for'   => '',
            //      'Credit_amount' => $commission[0]['Amount'],
            //      'Debit_amount' => 0,
            //       );
            // $this->db->insert('gc_transaction_history',$history_data);

        }

    }

    }

public function cancel_payout($id){
        $data_status['Status']=4;
        $this->db->where('Commision_detail_ID',$id);
        if($this->db->update('gc_member_commission_details',$data_status)){


        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Commision_date',date('Y-m-d'));
        $this->db->where('commission.Status',4);
        $this->db->where('commission.Commision_detail_ID',$id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                'Company_id'                  => $this->session->userdata('CompanyId'),
                'Branch_id'                   => $this->session->userdata('CompanyId'),
                'Commision_detail_ID'         => $commission[0]['Commision_detail_ID'],
                'Membership_ID'               => $commission[0]['Membership_ID'],
                'Contract_ID'                 => $commission[0]['Contract_ID'],
                'Commission_type'             => $commission[0]['Commision_type'],
                'Generated_date'              => date('Y-m-d'),
                'Recieved_date  '             => date('Y-m-d'),
                'Payment_mode'                => 'Bank',
                'Bank_ID'                     => $commission[0]['Bank_ID'],
                'Actual_amount'               => $commission[0]['Amount'],
                'Charges'                     => 0,
                'Final_amount'                => $commission[0]['Amount'],
                'Payout_status'               => 4,
                );
            

            $this->db->insert('gc_member_payouts',$payout_data);

        }

    }

    }

    public function payout_later($id){
        $data_status['Status']=3;
        $this->db->where('Commision_detail_ID',$id);
        if($this->db->update('gc_member_commission_details',$data_status)){


        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Commision_date',date('Y-m-d'));
        $this->db->where('commission.Status',3);
        $this->db->where('commission.Commision_detail_ID',$id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                // 'Company_id'               => $this->session->userdata('CompanyId'),
                // 'Branch_id'                => $this->session->userdata('CompanyId'),
                // 'Commision_detail_ID'      => $commission[0]['Commision_detail_ID'],
                // 'Membership_ID'            => $commission[0]['Membership_ID'],
                // 'Contract_ID'              => $commission[0]['Contract_ID'],
                // 'Commission_type'          => $commission[0]['Commision_type'],
                // 'Generated_date'           => date('Y-m-d'),
                'Recieved_date  '          => date('Y-m-d'),
                // 'Payment_mode'             => 'Bank',
                // 'Bank_ID'                  => $commission[0]['Bank_ID'],
                // 'Actual_amount'            => $commission[0]['Amount'],
                // 'Charges'                  => 0,
                // 'Final_amount'             => $commission[0]['Amount'],
                'Payout_status'               => 3
                );
            

            $this->db->where('Commision_detail_ID',$id);
           $this->db->update('gc_member_payouts',$payout_data);

        }

    }

    }

public function mark_as_paid($id){
        $data_status['Status']=6;
        $this->db->where('Commision_detail_ID',$id);
        if($this->db->update('gc_member_commission_details',$data_status)){


        $this->db->select('commission.*,gc_bank.Bank_name,bank.*,member.First_name,member.Last_name,member.Gender,gc_commission.Commission as Commission_type_name,member.Membership_code,member.Mobile');
        $this->db->from('gc_member_commission_details as commission');
        
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_commission as gc_commission', 'gc_commission.ID = commission.Commision_type', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = commission.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->where('commission.Commision_date',date('Y-m-d'));
        $this->db->where('commission.Status',6);
        $this->db->where('commission.Commision_detail_ID',$id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $commission =$query->result_array();
            $payout_data=array(
                // 'Company_id'               => $this->session->userdata('CompanyId'),
                // 'Branch_id'                => $this->session->userdata('CompanyId'),
                // 'Commision_detail_ID'      => $commission[0]['Commision_detail_ID'],
                // 'Membership_ID'            => $commission[0]['Membership_ID'],
                // 'Contract_ID'              => $commission[0]['Contract_ID'],
                // 'Commission_type'          => $commission[0]['Commision_type'],
                // 'Generated_date'           => date('Y-m-d'),
                'Recieved_date  '             => date('Y-m-d'),
                // 'Payment_mode'             => 'Bank',
                // 'Bank_ID'                  => $commission[0]['Bank_ID'],
                // 'Actual_amount'            => $commission[0]['Amount'],
                // 'Charges'                  => 0,
                // 'Final_amount'             => $commission[0]['Amount'],
                'Payout_status'               => 1,
                );
            
        $this->db->where('Commision_detail_ID',$id);
        $this->db->update('gc_member_payouts',$payout_data);

        $this->db->select('Payout_ID');
        $this->db->from('gc_member_payouts');
        $this->db->where('Commision_detail_ID',$id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $pay=$query->result_array();
            $payout_id=$pay[0]['Payout_ID'];
        }



            $history_data=array(
                 'Company_id'                 => $this->session->userdata('CompanyId'),
                 'Branch_id'                  => $this->session->userdata('CompanyId'), 
                 'Membership_ID'              => $commission[0]['Membership_ID'],
                 'Contract_ID'                => $commission[0]['Contract_ID'],
                 'Payout'                     => $payout_id,
                 'Payout_ID'                  => $commission[0]['Payout_ID'],
                 'Date'                       => date('Y-m-d'),
                 'History_for'                => 'Credited Commission Amount is '.$commission[0]['Amount'] ,
                 'Credit_amount'              => $commission[0]['Amount'],
                 'Type'                       => 1,
                 'Debit_amount'               => 0
                  );
            $this->db->insert('gc_transaction_history',$history_data);

        }

    }

    }


function getall_members($status,$status1) {

        $this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');

        // $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
        $this->db->group_by("member.Membership_ID");
        if($status!=1){
        $this->db->where("member.Status",$status);}
        if($status1==10 || $status1==11){
            if($status1==10){
                $this->db->where("bank.Status",5);
            }elseif($status1==11){
                $this->db->where("documents.Status",5);
            }
        }
        $this->db->group_by("payments.Membership_ID");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


public function update_document_status($data,$Membership_ID) {
    $id=$data['Document_ID'];
    unset($data['Document_ID']);
        $this->db->where('Document_ID',$id);
        $this->db->update('gc_member_documents',$data);

        $data1['Status']=4;
        $this->db->where('Membership_ID',$Membership_ID);
        if($this->db->update('gc_membership',$data1)){
            return 1;
            }else{
                return 0;
            }
    }


}



