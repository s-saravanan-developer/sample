<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Properties_model extends CI_Model { 


    
    public function getall_properties_types() {

    $this->db->select('*');
    $this->db->where('status!=',3);
    $query = $this->db->get('prop_properties_types');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    public function getall_property_types_active() {

    $this->db->select('*');
    $this->db->where('status',1);
    $query = $this->db->get('prop_properties_types');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }
    

    public function getall_properties() {

    $this->db->select('*');
    $this->db->where('status!=',3);
    $query = $this->db->get('prop_properties');
    if ($query->num_rows() > 0) {
        $properties = $query->result_array(); 
                foreach ($properties as $key => $value) {
                    // $delete_status = $this->check_delete_status($value['company_id']);
                    // $delete_status = 0;
                    if(isset($delete_status)){ 
                        $properties[$key]['delete_status'] = 1; 
                    }
                    else{ 
                        $properties[$key]['delete_status'] = 0;
                    }    
                }
            return $properties;
    }
    return NULL;
    }   

    public function getall_sub_properties() {

    $this->db->select('prop.*,company.company_name,pro.properties_name,pro.location');
    $this->db->where('prop.status!=',3);
    $this->db->join('prop_company_table as company','company.company_id=prop.company_id','left');
    $this->db->join('prop_properties as pro','pro.properties_id=prop.properties','left');
    $query = $this->db->get('prop_sub_properties as prop');
    if ($query->num_rows() > 0) {
        $sub_properties = $query->result_array(); 
                foreach ($sub_properties as $key => $value) {
                    // $delete_status = $this->check_delete_status($value['company_id']);
                    // $delete_status = 0;
                    if(isset($delete_status)){ 
                        $sub_properties[$key]['delete_status'] = 1; 
                    }
                    else{ 
                        $sub_properties[$key]['delete_status'] = 0;
                    }    
                }
            return $sub_properties;
    }
    return NULL;
    }


     
    public function getall_properties_active() {

    $this->db->select('*');
    $this->db->where('status',1);
    $query = $this->db->get('prop_properties');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    public function get_company_based_properties($id) {

    $this->db->select('*');
    $this->db->where('company_id',$id);
    $query = $this->db->get('prop_properties');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }
    

    public function get_properties_by_id($id) {

    $this->db->select('*');
    $this->db->where('properties_id',$id);
    $query = $this->db->get('prop_properties');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

    public function get_sub_properties_by_id($id) {

    $this->db->select('child.*,parent.*,child.status as detail_status');
    $this->db->where('parent.sub_property_id',$id);
    $this->db->where('child.status',1);
    $this->db->join('prop_sub_properties as parent','parent.sub_property_id=child.sub_property_id','left');
    $query = $this->db->get('prop_sub_properties_details as child');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }
    

    public function getall_companies_active() {

    $this->db->select('*');
    $this->db->where('status',1);
    $query = $this->db->get('prop_company_table');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }else{
        return NULL;
    }
    
    }

    public function inserting_properties($properties_data) {
        if($this->db->insert('prop_properties',$properties_data)){
            return $this->db->insert_id();
        }else{
            return false;
        }
    }


    public function updating_properties($properties_data,$id) {

        $properties_data['updated_by']=$this->session->userdata('id');
        $this->db->where('properties_id',$id);
        $this->db->update('prop_properties',$properties_data);
        
    }

    public function inserting_sub_properties($properties_data) {
        if($this->db->insert('prop_sub_properties',$properties_data)){
            return $this->db->insert_id();
        }else{
            return false;
        }
    }

    public function inserting_sub_properties_details($properties_detail_data) {
        if($this->db->insert('prop_sub_properties_details',$properties_detail_data)){
            return $this->db->insert_id();
        }else{
            return false;
        }
    }
    


    public function updating_sub_properties($properties_data,$id) {
        $properties_data['updated_by']=$this->session->userdata('id');
        $this->db->where('sub_property_id',$id);
        $this->db->update('prop_sub_properties',$properties_data);
        
    }    

    public function updating_sub_properties_details($properties_detail_data) {
        if(!empty($properties_detail_data['detail_id'])){
            $id=$properties_detail_data['detail_id'];
            unset($properties_detail_data['detail_id']);
            $this->db->where('detail_id',$id);
            $this->db->update('prop_sub_properties_details',$properties_detail_data);
    }else{  
            unset($properties_detail_data['detail_id']);
            $this->db->insert('prop_sub_properties_details',$properties_detail_data);
    }
        
        
    }     

    public function getall_properties_types_active() {

    $this->db->select('*');
    $this->db->where('status',1);
    $query = $this->db->get('prop_properties_types');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }




 function delete_checkbox($id,$table,$success){
      
    $data['Updated_date'] = date('Y-m-d H:i:s');
            $data['status']         = 3;    

        $this->db->where('id', $id);
        if ($this->db->update($table, $data)) {
            $this->session->set_flashdata($success, 'Deleted');
            return TRUE;
       }
        
        return FALSE;               
     }

function active_all_checkbox($id){
      
            $data['updated_date'] = date('Y-m-d H:i:s');
            $data['status']         = 1;    

        $this->db->where('id', $id);
        if ($this->db->update('gc_countries', $data)) {
            $this->session->set_flashdata('country_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}

function deactivate_all_checkbox($id){

      $data['updated_date'] = date('Y-m-d H:i:s');
      $data['status']       = 2;

        $this->db->where('id', $id);
        if ($this->db->update('gc_countries', $data)) {
            $this->session->set_flashdata('country_success', 'Updated');
            return TRUE;
        }
        return FALSE;  
}



}

