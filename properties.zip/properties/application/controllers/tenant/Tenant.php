<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tenant extends CI_Controller {

	public function __construct() {
        parent::__construct();
        if ($this->session->userdata('is_logged_in') == '') {            
            redirect('login');
            session_destroy();
        }
        $this->load->helper(array('form', 'url'));
        $this->load->model('tenant/Tenant_model');
        $this->load->model('master/Location_model');
        $this->load->model('master/Upload_model');
        $this->load->model('master/Users_model');
    }

    /**
     * [gst Page]
     * @return [countty] Main Page
     * 
     */
	public function index($platform='web')
	{  
        $platform = $this->input->post('platform');
        if(empty($platform)) {
            $platform = 'web';
        }
		$template['table_name'] 	=	"prop_tenant_table";
        $template['tenant']        =    $this->Tenant_model->get_all_tenant();
        // var_dump($template['tenant']);die();
		$template['page']		    =	'tenant/tenant';

        $data['data'] = ['tenant'                => $template['tenant']];
        if(!empty($data) & $platform != 'web') {
            header('Content-Type: application/json');
            echo json_encode($data);
        } else {
        $this->load->view('template',$template);
        }
	}

    public function tenant_add()
    {       
        $template['countries'] = $this->Location_model->get_location_country();
        $template['states'] = $this->Location_model->get_states_by_country_id(1);
        $template['tenant_group'] =   $this->Tenant_model->get_all_tenant_group_active();
        $template['companies'] = $this->Users_model->get_all_companies();
        
        $template['table_name']     =   "prop_tenant_table";
        $template['page']           =   'tenant/tenant_add';
        $this->load->view('template',$template);
    }

    public function tenant_edit()
    {   
        $id=$this->input->get('id');
        $template['countries']      = $this->Location_model->get_location_country();
        // $template['states']         = $this->Location_model->get_states_by_country_id(1); 
        $template['states']         = $this->Location_model->get_full_states_data(); 
        $template['tenant_group'] =   $this->Tenant_model->get_all_tenant_group_active();
        $template['city']           = $this->Location_model->get_full_city_data();       
        $template['edit_tenant']   = $this->Tenant_model->get_edit_tenant_data($id); 
        $template['companies'] = $this->Users_model->get_all_companies();
        $template['page']           =   'tenant/tenant_edit';
        $this->load->view('template',$template);
    }



    public function group()
    {       
        $template['table_name']     =   "prop_tenant_group";
        $template['tenant_group'] =   $this->Tenant_model->get_all_tenant_group();
        $template['page']           =   'tenant/tenant_group';
        $this->load->view('template',$template);
    }

    public function tenant_group_add()
    {
        $this->db->trans_start();
        $tenant_group = $this->input->post('tenantgroup');
        $tenant_group['company_id'] = $this->session->userdata('company_id');
        $this->Tenant_model->adding_tenant_group($tenant_group);
        $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE)
        {
            $this->session->set_flashdata('tenant_error', 'error');
        }else{
                    $this->session->set_flashdata('tenant_success', 'Added');
              }    
        redirect('tenant/Tenant/group');
    }

   

    public function tenant_group_edit()
    {
        $this->db->trans_start();
        $id = $this->input->post('tenant_group_id');
        $tenant_group_edit = $this->input->post('tenantgroup');
        $this->Tenant_model->editing_tenant_group($tenant_group_edit,$id);
        $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE)
        {
            $this->session->set_flashdata('tenant_error', 'error');
        }else{
                    $this->session->set_flashdata('tenant_success', 'Updated');
                }    
        redirect('tenant/Tenant/group');
    }    

    public function adding_tenant()
    {        
        $tenant_add = $this->input->post('tenant');         
        // $file_name   = $this->Upload_model->tenant_logo_upload_file();
        // $tenant_add['tenant_logo']= $file_name;

        // adding Users
        // $increment_code = $this->db->count_all_results('prop_users')+1;

        $Prefix         = $this->Users_model->get_prefix();
        $increment1=(substr($this->db->select('tenant_code')->order_by('tenant_id','desc')->limit(1)->get('prop_tenant_table')->row('tenant_code'),11))+1;
        $tenant_add['tenant_code']=$Prefix[0]['customer_prefix'].'-'.sprintf("%'.06d", $increment1);
        $tenant_add['company_id']=$this->session->userdata('company_id');
        
        $tenant_id =$this->Tenant_model->insert_tenant($tenant_add);
        // $user_data = array(
        //     'tenant_id'      => $tenant_id,
        //     'tenant_code'       => $Prefix[0]['user_prefix'].'-'.sprintf("%'.06d", $increment1),
        //     'firstname'       => $tenant_add['tenant_name'],
        //     'username'        => $tenant_add['tenant_name'],
        //     'password'        => 'welcome123',
        //     'email'           => $tenant_add['email'],
        //     'country_id'      => $tenant_add['country'],
        //     'state_id'        => $tenant_add['state_id'],
        //     'city_id'         => $tenant_add['city_id'],
        //     'address1'        => $tenant_add['address1'],
        //     'address2'        => $tenant_add['address2'],
        //     'mobile'          => $tenant_add['mobile_number'],
        //     'phone'           => $tenant_add['phone_number'],
        //     'pincode'         => $tenant_add['zip_code'],
        //     'user_type_id'    => 1,
        //     'created_date'    => date('Y-m-d H:i:s')
        // );
        // $this->Users_model->insert_user($user_data);
        // $increment_code1 = $this->db->count_all_results('prop_hub_branch')+1;

        // $branch_data =array(
        //     'tenant_id'            =>  $tenant_id,
        //     'Branch_name'           =>  $tenant_add['tenant_name'],
        //     'Hub_code'              =>  'BRN-000'.$increment_code1,
        //     'Branch_code'           =>  'BRN-000'.$increment_code1,
        //     'Mobile'                =>  $tenant_add['mobile_number'],
        //     'Email'                 =>  $tenant_add['email'],
        //     'Contact_person'        =>  $tenant_add['contact_person'],
        //     'Country_id'            =>  $tenant_add['Country'],
        //     'State_id'              =>  $tenant_add['StateID'],
        //     'City_id'               =>  $tenant_add['CityID'],
        //     'GstType'               =>  $tenant_add['GSTN_type'],
        //     'Gst_no'                =>  $tenant_add['GSTINNumber'],
        //     'Address'               =>  $tenant_add['Address1'],
        //     'Address2'              =>  $tenant_add['Address2'],
        //     'Pincode'               =>  $tenant_add['Zip_code']
        // );
        // $this->Tenant_model->insert_branch($branch_data);
        $this->session->set_flashdata('tenant_success', 'Tenant Added');

        redirect('tenant/Tenant');
    }

    public function editing_tenant()
    {
        error_reporting(0);
        $id = $this->input->post('id');
        $editing_tenant = $this->input->post('tenant');
        // print_r($editing_tenant);
        // die();
        $this->Tenant_model->edit_tenant($editing_tenant,$id);
        // if($_FILES["tenant_logo"]['name'] != NULL)
        // {
        //     $image_data   = $this->Upload_model->replace_image();
        //     $this->Tenant_model->edit_tenant($editing_tenant,$id,$image_data);
        // }else
        // {
        //     $old_file_name = $this->input->post('old_file_name');
        //     $this->Tenant_model->edit_tenant($editing_tenant,$id,$old_file_name);
        //     $branch_data =array(
        //     'Branch_name'           =>  $editing_tenant['tenant_name'],
        //     'Mobile'                =>  $editing_tenant['mobile_number'],
        //     'Email'                 =>  $editing_tenant['email'],
        //     'Contact_person'        =>  $editing_tenant['contact_person'],
        //     'Country_id'            =>  $editing_tenant['country'],
        //     'State_id'              =>  $editing_tenant['state_id'],
        //     'City_id'               =>  $editing_tenant['city_id'],
        //     'tax_no1'               =>  $editing_tenant['tax_no1'],
        //     'tax_no2'                =>  $editing_tenant['tax_no2'],
        //     'address1'               =>  $editing_tenant['address1'],
        //     'address2'              =>  $editing_tenant['address2'],
        //     'Pincode'               =>  $editing_tenant['zip_code']
        // );
        //     $this->Tenant_model->edit_branch($branch_data,$id);
            // echo $old_file_name;
        // }
        $this->session->set_flashdata('tenant_success', 'Updated');        
        redirect('tenant/Tenant');
    }


    /**
     * Common Funtion To Delete Or Status Update To 3 
     * @return [type] [description]
     */
    public function delete()
    {        
        $url        = $this->input->post('url');    
        $id         = $this->input->post('tenant_id');
        $table_name = $this->input->post('table_name'); $table_name = strtolower($table_name);
        $this->Tenant_model->delete($table_name,$id);
        $this->session->set_flashdata('tenant_success', 'Deleted');  
        redirect('tenant/'.$url.'');
    }


    // Check Duplicate Value
    public function check_duplicate_tenant_name()
     {
         $c_name        = $this->input->post('tenant_name');
         $tenant_name  = $this->Tenant_model->check_duplicate_function_tenant($c_name);
         if(isset($tenant_name[0]['tenant_name'])){
            echo '1';
         }else{ echo '0';}

     } 

}

?>