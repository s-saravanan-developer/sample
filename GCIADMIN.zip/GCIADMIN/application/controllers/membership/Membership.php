<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Membership extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->library('excel');
        $this->load->model('member/Membership_model');
        $this->load->model('master/Upload_model');

        $this->load->library('session');
        $this->load->helper('captcha');
        $this->load->library('ssp');
    }

    public function index($platform='web')
    {
        $platform = $this->input->post('platform');
        if(empty($platform)) {
            $platform = 'web';
        }
        $template['page']            ='membership/viewmembership';
        $template['bank']            =  $this->Membership_model->getall_bank();
        $template['payment_mode']    =  $this->Membership_model->getall_payment_modes();
        $template['topup']           =  $this->Membership_model->getall_topups();
        $template['payout']          =  $this->Membership_model->getall_payouts_franchasie();
        $template['membership_type'] =  $this->Membership_model->getall_membershiptype();
        $template['invest_type']     =  $this->Membership_model->getall_invest_type();
        // var_dump($template['membership_type']);die();
        $data['data'] = ['bank'            => $template['bank'],
        'payment_mode'    => $template['payment_mode'],
        'topup'           => $template['topup'],
        'payout'          => $template['payout'],
        'membership_type' => $template['membership_type'],
        'invest_type' => $template['invest_type']];
        if(!empty($data) & $platform != 'web') {
            header('Content-Type: application/json');
            echo json_encode($data);
        } else{
            $this->load->view('template',$template);
        }
    }

    public function members()
    {
        $this->load->model('member/Membership_model'); 
        $this->load->model('Report_model'); 
        $template['page']='membership/pending_members';
        $status=5;
        $status1='';
        $template['increment_code'] = $this->db->count_all_results('gc_membership');
        // $template['members'] =  $this->Membership_model->getall_members($status,$status1);

        $this->db->where('Status',6);
        $template['bank_status'] =  $this->db->count_all_results('gc_member_banks');

        $this->db->where('Status',6);
        $this->db->group_by('Membership_ID');
        $template['document_status'] =  $this->db->count_all_results('gc_member_documents');

        $this->db->where('Payment_status',6);
        $this->db->group_by('Membership_ID');
        $template['payment_status'] =  $this->db->count_all_results('gc_member_payments');

        $this->db->join('gc_membership as members', 'members.Membership_ID = gc_member_banks.Membership_ID', 'left');
        $this->db->where('gc_member_banks.Status',5);
        $this->db->where('members.Status',5);
        $this->db->from('gc_member_banks');
        $template['bank_status1'] =  $this->db->count_all_results();

        $this->db->select('members.*');
        $this->db->from('gc_membership members');
        $this->db->join('gc_member_documents', 'gc_member_documents.Membership_ID = members.Membership_ID', 'left');
        $this->db->where('gc_member_documents.Status',5);
        $this->db->where('members.Status',5);
        $this->db->group_by('gc_member_documents.Membership_ID');
        $template['document_status1'] =  $this->db->count_all_results();


        // $template['document_status'] =  $this->Membership_model->getall_members();
        // $template['payment_status'] =  $this->Membership_model->getall_members();

        // var_dump($template['membership_type']);die();
        $this->load->view('template',$template);
    }

    public function pending_members()
    {
        $this->load->model('member/Membership_model');
        $this->load->model('Report_model');
        $template['page']='membership/pending_members';
        $status=5;
        $status1='';
        $template['increment_code'] = $this->db->count_all_results('gc_membership');
        // $template['members'] =  $this->Membership_model->getall_members($status,$status1);
        $this->db->where('Status',6);
        $template['bank_status'] =  $this->db->count_all_results('gc_member_banks');

        $this->db->where('Status',6);
        $this->db->group_by('Membership_ID');
        $template['document_status'] =  $this->db->count_all_results('gc_member_documents');

        $this->db->where('Payment_status',6);
        $this->db->group_by('Membership_ID');
        $template['payment_status'] =  $this->db->count_all_results('gc_member_payments');
        // $template['document_status'] =  $this->Membership_model->getall_members();
        // $template['payment_status'] =  $this->Membership_model->getall_members();

        $this->db->join('gc_membership as members', 'members.Membership_ID = gc_member_banks.Membership_ID', 'left');
        $this->db->where('gc_member_banks.Status',5);
        $this->db->where('members.Status',5);
        $this->db->from('gc_member_banks');
        $template['bank_status1'] =  $this->db->count_all_results();


        $this->db->select('members.*');
        $this->db->from('gc_membership members');
        $this->db->join('gc_member_documents', 'gc_member_documents.Membership_ID = members.Membership_ID', 'left');
        $this->db->where('gc_member_documents.Status',5);
        $this->db->where('members.Status',5);
        $this->db->group_by('gc_member_documents.Membership_ID');
        $template['document_status1'] =  $this->db->count_all_results();


        // $this->db->select('members.*');
        // $this->db->from('gc_membership members');
        // $this->db->join('gc_member_payments', 'gc_member_payments.Membership_ID = members.Membership_ID', 'left');
        // $this->db->where('gc_member_payments.Payment_status!=',6);
        // $this->db->where('members.Status',5);
        // $this->db->group_by('gc_member_payments.Membership_ID');
        // $template['payment_status1'] =  $this->db->count_all_results();



        // var_dump($template['membership_type']);die();
        $this->load->view('template',$template);
    }

    // public function pending_members()
    // {
    //     $this->load->model('member/Membership_model');
    //     $template['page']='membership/processing_members';
        // $status = 4;  
        // $status1 = $this->input->post("status1");  
        // $this->load->model('member/Membership_model');
        // $template['members'] =  $this->Membership_model->getall_members($status,$status1);

    //     $this->load->view('template',$template);
    // }

    public function processing_members1()
    {
        $this->load->model('member/Membership_model');
        $this->load->model('Report_model');
        $template['page']='membership/processing_members1';

        $status=4;
        $status1='';
        $template['increment_code'] = $this->db->count_all_results('gc_membership');
        $template['members'] =  $this->Membership_model->getall_members1($status,$status1);
        // var_dump($template['members']);die();
        $this->db->where('Status',6);
        $template['bank_status'] =  $this->db->count_all_results('gc_member_banks');

        $this->db->where('Status',6);
        $this->db->group_by('Membership_ID');
        $template['document_status'] =  $this->db->count_all_results('gc_member_documents');

        $this->db->where('Payment_status',6);
        $this->db->group_by('Membership_ID');
        $template['payment_status'] =  $this->db->count_all_results('gc_member_payments');
        // $template['document_status'] =  $this->Membership_model->getall_members();
        // $template['payment_status'] =  $this->Membership_model->getall_members();

        $this->db->join('gc_membership as members', 'members.Membership_ID = gc_member_banks.Membership_ID', 'left');
        $this->db->where('gc_member_banks.Status',5);
        $this->db->where('members.Status',4);
        $this->db->from('gc_member_banks');
        $template['bank_status1'] =  $this->db->count_all_results();


        $this->db->select('members.*');
        $this->db->from('gc_membership members');
        $this->db->join('gc_member_documents', 'gc_member_documents.Membership_ID = members.Membership_ID', 'left');
        $this->db->where('gc_member_documents.Status',5);
        $this->db->where('members.Status',4);
        $this->db->group_by('gc_member_documents.Membership_ID');
        $template['document_status1'] =  $this->db->count_all_results();

        // var_dump($template['membership_type']);die();
        $this->load->view('template',$template);
    }

    public function processing_members()
    {
     $this->load->model('member/Membership_model');
     $template['page']='membership/view_processing';
     $this->load->model('Report_model');

     $template['bank']            =  $this->Membership_model->getall_bank();
     $template['payout']          =  $this->Membership_model->getall_payouts_franchasie();
     $status=4;
     $status1='';
     $template['increment_code'] = $this->db->count_all_results('gc_membership');
     $this->db->where('Status',6);
     $template['bank_status'] =  $this->db->count_all_results('gc_member_banks');

     $this->db->where('Status',6);
     $this->db->group_by('Membership_ID');
     $template['document_status'] =  $this->db->count_all_results('gc_member_documents');

     $this->db->where('Payment_status',6);
     $this->db->group_by('Membership_ID');
     $template['payment_status'] =  $this->db->count_all_results('gc_member_payments');
        // $template['document_status'] =  $this->Membership_model->getall_members();
        // $template['payment_status'] =  $this->Membership_model->getall_members();

     $this->db->join('gc_membership as members', 'members.Membership_ID = gc_member_banks.Membership_ID', 'left');
     $this->db->where('gc_member_banks.Status',5);
     $this->db->where('members.Status',4);
     $this->db->from('gc_member_banks');
     $template['bank_status1'] =  $this->db->count_all_results();


     $this->db->select('members.*');
     $this->db->from('gc_membership members');
     $this->db->join('gc_member_documents', 'gc_member_documents.Membership_ID = members.Membership_ID', 'left');
     $this->db->where('gc_member_documents.Status',5);
     $this->db->where('members.Status',4);
     $this->db->group_by('gc_member_documents.Membership_ID');
     $template['document_status1'] =  $this->db->count_all_results();

        // var_dump($template['membership_type']);die();
     $this->load->view('template',$template);
 }


 public function payment_members()
 {
    $this->load->model('member/Membership_model');
    $this->load->model('Report_model');
    $template['page']='membership/payment_members';
    $template['bank']            =  $this->Membership_model->getall_bank();
    $status=4;
    $status1=12;
    $template['increment_code'] = $this->db->count_all_results('gc_membership');
        // $template['members'] =  $this->Membership_model->getall_members($status,$status1);
    $this->db->where('Status',6);
    $template['bank_status'] =  $this->db->count_all_results('gc_member_banks');

    $this->db->where('Status',6);
    $this->db->group_by('Membership_ID');
    $template['document_status'] =  $this->db->count_all_results('gc_member_documents');

    $this->db->where('Payment_status',6);
    $this->db->group_by('Membership_ID');
    $template['payment_status'] =  $this->db->count_all_results('gc_member_payments');
        // $template['document_status'] =  $this->Membership_model->getall_members();
        // $template['payment_status'] =  $this->Membership_model->getall_members();

    $this->db->join('gc_membership as members', 'members.Membership_ID = gc_member_banks.Membership_ID', 'left');
    $this->db->where('gc_member_banks.Status',5);
    $this->db->where('members.Status',5);
    $this->db->from('gc_member_banks');
    $template['bank_status1'] =  $this->db->count_all_results();


    $this->db->select('members.*');
    $this->db->from('gc_membership members');
    $this->db->join('gc_member_documents', 'gc_member_documents.Membership_ID = members.Membership_ID', 'left');
    $this->db->where('gc_member_documents.Status',5);
    $this->db->where('members.Status',5);
    $this->db->group_by('gc_member_documents.Membership_ID');
    $template['document_status1'] =  $this->db->count_all_results();
    $this->load->view('template',$template);
}


public function payment_reupload_members()
{
    $this->load->model('member/Membership_model');
    $this->load->model('Report_model');
    $template['page']='membership/reupload_members';
    $template['bank']            =  $this->Membership_model->getall_bank();
    $status=4;
    $status1=13;
    $template['increment_code'] = $this->db->count_all_results('gc_membership');
        // $template['members'] =  $this->Membership_model->getall_members($status,$status1);
    $this->db->where('Status',6);
    $template['bank_status'] =  $this->db->count_all_results('gc_member_banks');

    $this->db->where('Status',6);
    $this->db->group_by('Membership_ID');
    $template['document_status'] =  $this->db->count_all_results('gc_member_documents');

    $this->db->where('Payment_status',6);
    $this->db->group_by('Membership_ID');
    $template['payment_status'] =  $this->db->count_all_results('gc_member_payments');
        // $template['document_status'] =  $this->Membership_model->getall_members();
        // $template['payment_status'] =  $this->Membership_model->getall_members();

    $this->db->join('gc_membership as members', 'members.Membership_ID = gc_member_banks.Membership_ID', 'left');
    $this->db->where('gc_member_banks.Status',5);
    $this->db->where('members.Status',5);
    $this->db->from('gc_member_banks');
    $template['bank_status1'] =  $this->db->count_all_results();


    $this->db->select('members.*');
    $this->db->from('gc_membership members');
    $this->db->join('gc_member_documents', 'gc_member_documents.Membership_ID = members.Membership_ID', 'left');
    $this->db->where('gc_member_documents.Status',5);
    $this->db->where('members.Status',5);
    $this->db->group_by('gc_member_documents.Membership_ID');
    $template['document_status1'] =  $this->db->count_all_results();
    $this->load->view('template',$template);
}

public function processing_pagination1(){
  $start=$_POST['page'];
  $end=$_POST['len'];
  $ser=$_POST['area'];
  // $start_query=$_POST['page']*$end;
  $start_query=($_POST['page']-1)*$end;
  $tbl_name="gc_membership";
// if($ser=='')
//     {
   // $query = $this->db->query("SELECT * FROM $tbl_name WHERE status!=3 ORDER BY id ASC LIMIT $start_query, $end");
   // $data['employees_management1']=$query->result();

//         $this->db->select('member.*,contract.*,member.Status as Member_status,contract.Status as Cont_status,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name,users.email_address as loginemail,users.og_password as loginpassword');
//         $this->db->from('gc_membership as member');
//         $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
//         $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
//         $this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
//         $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
//         $this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
//         $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
//         $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
//         $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
//         $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
//         $this->db->join('gc_users as users', 'users.id = member.Membership_ID', 'left');
  $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Created_date,member.Mobile,member.Gender,member.Membership_code,member.Status as Member_status,type.Membership_type,bank.Status as Bank_status,payments.Payment_status,bank.Bank_ID as Bank_Bank_ID,contract.Contract_ID,bank.Status as Bank_status');
          // $this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name,users.email_address as loginemail,users.og_password as loginpassword');
  $this->db->from('gc_membership as member');
  $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
  $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
        // $this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
        // $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
  $this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
        // $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
  $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
        // $this->db->join('gc_users as users', 'users.id = member.Membership_ID', 'left');

        // $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
  $this->db->group_by("member.Membership_ID");
// $this->db->group_by("member.Membership_ID");
  $status=4;
  if($status!=1){
    $this->db->where("member.Status=",$status);}
    if($ser!=''){
       $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
       $this->db->where($ser_de);
   }
   $this->db->group_by("payments.Membership_ID");

   $this->db->limit($end,$start_query);
// $this->db->limit($start_query,$end);
   $query=$this->db->get();
   $data['members']=$query->result_array();


   $this->db->select('member.Membership_ID');
   $this->db->from('gc_membership as member');
   $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
   $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
   $this->db->group_by("member.Membership_ID");
   $this->db->where("member.Status",4);
   $query=$this->db->get();
   $data['total_pages']=$query->num_rows();


   

   // $query =$this->db->query("SELECT * FROM  $tbl_name WHERE ".$ser_de." status=0 LIMIT ".$start_query.",".$end.""); 
   // $data['employees_management1']=$query->result();
   // $data['totalrow']=$query->num_rows();

   $this->load->model('Report_model');
// var_dump($data['members']);die();
   $this->load->view('membership/ajax_members',$data);

}


// function sample_count(){
// $this->db->select('member.Membership_ID');
// $this->db->from('gc_membership as member');
// $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
// $this->db->group_by("member.Membership_ID");
//         $this->db->where("member.Status",4);
//         // echo $this->db->count_all_results();
//         $query=$this->db->get();
//     //     if($ser!=''){
//     //          $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
//     // $this->db->where($ser_de);
//     //     }
// // $this->db->group_by("payments.Membership_ID");
// echo $query->num_rows();

// }


public function activated_pagination(){
  $start=$_POST['page'];
  $end=$_POST['len'];
  $ser=$_POST['area'];
  // $start_query=$_POST['page']*$end ;
  $start_query=($_POST['page']-1)*$end;
  $tbl_name="gc_membership";
  $this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
  $this->db->from('gc_membership as member');
 // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
  $this->db->group_by("member.Membership_ID");
  $this->db->where("member.Status",6);
  $this->db->where("member.Bank_verify",6);
  $this->db->where("member.Doc_verify",6);
  $this->db->where("member.Payment_verify",6);
  if($ser!=''){
   $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
   $this->db->where($ser_de);
   $this->db->where("member.Status",6);
   $this->db->where("member.Bank_verify",6);
   $this->db->where("member.Doc_verify",6);
   $this->db->where("member.Payment_verify",6);
}
// $this->db->group_by("payments.Membership_ID");

$this->db->limit($end,$start_query);
// $this->db->limit($start_query,$end);
$query=$this->db->get();
$data['members']=$query->result_array();


$this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
$this->db->from('gc_membership as member');
// $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
$this->db->group_by("member.Membership_ID");
$this->db->where("member.Status",6);
if($ser!=''){
   $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
   $this->db->where($ser_de);
   $this->db->where("member.Status",6);
   $this->db->where("member.Bank_verify",6);
   $this->db->where("member.Doc_verify",6);
   $this->db->where("member.Payment_verify",6);
}
$this->db->where("member.Bank_verify",6);
$this->db->where("member.Doc_verify",6);
$this->db->where("member.Payment_verify",6);
$query=$this->db->get();
$data['total_pages']=$query->num_rows();
$this->load->model('Report_model');
$this->load->view('membership/ajax_activated_members',$data);


}


public function processing_pagination(){
  $start=$_POST['page'];
  $end=$_POST['len'];
  $ser=$_POST['area'];
  // $start_query=$_POST['page']*$end ;
  $start_query=($_POST['page']-1)*$end;
  $tbl_name="gc_membership";
  $this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
  $this->db->from('gc_membership as member');
 // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
  $this->db->group_by("member.Membership_ID");
  $this->db->where("member.Status",4);
  $this->db->where("member.Doc_verify",6);
  $this->db->where("member.Bank_verify",5);
  if($ser!=''){
   $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
   $this->db->where($ser_de);
   $this->db->where("member.Status",4);
   $this->db->where("member.Doc_verify",6);
   $this->db->where("member.Bank_verify",5);
}
// $this->db->group_by("payments.Membership_ID");

$this->db->limit($end,$start_query);
// $this->db->limit($start_query,$end);
$query=$this->db->get();
$data['members']=$query->result_array();

$this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
$this->db->from('gc_membership as member');
// $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
$this->db->group_by("member.Membership_ID");
$this->db->where("member.Status",4);
$this->db->where("member.Doc_verify",6);
$this->db->where("member.Bank_verify",5);
$query=$this->db->get();
$data['total_pages']=$query->num_rows();
$this->load->model('Report_model');
$this->load->view('membership/ajax_members1',$data);

}


public function payment_verify_pagination(){
	// extract($_POST);
	// echo '<pre>';
	// print_r($_POST);
  $start=$_POST['page'];
  $end=$_POST['len'];
  $ser=$_POST['area'];
  $acc=$_POST['acc'];


  // $start_query=$_POST['page']*$end ;
  $start_query=($_POST['page']-1)*$end;
  $tbl_name="gc_membership";
  $this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
  $this->db->from('gc_membership as member');
  $this->db->join('gc_wallet_topup as wallet','wallet.Membership_ID = member.Membership_ID','left');
  $this->db->join('gc_wallet_payments as payment','payment.Service_point_ID = wallet.Wallet_topup_ID','left');
 // $this->db->join('gc_member_payments as payment1','payment1.Membership_ID = member.Membership_ID','left');
 // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
  

  $this->db->where("member.Status",4);
  $this->db->where("member.Bank_verify",6);
  $this->db->where("member.Doc_verify",6);
  $this->db->where("member.Payment_verify",5);
  if(!empty($acc)){
      $acc1=explode(',', $acc);
      $this->db->where_in('payment.Payment_type_ID',$acc1);
      $this->db->where("wallet.Membership_ID is NOT NULL");
	   		// $this->db->group_by('wallet.Wallet_topup_ID');
	   		// $this->db->group_by('member.Membership_ID');
	   		// $this->db->order_by("payment.Payment_ID",'ASC')->limit('1');
  }
  if($ser!=''){
   $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
   $this->db->where($ser_de);
   $this->db->where("member.Status",4);
   $this->db->where("member.Bank_verify",6);
   $this->db->where("member.Doc_verify",6);
   $this->db->where("member.Payment_verify",5);
   if(!empty($acc)){
      $acc1=explode(',', $acc);
      $this->db->where_in('payment.Payment_type_ID',$acc1);
      $this->db->where("wallet.Membership_ID is NOT NULL");
	   		// $this->db->group_by('wallet.Wallet_topup_ID');
	   		// $this->db->group_by('member.Membership_ID');
	   		// $this->db->order_by("payment.Payment_ID",'ASC')->limit('1');
  }

}
// $this->db->group_by("payments.Membership_ID");
// $this->db->order_by("member.Membership_ID",'DESC');
$this->db->group_by("member.Membership_ID");
$this->db->limit($end,$start_query);
// $this->db->limit($start_query,$end);
$query1=$this->db->get();
$members1=$query1->result_array();

// echo '<pre>';
// print_r($members1);

// part 2start
$this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
$this->db->from('gc_membership as member');
 // $this->db->join('gc_wallet_topup as wallet','wallet.Membership_ID = wallet.Membership_ID','left');
 // $this->db->join('gc_wallet_payments as payment','payment.Service_point_ID = wallet.Wallet_topup_ID','left');
$this->db->join('gc_member_payments as payment1','payment1.Membership_ID = member.Membership_ID','left');
 // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');

$this->db->where("member.Status",4);
$this->db->where("member.Bank_verify",6);
$this->db->where("member.Doc_verify",6);
$this->db->where("member.Payment_verify",5);
if(!empty($acc)){
 	// var_dump($acc);die();
  $acc1=explode(',', $acc);
  $this->db->where_in('payment1.Payment_type_ID',$acc1);
  $this->db->where("payment1.Membership_ID is NOT NULL");
}
if($ser!=''){
   $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
   $this->db->where($ser_de);
   $this->db->where("member.Status",4);
   $this->db->where("member.Bank_verify",6);
   $this->db->where("member.Doc_verify",6);
   $this->db->where("member.Payment_verify",5);
   if(!empty($acc)){
 	// var_dump($acc);die();
      $acc1=explode(',', $acc);
      $this->db->where_in('payment1.Payment_type_ID',$acc1);
      $this->db->where("payment1.Membership_ID is NOT NULL");
  }


}
// $this->db->group_by("payments.Membership_ID");
$this->db->group_by("member.Membership_ID");
$this->db->order_by("member.Membership_ID",'DESC');
$this->db->limit($end,$start_query);
// $this->db->limit($start_query,$end);
$query2=$this->db->get();
$members2=$query2->result_array();
// echo '<pre>';
// print_r($members2);die();
$data['members']=array_merge($members1,$members2);
// print_r($data['members']);die();
// part 2 end
// var_dump($data['members']);die();

$this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
$this->db->from('gc_membership as member');
$this->db->join('gc_wallet_topup as wallet','wallet.Membership_ID = member.Membership_ID','left');
$this->db->join('gc_wallet_payments as payment','payment.Service_point_ID = wallet.Wallet_topup_ID','left');
 // $this->db->join('gc_member_payments as payment1','payment1.Membership_ID = member.Membership_ID','left');
// $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');

$this->db->where("member.Status",4);
$this->db->where("member.Bank_verify",6);
$this->db->where("member.Doc_verify",6);
$this->db->where("member.Payment_verify",5);
if(!empty($acc)){
  $acc1=explode(',', $acc);
  $this->db->where_in('payment.Payment_type_ID',$acc1);
  $this->db->where("payment.Membership_ID is NOT NULL");
}
if($ser!=''){
   $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
   $this->db->where($ser_de);
   $this->db->where("member.Status",4);
   $this->db->where("member.Bank_verify",6);
   $this->db->where("member.Doc_verify",6);
   $this->db->where("member.Payment_verify",5);
   if(!empty($acc)){
      $acc1=explode(',', $acc);
      $this->db->where_in('payment.Payment_type_ID',$acc1);
      $this->db->where("payment.Membership_ID is NOT NULL");
  }
}
// $this->db->where("member.Bank_verify",6);
// $this->db->where("member.Doc_verify",6);
// $this->db->where("member.Payment_verify",5);
$this->db->group_by("member.Membership_ID");
$query3=$this->db->get();
$total_pages1=$query3->num_rows();

// part 2 start
$this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
$this->db->from('gc_membership as member');
 // $this->db->join('gc_wallet_topup as wallet','wallet.Membership_ID = wallet.Membership_ID','left');
 // $this->db->join('gc_wallet_payments as payment','payment.Service_point_ID = wallet.Wallet_topup_ID','left');
$this->db->join('gc_member_payments as payment1','payment1.Membership_ID = member.Membership_ID','left');
// $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');

$this->db->where("member.Status",4);
$this->db->where("member.Bank_verify",6);
$this->db->where("member.Doc_verify",6);
$this->db->where("member.Payment_verify",5);
if(!empty($acc)){
  $acc1=explode(',', $acc);
  $this->db->where_in('payment1.Payment_type_ID',$acc1);
  $this->db->where("payment1.Membership_ID is NOT NULL");
}
if($ser!=''){
   $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
   $this->db->where($ser_de);
   $this->db->where("member.Status",4);
   $this->db->where("member.Bank_verify",6);
   $this->db->where("member.Doc_verify",6);
   $this->db->where("member.Payment_verify",5);
   if(!empty($acc)){
      $acc1=explode(',', $acc);
      $this->db->where_in('payment1.Payment_type_ID',$acc1);
      $this->db->where("payment1.Membership_ID is NOT NULL");
  }
}

$this->db->group_by("member.Membership_ID");
$query4=$this->db->get();
$total_pages2=$query4->num_rows();
// part 2 end

$data['total_pages']=$total_pages1+$total_pages2;

$this->load->model('Report_model');
$this->load->view('membership/ajax_payment_verify_members',$data);


}

public function payment_reupload_pagination(){
  $start=$_POST['page'];
  $end=$_POST['len'];
  $ser=$_POST['area'];
  // $start_query=$_POST['page']*$end ;
  $start_query=($_POST['page']-1)*$end;
  $tbl_name="gc_membership";
  $this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
  $this->db->from('gc_membership as member');
 // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
  $this->db->group_by("member.Membership_ID");
  $this->db->where("member.Status",4);
  $this->db->where("member.Bank_verify",6);
  $this->db->where("member.Doc_verify",6);
  $this->db->where("member.Payment_verify",9);
  if($ser!=''){
   $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
   $this->db->where($ser_de);
   $this->db->where("member.Status",4);
   $this->db->where("member.Bank_verify",6);
   $this->db->where("member.Doc_verify",6);
   $this->db->where("member.Payment_verify",9);
}
// $this->db->group_by("payments.Membership_ID");

$this->db->limit($end,$start_query);
// $this->db->limit($start_query,$end);
$query=$this->db->get();
$data['members']=$query->result_array();
// var_dump($data['members']);die();

$this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
$this->db->from('gc_membership as member');
// $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
$this->db->group_by("member.Membership_ID");
$this->db->where("member.Status",4);
if($ser!=''){
   $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
   $this->db->where($ser_de);
   $this->db->where("member.Status",4);
   $this->db->where("member.Bank_verify",6);
   $this->db->where("member.Doc_verify",6);
   $this->db->where("member.Payment_verify",9);
}
$this->db->where("member.Bank_verify",6);
$this->db->where("member.Doc_verify",6);
$this->db->where("member.Payment_verify",9);
$query=$this->db->get();
$data['total_pages']=$query->num_rows();
$this->load->model('Report_model');
$this->load->view('membership/ajax_payment_reupload_members',$data);


}


public function doc_pagination(){

  $start=$_POST['page'];
  $end=$_POST['len'];
  $ser=$_POST['area'];
  // $start_query=$_POST['page']*$end ;
  $start_query=($_POST['page']-1)*$end;
  $tbl_name="gc_membership";

  $this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
  $this->db->from('gc_membership as member');
 // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
 // $this->db->group_by("member.Membership_ID");
  $this->db->where("member.Status!=",6);
  $this->db->where("member.Doc_verify",5);
 // $this->db->where("member.Bank_verify",5);
// $this->db->order_by("member.Membership_ID",'DESC');

 // $this->db->select('member.Activated_date,member.Membership_ID,member.Register_from,member.First_name,member.Last_name,member.Created_date,member.Mobile,member.Gender,member.Membership_code,member.Status as Member_status,type.Membership_type,bank.Status as Bank_status,payments.Payment_status,bank.Bank_ID as Bank_Bank_ID,contract.Contract_ID,contract.Contract_status_date,bank.Status as Bank_status');
 // $this->db->from('gc_membership as member');
 // $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
// $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
  $this->db->group_by("member.Membership_ID");
  $this->db->order_by("member.Membership_ID",'DESC');
 // $this->db->where("member.Status",5);
  $this->db->where("member.Doc_verify",5);
  if($ser!=''){
   $ser_de ="member.First_name LIKE '%$ser%' OR  member.Last_name LIKE '%$ser%' OR member.Mobile LIKE '%$ser%' OR member.Membership_code LIKE '%$ser%'";
   $this->db->where($ser_de);
   $this->db->where("member.Status!=",6);
   $this->db->where("member.Doc_verify",5);
   $this->db->group_by("member.Membership_ID");
}
// $this->db->group_by("payments.Membership_ID");

$this->db->limit($end,$start_query);
// $this->db->limit($start_query,$end);
$query=$this->db->get();
$data['members']=$query->result_array();
// var_dump($data['members']);die();


$this->db->select('member.Membership_ID,member.Register_from,member.Created_date');
$this->db->from('gc_membership as member');
 // $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
 // $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
 // $this->db->group_by("member.Membership_ID");
$this->db->where("member.Status!=",6);
$this->db->where("member.Doc_verify",5);
 // $this->db->where("member.Bank_verify",5);
$this->db->order_by("member.Membership_ID",'DESC');
// $this->db->select('member.Activated_date,member.Membership_ID,member.Register_from,member.First_name,member.Last_name,member.Created_date,member.Mobile,member.Gender,member.Membership_code,member.Status as Member_status,type.Membership_type,bank.Status as Bank_status,payments.Payment_status,bank.Bank_ID as Bank_Bank_ID,contract.Contract_ID,contract.Contract_status_date,bank.Status as Bank_status');
// $this->db->from('gc_membership as member');
// $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_membershiptype as type', 'type.ID = member.Membership_type', 'left');
// $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
// $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');
$this->db->group_by("member.Membership_ID");
// $this->db->where("member.Status",5);
// $this->db->where("member.Doc_verify",5);
$query=$this->db->get();
$data['total_pages']=$query->num_rows();
$this->load->model('Report_model');
$this->load->view('membership/ajax_bank_members',$data);

}

public function activated_members()
{
    $this->load->model('member/Membership_model');
    $this->load->model('Report_model');
    $template['page']='membership/activated_members2';
    $status=6;
    $status1='';
    $template['increment_code'] = $this->db->count_all_results('gc_membership');
        // $template['members'] =  $this->Membership_model->getall_members($status,$status1);
    $this->db->where('Status',6);
    $template['bank_status'] =  $this->db->count_all_results('gc_member_banks');
    $template['bank']            =  $this->Membership_model->getall_bank();

    $this->db->where('Status',6);
    $this->db->group_by('Membership_ID');
    $template['document_status'] =  $this->db->count_all_results('gc_member_documents');

    $this->db->where('Payment_status',6);
    $this->db->group_by('Membership_ID');
    $template['payment_status'] =  $this->db->count_all_results('gc_member_payments');

    $this->load->view('template',$template);
}

public function rejected_members()
{
    $this->load->model('member/Membership_model');
    $template['page']='membership/rejected_members';
    $status=['7','8'];
    $status1='';
    $template['increment_code'] = $this->db->count_all_results('gc_membership');
    $template['members'] =  $this->Membership_model->getall_members($status,$status1);
    $this->db->where('Status',6);
    $template['bank_status'] =  $this->db->count_all_results('gc_member_banks');

    $this->db->where('Status',6);
    $this->db->group_by('Membership_ID');
    $template['document_status'] =  $this->db->count_all_results('gc_member_documents');

    $this->db->where('Payment_status',6);
    $this->db->group_by('Membership_ID');
    $template['payment_status'] =  $this->db->count_all_results('gc_member_payments');

    $this->load->view('template',$template);
}

public function view_members(){
 $member=decrypt($this->input->get('id'));
 $template['members'] =  $this->Membership_model->getall_members_by_id($member);
    // var_dump($template['members']);
 $this->load->model('member/Contract_model');
 $template['contract'] =  $this->Contract_model->get_contract_details($template['members'][0]['Membership_code']);
 $this->load->model('member/Membership_model');
 $template['page']='membership/view_members';
 $this->load->view('template',$template);

}


public function view_panel(){
 $member=decrypt($this->input->get('id'));
 $template['url']=$this->input->get('rt');
 
 $template['members'] =  $this->Membership_model->getall_members_by_id($member);
 $template['Membership_ID'] =$member;
    // var_dump($template['members']);
 $this->load->model('member/Contract_model');
 $template['contract'] =  $this->Contract_model->get_contract_details($template['members'][0]['Membership_code']);
 $this->load->model('member/Membership_model');
 $template['page']='membership/view_panel';
 $this->load->view('template',$template);

}


public function edit_members(){
    $member=$this->input->get('id');
    $template['members'] =  $this->Membership_model->getall_members_by_id($member); 
    $template['bank']            =  $this->Membership_model->getall_bank();   
    $this->load->model('member/Membership_model');
    $template['page']='membership/edit_members';
    $this->load->view('template',$template);
}    
public function get_referer_by_code()
{
    $referer = $this->input->post("referer");
    
    $data['referer'] =  $this->Membership_model->get_referer_by_code($referer);
    $data['bank']            =  $this->Membership_model->getall_bank();
    $data['payment_mode']    =  $this->Membership_model->getall_payment_modes();
    $data['topup']           =  $this->Membership_model->getall_topups();
    $data['payout']          =  $this->Membership_model->getall_payouts();
    $data['membership_type'] =  $this->Membership_model->getall_membershiptype();
    if($data['referer']!=0){
        // var_dump($template['membership_type']);die();
        $temp['data'] = ['value'                => 'Success',
        'referer'               => $data['referer'],
        'bank'                 => $data['bank'],
        'payment_mode'         => $data['payment_mode'],
        'topup'                => $data['topup'],
        'payout'               => $data['payout'],
        'membership_type'      => $data['membership_type']];
    }else{
        $temp['data'] = ['value'             => 'Failure',
        'referer'             => $data['referer'],
        'bank'                 => $data['bank']="",
        'payment_mode'         => $data['payment_mode']="",
        'topup'                => $data['topup']="",
        'payout'               => $data['payout']="",
        'membership_type'      => $data['membership_type']=""];
    }

    header('Content-Type: application/json');
    echo json_encode($temp);
}

public function get_referer_detail()
{
    $referer = $this->input->post("referer");
    
    $temp['referer'] =  $this->Membership_model->get_referer_by_code($referer);
    if($data['referer']!=0){
        $data['data'] = ['value'             => 'Success',
        'referer'             => $temp['referer']];
    }else{
        $data['data'] = ['value'             => 'Failure',
        'referer'             => $temp['referer']];
    }
    
    header('Content-Type: application/json');
    echo json_encode($data);
}

public function status_wise_members()
{
    $status = $this->input->post("status");  
    $status1 = $this->input->post("status1");  
    $this->load->model('member/Membership_model');
        //$template['page']='membership/manage_members';
    $template['members'] =  $this->Membership_model->getall_members($status,$status1);

    

    if($status==5){
        $this->db->join('gc_membership as members', 'members.Membership_ID = gc_member_banks.Membership_ID', 'left');
        $this->db->where('gc_member_banks.Status',5);
        $this->db->where('members.Status',5);
        $this->db->from('gc_member_banks');
        $template['bank_status1'] =  $this->db->count_all_results();


        $this->db->select('members.*');
        $this->db->from('gc_membership members');
        $this->db->join('gc_member_documents', 'gc_member_documents.Membership_ID = members.Membership_ID', 'left');
        $this->db->where('gc_member_documents.Status',5);
        $this->db->where('members.Status',5);
        $this->db->group_by('gc_member_documents.Membership_ID');
        $template['document_status1'] =  $this->db->count_all_results();
    }elseif($status==4){
        $this->db->join('gc_membership as members', 'members.Membership_ID = gc_member_banks.Membership_ID', 'left');
        $this->db->where('gc_member_banks.Status',5);
        $this->db->where('members.Status',4);
        $this->db->from('gc_member_banks');
        $template['bank_status1'] =  $this->db->count_all_results();


        $this->db->select('members.*');
        $this->db->from('gc_membership members');
        $this->db->join('gc_member_documents', 'gc_member_documents.Membership_ID = members.Membership_ID', 'left');
        $this->db->where('gc_member_documents.Status',5);
        $this->db->where('members.Status',4);
        $this->db->group_by('gc_member_documents.Membership_ID');
        $template['document_status1'] =  $this->db->count_all_results();
    }
    $this->load->view('membership/ajax_members',$template);
    
}

public function calculate_commission()
{
    $status = $this->input->post("status");
    $Cal_date = $this->input->post("Cal_date");
    
        //$template['page']='membership/manage_members';
    $template['members'] =  $this->Membership_model->calculate_commission($Cal_date);
        //$this->load->view('membership/ajax_members',$template);
}

public function calculate_commission_new()
{
    $status = $this->input->post("status");
    $Cal_date = $this->input->post("Cal_date");
        // die();
        //$template['page']='membership/manage_members';
    $template['members'] =  $this->Membership_model->calculate_commission_new3($Cal_date);
        //$this->load->view('membership/ajax_members',$template);
}

public function bulk_calculation(){
	$template['members'] =  $this->Membership_model->bulk_calculation_new();
}    

public function calculate_daily_commission()
{
    $status = $this->input->post("status");
    $Cal_date = $this->input->post("Cal_date");
    
        //$template['page']='membership/manage_members';
    $template['members'] =  $this->Membership_model->calculate_daily_commission2($Cal_date);
        //$this->load->view('membership/ajax_members',$template);
}    

public function calculate_binary_commission()
{
    $status = $this->input->post("status");
    $Cal_date = $this->input->post("Cal_date");
    
        //$template['page']='membership/manage_members';
    $template['members'] =  $this->Membership_model->calculate_binary_commission($Cal_date);
        //$this->load->view('membership/ajax_members',$template);
}



public function mobile_verify()
{
    $mobile = $this->input->post("mobile");
        // $temp['referer'] =  $this->Membership_model->mobile_verify($mobile);
    $this->db->select('Membership_ID,First_name,Last_name,Membership_code,Status');
    $this->db->where('Mobile',$mobile);
    $query = $this->db->get('gc_membership');
    if ($query->num_rows() > 0) {
        $verify['content'] =  'Member Already Exist!';
        $verify['status']  =  '1';
        $verify['value']  =  'Failiure';
        $verify['mobile']  =  "";

    }else{
        $temp['Mobile']=$mobile;
        $temp['OTP']=$this->generatePIN(4);
        if($this->db->insert('gc_temp_user',$temp)){
            $temp_id=$this->db->insert_id();
            $sms_content="Please Use This OTP : ".$temp['OTP'];

                // $sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=ZmQxNzA1OWEyZTE&mobiles='.$mobile.'&message='.$sms_content.'&sender=PKSEVA&type=1&route=2';
            $sms_url='http://bulksmscoimbatore.co.in/sendsms?uname=mequals&pwd=mequals@123&senderid=BUGFIX&to='.$mobile.'&msg='.urlencode($sms_content).'&route=SID';

            $ch = curl_init($sms_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
            $response=curl_exec($ch);
                // curl_close($ch);

            if (curl_errno($ch)) {
                $error = curl_error($ch);
            }
            $curl_data = explode(',', $response);
            curl_close($ch);
            
        }
        $verify['content'] =  'Please Enter OTP';
        $verify['status']  ='0';
        $verify['mobile']  =  $mobile;
        $verify['value']  =  'Success';

    }
    $data['data'] = ['content'             => $verify['content'],
    'status'             => $verify['status'],
    'mobile'               =>$verify['mobile'],
    'value'                => $verify['value']];
    header('Content-Type: application/json');
    echo json_encode($data);
}
// Mobile Verity OTP End //


// Resend OTP Start //
public function resend_otp()
{
    $mobile = $this->input->post("mobile");
            //$id = $this->input->post("temp_id");

    $temp['Mobile']=$mobile;
    $temp['OTP']=$this->generatePIN(4);
    $this->db->where('Mobile',$mobile);
    $this->db->delete('gc_temp_user');
    $this->db->where('Mobile',$mobile);
    if($this->db->insert('gc_temp_user',$temp)){
        $sms_content="Please Use This OTP : ".$temp['OTP'];

                // $sms_url='http://mysms.mequals.me/api/sendhttp.php?authkey=ZmQxNzA1OWEyZTE&mobiles='.$mobile.'&message='.$sms_content.'&sender=PKSEVA&type=1&route=2';
        $sms_url='http://bulksmscoimbatore.co.in/sendsms?uname=mequals&pwd=mequals@123&senderid=BUGFIX&to='.$mobile.'&msg='.urlencode($sms_content).'&route=SID';

        $ch = curl_init($sms_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
        $response=curl_exec($ch);
                // curl_close($ch);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
        }
        $curl_data = explode(',', $response);
        curl_close($ch);
        
    }

    $verify['content']  =  'Please Enter OTP';
    $verify['status']   =  '0';
    $verify['mobile']   =  $mobile;
    

    $data['data'] = ['Content'             => $verify['content'],
    'status'                   => $verify['status'],
    'mobile'                   => $verify['mobile'],
    'value'                    => "Success" ];
    header('Content-Type: application/json');
    echo json_encode($data);

    
}
// Resend OTP END //

// Expiry OTP Start //
public function expiry_otp()
{
    $mobile         = $this->input->post("mobile");
    $this->db->where('Mobile',$mobile);
    $query          = $this->db->delete('gc_temp_user');
    $temp['content']='OTP Expired!';
    $temp['status'] =3;


    $data['data'] = ['content'             => $temp['content'],
    'status'               => $temp['status'],
    'value'               => "Success"];
    header('Content-Type: application/json');
    echo json_encode($data);
}
// Expiry OTP End //

// Verity OTP Start //
public function verify_otp()
{
    $mobile          = $this->input->post("mobile");
    $otp             = $this->input->post("otp");
    $this->db->select('*');
    $this->db->where('OTP',$otp);
    $this->db->where('Mobile',$mobile);
    $query           = $this->db->get('gc_temp_user');
    if ($query->num_rows() > 0) {
     $this->db->where('OTP',$otp);
     $this->db->where('Mobile',$mobile);
     $query          = $this->db->delete('gc_temp_user'); 
     $verify['content'] =  'OTP Verified!';
     $verify['status']  =  '1';
     $verify['mobile']  =  $mobile;
     $verify['value']   =  "Success";

 }else{
    $verify['content'] =  'Invalid OTP!';
    $verify['status']  =  '0';
    $verify['mobile']  =  $mobile;
    $verify['value']   =  "Failure";
}

$data['data'] = ['content'              => $verify['content'],
'status'               => $verify['status'],
'mobile'               => $verify['mobile'],
'value'                 => $verify['value']];
header('Content-Type: application/json');
echo json_encode($data);
}
// Verity OTP End //


public function get_pincode_details()
{
    $pincode         = $this->input->post("pincode");

    $this->db->select('area.id as taluk_id,area.area_name as taluk_name,city.id as City_id,city.city_name as City_name,state.id as State_id,state.state_name as State_name,country.id as Country_id,country.country_name as Country_name');

    $this->db->from('gc_areas as area');
    $this->db->join('gc_cities as city', 'city.id = area.city_id', 'left');
    $this->db->join('gc_states as state', 'state.id = area.state_id', 'left');
    $this->db->join('gc_countries as country', 'country.id = area.country_id', 'left');
    $this->db->where("area.Pincode",$pincode);
    $query = $this->db->get();
    if ($query->num_rows() > 0) {
        $temp['pincode'] = $query->result_array();
        $temp['value']= "Success";
    }else{
        $temp['pincode']= "";
        $temp['value']= "Failure";

    }

            // $this->db->where('ID',$id);
            // $query          = $this->db->delete('gc_temp_user');
            // $temp['content']='OTP Expired!';
            // $temp['status'] =3;

    $data['data'] = ['pincode'             => $temp['pincode'],
    'value'             => $temp['value']];
    header('Content-Type: application/json');
    echo json_encode($data);
}

public function get_topup_details()
{
    $topup = $this->input->post("topup");
    $temp['topup'] =  $this->Membership_model->get_topup_details($topup);
    if($temp['topup']!=0){

        header('Content-Type: application/json');
        $data['data'] = ['topup'              => $temp['topup'],
        'value'    =>"Success"];
    }else{
        $data['data'] = ['topup'              => $temp['topup']="",
        'value'    =>"Failure"];
    }
    header('Content-Type: application/json');                   
    echo json_encode($data);
}


public function add()
{
        // extract($_POST);
        // print_r($_POST);die();
    $member = $this->input->post("member");
        // var_dump($member);
    $photo = $this->input->post("Photo");
    $upload1 = $this->input->post("upload1");
    $upload2 = $this->input->post("upload2");
    $upload3 = $this->input->post("upload3");
    $address_data = $this->input->post("address_data");
    $nominee_data = $this->input->post("nominee_data");
    $bank_data = $this->input->post("bank_data");
    $upload_rows = $this->input->post('upload_rows');
    $upload_rows=explode(',',$upload_rows);

    foreach($upload_rows as $val){
     
        $upload_data['upload_data_'.$val] = $this->input->post('upload_data_'.$val);

        $profile_name = 'upload'.$val;

        // Membership Code
        // $pan=$upload_data["upload_data_1"]["Document_no"];

        // if(!empty($pan)){
        // $newpan = substr($pan, -5);
        // }

        // $newmob = substr($member['Mobile'], -5);
        // $Membership_code=$newpan.$newmob;
        $Membership_code='GCI'.$this->generatePIN(7);


        $docs_name = $this->Membership_model->member_profile_attachment_1($Membership_code,$profile_name,$upload_data['upload_data_'.$val]['Document_type']);

        $upload_data['upload_data_'.$val]['Folder_name']=$Membership_code;
        $upload_data['upload_data_'.$val]['Document_name']=$docs_name;
        $upload_data['upload_data_'.$val]['File_path']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/';
    }
        // $Upload_data = $this->input->post("Upload_data");
            // if(isset($this->input->post("contract_data"))){
    if(isset($_POST['contract_data'])){

        $contract_data = $this->input->post("contract_data");
    }else{
        $contract_data=[];
    }
    
            // if(isset($this->input->post('unique_id'))){
    if(isset($_POST['unique_id'])){
        $unique_id = $this->input->post('unique_id');
        $unique=explode(',',$unique_id);
        foreach($unique as $val1){
           $payment_data['payment_data_'.$val1] = $this->input->post('payment_data_'.$val1);
           $payment_data['payment_data_'.$val1]['Date']   = date('Y-m-d',strtotime($payment_data['payment_data_'.$val1]['Date']));

           $statement_name='state_ment_'.$val1;

           $doc_name = $this->Membership_model->member_profile_attachment_1($Membership_code,$statement_name,'statement');
           $payment_data['payment_data_'.$val1]['Statement']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/'.$doc_name;
       }

   }else{
    $payment_data=[];
}

        // $payment_data = $this->input->post("payment_data");
$agreement_data = $this->input->post("agreement_data");


// var_dump($payment_data);
// echo $payment_data['payment_data_1']['Amount'];die();
if (!empty($payment_data)) {


    if ($contract_data['Amount']>0 && $payment_data['payment_data_1']['Amount']>0) {
        $count = $this->db->where('Mobile',$member['Mobile'])->count_all_results('gc_membership');
        if ($count<=0) {
            $events1 = $this->Membership_model->add_membership($member,$address_data,$nominee_data,$bank_data,$upload_data,$contract_data,$payment_data,$agreement_data,$Membership_code);
            redirect('membership/Membership/pending_members');
        }else{
            redirect('membership/Membership');
        }
    }

}else{
    redirect('membership/Membership');
}


        // var_dump($agreement_data);
}

public function generatePIN($digits){
    $i = 0; //counter
    $pin = ""; //our default pin is blank.
    while($i < $digits){
        //generate a random number between 0 and 9.
        $pin .= mt_rand(0, 9);
        $i++;
    }
    return $pin;
}

public function get_currency()
{
	$id=$this->input->get('id');
	// echo $this->Membership_model->get_currency($id);

	$data=$this->db->get_where('gc_currency',array('Mode' => $id))->result_array();
    if(!empty($data)){
       echo  $data[0]['Value'];
   }else{
       if($id==1){
          echo  75;
      }else{
          echo  70;
      }
  }


}

public function update()
{
    $member = $this->input->post("member");
    $Membership_ID = $this->input->post("Membership_id");
    $Membership_code = $this->input->post("Membership_code");
    $photo = $this->input->post("Photo");
    $address_data = $this->input->post("address_data");
    $nominee_data = $this->input->post("nominee_data");
    $bank_data = $this->input->post("bank_data");


    $events1 = $this->Membership_model->update_membership($member,$address_data,$nominee_data,$bank_data,$photo,$Membership_ID,$Membership_code);

    redirect('membership/Membership/members');

        // var_dump($agreement_data);
}


public function tree_view()
{
    $this->load->model('member/Membership_model');
    $id=$this->input->get('id');
    $template['page']            ='membership/tree_view';
    $template['member']          =  $this->Membership_model->get_parent_detail($id);
        // var_dump($template['member']);die();
    $template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
    $template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
        // var_dump($template['child_parent_binary']);
    $this->load->view('template',$template);
    
}


public function tree_view1()
{
    $this->load->model('member/Membership_model');
    $Membership_ID = $this->input->get("id");
    $template['Membership_code']            =$Membership_ID;
    $template['page']            ='membership/tree_view';
        // $template['member']          =  $this->Membership_model->get_parent_detail($id);
        // // var_dump($template['member']);die();
        // $template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
        // $template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
        // var_dump($template['child_parent_binary']);
    $this->load->view('template',$template);
    
}

public function tabular_tree_view1()
{
    $this->load->model('member/Membership_model');
    $Membership_ID = $this->input->get("id");
    $template['Membership_code']            =$Membership_ID;
    $template['page']            ='membership/tabular_tree_view';
    $this->load->view('template',$template); 
}

public function tree()
{
    $template['page']            ='membership/search_tree_view';
    $this->load->view('template',$template);
}

public function get_topup_list() {

    $invest_type = $this->input->post('invest_type');
    $data = $this->Membership_model->get_all_topup_list_by_invest_type($invest_type,$level_type=1);
    
    if(isset($data)){
        echo '<option value="">Select Top-up</option>';      
        foreach ($data as $value)  {
            echo '<option value="'.$value['ID'].'">'.$value['Franchise'].'</option>'; 
        }}else{
            echo '<option value="">Select Select Top-up</option>';            
        }
    }

    public function get_tree_details()
    {   

        $id = $this->input->post("mobile"); 

        $this->load->model('member/Membership_model');
        $template['member_id']   =  $this->Membership_model->get_member_detailbyid($id);
        $template['member']   =  $this->Membership_model->get_parent_detail($template['member_id'][0]['Membership_ID']);
        if(!empty($template['member'] )){
            $member_refer= $template['member'][0]['Reference_ID'];
            $template['member_refer1']  =  $this->Membership_model->get_parent_referer($member_refer);
            if(!empty($template['member_refer1'])){
                $template['member_refer'] =$template['member_refer1'][0]['Membership_code'];
            }else{
               $template['member_refer'] =0;
           }
       }else{
        $template['member_refer']=0;
    }
      // echo ($template['member'][0]['Membership_code']);
    $template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
    $template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
       // var_dump($template['child_parent_binary']);die();
    $this->load->view('membership/ajax_tree',$template);
}

public function get_tree_details1()
{   

    $id = $this->input->post("mobile"); 

    $this->load->model('member/Membership_model');
    $template['member_id']   =  $this->Membership_model->get_member_detailbyid($id);
    $template['member']   =  $this->Membership_model->get_parent_detail($template['member_id'][0]['Membership_ID']);
    if(!empty($template['member'] )){
        $member_refer= $template['member'][0]['Reference_ID'];
        $template['member_refer1']  =  $this->Membership_model->get_parent_referer($member_refer);
        if(!empty($template['member_refer1'])){
            $template['member_refer'] =$template['member_refer1'][0]['Membership_code'];
        }else{
           $template['member_refer'] =0;
       }
   }else{
    $template['member_refer']=0;
}
      // echo ($template['member'][0]['Membership_code']);
$template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
$template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
       // var_dump($template['child_parent_binary']);die();
$this->load->view('membership/ajax_tree',$template);
}    

public function get_tabular_tree_details()
{   
    ini_set('display_errors', 0);
    $id = $this->input->post("mobile"); 

    $this->load->model('member/Membership_model');
    $template['member_id']   =  $this->Membership_model->get_member_detailbyid($id);
    $template['member']   =  $this->Membership_model->get_parent_detail($template['member_id'][0]['Membership_ID']);
    if(!empty($template['member'] )){
        $member_refer= $template['member'][0]['Reference_ID'];
        $template['member_refer1']  =  $this->Membership_model->get_parent_referer($member_refer);
        if(!empty($template['member_refer1'])){
            $template['member_refer'] =$template['member_refer1'][0]['Membership_code'];
        }else{
           $template['member_refer'] =0;
       }
   }else{
    $template['member_refer']=0;
}
      // echo ($template['member'][0]['Membership_code']);
$template['child_parent']    =  $this->Membership_model->get_child_by_parent($template['member'][0]['Membership_ID']);
$template['child_parent_binary']    =  $this->Membership_model->get_child_by_parent_binary($template['member'][0]['Membership_ID']);
       // var_dump($template['child_parent_binary']);die();
$this->load->view('membership/ajax_tree',$template);
}

public function update_bank_status()
{
    	// extract($_POST);
    	// var_dump($_FILES);die();
    $bank_verify = $this->input->post("bank_verify");
    $Membership_ID = $this->input->post("Membership_ID");
    $Membership_code = $this->input->post('Membership_code');
    $redirect = $this->input->post('redirect');

    if(isset($bank_verify['Status'])){

             	//if($bank_verify['Status']==6){

     if(!empty($_FILES['passbook_upload']['name'])){
        $profile_name = 'passbook_upload';
        $doc_type = 'Passbook';

        $docs_name = $this->Membership_model->member_profile_attachment_1($Membership_code,$profile_name,$doc_type);
        $bank_verify['Document_name']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/'.$docs_name;
    }
             	//}
}

$temp['banks'] =  $this->Membership_model->update_bank_status($bank_verify,$Membership_ID);
        // echo  $temp['banks'];
redirect('membership/Membership/'.$redirect);
}

public function update_document_status()
{
    	// extract($_POST);
    	// var_dump($_POST);die();
    $upload_rows = $this->input->post('upload_rows');
    $Membership_ID = $this->input->post('Membership_ID');
    $Membership_code = $this->input->post('Membership_code');
    $redirect = $this->input->post('redirect');

    $upload_rows=explode(',',$upload_rows);
    foreach($upload_rows as $val){
       $upload_data['doc_verify_'.$val]                  = $this->input->post('doc_verify_'.$val);
       if(isset($upload_data['doc_verify_'.$val]['Status'])){

          if($upload_data['doc_verify_'.$val]['Status']==6){

             if(!empty($_FILES['upload1']['name'])){
                $profile_name = 'upload1';
                $docs_name = $this->Membership_model->member_profile_attachment_1($Membership_code,$profile_name,$upload_data['doc_verify_'.$val]['Document_type']);
                $upload_data['doc_verify_'.$val]['Document_name']=$docs_name;
                $upload_data['doc_verify_'.$val]['File_path']="http://".$_SERVER['HTTP_HOST'].base_url().'attachments/Members/'.$Membership_code.'/';
            }
            
        }

        $temp['docs'] =  $this->Membership_model->update_document_status($upload_data['doc_verify_'.$val],$Membership_ID);
    }
}

redirect('membership/Membership/'.$redirect);
}

public function contract()
{
    $Membership_ID = decrypt($this->input->get("id"));  
    $status = decrypt($this->input->get("status"));
    $template['url'] = $this->input->get("url");
    $template['page']            ='contract/contract';
    $template['Membership_code']            =$Membership_ID;
    $template['automatic_flag']             =1;
    $template['status']                     =$status;
        // var_dump($template);die();
    $this->load->view('template',$template);
}



public function get_member_contents_details(){
    $Membership_code = $this->input->post('Membership_code');
    $type          = $this->input->post('type');
    $this->load->model('member/Membership_model');
    // var_dump($Membership_code);die();
    $template['member'] =  $this->Membership_model->getall_members_by_code($Membership_code);

    if($type=='Profile_tab_details'){
        $template['members'] =  $this->Membership_model->getall_members_by_code($Membership_code);
        $this->load->model('member/Contract_model'); 
        $template['contract'] =  $this->Contract_model->get_contract_details($Membership_code);       
    }
    if($type=='Referal_tab_details'){

        
        $template['content'] = $this->Membership_model->Referal_tab_details($template['member'][0]['Membership_ID']);
        
    }
    if($type=='Investment_tab_details'){

        
        $template['content'] = $this->Membership_model->Investment_tab_details($template['member'][0]['Membership_ID']);
        
    }
    if($type=='Level_benefits_tab_details'){

        $template['content'] = $this->Membership_model->Level_benefits_tab_details($template['member'][0]['Membership_ID']);
        
    }
    if($type=='Level_list_tab_details'){

        $template['content'] = $this->Membership_model->Level_list_tab_details($template['member'][0]['Membership_ID']);
        
    }
    if($type=='Upline_view_tab_details'){

        $template['content'] = $this->Membership_model->Upline_view_tab_details($template['member'][0]['Membership_ID']);
        
    }
    if($type=='Payments_tab_details'){

        $template['content'] = $this->Membership_model->Payments_tab_details($template['member'][0]['Membership_ID']);
        
    }
    // var_dump($template);die();
    $template['Membership_ID']=$template['member'][0]['Membership_ID'];
    $this->load->view('membership/ajax_panel',$template);

}

public function get_member_contents(){
	$Membership_ID = $this->input->post('Membership_ID');
	$type          = $this->input->post('type');
	$this->load->model('member/Membership_model');

   if($type=='Profile_tab_details'){

		// $template['content'] = $this->Membership_model->Profile_tab_details($Membership_ID
    $template['members'] =  $this->Membership_model->getall_members_by_id($Membership_ID);
    // var_dump($template['members']);
    $this->load->model('member/Contract_model'); 
    $template['contract'] =  $this->Contract_model->get_contract_details($template['members'][0]['Membership_code']);		
}
if($type=='Referal_tab_details'){

  
  $template['content'] = $this->Membership_model->Referal_tab_details($Membership_ID);
  
}
if($type=='Investment_tab_details'){

 
  $template['content'] = $this->Membership_model->Investment_tab_details($Membership_ID);
  
}
if($type=='Level_benefits_tab_details'){

  $template['content'] = $this->Membership_model->Level_benefits_tab_details($Membership_ID);
  
}
if($type=='Level_list_tab_details'){

  $template['content'] = $this->Membership_model->Level_list_tab_details($Membership_ID);
  
}
if($type=='Upline_view_tab_details'){

  $template['content'] = $this->Membership_model->Upline_view_tab_details($Membership_ID);
  
}
if($type=='Payments_tab_details'){

  $template['content'] = $this->Membership_model->Payments_tab_details($Membership_ID);
  
}
$template['Membership_ID']=$Membership_ID;
$this->load->view('membership/ajax_panel',$template);

}

public function members_import()
{
        // Upload Function ## Parameter $folder_name
    $file = $this->Upload_model->Upload_excel('Members_data');
        // File Path

    $inputFileName = FCPATH . "attachments/Members_data/".$file;
        // print_r($inputFileName);

        // Process
    
    try {
                //require_once( APPPATH . 'third_party/PHPExcel.php');
        PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
    
    $arrayCount = count($allDataInSheet);
    $flag = 0;
    $createArray = array(
        'First_name',
        'Last_name',
        'Referal_ID',
        'Mobile',
        'Gender',
        'Email',
        'DOB',
        'F_f_name',
        'F_l_name',
        'Address_1',
        'Address_2',
        'Pincode',
        'Nominee_name',
        'Nominee_relationship',
        'Nominee_mobile',
        'Reg_date',
        'Account_holder',
        'Bank_ID',
        'Account_no',
        'Branch',
        'IFSC',
        'Document_no_pan',
        'Document_no_aadhar',
        'Document_no_cheque',
        'Membership_type',
        'Topup_id',
        'Payout_type',
        'Invest_type',
        'Payment_type_ID',
        'Reference_no',
        'Date'
    );

    $makeArray = array(
        'First_name'            => 'First_name',
        'Last_name'             => 'Last_name',
        'Referal_ID'            => 'Referal_ID',
        'Mobile'                => 'Mobile',
        'Gender'                => 'Gender',
        'Email'                 => 'Email',
        'DOB'                   => 'DOB',
        'F_f_name'              => 'F_f_name',
        'F_l_name'              => 'F_l_name',
        'Address_1'             => 'Address_1',
        'Address_2'             => 'Address_2',
        'Pincode'               => 'Pincode',
        'Nominee_name'          => 'Nominee_name',
        'Nominee_relationship'  => 'Nominee_relationship',
        'Nominee_mobile'        => 'Nominee_mobile',
        'Reg_date'              => 'Reg_date',
        'Account_holder'        => 'Account_holder',
        'Bank_ID'               => 'Bank_ID',
        'Account_no'            => 'Account_no',
        'Branch'                => 'Branch',
        'IFSC'                  => 'IFSC',
        'Document_no_pan'       => 'Document_no_pan',
        'Document_no_aadhar'    => 'Document_no_aadhar',
        'Document_no_cheque'    => 'Document_no_cheque',
        'Membership_type'       => 'Membership_type',
        'Topup_id'              => 'Topup_id',
        'Payout_type'           => 'Payout_type',
        'Invest_type'           => 'Invest_type',
        'Payment_type_ID'       => 'Payment_type_ID',
        'Reference_no'          => 'Reference_no',
        'Date'                  => 'Date'
    );
    
    $SheetDataKey = array();

    foreach ($allDataInSheet as $dataInSheet) {
        foreach ($dataInSheet as $key => $value) {
            if (in_array(trim($value), $createArray)) {
                $value = preg_replace('/\s+/', '', $value);
                $SheetDataKey[trim($value)] = $key;
            } else {
                
            }
        }
    }
    
    $data = array_diff_key($makeArray, $SheetDataKey);
            // var_dump($data);
    
    if (empty($data)) {
        $flag = 1;
    }

    if ($flag == 1) {
        for ($i = 2; $i <= $arrayCount; $i++) {
                    // $cus_code = $this->Customer_model->get_prefix();
                    // $incre_id = $this->Customer_model->get_increment_code();
            $fetchData[$i]  = array(
                'First_name'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['First_name']]), FILTER_SANITIZE_STRING),
                'Last_name'             => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Last_name']]), FILTER_SANITIZE_STRING),
                'Referal_ID'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Referal_ID']]), FILTER_SANITIZE_STRING),
                'Mobile'                => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Mobile']]), FILTER_SANITIZE_STRING),
                'Gender'                => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Gender']]), FILTER_SANITIZE_STRING),
                'Email'                 => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Email']]), FILTER_SANITIZE_STRING),
                'DOB'                   => filter_var(trim($allDataInSheet[$i][$SheetDataKey['DOB']]), FILTER_SANITIZE_STRING),
                'F_f_name'              => filter_var(trim($allDataInSheet[$i][$SheetDataKey['F_f_name']]), FILTER_SANITIZE_STRING),
                'F_l_name'              => filter_var(trim($allDataInSheet[$i][$SheetDataKey['F_l_name']]), FILTER_SANITIZE_STRING),
                'Address_1'             => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Address_1']]), FILTER_SANITIZE_STRING),
                'Address_2'             => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Address_2']]), FILTER_SANITIZE_STRING),
                'Pincode'               => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Pincode']]), FILTER_SANITIZE_STRING),
                'Nominee_name'          => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Nominee_name']]), FILTER_SANITIZE_STRING),
                'Nominee_relationship'  => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Nominee_relationship']]), FILTER_SANITIZE_STRING),
                'Nominee_mobile'        => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Nominee_mobile']]), FILTER_SANITIZE_STRING),
                'Reg_date'              => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Reg_date']]), FILTER_SANITIZE_STRING),
                'Account_holder'        => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Account_holder']]), FILTER_SANITIZE_STRING),
                'Bank_ID'               => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Bank_ID']]), FILTER_SANITIZE_STRING),
                'Account_no'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Account_no']]), FILTER_SANITIZE_STRING),
                'Branch'                => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Branch']]), FILTER_SANITIZE_STRING),
                'IFSC'                  => filter_var(trim($allDataInSheet[$i][$SheetDataKey['IFSC']]), FILTER_SANITIZE_STRING),
                'Document_no_pan'       => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Document_no_pan']]), FILTER_SANITIZE_STRING),
                'Document_no_aadhar'    => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Document_no_aadhar']]), FILTER_SANITIZE_STRING),
                'Document_no_cheque'    => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Document_no_cheque']]), FILTER_SANITIZE_STRING),
                'Membership_type'       => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Membership_type']]), FILTER_SANITIZE_STRING),
                'Topup_id'              => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Topup_id']]), FILTER_SANITIZE_STRING),
                'Payout_type'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Payout_type']]), FILTER_SANITIZE_STRING),
                'Invest_type'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Invest_type']]), FILTER_SANITIZE_STRING),
                'Payment_type_ID'       => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Payment_type_ID']]), FILTER_SANITIZE_STRING),
                'Reference_no'          => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Reference_no']]), FILTER_SANITIZE_STRING),
                'Date'                  => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Date']]), FILTER_SANITIZE_STRING),

            );
                    //$result = $this->Customer_model->adding_customers($fetchData[$i]);
// var_dump($fetchData[$i]);
$result =  $this->Membership_model->adding_excel_data($fetchData[$i]);
                   // die();
}

} else {
    echo "Please import correct file";
}
}

public function members_import1()
{
        // Upload Function ## Parameter $folder_name
    $file = $this->Upload_model->Upload_excel('Members_data');
        // File Path

    $inputFileName = FCPATH . "attachments/Members_data/".$file;
        // print_r($inputFileName);

        // Process
    
    try {
                //require_once( APPPATH . 'third_party/PHPExcel.php');
        PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
    
    $arrayCount = count($allDataInSheet);
    $flag = 0;
    $createArray = array(
        'First_name',
        'Last_name',
        'Referal_ID',
        'Mobile',
        'Gender',
        'Email',
        'DOB',
        'F_f_name',
        'F_l_name',
        'Address_1',
        'Address_2',
        'Pincode',
        'Nominee_name',
        'Nominee_relationship',
        'Nominee_mobile',
        'Reg_date',
        'Account_holder',
        'Bank_ID',
        'Account_no',
        'Branch',
        'IFSC',
        'Document_no_pan',
        'Document_no_aadhar',
        'Document_no_cheque',
        'Membership_type',
        'Topup_id',
        'Topup',
        'Commission_mode',
        'Payout_type',
        'Invest_type',
        'Payment_type_ID',
        'Reference_no',
        'Date'
    );

    $makeArray = array(
        'First_name'            => 'First_name',
        'Last_name'             => 'Last_name',
        'Referal_ID'            => 'Referal_ID',
        'Mobile'                => 'Mobile',
        'Gender'                => 'Gender',
        'Email'                 => 'Email',
        'DOB'                   => 'DOB',
        'F_f_name'              => 'F_f_name',
        'F_l_name'              => 'F_l_name',
        'Address_1'             => 'Address_1',
        'Address_2'             => 'Address_2',
        'Pincode'               => 'Pincode',
        'Nominee_name'          => 'Nominee_name',
        'Nominee_relationship'  => 'Nominee_relationship',
        'Nominee_mobile'        => 'Nominee_mobile',
        'Reg_date'              => 'Reg_date',
        'Account_holder'        => 'Account_holder',
        'Bank_ID'               => 'Bank_ID',
        'Account_no'            => 'Account_no',
        'Branch'                => 'Branch',
        'IFSC'                  => 'IFSC',
        'Document_no_pan'       => 'Document_no_pan',
        'Document_no_aadhar'    => 'Document_no_aadhar',
        'Document_no_cheque'    => 'Document_no_cheque',
        'Membership_type'       => 'Membership_type',
        'Topup_id'              => 'Topup_id',
        'Topup'                 => 'Topup',
        'Commission_mode'       => 'Commission_mode',
        'Payout_type'           => 'Payout_type',
        'Invest_type'           => 'Invest_type',
        'Payment_type_ID'       => 'Payment_type_ID',
        'Reference_no'          => 'Reference_no',
        'Date'                  => 'Date'
    );
    
    $SheetDataKey = array();

    foreach ($allDataInSheet as $dataInSheet) {
        foreach ($dataInSheet as $key => $value) {
            if (in_array(trim($value), $createArray)) {
                $value = preg_replace('/\s+/', '', $value);
                $SheetDataKey[trim($value)] = $key;
            } else {
                
            }
        }
    }
    
    $data = array_diff_key($makeArray, $SheetDataKey);
            // var_dump($data);
    
    if (empty($data)) {
        $flag = 1;
    }

    if ($flag == 1) {
        for ($i = 2; $i <= $arrayCount; $i++) {
                    // $cus_code = $this->Customer_model->get_prefix();
                    // $incre_id = $this->Customer_model->get_increment_code();
            $fetchData[$i]  = array(
                'First_name'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['First_name']]), FILTER_SANITIZE_STRING),
                'Last_name'             => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Last_name']]), FILTER_SANITIZE_STRING),
                'Referal_ID'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Referal_ID']]), FILTER_SANITIZE_STRING),
                'Mobile'                => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Mobile']]), FILTER_SANITIZE_STRING),
                'Gender'                => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Gender']]), FILTER_SANITIZE_STRING),
                'Email'                 => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Email']]), FILTER_SANITIZE_STRING),
                'DOB'                   => filter_var(trim($allDataInSheet[$i][$SheetDataKey['DOB']]), FILTER_SANITIZE_STRING),
                'F_f_name'              => filter_var(trim($allDataInSheet[$i][$SheetDataKey['F_f_name']]), FILTER_SANITIZE_STRING),
                'F_l_name'              => filter_var(trim($allDataInSheet[$i][$SheetDataKey['F_l_name']]), FILTER_SANITIZE_STRING),
                'Address_1'             => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Address_1']]), FILTER_SANITIZE_STRING),
                'Address_2'             => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Address_2']]), FILTER_SANITIZE_STRING),
                'Pincode'               => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Pincode']]), FILTER_SANITIZE_STRING),
                'Nominee_name'          => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Nominee_name']]), FILTER_SANITIZE_STRING),
                'Nominee_relationship'  => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Nominee_relationship']]), FILTER_SANITIZE_STRING),
                'Nominee_mobile'        => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Nominee_mobile']]), FILTER_SANITIZE_STRING),
                'Reg_date'              => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Reg_date']]), FILTER_SANITIZE_STRING),
                'Account_holder'        => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Account_holder']]), FILTER_SANITIZE_STRING),
                'Bank_ID'               => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Bank_ID']]), FILTER_SANITIZE_STRING),
                'Account_no'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Account_no']]), FILTER_SANITIZE_STRING),
                'Branch'                => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Branch']]), FILTER_SANITIZE_STRING),
                'IFSC'                  => filter_var(trim($allDataInSheet[$i][$SheetDataKey['IFSC']]), FILTER_SANITIZE_STRING),
                'Document_no_pan'       => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Document_no_pan']]), FILTER_SANITIZE_STRING),
                'Document_no_aadhar'    => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Document_no_aadhar']]), FILTER_SANITIZE_STRING),
                'Document_no_cheque'    => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Document_no_cheque']]), FILTER_SANITIZE_STRING),
                'Membership_type'       => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Membership_type']]), FILTER_SANITIZE_STRING),
                'Topup_id'              => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Topup_id']]), FILTER_SANITIZE_STRING),
                'Topup'                 => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Topup']]), FILTER_SANITIZE_STRING),
                'Commission_mode'        => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Commission_mode']]), FILTER_SANITIZE_STRING),
                'Payout_type'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Payout_type']]), FILTER_SANITIZE_STRING),
                'Invest_type'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Invest_type']]), FILTER_SANITIZE_STRING),
                'Payment_type_ID'       => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Payment_type_ID']]), FILTER_SANITIZE_STRING),
                'Reference_no'          => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Reference_no']]), FILTER_SANITIZE_STRING),
                'Date'                  => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Date']]), FILTER_SANITIZE_STRING),

            );
                    //$result = $this->Customer_model->adding_customers($fetchData[$i]);
// var_dump($fetchData[$i]);
$result =  $this->Membership_model->adding_excel_data1($fetchData[$i]);
                   // die();
}

} else {
    echo "Please import correct file";
}
}

public function members_surety_import()
{
        // Upload Function ## Parameter $folder_name
    $file = $this->Upload_model->Upload_excel('Members_data');
        // File Path

    $inputFileName = FCPATH . "attachments/Members_data/".$file;
        // print_r($inputFileName);

        // Process
    
    try {
                //require_once( APPPATH . 'third_party/PHPExcel.php');
        PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
    
    $arrayCount = count($allDataInSheet);
    $flag = 0;
    $createArray = array(
       'S_no',
       'Membership_code',
       'First_name',
       'Amount',
       'Cheque_no',
       'Cheque_date',
       'Bank_ID',
       'Mobile'
   );

    $makeArray = array(
       'S_no',
       'Membership_code',
       'First_name',
       'Amount',
       'Cheque_no',
       'Cheque_date',
       'Bank_ID',
       'Mobile'
   );
    
    $SheetDataKey = array();

    foreach ($allDataInSheet as $dataInSheet) {
        foreach ($dataInSheet as $key => $value) {
            if (in_array(trim($value), $createArray)) {
                $value = preg_replace('/\s+/', '', $value);
                $SheetDataKey[trim($value)] = $key;
            } else {
                
            }
        }
    }
            // var_dump($makeArray);
            // var_dump($SheetDataKey);
    
    $data = array_diff_key($makeArray, $SheetDataKey);
            // var_dump($data);
    
    if (empty($data)) {
        $flag = 1;
    }
            // var_dump($allDataInSheet[2][$SheetDataKey['Membership_code']]);

            // if ($flag == 1) {
    for ($i = 2; $i <= $arrayCount; $i++) {
                    // $cus_code = $this->Customer_model->get_prefix();
                    // $incre_id = $this->Customer_model->get_increment_code();
        $fetchData[$i]  = array(
          'S_no'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['S_no']]), FILTER_SANITIZE_STRING),
          'Membership_code'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Membership_code']]), FILTER_SANITIZE_STRING),
          'First_name'             => filter_var(trim($allDataInSheet[$i][$SheetDataKey['First_name']]), FILTER_SANITIZE_STRING),
          'Amount'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Amount']]), FILTER_SANITIZE_STRING),
          'Cheque_no'                => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Cheque_no']]), FILTER_SANITIZE_STRING),
          'Cheque_date'                => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Cheque_date']]), FILTER_SANITIZE_STRING),
          'Bank_ID'                 => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Bank_ID']]), FILTER_SANITIZE_STRING),
          'Mobile'            => filter_var(trim($allDataInSheet[$i][$SheetDataKey['Mobile']]), FILTER_SANITIZE_STRING),

      );
                    //$result = $this->Customer_model->adding_customers($fetchData[$i]);
// var_dump($fetchData[$i]);die();
        $result =  $this->Membership_model->adding_surety_excel($fetchData[$i]);
                   // die();
    }
    
            // } else {
            //     echo "Please import correct file";
            // }
}
public function Activate_member1()
{
    $member = $this->db->get_where('gc_membership', array('Status' => 4))->result_array();
        // echo '<pre>';
        // print_r($member);die();
    foreach($member as $val){
        $contract = $this->db->get_where('gc_member_franchisee_contract', array('Membership_ID' => $val['Membership_ID']))->result_array();

        foreach($contract as $con){

            $result =  $this->Membership_model->Activate_member_contract1($val['Membership_ID'],$con['Contract_ID']);
        }
    }

    
        // echo $result;
}


public function Activate_member2()
{
        // $member = $this->db->get_where('gc_membership', array('Status' => 4,'Created_date<' =>'2019-05-15'))->result_array();
    $member = $this->db->where('Status',3)->get('gc_membership')->result_array();
        // echo '<pre>';
        // print_r($member);die();
    foreach($member as $val){
        $contract = $this->db->get_where('gc_member_franchisee_contract', array('Membership_ID' => $val['Membership_ID']))->result_array();

        if(!empty( $contract)){
           foreach($contract as $con){

            $result =  $this->Membership_model->Activate_member_contract2($val['Membership_ID'],$con['Contract_ID'],$con['Invest_type']);
        }
    }else{

        	// if($val['Register_from']=='member'){
      $wallet_topup = $this->db->get_where('gc_wallet_topup', array('Membership_ID' => $val['Membership_ID'],'Status' =>1))->result_array();
        		// var_dump($wallet_topup);die();
      if(!empty($wallet_topup)){
         $result=$this->Membership_model->Activate_member_contract_by_wallet($wallet_topup);
     }


        	// }else{
        		// $result =  $this->Membership_model->Activate_member_contract2($val['Membership_ID'],$Contract_ID='',$invest_type='');
        	// }
     
     
 }

 
        // echo $result;
}
}


public function Activate_member()
{
    $Membership_ID = $this->input->post("Membership_ID");  
    $Contract_ID = $this->input->post("Contract_ID");
    $Commission_mode = $this->input->post("Commission_mode");
    $cmsn_per = $this->input->post("cmsn_per");
    $Memberhip_type = $this->input->post("Memberhip_type");
    $Membership_payout = $this->input->post("Membership_payout");

    $result =  $this->Membership_model->Activate_member_contract($Membership_ID,$Contract_ID,$Commission_mode,$cmsn_per,$Memberhip_type,$Membership_payout);
    echo $result;
}

public function block_member()
{
    $Membership_ID = $this->input->post("Membership_ID");  
    $reason = $this->input->post("reason");
    $result =  $this->Membership_model->block_member_contract($Membership_ID,$reason);
    echo $result;
}



public function sms()
{
    $mobile="8122325955";
    $sms_content="Hi Satheesh I Love U...";
    $sms_url='http://bulksmscoimbatore.co.in/sendsms?uname=mequals&pwd=mequals@123&senderid=BUGFIX&to='.$mobile.'&msg='.urlencode($sms_content).'&route=SID';

    $ch = curl_init($sms_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $sms_url);
    $response=curl_exec($ch);
                // curl_close($ch);

    if (curl_errno($ch)) {
        $error = curl_error($ch);
    }
    $curl_data = explode(',', $response);
    curl_close($ch);
}   

public function check()
{   
    $Membership_ID=5373;
    $membership[0]['Reference_ID']=6;
    $level['Level_ID']=1;
    $Contract_ID=16;
    $this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return');
    $this->db->from('gc_member_level_details as level');
    $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$Contract_ID, 'left');
    $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
    $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
    $this->db->where('level.Child_ID',$Membership_ID);
    $this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
    $this->db->where('level.Level_ID',$level['Level_ID']);
    $query= $this->db->get();
    $level_details=$query->result_array();
    var_dump($level_details);
}

// public function generatePIN($digits = 4){
//     $i = 0; //counter
//     $pin = ""; //our default pin is blank.
//     while($i < $digits){
//         //generate a random number between 0 and 9.
//         $pin .= mt_rand(0, 9);
//         $i++;
//     }
//     return $pin;
// }

public function check1() {
    $this->db->select('Weeks');
    $this->db->where('Status',1);
    $this->db->where('ID',2);
    $query = $this->db->get('gc_leveltype');
    if ($query->num_rows() > 0) {
        $days=$query->result_array();
        $week_days=explode(',',$days[0]['Weeks']);
        $final_days=[];
        $final_days1=[];
        foreach($week_days as $value){
            $new = [];
            for($i = 1;$i<=12;$i++){
                $days = $this->getDays(date('Y'),$i,$value);
                $final[] = $days;
                foreach($days as $val){
                    array_push($final_days,$val);
                }
                
            }
            
                // array_push($final_days)
        }
        var_dump($final_days);


            //echo date('Y-n-j');
        if(in_array(date('Y-n-j'), $final_days)){
                //echo "irukku";
            $this->db->where('Date',date('Y-m-d'));
            $query = $this->db->get('gc_individual_calendar');
            if ($query->num_rows() > 0) {
                //echo "not insert";
                //echo "illa";
            }else{
                //echo "irukku1";
               // echo $new_date=array_search(date('Y-n-j'), $final_days)-1;
               // $first_date=date('Y-m-d');

               // date('Y-m-d', strtotime("+3 months", strtotime($effectiveDate)));

               // date("Y-m-d", strtotime('+'.$i.' Monday' ,strtotime($first_date)));

               // array_push($new,date("Y-m-d", strtotime('+'.$i.' Monday')));
            }

        }

    }
}

public function get_advance_date(){
    $ad_days=0;
    $cur_date=date('2019-01-10');
    $this->db->select('Weeks');
    $this->db->where('Status',1);
    $this->db->where('ID',1);
    $query = $this->db->get('gc_leveltype');
    if ($query->num_rows() > 0) {
        $days=$query->result_array();
        $week_days=explode(',',$days[0]['Weeks']);
            //var_dump($week_days);
        $date=new DateTime();
        $year=date('Y');
        $date->setDate($year, 01, 01);
        $dt = $date->format('Y-m-d');
        $day=date('l', strtotime($dt));
        $search =date('N', strtotime($day));

        $arr = [];
        $arr2 = [];

        for ($i=0 ;$i < count($week_days); $i++) {

            if($week_days[$i] == $search){
                $arr[$i] = $week_days[$i];
                $search = $week_days[$i] + 1;
            }else{
                $arr2[$i] = $week_days[$i];
            }
        }

        $action = array_merge($arr,$arr2);
        $days = array(
           '1' => 'Monday',
           '2' => 'Tuesday',
           '3' => 'Wednesday',
           '4' => 'Thursday',
           '5' => 'Friday',
           '6' => 'Saturday',
           '7' => 'Sunday'
       );
        $final_dt=[];

        foreach($action as $da){
            if (array_key_exists($da,$days))
            {
              array_push($final_dt,$days[$da]);
          }

      }

//var_dump($final_dt);
      $final_dates=[];
      for($i=1; $i<=52; $i++){
        foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
            array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
        }
    }
    $cur_date=date("Y-m-d", strtotime($cur_date));
    
    //var_dump($final_dates);
    foreach($final_dates as $key=> $fin){
        if($cur_date < $fin){
            $keyval= $key+$ad_days;
            if(isset($final_dates[$keyval])){
                echo  $final_dates[$keyval];
            }else{
                echo date('Y-01-01');
            }
            
            break;
        }else{
            $keyval=$key;
            $final_dates[$keyval];
        }
    }
    //echo $serch_date=$final_dates[$keyval];
}

}

public function getDays($y,$m,$d){ 
    $date = "$y-$m-1";
    $first_day = date('N',strtotime($date));
    $first_day = $d - $first_day + 1;
    $last_day =  date('t',strtotime($date));
    $days = array();
    for($i=$first_day; $i<=$last_day; $i=$i+7 ){
        $days[] = $y.'-'.$m.'-'.$i;
        //$days[] = implode(',',$days);
    }
    return $days;
}

public function check3() {

    $date=new DateTime();
    $year=date('Y');
    $date->setDate($year, 01, 01);
    $dt = $date->format('Y-m-d');
    $day=date('l', strtotime($dt));
    $day_of_week = date('N', strtotime($day));

    $this->db->select('Weeks');
    $this->db->where('Status',1);
    $this->db->where('ID',2);
    $query = $this->db->get('gc_leveltype');
    if ($query->num_rows() > 0) {
        $days=$query->result_array();
        $week_days=explode(',',$days[0]['Weeks']);
        $arr1=[];
        $arr2=[];
        foreach($week_days as $wk){
            if($day_of_week==$wk){

            }
        }
    }
}


function check5(){
    $date=new DateTime();
    $year=date('Y');
    $date->setDate($year, 01, 01);
    $dt = $date->format('Y-m-d');
    $day=date('l', strtotime($dt));
    $day_of_week = date('N', strtotime($day));

    $new=[];
    $new1=['Tuesday','Wednesday','Thursday','Friday','Monday',];
    $new2=['1'=>'Tuesday','2'=>'Wednesday','3'=>'Thursday','4'=>'Friday','5'=>'Monday',];
    $first_date=date('Y-01-01');
//$count=count();
    for($i=1; $i<=52; $i++){
        
        foreach($new2 as $key=> $newval){
          
            echo  date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($first_date))).'<br>';
        }

         //foreach($new2 as $key=> $newval){
        
        //echo  date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($first_date))).'<br>';
        
       // }
    //}
        
    }
}

public function check6(){
    $this->db->select('Weeks');
    $this->db->where('Status',1);
    $this->db->where('ID',1);
    $query = $this->db->get('gc_leveltype');
    if ($query->num_rows() > 0) {
        $days=$query->result_array();
        $week_days=explode(',',$days[0]['Weeks']);
            //var_dump($week_days);
        $date=new DateTime();
        $year=date('Y');
        $date->setDate($year, 01, 01);
        $dt = $date->format('Y-m-d');
        $day=date('l', strtotime($dt));
        $search =date('N', strtotime($day));

        $arr = [];
        $arr2 = [];

        for ($i=0 ;$i < count($week_days); $i++) {

            if($week_days[$i] == $search){
                $arr[$i] = $week_days[$i];
                $search = $week_days[$i] + 1;
            }else{
                $arr2[$i] = $week_days[$i];
            }
        }

        $action = array_merge($arr,$arr2);
        $days = array(
           '1' => 'Monday',
           '2' => 'Tuesday',
           '3' => 'Wednesday',
           '4' => 'Thursday',
           '5' => 'Friday',
           '6' => 'Saturday',
           '7' => 'Sunday'
       );
        $final_dt=[];

        foreach($action as $da){
            if (array_key_exists($da,$days))
            {
              array_push($final_dt,$days[$da]);
          }

      }

//var_dump($final_dt);
      $final_dates=[];
      for($i=1; $i<=52; $i++){
        foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
            array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
        }
    }
    foreach($final_dates as $key=> $fin){
        if(date('Y-m-d')==$fin){
            $keyval= $key-1;
        }
    }
    return $serch_date=$final_dates[$keyval];
}
}

public function check7(){
    $this->db->select('Weeks');
    $this->db->where('Status',1);
    $this->db->where('ID',1);
    $query = $this->db->get('gc_leveltype');
    if ($query->num_rows() > 0) {
        $days=$query->result_array();
        $week_days=explode(',',$days[0]['Weeks']);
        $final_days=[];
        $final_days1=[];
        
        $date=new DateTime();
        $year=date('Y');
        $date->setDate($year, 01, 01);
        $dt = $date->format('Y-m-d');
        $day=date('l', strtotime($dt));
        $search =date('N', strtotime($day));

        $arr = [];
        $arr2 = [];

        for ($i=0 ;$i < count($week_days); $i++) {

            if($week_days[$i] == $search){
                $arr[$i] = $week_days[$i];
                $search = $week_days[$i] + 1;
            }else{
                $arr2[$i] = $week_days[$i];
            }
        }

        $action = array_merge($arr,$arr2);
        $days = array(
           '1' => 'Monday',
           '2' => 'Tuesday',
           '3' => 'Wednesday',
           '4' => 'Thursday',
           '5' => 'Friday',
           '6' => 'Saturday',
           '7' => 'Sunday'
       );
        $final_dt=[];
        foreach($action as $da){
            if (array_key_exists($da,$days))
            {
              array_push($final_dt,$days[$da]);
          }

      }

//var_dump($final_dt);
      $final_dates=[];
      for($i=1; $i<=52; $i++){
        foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
            array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
        }
    }
    //var_dump($final_dates);


    if(in_array(date('Y-m-d'), $final_dates)){

        $this->db->where('Date',date('Y-m-d'));
        $query = $this->db->get('gc_individual_calendar');
        if ($query->num_rows() > 0) {
                //echo "not insert";
        }else{
         
                // Get Transaction Tabl
            $this->db->select('transaction.*');
            $this->db->from('gc_transaction as transaction');
            $this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');

            $this->db->where('transaction.Transaction_status',1);
            $this->db->where('member.Status',6);
            $this->db->where('contract.Withdrawn_status',5);
            $query1 = $this->db->get();
            if ($query1->num_rows() > 0) {
                $transaction=$query1->result_array();
                    // var_dump($final_days);die();
                foreach($transaction as $tran){

                    $commision_data=array(
                        'Company_id'       => $this->session->userdata('CompanyId'),
                        'Branch_id'        => $this->session->userdata('CompanyId'),
                        'Transaction_ID'   => $tran['Transaction_ID'],
                        'Membership_ID'    => $tran['Membership_ID'], 
                        'Contract_ID'      => $tran['Contract_ID'], 
                        'Transaction_type' => $tran['Transaction_ID'],
                        'Commision_date'  => date('Y-m-d'), 
                        'Remarks'          => '', 
                        'Created_by'       => $this->session->userdata('UserId')
                    );
                    $this->db->insert('gc_member_commission',$commision_data);
                    $commision_id=$this->db->insert_id();

                    // Get Transaction detail Table
                    $this->db->select('*');
                    $this->db->where('Status',1);
                    $this->db->where('Transaction_ID',$tran['Transaction_ID']);
                    $query2 = $this->db->get('gc_transaction_details');
                    if ($query2->num_rows() > 0) {
                        $transaction_detail=$query2->result_array();
                        foreach($transaction_detail as $tran_det){
                            $commision_detail_data=array(
                                'Company_id'               => $this->session->userdata('CompanyId'),
                                'Branch_id'                => $this->session->userdata('CompanyId'),
                                'Commission_ID'            => $commision_id,
                                'Transaction_ID'           => $tran_det['Transaction_ID'],
                                'Transaction_detail_ID'    => $tran_det['Transaction_detail_ID'],
                                'Member_level_detail_ID'   => $tran_det['Member_level_detail_ID'],
                                'Membership_ID'            => $tran_det['Membership_ID'], 
                                'Contract_ID'              => $tran_det['Contract_ID'], 
                                'Commision_type'           => $tran_det['Commision_type'],
                                'Payout_ID'                => $tran_det['Payout_ID'],
                                'Commision_date'           => date('Y-m-d'), 
                                'Amount'                   => $tran_det['Amount'], 
                                'Commision'                => $tran_det['Commision'],
                                'Remarks'                  => '', 
                                'Created_by'               => $this->session->userdata('UserId')
                            );
                            $this->db->insert('gc_member_commission_details',$commision_detail_data);

                        }

                    }
                }

            }
        }

    }

}

}
public function check10(){
    $level_counts=[];
    $grade_ids=[];
    for($j=1;$j<=9;$j++){
        $this->db->where('Membership_ID',1);
        $this->db->where('Level_ID',$j);
        $mem_counts =  $this->db->count_all_results('gc_member_levels');
        $level_counts['Level_'.$j]=$mem_counts;
    }
            //var_dump($level_counts);
    $this->db->select('*');
    $this->db->where('Status',1);
    $query =  $this->db->get('gc_grade');
    if($query->num_rows() > 0) {
        $grade=$query->result_array();

        foreach($grade as $gradevals){
            foreach($level_counts as $lvl){
                $array=[];
                $a=0;

                if($lvl['Level_1'] >= $gradevals['Level_1_count']){
                  $array[$a]=1;
              }else{
                  $array[$a]=0;
              }
              $a++;
              if($lvl['Level_2'] >= $gradevals['Level_2_count']){
                  $array[$a]=1;
              }else{
                  $array[$a]=0;
              }
              $a++;
              if($lvl['Level_3'] >= $gradevals['Level_3_count']){
                  $array[$a]=1;
              }else{
                  $array[$a]=0;
              }
              $a++;
              if($lvl['Level_4'] >= $gradevals['Level_4_count']){
                  $array[$a]=1;
              }else{
                  $array[$a]=0;
              }
              $a++;
              if($lvl['Level_5'] >= $gradevals['Level_5_count']){
                  $array[$a]=1;
              }else{
                  $array[$a]=0;
              }
              $a++;
              if($lvl['Level_6'] >= $gradevals['Level_6_count']){
                  $array[$a]=1;
              }else{
                  $array[$a]=0;
              }
              $a++;
              if($lvl['Level_7'] >= $gradevals['Level_7_count']){
                  $array[$a]=1;
              }else{
                  $array[$a]=0;
              }
              $a++;
              if($lvl['Level_8'] >= $gradevals['Level_8_count']){
                  $array[$a]=1;
              }else{
                  $array[$a]=0;
              }
              $a++;
              if($lvl['Level_9'] >= $gradevals['Level_9_count']){
                  $array[$a]=1;
              }else{
                  $array[$a]=0;
              }
              $a++;

              $check=in_array(1, $array) < 0;
              if($check==true){
                array_push($grade_ids,$gradevals['ID']);
      //echo 'insert'.'<br>';
            }
            else{
  //echo 'do nothing'.'<br>';
            }
        }
    }
                //var_dump($grade_ids);
    if(!empty($grade_ids)){
        $this->db->select('ID,min(Grade_level) as Grade_level');
        $this->db->where('Status',1);
        $this->db->where_in('ID',$grade_ids);
        $least=$this->db->get('gc_grade');
        if($least->num_rows() > 0) {
         $least_c=$least->row();
         $inserting_grade=$least_c->ID;
         $membership_data['Member_grade']=$inserting_grade;
         $this->db->where('Membership_ID',1);
         $this->db->update('gc_membership',$membership_data);
     }
 }

}
}

function check21(){
    $this->db->select('min(member.Membership_ID) as Membership_ID,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
    $this->db->from('gc_membership as member');
    $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = member.Membership_ID', 'left');
    $query_member = $this->db->get();
    if ($query_member->num_rows() > 0) {
        $root_member=$query_member->result_array();
        $root_id=$root_member[0]['Membership_ID'];
        $root_contract=$root_member[0]['Contract_ID'];
        if($root_member[0]['Payout_status']==2){
            $root_payout_id=$root_member[0]['New_payout_ID'];
        }else{
            $root_payout_id=$root_member[0]['Old_payout_ID'];
        }
    }
}


function check50(){

            //echo $limit=$this->db->count_all_results('gc_binary_member_relation');

    $limit=1;
    $p_type=1;
    $Ex_position_type=1;
    $parent_id=101;
    for($i=1;$i<=$limit;$i++){
        $this->db->select('*');
        $this->db->where('Position_type',$p_type);
        $this->db->where('Ex_position_type',$Ex_position_type);
        $this->db->where('Parent_ID',$parent_id);
        $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
        $query4 = $this->db->get('gc_binary_member_relation');
        if($query4->num_rows() > 0){
            $binary4=$query4->result_array();
            echo $parent_id=$binary4[0]['Child_ID'].'<br>';
            $limit++;
        }

    }
    echo $parent_id;

}

function check51(){
    $binary_relation['Child_ID']        = 239;
    $binary_relation['Level_type_ID']   = 2;
    $binary_relation['Refer_parent_ID']   = 209;
    $binary_relation['Position']   = 4;
    $parent_id=$binary_relation['Refer_parent_ID'];
            if($binary_relation['Position'] % 2 == 0){ // determination if Start
                // echo 'right';
               $p_type=2;
               $determin = 2;
               if($parent_id==1){
                    // echo 'right';
                $Ex_position_type=2;
            }
            else{
                $this->db->select('*');
                $this->db->where('Child_ID',$parent_id);
                $query = $this->db->get('gc_binary_member_relation');
                $binary=$query->result_array();
                $Ex_position_type=$binary[0]['Ex_position_type'];
            }

                }  // determination if End

            else{  // determination else Start
                // echo 'left';
                $p_type=1;
                $determin = 1;
                if($parent_id==1){
                    // echo 'left';
                    $Ex_position_type=1;
                }
                else{
                    $this->db->select('*');
                    $this->db->where('Child_ID',$parent_id);
                    $query = $this->db->get('gc_binary_member_relation');
                    $binary=$query->result_array();
                    $Ex_position_type=$binary[0]['Ex_position_type'];
                }
            } // determination else End

            $limit=1;
            for($i=1;$i<=$limit;$i++){
                $this->db->select('*');
                $this->db->where('Position_type',$p_type);
                $this->db->where('Ex_position_type',$Ex_position_type);
                $this->db->where('Parent_ID',$parent_id);
                $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
                $query4 = $this->db->get('gc_binary_member_relation');
                if($query4->num_rows() > 0){
                    $binary4=$query4->result_array();
                    echo  $parent_id=$binary4[0]['Child_ID'].'<br>';
                    $limit++;
                }
                
            }
            
            $binary_relation['Determination']   = $determin;
            $binary_relation['Position_type']   = $p_type;
            $binary_relation['Ex_position_type']   = $Ex_position_type;
            $binary_relation['Parent_id']    =  $parent_id;
            $binary_relation['Company_id']   =  1;
            $binary_relation['Branch_id']    =  1;
            $binary_relation['Date']   = '';
            var_dump($binary_relation);die();
            $this->db->insert('gc_binary_member_relation', $binary_relation);
        }

        function check52(){
            //echo $this->random_strings(10);
            //$this->load->helper('string');
         echo random_string('alnum',10);
     }

     function random_strings($length_of_string) { 
        $this->load->helper('string');
        return substr(bin2hex(random_bytes($length_of_string)),0, $length_of_string); 

    }

    function check53(){
        $this->db->select('transaction.*,contract.Payment_status_date,contract.Contract_ID,member.Members_count');
        $this->db->from('gc_transaction as transaction');
        $this->db->join('gc_membership as member', 'member.Membership_ID = transaction.Membership_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = transaction.Contract_ID', 'left');
        $this->db->join('gc_transaction_details as t_det', 't_det.Transaction_ID = transaction.Transaction_ID', 'left');

        $this->db->where('transaction.Transaction_status',1);
        $this->db->where('member.Status',6);
        $this->db->where('contract.Withdrawn_status',5);
        $this->db->where('member.Membership_ID',1);

        $this->db->group_by('t_det.Transaction_ID');
                // $this->db->where('transaction.Transaction_date <=',date('Y-m-d',strtotime($previous_trading)));
        $query1 = $this->db->get();
        $members=$query1->result_array();
                //var_dump($members);




        $this->db->select('sum(topup.Value) as Volume');
    // $this->db->select('level.Child_ID');
        $this->db->from('gc_member_level_details as level');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level.Child_ID', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = level.Child_ID', 'left');
        $this->db->where('level.Membership_ID',1);
        $this->db->where('level.Level_ID',1);
        $this->db->where('member.Status',6);
        $this->db->where('contract.Withdrawn_status',5);
        $query1 = $this->db->get();
        $transaction=$query1->result_array();

        $this->db->select('*');
        $this->db->from('gc_commission_setting');
        $this->db->where('Status',1);
        $query = $this->db->get();
        $commission=$query->result_array();

        if($commission[0]['Members_count']>=$members[0]['Members_count'] || $commission[0]['Volume_amount']>=$transaction[0]['Volume']){
            echo 'eligible';
        }else{
            'not_eligible';
        }
    }
    function check200(){
    // MONTH(columnName)
        $date = "2019-03-12";
        $d = date_parse_from_format("Y-m-d", $date);
// echo 'Month1_'. $mnt=$d["month"]-1; 
        $mnt=$d["month"]-1;
        $first_day_this_month = date('Y-m-01');
        $dt=date('Y')."-".$mnt."-01";
        $dt=date('Y-m-d',strtotime($dt));
        $this->db->where('MONTH(Commission_date)',$dt);
        echo$comision_status=  $this->db->count_all_results('gc_binary_commisions');
    }
    
    public function check100(){
        $date = "2019-03-12";
        $Cal_date=$date;
        $d = date_parse_from_format("Y-m-d", $date);
        $mnt=$d["month"]-1; 
        $first_day_this_month = date('Y-m-01');
        $dt=date('Y')."-".$mnt."-01";
        $dt=date('Y-m-d',strtotime($dt));
// echo 'First_date-'.$last_day_this_month  = date('Y-m-01',strtotime($dt));
        $first_day_this_month  = date('Y-m-01',strtotime($dt));
// echo 'Last_date-'.$last_day_april_2010 = date('Y-m-t', strtotime($dt));
        $last_day_april_2010 = date('Y-m-t', strtotime($dt));


        $this->db->where('MONTH(Commission_date)',$dt);
        $comision_status=  $this->db->count_all_results('gc_binary_commisions');
if($comision_status<=0){ // Commission status if start

    $Cal_date=date('Y-m-d',strtotime($Cal_date));
    $final_dates=[];
    $yrl_dates_0=[];
    $this->db->select('Weeks');
    $this->db->where('Status',1);
    $this->db->where('ID',1);
    $query = $this->db->get('gc_leveltype');
    if ($query->num_rows() > 0) {
        $days=$query->result_array();
        $week_days=explode(',',$days[0]['Weeks']);
        $final_days=[];
        $final_days1=[];


        $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
            $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
        

        $this->db->select('Date');
        $query = $this->db->get('gc_individual_calendar');
        if ($query->num_rows() > 0) {
            $db_leave=$query->result_array();
        }else{
            $db_leave=[];
        }

        $empt_leave=[];
        foreach($db_leave as $lv){
            array_push($empt_leave,$lv['Date']);

        }
        $final_dates=array_values(array_diff($final_dates,$empt_leave));
    }
            if(in_array($Cal_date, $final_dates)){ // commission_date check if start

                $this->db->select('Membership_ID');
                $this->db->where('Membership_type',2);
                $this->db->where('Status',6);
                $query_member=$this->db->get('gc_membership');
if($query_member->num_rows() >0){ // Member Num Rows if Start  
    $member=$query_member->result_array();
    foreach($member as $memership){ // Member Foreach Start
        $this->db->select('Child_ID,Position_type');
        $this->db->where_in('Parent_ID',$memership['Membership_ID']);
        $this->db->order_by('Position_type');
        $query_bin = $this->db->get('gc_binary_member_relation');
        if($query_bin->num_rows() > 0){  // Query_bin numrows if start
            $member_binary=$query_bin->result_array();
            if($query_bin->num_rows()==2){ // Query_bin numrows1 if start 
                // foreach($member_binary as $bin){
                //     if($bin['Position_type']==1){

                //     }
                // }
                if($member_binary[0]['Position_type']==1){
                    $left_tree=$member_binary[0]['Child_ID'];
                    $right_tree=$member_binary[1]['Child_ID'];
                }else{
                    $left_tree=$member_binary[1]['Child_ID'];
                    $right_tree=$member_binary[0]['Child_ID'];
                }
                
            } // Query_bin numrows1 else start 
            else{ // Query_bin numrows1 if end 
                if($member_binary[0]['Position_type']==1){
                    $left_tree=$member_binary[0]['Child_ID'];
                    $right_tree='';
                }else{
                    $left_tree='';
                    $right_tree=$member_binary[0]['Child_ID'];
                }
            } // Query_bin numrows1 else end 

            // *** Left Tree Members start *** //
            if(!empty($left_tree)){
                $final_left_tree=[$left_tree];
                $left_parent_id=[$left_tree];

                $left_limit=1;
                        for($i=1;$i<=1000;$i++){ // left for start  
                        // for($i=1;$i<=$left_limit;$i++){  
                            $this->db->select('Child_ID');
                            $this->db->where_in('Parent_ID',$left_parent_id);
                            // $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
                            $left_query = $this->db->get('gc_binary_member_relation');
                            if($left_query->num_rows() > 0){
                                foreach($left_query->result_array() as $key => $val){
                                    $left_parent_id[$key]=$val['Child_ID'];
                                    array_push($final_left_tree,$val['Child_ID']);
                                }
                                //print_r($left_parent_id);echo '<br>';
                                    //$left_limit++;
                            }
                            
                        } // left for end

                         // *** Left Tree Members commision getting start *** //
                        $this->db->select('sum(Total_B_V) as Left_bv');
                        $this->db->where('Date >=',$first_day_this_month);
                        $this->db->where('Date <=',$last_day_this_month);
                        $this->db->where_in('Membership_ID',$final_left_tree);
                        $left_com_query=$this->db->get('gc_binary_transaction_details');
                        $left_com=$left_com_query->result_array();
                        if(!empty($left_com[0]['Left_bv'])){
                         $left_binary_commission=$left_com[0]['Left_bv']; 
                     }else{
                        $left_binary_commission=0;
                    }
                    
                         // *** Left Tree Members commision getting end *** //
                }else{
                    $left_binary_commission=0;
                }
            // *** Left Tree Members end *** //

            // *** Right Tree Members start *** //
                if(!empty($right_tree)){
                    $final_right_tree=[$right_tree];
                    $right_parent_id=[$right_tree];

                    $right_limit=1;
                        for($j=1;$j<=1000;$j++){ // right for start
                        // for($j=1;$j<=$right_limit;$j++){
                            $this->db->select('Child_ID');
                            $this->db->where_in('Parent_ID',$right_parent_id);
                            // $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
                            $right_query = $this->db->get('gc_binary_member_relation');
                            if($right_query->num_rows() > 0){
                                foreach($right_query->result_array() as $key => $val){
                                    $right_parent_id[$key]=$val['Child_ID'];
                                    array_push($final_right_tree,$val['Child_ID']);
                                }
                                //print_r($parent_id);echo '<br>';
                                    //$right_limit++;
                            }
                            
                        } // right for end

                          // *** right Tree Members commision getting start *** //
                        $this->db->select('sum(Total_B_V) as Right_bv');
                        $this->db->where('Date >=',$first_day_this_month);
                        $this->db->where('Date <=',$last_day_this_month);
                        $this->db->where_in('Membership_ID',$final_right_tree);
                        $right_com_query=$this->db->get('gc_binary_transaction_details');
                        $right_com=$right_com_query->result_array();
                        if(!empty($right_com[0]['Left_bv'])){
                         $right_binary_commission=$right_com[0]['Left_bv']; 
                     }else{
                        $right_binary_commission=0;
                    }
                         // *** right Tree Members commision getting end *** //
                }else{
                    $right_binary_commission=0;
                }
            // *** Right Tree Members end *** //

                if($left_binary_commission>=$right_binary_commission){
                    $final_com=$left_binary_commission;
                }else{
                    $final_com=$right_binary_commission;
                }

                $this->db->select('*');
                $this->db->where('Status',1);
                $query_setting = $this->db->get('gc_bv_settings');
                $setting_val=$query_setting->result_array();
                $B_V=$setting_val[0]['B_V'];
                $B_V_percentage=$setting_val[0]['B_V_Commission'];

                $bv_per_cal=($final_com/$B_V) * $B_V_percentage;
                $final_Commission=round(($final_com * $bv_per_cal) / 100);

                $binary_commission_data=array(
                    'Company_ID' => $this->session->userdata('CompanyId'),
                    'Branch_id' => $this->session->userdata('CompanyId'),
                    'Transaction_ID' => '',
                    'Transaction_detail_ID' => '',
                    'Membership_ID' => $memership['Membership_ID'],
                    'Order_ID' => '',
                    'Total_B_V' => $final_com,
                    'Commission_percentage' => $bv_per_cal,
                    'Commission_amount' => $final_Commission,
                    'Commission_date' => $date,
                    'Payout_ID' => 3,
                    'Remarks' => ''
                );
                $this->db->insert('gc_binary_commisions',$binary_commission_data);


        }  // Query_bin numrows if end
    } // Member Foreach End
} // Member Num Rows if end

} // commission_date check if end

} // Commission status if end

}

public function get_three_yrs_holidays($year,$week_days){

//$week_days=['6','7'];
            //var_dump($week_days);
    $date=new DateTime();
//$year=date('Y');
    $date->setDate($year, 01, 01);
    $dt = $date->format('Y-m-d');
    $day=date('l', strtotime($dt));
    $search =date('N', strtotime($day));

    $arr = [];
    $arr2 = [];

    for ($i=0 ;$i < count($week_days); $i++) {

        if($week_days[$i] == $search){
            $arr[$i] = $week_days[$i];
            $search = $week_days[$i] + 1;
        }else{
            $arr2[$i] = $week_days[$i];
        }
    }

    $action = array_merge($arr,$arr2);
    $days = array(
       '1' => 'Monday',
       '2' => 'Tuesday',
       '3' => 'Wednesday',
       '4' => 'Thursday',
       '5' => 'Friday',
       '6' => 'Saturday',
       '7' => 'Sunday'
   );
    $final_dt=[];
//var_dump($action);
    foreach($action as $da){
        if (array_key_exists($da,$days))
        {
    //$sim=array('N' => $days[$da], 'A' => $da);
          array_push($final_dt,$days[$da]);
      }

  }
//var_dump($final_dt);

  $final_dates=[];
  for($i=1; $i<=52; $i++){
    foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
        array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
    }
}
return $final_dates;
}
public function captcha(){
        // If captcha form is submitted
    if($this->input->post('submit')){
        $inputCaptcha = $this->input->post('captcha');
        $sessCaptcha = $this->session->userdata('captchaCode');
        if($inputCaptcha === $sessCaptcha){
            echo 'Captcha code matched.';
        }else{
            echo 'Captcha code does not match, please try again.';
        }
    }
    
        // Captcha configuration
    $config = array(
        'img_path'      => 'captcha_images/',
        'img_url'       => base_url().'captcha_images/',
        'font_path'     => 'system/fonts/texb.ttf',
        'img_width'     => '160',
        'img_height'    => 50,
        'word_length'   => 8,
        'font_size'     => 18
    );
    $captcha = create_captcha($config);
    
        // Unset previous captcha and set new captcha word
    $this->session->unset_userdata('captchaCode');
    $this->session->set_userdata('captchaCode', $captcha['word']);
    
        // Pass captcha image to view
    $data['captchaImg'] = $captcha['image'];
    
        // Load the view
    $this->load->view('captcha/index', $data);
}

public function captcha_check(){
        // If captcha form is submitted
        // if($this->input->post('submit')){
    $inputCaptcha = $this->input->post('captcha');
    $sessCaptcha = $this->session->userdata('captchaCode');
    if($inputCaptcha === $sessCaptcha){
        $data['msg']='Captcha code matched.';
    }else{
        $data['msg']= 'Captcha code does not match, please try again.';
    }
        // }
    
        // Captcha configuration
    $config = array(
        'img_path'      => 'captcha_images/',
        'img_url'       => base_url().'captcha_images/',
        'font_path'     => 'system/fonts/texb.ttf',
        'img_width'     => '160',
        'img_height'    => 50,
        'word_length'   => 8,
        'font_size'     => 18
    );
    $captcha = create_captcha($config);
    
        // Unset previous captcha and set new captcha word
    $this->session->unset_userdata('captchaCode');
    $this->session->set_userdata('captchaCode', $captcha['word']);
    
        // Pass captcha image to view
    $data['captchaImg'] = $captcha['image'];
    
        // Load the view
    echo json_encode($data);
        //$this->load->view('captcha/index', $data);
}
public function refresh(){
        // Captcha configuration
    $config = array(
        'img_path'      => 'captcha_images/',   
        'img_url'       => base_url().'captcha_images/',
        'font_path'     => 'system/fonts/texb.ttf',
        'img_width'     => '160',
        'img_height'    => 50,
        'word_length'   => 8,
        'font_size'     => 18
    );
    $captcha = create_captcha($config);
    
        // Unset previous captcha and set new captcha word
    $this->session->unset_userdata('captchaCode');
    $this->session->set_userdata('captchaCode',$captcha['word']);
    
        // Display captcha image
    echo $captcha['image'];
}
public function sarvan(){
    if($this->input->post('submit')){
        $inputCaptcha = $this->input->post('captcha');
        $sessCaptcha = $this->session->userdata('captchaCode');
        if($inputCaptcha === $sessCaptcha){
            echo 'Captcha code matched.';
        }else{
            echo 'Captcha code does not match, please try again.';
        }
    }
    echo $inputCaptcha = $this->input->post('captcha');
    
}

public function server_processing_members()
{
        // $batch_id   = $this->input->get('batch');
        // $product_id = $this->input->get('product');
        // $all_data = $this->input->get('all_data');

        // if($all_data == 0){
        //     if($batch_id != ''){
        //         $batch_where = "batch.Batch_setting_id IN (".$batch_id.")";
        //     }else{
        //         $batch_where = "";
        //     }
    
        //     if($product_id != ''){
        //         $product_where = "batch.Product_id IN (".$product_id.")";
        //     }else{
        //         $product_where = "";
        //     }

        //     if($batch_id != '' && $product_id != ''){
        //         $condions =" ".$batch_where."AND ".$product_where;
        //     }elseif($batch_id != ''){
        //         $condions =" ".$batch_where;            
        //     }elseif($product_id != ''){
        //         $condions =" ".$product_where;            
        //     }else{
        //         $condions ="";                        
        //     }
        // }else{
        //     $condions ="";
        // }

    $table = 'gc_membership';

    $primaryKey = 'Membership_ID';
    
    $columns = array(



        array(
            'db'        => '`member`.`Membership_ID`',
            'dt'        => 0,
            'field' => 'Membership_ID',
            'formatter' => function( $d, $row ) {
                return $d;
            }
        ),

        array(
            'db'        => '`member`.`Membership_ID`',
            'dt'        => 1,
            'field' => 'Membership_ID',
            'formatter' => function( $d, $row ) {
                $add='';
                $add.= '
                

                <a href="'.base_url().'membership/Membership/view_members?id='.$row[1].'" id="viewmembers"  class="btn btn-primary btn-sm " ><i class="la la-eye" data-toggle="tooltip" data-placement="top" data-original-title="View"  style="
                
                color:  white;"></i></a>';
                $doc_val=$this->Membership_model->get_doc_records($row[1]);
                $bank_val=$this->Membership_model->get_bank_records($row[1]);
                $pays_val=$this->Membership_model->get_pays_records($row[1]);

                $add.='<div class="btn-group dropup">
                <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="zmdi zmdi-settings zmdi-hc-fw" style="color:  white;" data-toggle="tooltip" data-placement="top" data-original-title="Status"></i> </button>
                <div class="dropdown-menu" >

                <a class="dropdown-item" href="#" onclick="set_bank_records('.$row[1].','.$row[3].','.$row[3].','.$bank_val[0]['Member_bank_ID'].','.$bank_val[0]['Account_holder'].','.$bank_val[0]['Account_no'].','.$bank_val[0]['IFSC'].','.$bank_val[0]['Bank_name'].','. $doc_val[2]['Document_name'].','.$row[5].','.$bank_val[0]['Status'].')" data-toggle="modal" data-target=".bank_verify_modal">Bank Verify</a>

                <a class="dropdown-item" href="#" onclick="set_document_records('.$row[3].','.$row[3].','.$doc_val[0]['Document_ID'].','.$doc_val[0]['Document_no'].','. $doc_val[0]['Document_name'].','.$doc_val[1]['Document_ID'].','.$doc_val[1]['Document_no'].','. $doc_val[1]['Document_name'] .','.$doc_val[2]['Document_ID'].','.$doc_val[2]['Document_no'].','. $doc_val[2]['Document_name'] .','.$row[1].','.$doc_val[0]['Status'].','.$doc_val[1]['Status'].','.$doc_val[2]['Status'].','.$row[5].')" data-toggle="modal" data-target=".document_verify_modal">Document Verify</a>
                </div>';

                $add.='<a href="'.base_url().'membership/Membership/contract?id='.$row[5].'" id="View Contract"  class="btn btn-accent btn-sm "><i class="zmdi zmdi-wrench zmdi-hc-fw" data-toggle="tooltip" data-placement="top" data-original-title="Contract"  style="
                
                color:  white;"></i></a>

                <a href="#" onclick="block_member('.$row[3].','.$row[3].','.$row[1].')"  class="btn btn-info btn-sm "  ><i class="zmdi zmdi-block-alt zmdi-hc-fw" data-toggle="tooltip" data-placement="top" data-original-title="Block Member"  style="
                
                color:  white;"></i></a>';
                return $add;
            }
        ),

        array(
            'db'        => '`member`.`Membership_ID`',
            'dt'        => 2,
            'field' => 'Membership_ID',
            'formatter' => function( $d, $row ) {
                $add = '<a href="'.base_url().'membership/Membership/tree_view1?id='.$row[5].'" target="_blank" id="tree_view"  class="btn btn-info btn-sm "  ><i class="la la-tree" data-toggle="tooltip" data-placement="top" data-original-title="View"  style="color:  white;"></i></a>';
                return $add;
            }
        ),

        

        array( 'db' => '`member`.`First_name`', 'dt' => 3, 'field' => 'First_name' ),

        array( 'db' => '`member`.`Membership_type`',  'dt' => 4, 'field' => 'Membership_type' ),

        array( 'db' => '`member`.`Membership_code`', 'dt' => 5, 'field' => 'Membership_code' ),

        array( 'db' => '`member`.`Mobile`',   'dt' => 6, 'field' => 'Mobile' ), 

        array( 'db' => '`member`.`Created_date`',   'dt' => 7, 'field' => 'Created_date' ),

        array( 'db' => '`contract`.`Contract_status_date`',   'dt' => 8, 'field' => 'Contract_status_date' ),  

        array(
            'db'        => '`bank`.`Status`',
            'dt'        => 9,
            'field' => 'Status',
            'formatter' => function( $d, $row ) {
                $sta='';
                if($row[9] == 5){
                    $sta.= '<span class="badge badge-danger">Pending</span>';
                }else{
                    $sta.= '<span class="badge badge-success">Verified</span>';
                }
                
                return $sta;
            }
        ),
        
        array( 'db' => '`member`.`Membership_ID`',   'dt' => 10, 'field' => 'Membership_ID' ),
    );

        // SQL server connection information
        // require('config.php');
$sql_details = array(
    'user' => $this->db->username,
    'pass' => $this->db->password,
    'db'   => $this->db->database,
    'host' => $this->db->hostname,
);

$joinQuery = "FROM `gc_membership` as `member` LEFT JOIN `gc_member_franchisee_contract` as `contract` ON `contract`.`Membership_ID` = `member`.`Membership_ID` LEFT JOIN `gc_member_payments` as `payments` ON `payments`.`Membership_ID` = `member`.`Membership_ID` LEFT JOIN `gc_membershiptype` as `type` ON `type`.`ID` = `member`.`Membership_type` LEFT JOIN `gc_member_banks` as `bank` ON `bank`.`Membership_ID` = `member`.`Membership_ID` LEFT JOIN `gc_member_documents` as `documents` ON `documents`.`Membership_ID` = `member`.`Membership_ID` ";
        // $extraWhere = $condions;
        // $groupBy = "";
$groupBy = "member.Membership_ID";
$having = "";
$extraWhere="member.Status=6";

echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, $having )
);


}

function check500(){
    // $mem_qry = $this->db->select('Membership_ID,Payout_ID')->get_where('gc_membership', array('Membership_ID' => 7))->result_array();
    // var_dump($mem_qry);
   $this->db->select('topup.Validity,topup.Value,topup.Return,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status,contract.Multiples');
   $this->db->from('gc_member_topup as topup');
   $this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');
   $this->db->where('contract.Contract_ID',5);
   $this->db->where('contract.Membership_ID',8);
   $query = $this->db->get();
   $contract=$query->result_array();
   var_dump($contract);
}

//$GLOBALS['empty'] = [];
function check501(){

    $child_id=135;
    $empty=[];
    $dat=$this->check501($child_id);
    $limit=1;
    for($i=1;$i<=$limit;$i++){
      $prts=[];
      $this->db->select('Parent_ID,Position_type');
      $this->db->where('Child_ID',$child_id);
      $query[$i] = $this->db->get('gc_binary_member_relation');
      if($query[$i]->num_rows() > 0){
       $binary[$i]=$query[$i]->result_array();
       $prts=array('ID' => $binary[$i][0]['Parent_ID'],
           'Position' => $binary[$i][0]['Position_type']);
       $child_id=$binary[$i][0]['Parent_ID'];
       array_push($empty,$prts);
       
       $limit++;

   }
   
}
echo '<pre>';
print_r($empty);

}
function find_id($child_id){
    $limit=1;
    for($i=1;$i<=$limit;$i++){
      $prts=[];
      $this->db->select('Parent_ID,Position_type');
      $this->db->where('Child_ID',$child_id);
      $query[$i] = $this->db->get('gc_binary_member_relation');
      if($query[$i]->num_rows() > 0){
       $binary[$i]=$query[$i]->result_array();
       $prts=array('ID' => $binary[$i][0]['Parent_ID'],
           'Position' => $binary[$i][0]['Position_type']);
       $child_id=$binary[$i][0]['Parent_ID'];
       return $prts;
             //array_push($empty,$prts);
             // $limit++;
       
   }else{
      return NULL;
  }
}

}

function check502(){
	$Child_ID=113;
	$parents=[];
	$limit=1;
    for($i=1;$i<=$limit;$i++){
    	$pts=[];	
        $this->db->select('one.Parent_ID,one.Position_type as child_position,two.Position_type');
        $this->db->from('gc_binary_member_relation as one');
        $this->db->join('gc_binary_member_relation as two', 'two.Child_ID = one.Parent_ID', 'left');
        $this->db->where('one.Child_ID',$Child_ID);
        $query4 = $this->db->get();
        if($query4->num_rows() > 0){
            $binary4=$query4->result_array();
            $pts=array('ID' => $binary4[0]['Parent_ID'],
              'Parent_position' => $binary4[0]['Position_type'],
              'Child_position' => $binary4[0]['child_position']);
            $Child_ID=$binary4[0]['Parent_ID'];
            array_push($parents,$pts);
            $limit++;
        }

    }
    echo "<pre>";
    print_r($parents);
}

function check503(){
	$final_left_tree=[$left_tree];
    $left_parent_id=[$left_tree];

    $left_limit=1;
                            for($i=1;$i<=10000;$i++){ // left for start  
                            // for($i=1;$i<=$left_limit;$i++){  
                                $this->db->select('Child_ID');
                                $this->db->where_in('Parent_ID',$left_parent_id);
                                // $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
                                $left_query = $this->db->get('gc_binary_member_relation');
                                if($left_query->num_rows() > 0){
                                    foreach($left_query->result_array() as $key => $val){
                                        $left_parent_id[$key]=$val['Child_ID'];
                                        array_push($final_left_tree,$val['Child_ID']);
                                    }
                                    //print_r($left_parent_id);echo '<br>';
                                        //$left_limit++;
                                }
                                
                            }
                        }

                        function check999(){
	// $Cal_date=date('Y-m-d');
	// $date=date('d',strtotime($Cal_date));
                           $commission_pay_date=['7','14','21','28'];
                           $per_date=29;
                           foreach($commission_pay_date as $val){
                            if($per_date <= $val){
                               $exct_day= $val;
                               break;
                           }else{
                               $exct_day=$commission_pay_date[0];
                           }

                       }
                       if($per_date<=$exct_day){
                           echo $final_payout_date=date('Y-m-'.$exct_day);
                       }else{
                           $samp_dy=date('Y-m-'.$exct_day);
                           echo $final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
                           
                       }
                   }

                   function check1001(){
                      $commission_pay_date=['7','14','21','28'];
                      $per_date=29;
                      foreach($commission_pay_date as $val){
                        if($per_date <= $val){
                           $exct_day= $val;
                           break;
                       }else{
                           $exct_day=$commission_pay_date[0];
                       }

                   }
                   if($per_date<=$exct_day){
                       $final_payout_date=date('Y-07-'.$exct_day);
                   }else{
                       $samp_dy=date('Y-08-'.$exct_day);
                       $final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
                       
                   }

                   echo $this->fet_excat_payout_date($final_payout_date);

               }


               public function sarv(){
                   $cr='2019-01-28';
                   $py_days=14;
                   $cur_payout=date('Y-m-d', strtotime($cr. ' + '.$py_days.' days'));
                   echo $this->get_excat_next_payout($cur_payout);
               }
               public function get_excat_next_payout($cl_dt){
	//$cl_dt='2019-05-08';
                   $com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
                   if(!empty($com_pay_date)){
                      $commission_pay_date=$com_pay_date[0]['Pay_dates'];
                  }else{
                      $commission_pay_date='7,14,21,28';
                  }
                  $commission_pay_date=explode(',',$commission_pay_date);

                      	//$cl_dt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $tran['Membership_ID'],'Contract_ID' => $tran['Contract_ID']))->row()->Pay_date;
                  $per_date=date('d',strtotime($cl_dt));
                  $temp_date=date('Y-m',strtotime($cl_dt));
                  foreach($commission_pay_date as $val){
                    if($per_date <= $val){
                       $exct_day= $val;
                       break;
                   }else{
                       $exct_day=$commission_pay_date[0];
                   }

               }
               if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
                   $final_payout_date=date($temp_date.'-'.$exct_day);
               }else{
									// $samp_dy=date('Y-m-'.$exct_day);
                   $samp_dy=date($temp_date.'-'.$exct_day);
                   $final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
                   
               }

							// return $payout_date=$this->fet_exact_payout_date($final_payout_date);
               return $payout_date=date('Y-m-d',strtotime($final_payout_date));
           }

           public function get_excat_next_payout1(){
               echo $cl_dt='2019-05-15';echo '<br>';
               $com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
               if(!empty($com_pay_date)){
                  $commission_pay_date=$com_pay_date[0]['Pay_dates'];
              }else{
                  $commission_pay_date='7,14,21,28';
              }
              $commission_pay_date=explode(',',$commission_pay_date);

						//$cl_dt=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID' => $tran['Membership_ID'],'Contract_ID' => $tran['Contract_ID']))->row()->Pay_date;
              echo $per_date=date('d',strtotime($cl_dt));echo '*-1-<br>';
              $temp_date=date('Y-m',strtotime($cl_dt));
              foreach($commission_pay_date as $key => $val){
                echo $val;echo "#<br>";
                if($per_date >= $val){

                   echo $exct_day = $val;echo '-1-<br>';
                   break;
               }else{
                   echo $exct_day=$commission_pay_date[3];echo '-2-<br>';
               }

           }
           if($per_date >= $exct_day){
            echo '1';echo '<br>';
									// $final_payout_date=date('Y-m-'.$exct_day);
            $final_payout_date=date($temp_date.'-'.$exct_day);
        }else{
           echo '2';echo '<br>';
									// $samp_dy=date('Y-m-'.$exct_day);
           $samp_dy=date($temp_date.'-'.$exct_day);
           $final_payout_date=date('Y-m-d', strtotime($samp_dy. '- 1  months'));
           
       }

							// return $payout_date=$this->fet_exact_payout_date($final_payout_date);
       echo  $payout_date=date('Y-m-d',strtotime($final_payout_date));
   }

   public function fet_exact_payout_date($final_payout_date)
   {
       $Cal_date=date('Y-m-d',strtotime($final_payout_date));
       $final_dates=[];
       $yrl_dates_0=[];
       $this->db->select('Weeks');
       $this->db->where('Status',1);
       $this->db->where('ID',1);
       $query = $this->db->get('gc_leveltype');
       if ($query->num_rows() > 0) {
          $days=$query->result_array();
          $week_days=explode(',',$days[0]['Weeks']);
          $final_days=[];
          $final_days1=[];


          $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
          foreach($yr as $key => $y){
              $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
          }
          $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);
          

          $this->db->select('Date');
          $query = $this->db->get('gc_individual_calendar');
          if ($query->num_rows() > 0) {
              $db_leave=$query->result_array();
          }else{
              $db_leave=[];
          }

          $empt_leave=[];
          foreach($db_leave as $lv){
              array_push($empt_leave,$lv['Date']);

          }
          $final_dates=array_values(array_diff($final_dates,$empt_leave));
          if(in_array($Cal_date, $final_dates)){

             return $Cal_date;
         }else{
             return $this->get_next_pay_date($Cal_date);
         }
     }
 }



 public function get_next_pay_date($cur_date){
    $final_dates=[];
    $yrl_dates_0=[];
    $this->db->select('Weeks');
    $this->db->where('Status',1);
    $this->db->where('ID',1);
    $query = $this->db->get('gc_leveltype');
    if ($query->num_rows() > 0) {
        $days=$query->result_array();
        $week_days=explode(',',$days[0]['Weeks']);

        $yr=[date('Y')-1,date('Y')+0,date('Y')+1];
        foreach($yr as $key => $y){
            $yrl_dates_0[$key]=$this->get_three_yrs_holidays($y,$week_days);
            
        }
        $final_dates=array_merge($yrl_dates_0[0],$yrl_dates_0[1],$yrl_dates_0[2]);

        $this->db->select('Date');
        $query = $this->db->get('gc_individual_calendar');
        if ($query->num_rows() > 0) {
            $db_leave=$query->result_array();
        }else{
            $db_leave=[];
        }
        $empt_leave=[];
        foreach($db_leave as $lv){
            array_push($empt_leave,$lv['Date']);

        }
        
                //print_r($db_leave);die();
        $final_dates=array_values(array_diff($final_dates,$empt_leave));

        foreach($final_dates as $key=> $fin){
            if($cur_date < $fin){
                
                $keyval= $key;
                if(isset($final_dates[$keyval])){
                    return $final_dates[$keyval];
                }
                
                break;
            }else{
                $keyval=$key;
                $final_dates[$keyval];
            }
        }
    }

}

function check504(){
	//$parents=[];
	$final_left_tree=[135];
    $left_parent_id=[135];
    $limit=1;
    for($i=1;$i<=$limit;$i++){
       $pts=[];	
       $this->db->select('*');
       $this->db->where_in('Parent_ID',$left_parent_id);
       $query4 = $this->db->get('gc_binary_member_relation');
       if($query4->num_rows() > 0){
        $binary4=$query4->result_array();
        foreach ($binary4 as $key => $value) {
           $left_parent_id[$key]=$value['Child_ID'];
           array_push($final_left_tree,$value['Child_ID']);
       }

                                // $Child_ID=$binary4[0]['Parent_ID'];
                                // array_push($parents,$pts);
       $limit++;
   }
   
}
echo "<pre>";
print_r($final_left_tree);
}

function check201(){
	$this->db->select('/member.Membership_ID,member.Reference_ID,member.Commission_mode,contract.Contract_ID,contract.Pay_date,contract.Lvl_pay_date,member.Payout_ID,contract.Amount');
    $this->db->from('gc_membership as member');
    $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
    $this->db->where('contract.Lvl_pay_date',date('Y-m-d',strtotime($Cal_date)));
    $this->db->where('member.Status',6);
    $this->db->where('member.Commission_mode',1);
    $this->db->where('contract.Contract_status',6);
    $this->db->where('contract.Withdrawn_status',5);
    $query = $this->db->get();

                if ($query->num_rows() > 0) { // Memberhsip Count if start
                	var_dump($query->result_array());die();
                    $final_members1=$query->result_array();
                    // foreach ($final_members1 as $key => $value_member1) {

                    // }
                }
            }

            function check202(){

               $start = '2019-01-01';
               $end = '2019-05-' . date('t', strtotime($start));
               while(strtotime($start) <= strtotime($end)) {
                $Cal_date = date('Y-m-d', strtotime($start));
        //$day_name = date('l', strtotime($start));
                $start = date("Y-m-d", strtotime("+1 day", strtotime($start)));
        //echo $day_num ."ss<br/>";
        //echo $Cal_date;
    //}die();

                echo $Cal_date=date('Y-m-d',strtotime($Cal_date)); echo "<br>";
            }



        }

        function check3000(){
           $Cal_date='2019-05-01';
           $com_pay_date=$this->db->get_where('gc_payout_type',array('id'=>2))->result_array();
           if(!empty($com_pay_date)){
              $commission_pay_date=$com_pay_date[0]['Pay_dates'];
          }else{
              $commission_pay_date='7,14,21,28';
          }
          $commission_pay_date=explode(',',$commission_pay_date);
          $per_date=date('d',strtotime($Cal_date));
          $temp_date=date('Y-m',strtotime($Cal_date));
          foreach($commission_pay_date as $val){
            if($per_date <= $val){
               $exct_day= $val;
               break;
           }else{
               $exct_day=$commission_pay_date[0];
           }

       }
       echo $exct_day;
       if($per_date<=$exct_day){
									// $final_payout_date=date('Y-m-'.$exct_day);
           $final_payout_date=date($temp_date.'-'.$exct_day);
       }else{
									// $samp_dy=date('Y-m-'.$exct_day);
           $samp_dy=date($temp_date.'-'.$exct_day);
           $final_payout_date=date('Y-m-d', strtotime($samp_dy. ' +1 months'));
           
       }
       echo $final_payout_date;
       echo $this->fet_excat_payout_date($final_payout_date);
   }

   function check300(){
	// $count=1;
 //    $this->db->where('Contract_ID',1);
 //    $this->db->where('Membership_ID',1);
 //    $this->db->set('Payout_count', "Payout_count +'$count'", FALSE);     
 //    $this->db->update('gc_member_franchisee_contract');
	// $this->db->select('member1.Mobile');
	// // $this->db->select('member2.Mobile');
	// $this->db->from('gc_membership as member1');
	// $this->db->join('gc_membership as member2','member2.Membership_ID=member1.Reference_ID','left');
	// $this->db->where('member1.Membership_ID',2729);
	// $member=$this->db->get();
	// if($member->num_rows()>0){
	// 	var_dump($member->result_array());
	// }
       $ref_mobile=$this->db->get_where('gc_membership',array('Membership_ID' => 2728))->result_array();

       $final_sms=[];
       $mem1=array('Mobile' => '8456845','Name'=> 'fdgsdgsdgsdg','Content'=>'hi');
       array_push($final_sms,$mem1);

       $mem2=array('Mobile' => $ref_mobile[0]['Mobile'],'Name'=> $ref_mobile[0]['First_name'],'Content'=>'hi'.$ref_mobile[0]['First_name']);
       array_push($final_sms,$mem2);
       var_dump($final_sms);


   }

   function check222(){
	//echo $reg_date=$this->db->get_where('gc_membership',array('Membership_ID' => 2728))->row()->Created_date;
//echo date('Y-m-d', strtotime($reg_date. ' + 2 months'));

// $data=$this->db->select('member.Membership_ID,member.Membership_type,contract.Membership_type as cont_mem')->from('gc_membership as member')->join('gc_member_franchisee_contract as contract','contract.Membership_ID=member.Membership_ID','left')->where('member.Membership_type',2)->->where('contract.')->get()->result_array();

// var_dump($data);
      $start = '2019-01-01';
      $end='2019-04-28';
    // $end = '2019-05-' . date('t', strtotime($start));
      while(strtotime($start) <= strtotime($end)) {
        $Cal_date = date('Y-m-d', strtotime($start));
        //$day_name = date('l', strtotime($start));
        $start = date("Y-m-d", strtotime("+1 day", strtotime($start)));
        //echo $day_num ."ss<br/>";
        //echo $Cal_date;
    //}die();
        echo $Cal_date=date('Y-m-d',strtotime($Cal_date));
    }
}

function check_delete(){
	$this->db->where('ID',21)->delete('gc_payment_mode');
}

public function set_green_star($Membership_ID){

	// $members=$this->db->select('Membership_ID,Created_date,Membership_mode')->get('gc_membership')->result_array();

// $Membership_ID=2727;
    $members=$this->db->select('Membership_ID,Created_date,Membership_mode')->where('Membership_ID',$Membership_ID)->get('gc_membership')->result_array();
    if(!empty($members)){
       $start_date=date('Y-m-d',strtotime($members[0]['Created_date']));

       $cur_pyt=date('Y-m-d',strtotime($this->db->get_where('gc_member_franchisee_contract',array('Invest_type'=>1,'Membership_ID'=>$Membership_ID))->row('Payout_date')));

       $py_days=15-1;
       $cur_payout=date('Y-m-d', strtotime($cur_pyt. ' + '.$py_days.' days'));
       $payout_date=$this->get_excat_next_payout($cur_payout);

	// foreach ($members as $key => $value) {
       

	// }

// find Star 1 start
       $days_1=30;
       $level_ID_1=1;
       $end_sate_1=date('Y-m-d', strtotime($start_date. ' + '.$days_1.' days'));
       $b_status_1=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID_1))->count_all_results('gc_green_star');
       if($b_status_1<=0){
           $this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID_1,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate_1))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
           if($start_date < '2019-05-01'){
              $this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
              $this->db->where('contract.Invest_type',2);
          }
          $green_count_1=$this->db->count_all_results('gc_member_level_details as level');
          if($green_count_1>=10){

           $str_update_1['Status']=6;
           $this->db->where('Membership_ID',$Membership_ID);     
           $this->db->update('gc_green_star',$str_update_1);
           $green_1=array(
               'Membership_ID'=>$Membership_ID,
               'Star'         =>1,
               'Level'		   =>$level_ID_1,
               'Members_count'=>$green_count_1,
               'Created_date' =>date('Y-m-d'),
               'Payout_date'  =>$payout_date,
               'Status'       =>1,
               'Benefit'      =>140
           );
           
           $this->db->insert('gc_green_star',$green_1);
       }
   }


// find Star 1 end


// find Star 2 start
   $days_2=60;
   $level_ID_2=2;
   $end_sate_2=date('Y-m-d', strtotime($start_date. ' + '.$days_2.' days'));
   $b_status_2=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID_2))->count_all_results('gc_green_star');
   if($b_status_2<=0){
       $this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID_2,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate_2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
       if($start_date < '2019-05-01'){
          $this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
          $this->db->where('contract.Invest_type',2);
      }
      $green_count_2=$this->db->count_all_results('gc_member_level_details as level');
      if($green_count_2>=50){
         $str_update_2['Status']=6;
         $this->db->where('Membership_ID',$Membership_ID);     
         $this->db->update('gc_green_star',$str_update_2);
         $green_2=array(
           'Membership_ID'=>$Membership_ID,
           'Star'         =>2,
           'Level'		   =>$level_ID_2,
           'Members_count'=>$green_count_2,
           'Created_date' =>date('Y-m-d'),
           'Payout_date'  =>$payout_date,
           'Status'       =>1,
           'Benefit'      =>700
       );
         
         $this->db->insert('gc_green_star',$green_2);
     }
 }


// find Star 2 end


// find Star 3 start
 $days_3=100;
 $level_ID_3=3;
 $end_sate_3=date('Y-m-d', strtotime($start_date. ' + '.$days_3.' days'));
 $b_status_3=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID_3))->count_all_results('gc_green_star');
 if($b_status_3<=0){
   $this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID_3,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate_3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
   if($start_date < '2019-05-01'){
      $this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
      $this->db->where('contract.Invest_type',2);
  }
  $green_count_3=$this->db->count_all_results('gc_member_level_details as level');
  if($green_count_3>=250){
     $str_update_3['Status']=6;
     $this->db->where('Membership_ID',$Membership_ID);     
     $this->db->update('gc_green_star',$str_update_3);
     $green_3=array(
       'Membership_ID'=>$Membership_ID,
       'Star'         =>3,
       'Level'		   =>$level_ID_3,
       'Members_count'=>$green_count_3,
       'Created_date' =>date('Y-m-d'),
       'Payout_date'  =>$payout_date,
       'Status'       =>1,
       'Benefit'      =>2150
   );
     
     $this->db->insert('gc_green_star',$green_3);
 }
}


// find Star 3 end


// find Star 4 start
$days_4=120;
$level_ID_4=4;
$end_sate_4=date('Y-m-d', strtotime($start_date. ' + '.$days_4.' days'));
$b_status_4=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID_4))->count_all_results('gc_green_star');
if($b_status_4<=0){
	$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID_4,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate_4))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
	if($start_date < '2019-05-01'){
		$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
		$this->db->where('contract.Invest_type',2);
	}
  $green_count_4=$this->db->count_all_results('gc_member_level_details as level');
  if($green_count_4>=550){
     $str_update_4['Status']=6;
     $this->db->where('Membership_ID',$Membership_ID);     
     $this->db->update('gc_green_star',$str_update_4);
     $green_4=array(
       'Membership_ID'=>$Membership_ID,
       'Star'         =>4,
       'Level'		   =>$level_ID_4,
       'Members_count'=>$green_count_4,
       'Created_date' =>date('Y-m-d'),
       'Payout_date'  =>$payout_date,
       'Status'       =>1,
       'Benefit'      =>4250
   );
     
     $this->db->insert('gc_green_star',$green_4);
 }
}


// find Star 4 end

// find Star 5 start
$days_5=150;
$level_ID_5=5;
$end_sate_5=date('Y-m-d', strtotime($start_date. ' + '.$days_5.' days'));
$b_status_5=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID_5))->count_all_results('gc_green_star');
if($b_status_5<=0){
	$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID_5,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate_5))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left');
	if($start_date < '2019-05-01'){
		$this->db->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left');
		$this->db->where('contract.Invest_type',2);
	}
  $green_count_5=$this->db->count_all_results('gc_member_level_details as level');
  if($green_count_5>=1200){
     $str_update_5['Status']=6;
     $this->db->where('Membership_ID',$Membership_ID);     
     $this->db->update('gc_green_star',$str_update_5);
     $green_5=array(
       'Membership_ID'=>$Membership_ID,
       'Star'         =>5,
       'Level'		   =>$level_ID_5,
       'Members_count'=>$green_count_5,
       'Created_date' =>date('Y-m-d'),
       'Payout_date'  =>$payout_date,
       'Status'       =>1,
       'Benefit'      =>7000
   );
     
     $this->db->insert('gc_green_star',$green_5);
 }
}


// find Star 5 end
}



}

public function check007(){

// $mem_code='GCI1918534209';
    $arr=array(
       array('Membership_ID'=>'GCI3790371','Membership_code'=>'GCI1912080605')	
	// array('Membership_ID'=>'GCI7255468','Membership_code'=>'GCI0817632'),
	// array('Membership_ID'=>'GCI3283236','Membership_code'=>'GCI0817632'),
	// array('Membership_ID'=>'GCI6267761','Membership_code'=>'GCI0817632')
	// array('Membership_ID'=>'GCI6785488','Membership_code'=>'GCI3466491'),
	// array('Membership_ID'=>'GCI1223724','Membership_code'=>'GCI1928646'),
	// array('Membership_ID'=>'GCI4886735','Membership_code'=>'GCI1928646'),
	// array('Membership_ID'=>'GCI0289905','Membership_code'=>'GCI62457327'),
	// array('Membership_ID'=>'GCI4583540','Membershipip_code'=>'GCI6759750'),
	// array('Membership_ID'=>'GCI7176187','Membership_code'=>'GCI3025096'),
	// array('Membership_ID'=>'GCI7864580','Membership_code'=>'GCI3025096'),
	// array('Membership_ID'=>'GCI6876371','Membership_code'=>'GCI9186033'),
       
	// array('Membership_ID'=>'GCI2349865','Membership_code'=>'GCI1910571203'),
	// array('Membership_ID'=>'GCI7419980','Membership_code'=>'GCI1910571203'),
	// array('Membership_ID'=>'GCI2072412','Membership_code'=>'GCI1910500006'),
	// array('Membership_ID'=>'GCI8731968','Membership_code'=>'GCI2072412'),

	// array('Membership_ID'=>'GCI1220209','Membership_code'=>'GCI1923595434'),
	// array('Membership_ID'=>'GCI7572536','Membership_code'=>'GCI1923595434')
	// array('Membership_ID'=>'GCI0433719','Membership_code'=>'GCI6260083'),
	// array('Membership_ID'=>'GCI6733164','Membership_code'=>'GCI9000849'),
	// array('Membership_ID'=>'GCI0861730','Membership_code'=>'GCI9000849'),
	// array('Membership_ID'=>'GCI9678312','Membership_code'=>'GCI9000849'),
	// array('Membership_ID'=>'GCI6390124','Membership_code'=>'GCI9000849'),
	// array('Membership_ID'=>'GCI1414725','Membership_code'=>'GCI1981182'),
	// array('Membership_ID'=>'GCI1918562207','Membership_code'=>'GCI1912093708'),
	// array('Membership_ID'=>'GCI9020936','Membership_code'=>'GCI1923595455'),
	// array('Membership_ID'=>'GCI4697837','Membership_code'=>'GCI1923595455'),
	// array('Membership_ID'=>'GCI8846960','Membership_code'=>'GCI1923595455'),
	// array('Membership_ID'=>'GCI0155771','Membership_code'=>'GCI3657781'),
	// array('Membership_ID'=>'GCI9970446','Membership_code'=>'GCI1918574907'),
	// array('Membership_ID'=>'GCI1918400901','Membership_code'=>'GCI1916481801'),
   );


    
// var_dump($arr);die();
    foreach ($arr as $key => $value) {
       echo $value['Membership_ID'].' - '.$value['Membership_code'].'<br>';
       $mem_code=$value['Membership_ID'];
       $rf_ID=$value['Membership_code'];

       $member['Reference_ID']=$this->db->get_where('gc_membership',array('Membership_code' => $rf_ID))->row('Membership_ID');
// echo '<br>';
       $mem=$this->db->get_where('gc_membership',array('Membership_code' => $mem_code))->row();

       $Membership_ID=$mem->Membership_ID;

       $mem_refc=$mem->Reference_ID;

       $mem_reg_from=$mem->Register_from;

       if($mem_reg_from=='admin'){
           $contract_data['Amount']=$this->db->get_where('gc_member_franchisee_contract',array('Membership_ID'=>$Membership_ID))->row('Amount');
       }else{
           $contract_data['Amount']=$this->db->get_where('gc_wallet_topup',array('Membership_ID'=>$Membership_ID))->row('Total_amount');
       }

       if($mem_refc!=$member['Reference_ID']){
	// echo '<br>';
        $Register_date=date('Y-m-d',strtotime($mem->Created_date));
// echo '<br>';

        $llmas=$this->db->get_where('gc_member_level_details',array('Child_ID' => $Membership_ID))->result_array();

// var_dump($llmas);
// die();
        if(!empty($llmas)){
            foreach ($llmas as $key => $value) {
               
               $this->db->where('Member_level_ID',$value['Member_level_ID'])->delete('gc_member_levels');
               $this->db->where('Member_level_ID',$value['Member_level_ID'])->delete('gc_member_level_details');
           }
       }

       $this->db->where('Parent_ID',$member['Reference_ID']);  
       $member_seq = $this->db->count_all_results('gc_franchisee_member_relation')+1;

       $franchisee_relation['Child_ID']        = $Membership_ID;
       $franchisee_relation['Parent_id']   = $member['Reference_ID'];
       $this->db->where('Child_ID', $Membership_ID);
       $this->db->update('gc_franchisee_member_relation', $franchisee_relation);

       echo $mem_code .' member updated in  gc_franchisee_member_relation table';
       echo '<br>';

       $member_update1['Reference_ID']   = $member['Reference_ID'];
       $member_update1['Reference_code']   = $rf_ID;
       $this->db->where('Membership_ID', $Membership_ID);
       $this->db->update('gc_membership', $member_update1);

       echo $mem_code .' member updated in  gc_membership table';
       echo '<br>';

       $member_update['Members_count']   = $member_seq;
       $this->db->where('Membership_ID', $member['Reference_ID']);
       $this->db->update('gc_membership', $member_update);


// Gold Offer Start
       
       if($Register_date >= '2019-05-01' && $Register_date <= '2019-08-08'){

          if($contract_data['Amount'] >= 10500 || $contract_data['Amount'] >= 25500 || $contract_data['Amount'] >= 50250 ){ 

             if($contract_data['Amount'] >= 10500 && $contract_data['Amount'] < 25500){
                $investor_part   =8;
                $sponsor_part    =4;
                $coordinator_part=2;
                $manager_part    =1;
                $head_part       =1;
            }

            if($contract_data['Amount'] >= 25500 && $contract_data['Amount'] < 50250){
                $investor_part   =20;
                $sponsor_part    =10;
                $coordinator_part=5;
                $manager_part    =2;
                $head_part       =2;
            }


            if($contract_data['Amount'] >= 50250){
                $investor_part   =45;
                $sponsor_part    =22;
                $coordinator_part=11;
                $manager_part    =5;
                $head_part       =5;
            }

            $gold=array(
             'Membership_ID'	    => $Membership_ID,
             'Child_ID'	        => '',
             'Level_ID'	        => '',
             'Child_investment'	=> $contract_data['Amount'],
             'Offer_value'	    => $investor_part,
             'Created_date'	    => $Register_date);

            $gl=$this->db->insert('gc_gold_offer',$gold);
        }


    }

// Gold Offer End

	//start Member binary Member Levels Insert
    $ref_ID="";$level_insert_id="";
    for($i=1;$i<=9;$i++){ 
        if($i==1){
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$member['Reference_ID']);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
                $binary=$query->result_array();
            //var_dump($binary);
                $crnt_lvl=$binary[0]['Current_level'];
                $level['Level_ID']=$i;
                if($crnt_lvl<=$i){
                    $member_level=$i;
                }
                else{
                    $member_level=$crnt_lvl;
                }
                $ref_ID=$binary[0]['Reference_ID'];
 // Member Level Master Insert start
                $levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
                $levels_master['Company_id']       =  1;
                $levels_master['Branch_id']        =  1;
                $levels_master['Level_ID']         =  1;
                $levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
                $levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
                $levels_master['Payout_status']    =  $binary[0]['Payout_status'];
                $levels_master['Date']   = $Register_date;
                $this->db->insert('gc_member_levels', $levels_master);
                $level_insert_id=$this->db->insert_id();

// Member Level Master Insert end         
// Member Level Details Insert start 
                $levels_data['Member_level_ID']  =  $level_insert_id;
                $levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
                $levels_data['Child_ID']         =  $Membership_ID;
                $levels_data['Company_id']       =  1;
                $levels_data['Branch_id']        =  1;
                $levels_data['Level_ID']         =  $level['Level_ID'];
            // $levels_data['Position']         =  $binary_relation['Ex_position_type'];
                $levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
                $levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
                $levels_data['Payout_status']    =  $binary[0]['Payout_status'];
                $levels_data['Level_date']       = $Register_date;
                $this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start
// Membership Current Level Insert start
                $mem_lvl['Member_grade']=NULL;
                $grade_count1=$this->db->where(array('Membership_ID'=>$binary[0]['Membership_ID'],'Level_ID'=>1))->count_all_results('gc_member_level_details');
			// echo $grade_count1;
                if($grade_count1>=6){
                 $mem_lvl['Member_grade']=3;
             }

             $grade_count2=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
             if($grade_count2>=6){
                 $mem_lvl['Member_grade']=2;
             }

             $grade_count3=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
             if($grade_count3>=6){
                 $mem_lvl['Member_grade']=1;
             }

             $mem_lvl['Current_level']=$member_level;
			// var_dump($mem_lvl);
             $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
             $this->db->update('gc_membership', $mem_lvl);

             if($Register_date >= '2019-05-01' && $Register_date <= '2019-08-08'){
               if($contract_data['Amount'] >= 10500 || $contract_data['Amount'] >= 25500 || $contract_data['Amount'] >= 50250 ){ 

                $gold_1=array(
                 'Membership_ID'	    => $binary[0]['Membership_ID'],
                 'Child_ID'	        => $Membership_ID,
                 'Level_ID'	        => $level['Level_ID'],
                 'Child_investment'	=> $contract_data['Amount'],
                 'Offer_value'	    => $sponsor_part,
                 'Created_date'	    => $Register_date);

                $gl_1=$this->db->insert('gc_gold_offer',$gold_1);

            }
        }

        $star=$this->set_green_star($binary[0]['Membership_ID']);
// Membership Current Level Insert end

    }
}
else{
    $this->db->select('*');
    $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
    $this->db->from('gc_membership as member');
    $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
    $this->db->where('member.Membership_ID',$ref_ID);
    $query= $this->db->get();
    if($query->num_rows() > 0) {
        $binary=$query->result_array();
        $crnt_lvl=$binary[0]['Current_level'];
        $level['Level_ID']=$i;
        if($crnt_lvl<=$i){
            $member_level=$i;
        }
        else{
            $member_level=$crnt_lvl;
        }
        $ref_ID=$binary[0]['Reference_ID'];

 // Member Level Master Insert start
        $levels_master['Membership_ID']    =  $binary[0]['Membership_ID'];
        $levels_master['Company_id']       =  1;
        $levels_master['Branch_id']        =  1;
        $levels_master['Level_ID']         =  $level['Level_ID'];
        $levels_master['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
        $levels_master['New_payout_ID']    =  $binary[0]['New_payout_ID'];
        $levels_master['Payout_status']    =  $binary[0]['Payout_status'];
        $this->db->insert('gc_member_levels', $levels_master);
        $levels_master['Date']             = $Register_date;
        $level_insert_id=$this->db->insert_id();
// Member Level Master Insert end         
// Member Level Details Insert start 
        $levels_data['Member_level_ID']  =  $level_insert_id;
        $levels_data['Membership_ID']    =  $binary[0]['Membership_ID'];
        $levels_data['Child_ID']         =  $Membership_ID;
        $levels_data['Company_id']       =  1;
        $levels_data['Branch_id']        =  1;
        $levels_data['Level_ID']         =  $level['Level_ID'];
            // $levels_data['Position']         =  $binary_relation['Ex_position_type'];
        $levels_data['Old_payout_ID']    =  $binary[0]['Old_payout_ID'];
        $levels_data['New_payout_ID']    =  $binary[0]['New_payout_ID'];
        $levels_data['Payout_status']    =  $binary[0]['Payout_status'];
        $levels_data['Level_date']       = $Register_date;
        $this->db->insert('gc_member_level_details', $levels_data);
// Member Level Details Insert start

// Membership Current Level Insert start
        $mem_lvl['Member_grade']=NULL;
        $grade_count1=$this->db->where(array('Membership_ID'=>$binary[0]['Membership_ID'],'Level_ID'=>1))->count_all_results('gc_member_level_details');
			// echo $grade_count1;
        if($grade_count1>=6){
         $mem_lvl['Member_grade']=3;
     }
     $grade_count2=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
     if($grade_count2>=6){
         $mem_lvl['Member_grade']=2;
     }
     $grade_count3=$this->db->where(array('level.Membership_ID'=>$binary[0]['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
     if($grade_count3>=6){
         $mem_lvl['Member_grade']=1;
     }

			// var_dump($mem_lvl);
     $mem_lvl['Current_level']=$member_level;
     $this->db->where('Membership_ID',$binary[0]['Membership_ID']);
     $this->db->update('gc_membership', $mem_lvl);

     if($Register_date >= '2019-05-01' && $Register_date <= '2019-08-08'){
       if($contract_data['Amount'] >= 10500 || $contract_data['Amount'] >= 25500 || $contract_data['Amount'] >= 50250 ){ 
        if($mem_lvl['Member_grade']==3 || $mem_lvl['Member_grade']==2 || $mem_lvl['Member_grade']==1 ){
           if($mem_lvl['Member_grade']==3){
              $offer=$coordinator_part;
          }elseif($mem_lvl['Member_grade']==2){
              $offer=$manager_part;
          }elseif($mem_lvl['Member_grade']==1){
              $offer=$head_part;						
          }
          $gold_2=array(
             'Membership_ID'	    => $binary[0]['Membership_ID'],
             'Child_ID'	        => $Membership_ID,
             'Level_ID'	        => $level['Level_ID'],
             'Child_investment'	=> $contract_data['Amount'],
             'Offer_value'	    => $offer,
             'Created_date'	    => $Register_date);

          $gl_2=$this->db->insert('gc_gold_offer',$gold_2);
      }	

      


  }

}


$star=$this->set_green_star($binary[0]['Membership_ID']);
// Membership Current Level Insert end            




}

}
}

echo $mem_code .' member updated in  Level & Level Details table';
echo '<br>';
}


}
// var_dump($arr);die();
// $mem_code=$this->input->get('Membership_code');
// $rf_ID='GCI1918570408';
// echo '<br>';
// $rf_ID=$this->input->get('Reference_code');


}

function checkfun(){
	echo $payment_mode=$this->db->get_where('gc_wallet_payments',array('Service_point_ID' => 6))->result_array()[0]['Payment_type_ID'];
}

function ck(){
	$ref_ID=4088;
	$this->db->select('member.Membership_ID,member.Commission_mode,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Payout_status,contract.Amount,contract.Pay_date,contract.Lvl_pay_date,contract.Payout_date,contract.Doc_status,contract.Payout_count,member.Mobile,member.First_name');
 $this->db->from('gc_membership as member');
 $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
 $this->db->where('member.Membership_ID',$ref_ID);
 $this->db->where('member.Commission_mode',1);
			// $this->db->where('member.Membership_type',1);
 $this->db->where('contract.Contract_status',6);
 $this->db->where('contract.Withdrawn_status',5);
 $this->db->where('contract.Contract_ID IS NOT NULL');


 $query= $this->db->get();
 if($query->num_rows() > 0) {
    
     $binary=$query->result_array();var_dump($binary);
     if($binary[0]['Commission_mode']==1){

         $crnt_lvl=$binary[0]['Current_level'];
         $level['Level_ID']=3;
		   //  if($crnt_lvl<=$i){
         
		   //  }
		   //  else{
		   //     $level['Level_ID']=$crnt_lvl;
		   // }
         $ref_ID=$binary[0]['Reference_ID'];

         $this->db->select('level.Member_level_detail_ID,lvl.Return,contract.Contract_ID,contract.Payout_status,contract.Amount as Value');
         $this->db->from('gc_member_level_details as level');
         $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
			// $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
         $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
         $this->db->where('level.Child_ID',$ref_ID);
         $this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
			//$this->db->where('level.Level_ID',$level['Level_ID']);
         $query= $this->db->get();
         $level_details=$query->result_array();
         if(!empty($level_details)){
            var_dump($level_details);
        }
    }
}
}


public function leader(){
    $members=$this->db->select('Membership_ID')->get('gc_membership')->result_array();

// Team Co-ordinator Foreach start
    foreach ($members as $key => $value) {
       $count1=$this->db->where(array('Membership_ID'=>$value['Membership_ID'],'Level_ID'=>1))->count_all_results('gc_member_level_details');
       if($count1>=6){
          $mbr['Member_grade']=3;
          $this->db->where('Membership_ID',$value['Membership_ID'])->update('gc_membership',$mbr);
      }
  }
// die();
// Team Co-ordinator Foreach End

// Team Leader Foreach start
  foreach ($members as $key => $value1) {
   
   $count2=$this->db->where(array('level.Membership_ID'=>$value1['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
   if($count2>=6){
      $mbr1['Member_grade']=2;
      $this->db->where('Membership_ID',$value1['Membership_ID'])->update('gc_membership',$mbr1);
  }
}

// Team Leader Foreach End

// die();

// Business head Foreach start
foreach ($members as $key => $value2) {
	// echo $value1['Membership_ID'].'<br>';
	$count3=$this->db->where(array('level.Membership_ID'=>$value2['Membership_ID'],'level.Level_ID'=>1,'member.Member_grade'=>2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
	if($count3>=6){
		$mbr2['Member_grade']=1;
		$this->db->where('Membership_ID',$value2['Membership_ID'])->update('gc_membership',$mbr2);
	}
}
// die();
// Business head Foreach End	



}

function star(){

    $members=$this->db->select('Membership_ID,Created_date,Membership_mode')->where('DATE(Created_date)<','2019-05-1')->get('gc_membership')->result_array();
// echo '<pre>';
// print_r($members);die();
    foreach ($members as $key => $value) {
       $Membership_ID=$value['Membership_ID'];
       $members1=$this->db->select('Membership_ID,Created_date,Membership_mode')->where('Membership_ID',$Membership_ID)->get('gc_membership')->result_array();
       $start_date=date('Y-m-d',strtotime($value['Created_date']));
	// foreach ($members as $key => $value) {
       $cur_pyt=date('Y-m-d',strtotime($this->db->get_where('gc_member_franchisee_contract',array('Invest_type'=>1,'Membership_ID'=>$Membership_ID))->row('Payout_date')));

       $py_days=15-1;
       $cur_payout=date('Y-m-d', strtotime($cur_pyt. ' + '.$py_days.' days'));
       $payout_date=$this->get_excat_next_payout($cur_payout);		

	// }

// find Star 1 start
       $days1=30;
       $level_ID1=1;
       $end_sate1=date('Y-m-d', strtotime($start_date. ' + '.$days1.' days'));
       $b_status1=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID1))->count_all_results('gc_green_star');
       if($b_status1<=0){
           $green_count1=$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID1,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate1,'contract.Invest_type',2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
           if($green_count1>=10){
             $this->db->where('Membership_ID',$Membership_ID);
             $this->db->set('Status', "6", FALSE);     
             $this->db->update('gc_green_star');
             $green1=array(
               'Membership_ID'=>$Membership_ID,
               'Star'         =>1,
               'Level'		   =>$level_ID1,
               'Members_count'=>$green_count1,
               'Created_date' =>date('Y-m-d'),
               'Payout_date'  =>$payout_date,
               'Status'       =>1,
               'Benefit'      =>140
           );
             
             $this->db->insert('gc_green_star',$green1);
         }
     }


// find Star 1 end


// find Star 2 start
     $days2=60;
     $level_ID2=2;
     $end_sate2=date('Y-m-d', strtotime($start_date. ' + '.$days2.' days'));
     $b_status2=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID2))->count_all_results('gc_green_star');
     if($b_status2<=0){
       $green_count2=$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID2,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate2,'contract.Invest_type',2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
       if($green_count2>=50){
         $this->db->where('Membership_ID',$Membership_ID);
         $this->db->set('Status', "6", FALSE);     
         $this->db->update('gc_green_star');
         $green2=array(
           'Membership_ID'=>$Membership_ID,
           'Star'         =>2,
           'Level'		   =>$level_ID2,
           'Members_count'=>$green_count2,
           'Created_date' =>date('Y-m-d'),
           'Payout_date'  =>$payout_date,
           'Status'       =>1,
           'Benefit'      =>700
       );
         
         $this->db->insert('gc_green_star',$green2);
     }
 }


// find Star 2 end


// find Star 3 start
 $days3=100;
 $level_ID3=3;
 $end_sate3=date('Y-m-d', strtotime($start_date. ' + '.$days3.' days'));
 $b_status3=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID3))->count_all_results('gc_green_star');
 if($b_status3<=0){
   $green_count3=$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID3,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate3,'contract.Invest_type',2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
   if($green_count3>=250){
     $this->db->where('Membership_ID',$Membership_ID);
     $this->db->set('Status', "6", FALSE);     
     $this->db->update('gc_green_star');
     $green3=array(
       'Membership_ID'=>$Membership_ID,
       'Star'         =>3,
       'Level'		   =>$level_ID3,
       'Members_count'=>$green_count3,
       'Created_date' =>date('Y-m-d'),
       'Payout_date'  =>$payout_date,
       'Status'       =>1,
       'Benefit'      =>2150
   );
     
     $this->db->insert('gc_green_star',$green3);
 }
}


// find Star 3 end


// find Star 4 start
$days4=120;
$level_ID4=4;
$end_sate4=date('Y-m-d', strtotime($start_date. ' + '.$days4.' days'));
$b_status4=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID4))->count_all_results('gc_green_star');
if($b_status4<=0){
	$green_count4=$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID4,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate4,'contract.Invest_type',2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
	if($green_count4>=550){
     $this->db->where('Membership_ID',$Membership_ID);
     $this->db->set('Status', "6", FALSE);     
     $this->db->update('gc_green_star');
     $green=array(
       'Membership_ID'=>$Membership_ID,
       'Star'         =>4,
       'Level'		   =>$level_ID4,
       'Members_count'=>$green_count4,
       'Created_date' =>date('Y-m-d'),
       'Payout_date'  =>$payout_date,
       'Status'       =>1,
       'Benefit'      =>4250
   );
     
     $this->db->insert('gc_green_star',$green4);
 }
}


// find Star 4 end

// find Star 5 start
$days5=150;
$level_ID5=5;
$end_sate5=date('Y-m-d', strtotime($start_date. ' + '.$days5.' days'));
$b_status5=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID5))->count_all_results('gc_green_star');
if($b_status5<=0){
	$green_count5=$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID5,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate5,'contract.Invest_type',2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->join('gc_member_franchisee_contract as contract','contract.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
	if($green_count5>=1200){
     $this->db->where('Membership_ID',$Membership_ID);
     $this->db->set('Status', "6", FALSE);     
     $this->db->update('gc_green_star');
     $green5=array(
       'Membership_ID'=>$Membership_ID,
       'Star'         =>5,
       'Level'		   =>$level_ID5,
       'Members_count'=>$green_count5,
       'Created_date' =>date('Y-m-d'),
       'Payout_date'  =>$payout_date,
       'Status'       =>1,
       'Benefit'      =>7000
   );
     
     $this->db->insert('gc_green_star',$green5);
 }
}


// find Star 5 end
}





}

function star1(){

    $members=$this->db->select('Membership_ID,Created_date,Membership_mode')->where('DATE(Created_date)>=','2019-05-1')->get('gc_membership')->result_array();
// echo '<pre>';
// print_r($members);die();
    foreach ($members as $key => $value) {
       $Membership_ID=$value['Membership_ID'];
	// $Membership_ID=4370;
       $members1=$this->db->select('Membership_ID,Created_date,Membership_mode')->where('Membership_ID',$Membership_ID)->get('gc_membership')->result_array();
       $start_date=date('Y-m-d',strtotime($value['Created_date']));
	// foreach ($members as $key => $value) {
       $cur_pyt=date('Y-m-d',strtotime($this->db->get_where('gc_member_franchisee_contract',array('Invest_type'=>1,'Membership_ID'=>$Membership_ID))->row('Payout_date')));

       $py_days=15-1;
       $cur_payout=date('Y-m-d', strtotime($cur_pyt. ' + '.$py_days.' days'));
       $payout_date=$this->get_excat_next_payout($cur_payout);		

	// }

// find Star 1 start
       $days1=30;
       $level_ID1=1;
       $end_sate1=date('Y-m-d', strtotime($start_date. ' + '.$days1.' days'));
       $b_status1=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID1))->count_all_results('gc_green_star');
// var_dump('1-level-'.$b_status1);
       if($b_status1<=0){
           $green_count1=$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID1,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate1))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
	// var_dump('1.1-level-'.$green_count1);
           if($green_count1>=10){
             $this->db->where('Membership_ID',$Membership_ID);
             $this->db->set('Status', "6", FALSE);     
             $this->db->update('gc_green_star');
             $green1=array(
               'Membership_ID'=>$Membership_ID,
               'Star'         =>1,
               'Level'		   =>$level_ID1,
               'Members_count'=>$green_count1,
               'Created_date' =>date('Y-m-d'),
               'Payout_date'  =>$payout_date,
               'Status'       =>1,
               'Benefit'      =>140
           );
             
             $this->db->insert('gc_green_star',$green1);
         }
     }


// find Star 1 end


// find Star 2 start
     $days2=60;
     $level_ID2=2;
     $end_sate2=date('Y-m-d', strtotime($start_date. ' + '.$days2.' days'));
     $b_status2=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID2))->count_all_results('gc_green_star');
// var_dump('2-level-'.$b_status2);
     if($b_status2<=0){
       $green_count2=$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID2,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate2))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
	// var_dump('2.1-level-'.$green_count2);
       if($green_count2>=50){
         $this->db->where('Membership_ID',$Membership_ID);
         $this->db->set('Status', "6", FALSE);     
         $this->db->update('gc_green_star');
         $green2=array(
           'Membership_ID'=>$Membership_ID,
           'Star'         =>2,
           'Level'		   =>$level_ID2,
           'Members_count'=>$green_count2,
           'Created_date' =>date('Y-m-d'),
           'Payout_date'  =>$payout_date,
           'Status'       =>1,
           'Benefit'      =>700
       );
         
         $this->db->insert('gc_green_star',$green2);
     }
 }


// find Star 2 end


// find Star 3 start
 $days3=100;
 $level_ID3=3;
 $end_sate3=date('Y-m-d', strtotime($start_date. ' + '.$days3.' days'));
 $b_status3=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID3))->count_all_results('gc_green_star');
// var_dump('3-level-'.$b_status3);
 if($b_status3<=0){
   $green_count3=$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID3,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate3))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
	// var_dump('3.1-level-'.$green_count3);
   if($green_count3>=250){
     $this->db->where('Membership_ID',$Membership_ID);
     $this->db->set('Status', "6", FALSE);     
     $this->db->update('gc_green_star');
     $green3=array(
       'Membership_ID'=>$Membership_ID,
       'Star'         =>3,
       'Level'		   =>$level_ID3,
       'Members_count'=>$green_count3,
       'Created_date' =>date('Y-m-d'),
       'Payout_date'  =>$payout_date,
       'Status'       =>1,
       'Benefit'      =>2150
   );
     
     $this->db->insert('gc_green_star',$green3);
 }
}


// find Star 3 end


// find Star 4 start
$days4=120;
$level_ID4=4;
$end_sate4=date('Y-m-d', strtotime($start_date. ' + '.$days4.' days'));
$b_status4=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID4))->count_all_results('gc_green_star');
// var_dump('4-level-'.$b_status4);
if($b_status4<=0){
	$green_count4=$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID4,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate4))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
	// var_dump('4.1-level-'.$green_count4);
	if($green_count4>=550){
     $this->db->where('Membership_ID',$Membership_ID);
     $this->db->set('Status', "6", FALSE);     
     $this->db->update('gc_green_star');
     $green=array(
       'Membership_ID'=>$Membership_ID,
       'Star'         =>4,
       'Level'		   =>$level_ID4,
       'Members_count'=>$green_count4,
       'Created_date' =>date('Y-m-d'),
       'Payout_date'  =>$payout_date,
       'Status'       =>1,
       'Benefit'      =>4250
   );
     
     $this->db->insert('gc_green_star',$green4);
 }
}


// find Star 4 end

// find Star 5 start
$days5=150;
$level_ID5=5;
$end_sate5=date('Y-m-d', strtotime($start_date. ' + '.$days5.' days'));
$b_status5=$this->db->where(array('Membership_ID'=>$Membership_ID,'Level'=>$level_ID5))->count_all_results('gc_green_star');
// var_dump('5-level-'.$b_status5);
if($b_status5<=0){
	$green_count5=$this->db->where(array('level.Membership_ID'=>$Membership_ID,'level.Level_ID'=>$level_ID5,'member.Membership_mode'=>1,'DATE(member.Created_date)>='=>$start_date,'DATE(member.Created_date)<='=>$end_sate5))->join('gc_membership as member','member.Membership_ID=level.Child_ID','left')->count_all_results('gc_member_level_details as level');
	// var_dump('5.1-level-'.$green_count5);
	if($green_count5>=1200){
     $this->db->where('Membership_ID',$Membership_ID);
     $this->db->set('Status', "6", FALSE);     
     $this->db->update('gc_green_star');
     $green5=array(
       'Membership_ID'=>$Membership_ID,
       'Star'         =>5,
       'Level'		   =>$level_ID5,
       'Members_count'=>$green_count5,
       'Created_date' =>date('Y-m-d'),
       'Payout_date'  =>$payout_date,
       'Status'       =>1,
       'Benefit'      =>7000
   );
     
     $this->db->insert('gc_green_star',$green5);
 }
}


// find Star 5 end
}

}

function gold(){
	$Register_date ='2019-05-05';
	$contract_amount=10500;
  if($reg_date >='2019-05-01' && $reg_date <= '2019-08-08'){

     if($contract_amount >= 10500){
        $investor_part=8;
        $sponsor_part =4;
        $coordinator_part=2;
        $manager_part =1;
        $head_part    =1;
    }

    if($contract_amount >= 25500){
        $investor_part=20;
        $sponsor_part =10;
        $coordinator_part=5;
        $manager_part =2;
        $head_part    =2;
    }


    if($contract_amount >= 50250){
        $investor_part=45;
        $sponsor_part =22;
        $coordinator_part=11;
        $manager_part =5;
        $head_part    =5;
    }


}
}

function downline(){

	//$parents=[];
	$final_array=[];
	$final_left_tree=[];
    $membership_id=[2737];
    if(!empty($membership_id)){
     $limit=1;
     for($i=1;$i<=$limit;$i++){

        $this->db->select('tree.Child_ID,member.Membership_code,CONCAT(member.First_name,member.Last_name) as Name,member.Mobile,member.Current_level');
        $this->db->from('gc_franchisee_member_relation as tree');
        $this->db->join('gc_membership as member', 'member.Membership_ID = tree.Child_ID', 'left');
        $this->db->where_in('tree.Parent_ID',$membership_id);
        $query4 = $this->db->get();

        if($query4->num_rows() > 0){
            $binary4=$query4->result_array();
            $membership_id=[];
            foreach ($binary4 as $key => $value) {
               $tmp=[];
               array_push($membership_id,$value['Child_ID']);
               $tmp=array('Membership_ID'=>$value['Child_ID'],
                'Membership_code'=>$value['Membership_code'],
                'Name'=>$value['Name'],
                'Level'=>$value['Current_level'],
                'Mobile'=>$value['Mobile']);
               array_push($final_array,$tmp);
           }
                                // echo "<pre>";
                                // print_r($membership_id);
           $limit++;
       }else{
           $membership_id=[];
       }
       
   }
}

                        // echo "<pre>";
                        // print_r($final_left_tree);
                        // print_r($final_array);
return $final_array;

}

function goog(){
	$binary_value['Membership_ID']=2751;
   $this->db->select('sum(contract.Amount) as Vol_am,count(level.Child_ID) as Vol_cnt');
					// $this->db->select('level.Child_ID');
   $this->db->from('gc_member_level_details as level');
   $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = level.Child_ID', 'left');
					 // $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
   $this->db->join('gc_membership as member', 'member.Membership_ID = level.Child_ID', 'left');
   $this->db->where('level.Membership_ID',$binary_value['Membership_ID']);
   $this->db->where('level.Level_ID',1);
   $this->db->where('member.Status',6);
   $this->db->where('contract.Withdrawn_status',5);
					 // $this->db->where('contract.Contract_ID',$tran['Contract_ID']);
   $query_volume = $this->db->get();
   $Volume_amnt=$query_volume->result_array();
   var_dump($Volume_amnt);die();
}



public function all_data(){
    $this->load->model('Report_model');
    $status = 4;  
    $status1 = 12;  
    $status2 = '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19'; 
    $this->load->model('member/Membership_model');
    $template['members'] =  $this->Membership_model->getall_members_payment($status,$status1,$status2);
    $this->load->view('membership/ajax_payment_new',$template);
}

public function account_data(){
    $this->load->model('Report_model');
    $status = 4;  
    $status1 = 12;  
    $status2 = '4,5,6,7,8,9,10,11,12,13,14,15,16,17,18';  
    $this->load->model('member/Membership_model');
    $template['members'] = $this->Membership_model->getall_members_payment($status,$status1,$status2);
    $this->load->view('membership/ajax_payment_new',$template);
}

public function conversion_data(){
    $this->load->model('Report_model');
    $status = 4;  
    $status1 = 12;  
    $status2 = 19;  
    $this->load->model('member/Membership_model');
    $template['members'] = $this->Membership_model->getall_members_payment($status,$status1,$status2);
    $this->load->view('membership/ajax_payment_new',$template);
}

public function cash_data(){
    $this->load->model('Report_model');
    $status = 4;  
    $status1 = 12;  
    $status2 = '1,2,3';  
    $this->load->model('member/Membership_model');
    $template['members'] = $this->Membership_model->getall_members_payment($status,$status1,$status2);
    $this->load->view('membership/ajax_payment_new',$template);
}

function check_remark(){
	date_default_timezone_set('Asia/Kolkata');
	$remark='-[Membership_type@'.date('Y-m-d H:i:s').']';
	$remark1=2;
	$this->db->where('Membership_ID',1);
	$this->db->set('Update_history', "CONCAT(Update_history,'$remark')", FALSE);     
	$this->db->set('UDF2', "10", FALSE);     
	$this->db->update('gc_membership');
}

// public function check_payment_table(){
// 	$payment=array(array('Membership_ID' => 10499, 'Contract_ID' =>11000,'Amount'=>1500,'Date'=>'2019-06-20','Payment_type_ID'=>6,'Bank_ID'=>26));

// foreach($payment as $value){
// 	echo '<pre>';
// 	print_r($value);echo '<br>';

// 	$count=$this->db->where('Membership_ID',$value['Membership_ID'])->count_all_results('gc_member_payments');
// 	if($count=0){
// 		$this->db->insert('gc_member_payments',$value);
// 		echo 'Inserted ID is  : '. $this->db->insert_id().'<br>';
// 	}


// }


// }

function check_contract_code(){
	$contract=$this->db->select('Contract_ID')->order_by('Contract_ID','ASC')->get('gc_member_franchisee_contract')->result_array();
	$i=1;
	foreach ($contract as $key => $value) {
		echo $contract_code['Contract_ref_no']='GRNC-CNT-'.sprintf("%'.06d", $i);echo '<br>';
		$this->db->where('Contract_ID',$value['Contract_ID'])->update('gc_member_franchisee_contract',$contract_code);
	$i++;}

}
// function check_inc(){
// 		$increment1=(substr($this->db->select('Contract_ref_no')->order_by('Contract_ID','desc')->limit(1)->get('gc_member_franchisee_contract')->row('Contract_ref_no'),9))+1;
// 		echo $contract_code['Contract_ref_no']='GRNC-CNT-'.sprintf("%'.06d", $increment1);
// }

}
