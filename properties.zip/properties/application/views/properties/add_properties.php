  <?php error_reporting(0); ?>

<div class="content-wrapper">
  <div class="content">
    <header class="page-header">
      <div class="d-flex align-items-center">
        <div class="mr-auto">
          <h1 class="separator">Properties</h1>
          <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="/medical_probook/dashboard/dashboard"><i class="icon dripicons-home"></i></a></li>
              <li class="breadcrumb-item"><a href="/medical_probook/dashboard/dashboard">Master</a></li>
              <li class="breadcrumb-item active" aria-current="page">Properties</li>
            </ol>
          </nav>
        </div>
        <ul class="actions top-right">
          <li class="dropdown">
            <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
              <i class="la la-ellipsis-h"></i>
            </a>
            <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right">
              <div class="dropdown-header">
                Quick Actions
              </div>
              <a href="#" class="dropdown-item">
                <i class="icon dripicons-clockwise"></i> Refresh
              </a>
              <a href="#" class="dropdown-item">
                <i class="icon dripicons-gear"></i> Manage Widgets
              </a>
              <a href="#" class="dropdown-item">
                <i class="icon dripicons-cloud-download"></i> Export
              </a>
              <a href="#" class="dropdown-item">
                <i class="icon dripicons-help"></i> Support
              </a>
            </div>
          </li>
        </ul>
      </div>
    </header>
    <form id="properties_dt" method="POST" action="<?php echo base_url(); ?>properties/Properties/adding">
      <section class="page-content container-fluid" style="padding-bottom: 0px;">
        <div class="row">
          <div class="col-12">
            <?php
            //var_dump($running_number);
            ?>
            <div class="card">
              <h5 class="card-header" style="background: #1e5598;">
              <div style="float: left;color: #fff;">
                Properties
              </div>
              <div id="tagsname"></div>
              </h5>
              <!-- <form maehtod="POST" > -->
              <div class="card-body">
                <div class="form-body">
                  <div class="row">
                    <!-- duration -->
                    <!-- <div class="col-md-6"> -->
                      <div class="card col-md-12" style="padding-bottom: 12px;">
                        <div class="form-body">
                          <!-- <div class="col-md-12"> -->
                            <div class="row">
                              <!-- LEFT -->
                              <!-- <div class="col-md-12"> -->

                                <div class="form-group col-md-4">
                                  <label class="col-form-label-lg control-label" for="validationCustom01">Company</label> <span class="text-danger">*</span>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text " id="basic-icon-addon1"><i class="la la-building"></i></span>
                                    </div>
                                    <select class="form-control need custom-select category custom-select my_region" id="company_id" autocomplete="off" required="" name="properties[company_id]" style="width: 90%;">
                                      <option value=''>Select Company </option>
                                      <?php
                                                if (!empty($companies)) {
                                                    foreach ($companies as $company) {
                                                        ?>
                                            <option value="<?php echo ucfirst($company['company_id']); ?>" <?php echo ($company['company_id'] == 0) ? 'selected' : ''; ?>><?php echo ucfirst($company['company_name']); ?></option>
                                            <?php } } ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-md-4">
                                            <label class="col-form-label-lg control-label" for="largeInput">Property Name <span style="color:red">*</span> </label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control  text-capitalize properties_name
                                            " aria-label="Icon Left" autofocus aria-describedby="basic-icon-addon1" name="properties[properties_name]" placeholder="Enter Property Name" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>

                                <div class="form-group col-md-4">
                                            <label class="col-form-label-lg control-label" for="largeInput">Location <span style="color:red">*</span> </label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control  text-capitalize location
                                            " aria-label="Icon Left" autofocus aria-describedby="basic-icon-addon1" name="properties[location]" placeholder="Enter Location" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                
                                <div class="form-group col-md-4">
                                            <label class="col-form-label-lg control-label" for="largeInput">Maintainance Person <span style="color:red">*</span> </label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control  text-capitalize maintainance_person
                                            " aria-label="Icon Left" autofocus aria-describedby="basic-icon-addon1" name="properties[maintainance_person]" placeholder="Enter Maintainance Person Name" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>
                                <div class="form-group col-md-4">
                                            <label class="col-form-label-lg control-label" for="largeInput">Maintainance Person Contact No <span style="color:red">*</span> </label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control  text-capitalize contact_no
                                            " aria-label="Icon Left" autofocus aria-describedby="basic-icon-addon1" name="properties[contact_no]" placeholder="Contact No" required="" type="text" maxlength="10">
                                            </div>                                            
                                         </div>

                                         <div class="form-group col-md-4">
                                            <label class="col-form-label-lg control-label" for="largeInput">Total Phase / Floor <span style="color:red">*</span> </label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control  text-capitalize total_phase
                                            " aria-label="Icon Left" autofocus aria-describedby="basic-icon-addon1" name="properties[total_phase]" placeholder="Total Phase / Floor" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>

                                         <div class="form-group col-md-4">
                                            <label class="col-form-label-lg control-label" for="largeInput">No.of Units <span style="color:red">*</span> </label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control  text-capitalize no_of_units
                                            " aria-label="Icon Left" autofocus aria-describedby="basic-icon-addon1" name="properties[no_of_units]" placeholder="No.of Units" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>

                                         <div class="form-group col-md-4">
                                            <label class="col-form-label-lg control-label" for="largeInput">Rental Units <span style="color:red">*</span> </label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control  text-capitalize rental_unit
                                            " aria-label="Icon Left" autofocus aria-describedby="basic-icon-addon1" name="properties[rental_unit]" placeholder="Rental Unit" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>

                                         <div class="form-group col-md-4">
                                            <label class="col-form-label-lg control-label" for="largeInput">Rental Squareft <span style="color:red">*</span> </label>
                                            <div class="input-group mb-3">
                                               <div class="input-group-prepend">
                                                  <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-balance zmdi-hc-fw"></i></span>
                                               </div>
                                               <input class="form-control  text-capitalize rental_sqft
                                            " aria-label="Icon Left" autofocus aria-describedby="basic-icon-addon1" name="properties[rental_sqft]" placeholder="Rental Squareft" required="" type="text" maxlength="50">
                                            </div>                                            
                                         </div>

                                         <!-- <div class="form-group col-md-4">
                                            
                                              <button class="btn btn-success" style="margin-top: 36px;" stype="submit">submit</button>
                                            </div> -->                                            
                                         </div>
                                         <div class="card-footer bg-light ">
                            <button class="btn btn-success" type="submit">Submit</button>
                            <a href="<?php echo base_url(); ?>properties/Properties" class="btn btn-accent">Cancel</a>
                            </div>
                                        
                              <!-- </div> -->
                              <!-- RIGHT -->
                             
                                  
                              </div>
                            <!-- </div> -->
                          </div>
                        </div>
                      <!-- </div> -->
                    </div>
                  
                  </div>
                 
                </div>                
                <br/>
                <!-- Table -->
                
                
              </div>
            </section>
          </form>
        </div>
      </div>
  <script>

    var remark_pack = [];

  $(document).ready(function(){
    $('#company_id').select2();
    $('#properties_id').select2();

    $('#company_id').change(function(){
      company=$(this).val();
    $.ajax({
    type: "POST",
    url: "<?php echo base_url(); ?>properties/Properties/get_company_based_properties",
    data: {company: company},
    cache: true,
    dataType: 'html',
    async: false,
    success: function(data){
     if(data!=0){
      $('#properties_id').empty().append(data);
    }else{
      swal('No Properties Available in Selected Company,Please Select Another..!')
      $('#company_id').val('');
      $('#properties_id').empty();

    }
    
    }
    });
    })
      // get_filtered_product_list();
      // 
      // $('.square_meter').keyup(function(){
      //   row_calc();
      // });
  });     

$(document).on('keyup', '.square_meter', function(e) {
row_calc();
});



  // $(document).on('keyup', '.unit', function(e) {
  // alert();
  // });

  $( "#s2_demo1" ).change(function() {
      region_based_team();
      complete_reset();
  });

  $('.team').change(function(){
      team_based_prefix_data();
      region_based_customer();
      complete_reset_team();      
  });

  $('.customer_selection').change(function(){
      customer_based_advice_select();
      // complete_reset();
  });

  $('.dc_advice_multi_select').change(function(){
       advice_selection_process();
       get_filtered_product_list('1'); 
       clear_all_rows_expect_1();             
  });

 $(document).on('change','.product_static',function(){  
    var id = $(this).parents('tr:first').attr('id');
    unit_data(id);
    get_all_quantity_stock(id);
    product_based_batch(id);
    product_filteration();
    clear_product_based(id);
  });

 $(document).on('change','#company_id',function(){  
    
  });
 

 $(document).on('change','.batch_static',function(){
      var id = $(this).parents('tr:first').attr('id');      
      clear_batch_based(id);      
      batch_selection_exp_date(id);
      stock_advice_check(id);
      calculate_total(id);
      bottom_total();
      product_filteration();
  });

 $(document).on('keyup','.advice_static',function(){
      var id = $(this).parents('tr:first').attr('id');      
      range_quantity_dc_action(id);      
      calculate_total(id);
      bottom_total();   
      flag_qty();
      stock_advice_check_for_advice_qty_change(id);         
  });

  var count = 1;
  $('.add_new_box').click(function(){ 
      count = count+1;     
      add_new_row_box(count);
      get_filtered_product_list(count);
      minimum_one_row_must_validation();
      all_row_id_base();
  });

  // Remove The Added Box

$(document).on('click', '.close_x', function(e) {      
      var id = $(this).parents('tr:first').attr('id');
      // var product_id = $('.product_select_'+id).val();
      $('#'+id+'').remove();
      // $('.product_static').each(function(){
      //   var value = $(this).val();
      //   if(value === product_id){
      //       var this_id = $(this).parents('tr:first').attr('id');
      //     $('#'+this_id+'').remove();
      //   }
      // });
      minimum_one_row_must_validation();
      // bottom_total();
      all_row_id_base();
      row_calc();

});

 function all_row_id_base(){
  var all_id = [];
  $('.root').each(function(){
      var value = $(this).attr('id');
      all_id.push(value);
  });
    $('.details_count').val(all_id);
 }

 function row_calc(){
    var sum = 0;
        $(".square_meter").each(function() {
            var value = $(this).val();
            // add only if the value is number
            if(!isNaN(value) && value.length != 0) {
                sum += parseFloat(value);
            }
            
            $(".total_sqt").val(sum);
            $(".total_sqt").text(sum);

        });
 }

   function clear_product_based(id){
    $('#'+id).find('.exp_date_'+id).val('');
    $('#'+id).find('.stock_'+id).val('');
    // $('#'+id).find('.advice_quantity_'+id).val('');
    $('#'+id).find('.total_'+id).val('');
    $('.advice_compare_stock_error_qty_'+id).val('0');
    $('.advice_compare_stock_error_'+id).empty();
    $('.pending_'+id).val('0');
   }

   function complete_reset(){
    var first_row = $('.root').first('tr:first').attr('id');
    $('.root').each(function(){
        var id = $(this).attr('id');
        if(id != first_row){
          $('#'+id).remove();
        }
    });    
    $('.customer_selection').empty();
    $('.customer_selection').append('<option value="">Select Customer</option>');
    $('.product_static').empty();
    $('.batch_static').empty();
    $('.dc_advice_multi_select').empty();
    $('#'+first_row).find('input').val('');
    $('.advice_compare_stock_error_qty_'+first_row).val('0');
    $('.advice_compare_stock_error_'+first_row).empty();
    $('.pending_'+first_row).val('0');
    $("#"+first_row).find('.product_static').removeAttr('readonly', 'readonly');
    $("#"+first_row).find('.batch_static').removeAttr('readonly', 'readonly');
    $("#"+first_row).find('.advice_static').removeAttr('readonly', 'readonly');
    $("#"+first_row).find('.select2-selection').removeClass('stop_pointing');
    bottom_total();
  }
  function complete_reset_team(){
    var first_row = $('.root').first('tr:first').attr('id');
    $('.root').each(function(){
        var id = $(this).attr('id');
        if(id != first_row){
          $('#'+id).remove();
        }
    });    
    // $('.customer_selection').empty();
    $('.product_static').empty();
    $('.batch_static').empty();
    $('.dc_advice_multi_select').empty();
    $('#'+first_row).find('input').val('');
    $('.advice_compare_stock_error_qty_'+first_row).val('0');
    $('.pending_'+first_row).val('0');
    $("#"+first_row).find('.product_static').removeAttr('readonly', 'readonly');
    $("#"+first_row).find('.batch_static').removeAttr('readonly', 'readonly');
    $("#"+first_row).find('.advice_static').removeAttr('readonly', 'readonly');
    $("#"+first_row).find('.select2-selection').removeClass('stop_pointing');
    bottom_total();
  }

  function clear_all_rows_expect_1(){
    var first_row = $('.root').first('tr:first').attr('id');
    $('.root').each(function(){
        var id = $(this).attr('id');
        if(id != first_row){
          $('#'+id).remove();
        }
    });    
    get_filtered_product_list(first_row);
    product_based_batch(first_row);
    $('#'+first_row).find('input').val('');
    $('.advice_compare_stock_error_qty_'+first_row).val('0');
    $('.pending_'+first_row).val('0');
    $("#"+first_row).find('.product_static').removeAttr('readonly', 'readonly');
    $("#"+first_row).find('.batch_static').removeAttr('readonly', 'readonly');
    $("#"+first_row).find('.advice_static').removeAttr('readonly', 'readonly');
    $("#"+first_row).find('.select2-selection').removeClass('stop_pointing');
    $('.advice_compare_stock_error_'+first_row).empty();    
    bottom_total();
  }


  function get_all_quantity_stock(id){
      var region      = $('.my_region').val();    
      var advice_id   = $('.dc_advice_multi_select').val();
      var product_id  = $('.product_select_'+id).val();

      $.ajax({
               type: "POST",
               url: "<?php echo base_url(); ?>transaction/dc_entry/get_advice_quantity",
               data: {
                region: region,
                advice_id: advice_id,
                product_id: product_id,
               },
               cache: true,
               async: false,
               success: function(data){
                if(data != '0'){
                  var all_pending_qty = [];
                  $('.pending_q').each(function() {
                      var this_id = $(this).parents('tr:first').attr('id');
                      var this_product_id = $('.product_select_'+this_id).val();
                      if(product_id === this_product_id){
                          var pending_status = $('.pending_'+this_id).val();
                          var pending_quantity = $('.advice_compare_stock_error_qty_'+this_id).val();
                          if(pending_quantity != ''){
                            all_pending_qty.push(pending_quantity);
                          }
                      }
                  });
                  if(all_pending_qty != 0){

                    $('.advice_quantity_exact_'+id).val(all_pending_qty.slice(-1)[0]);
                    $('.advice_quantity_'+id).val(all_pending_qty.slice(-1)[0]);
                    $('.advice_range_quantity_'+id).val(all_pending_qty.slice(-1)[0]);
                  }else{

                    $('.advice_quantity_exact_'+id).val(data);
                    $('.advice_quantity_'+id).val(data);
                    $('.advice_range_quantity_'+id).val(data);
                  }
                 }else{
                  swal('No Quantity,Please Select Another Product');
                    $('.advice_quantity_'+id).val('');
                    $('.advice_range_quantity_'+id).val('');
                    get_filtered_product_list(id);
                 }
              }
             });           
  }

  function clear_batch_based(id){
    $('.exp_date_'+id).val('');
    $('.stock_'+id).val('');
    // $('.advice_quantity_'+id).val('');
    $('.advice_compare_stock_error_'+id).empty();
    $('.total_'+id).val('');

  }

  function calculate_total(id){
    var stock_data  = $('.stock_'+id).val();
    var quantity    = $('.advice_quantity_exact_'+id).val();
    // var final_total = parseInt(stock_data) + parseInt(advice_qty);

    var str_rate = $('.str_rate_'+id).val();
    var cgst     = $('.cgst_'+id).val();
    var sgst     = $('.sgst_'+id).val();
    var igst     = $('.igst_'+id).val();

  // Find Total
  var total_value = quantity * str_rate;

  // CGST SGST
  var cgst_data =  (str_rate / 100) * (cgst);
  var sgst_data =  (str_rate / 100) * (sgst);


  var final_total = total_value + cgst_data + sgst_data;

    if(isNaN(final_total)){
      $('.total_'+id).val('');    
    }else{
      $('.total_'+id).val(final_total.toFixed(2));      
    }
  }


  function stock_advice_check_for_advice_qty_change(id){
      var selected_stock = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('stock');
      var current_advice_qty = parseInt($('.advice_quantity_exact_'+id).val());
      var current_advice_avail_qty = parseInt($('.advice_quantity_'+id).val());
      

      if(current_advice_qty < current_advice_avail_qty){
        // Show error Message        
          $('.advice_compare_stock_error_'+id).empty();
          var pending_qty  = current_advice_avail_qty - current_advice_qty ;
          
          // $('.advice_quantity_exact_'+id).val(selected_stock);
          $('.advice_compare_stock_error_qty_'+id).val(pending_qty);
          $('.advice_compare_stock_error_'+id).append('<code> Pending Qty '+(pending_qty)+'</code>');
          $('.stock_'+id).val(selected_stock);
          $('.pending_'+id).val('1');

      }else{
          // $('.advice_quantity_exact_'+id).val(current_advice_qty);        
          $('.advice_compare_stock_error_'+id).empty(); 
          $('.stock_'+id).val(selected_stock);
          $('.pending_'+id).val('0');
          $('.advice_compare_stock_error_qty_'+id).val('0');
      }
  }


  function stock_advice_check(id){
      var selected_stock = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('stock');
      var current_advice_qty = $('.advice_quantity_'+id).val();

      if(current_advice_qty > selected_stock){
        // Show error Message        
          $('.advice_compare_stock_error_'+id).empty();
          var pending_qty  = current_advice_qty - selected_stock ;
          
          $('.advice_quantity_exact_'+id).val(selected_stock);
          $('.advice_compare_stock_error_qty_'+id).val(pending_qty);
          $('.advice_compare_stock_error_'+id).append('<code> Pending Qty '+(pending_qty)+'</code>');
          $('.stock_'+id).val(selected_stock);
          $('.pending_'+id).val('1');

      }else{
          $('.advice_quantity_exact_'+id).val(current_advice_qty);        
          $('.advice_compare_stock_error_'+id).empty(); 
          $('.stock_'+id).val(selected_stock);
          $('.pending_'+id).val('0');
          $('.advice_compare_stock_error_qty_'+id).val('0');
      }
  }

  function batch_selection_exp_date(id){

    var selected_expdate = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('expdate');
    $('.exp_date_'+id).val(selected_expdate);

    var selected_stock = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('stock');

    var selected_adviceqty = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('adviceqty');

    var selected_batchstrrate = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('batchstrrate');
    $('.str_rate_'+id).val(selected_batchstrrate);

    var selected_cgst = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('batchcgst');
    $('.cgst_'+id).val(selected_cgst);

    var selected_sgst = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('batchsgst');
    $('.sgst_'+id).val(selected_sgst);

    var selected_igst = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('batchigst');
    $('.igst_'+id).val(selected_igst);

    var selected_tax = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('taxid');
    $('.taxid_'+id).val(selected_tax);
   
  }

  function product_based_batch(id){

      var region      = $('.my_region').val();    
      var advice_id   = $('.dc_advice_multi_select').val();
      var product_id  = $('.product_select_'+id).val();
      var repearted_id  = $('.batch_filter').val();

       $.ajax({
                 type: "POST",
                 url: "<?php echo base_url(); ?>transaction/dc_entry/get_batch_number_suggesion",
                 data: {
                    region_id  : region,
                    advice_id  : advice_id,
                    product_id : product_id,
                    repearted_id : repearted_id,
                 },
                 cache: true,
                 async: false,
                 success: function(data){
                   $('.batch_select_'+id).empty();
                   $('.batch_select_'+id).append(data);
                  // alert(data);
                 }
               });

  }

  function unit_data(id){
    var selected_unit = $('.product_select_'+id).find('option[value="'+$('.product_select_'+id).val()+'"]').data('unit');
    $('.unit_'+id).val(selected_unit);
  }

  function get_filtered_product_list(id){
      var region      = $('.my_region').val();
      var team        = $('.team').val();
      var advice_id   = $('.dc_advice_multi_select').val();

      var all_product_zero = [];
        $('.pending_q').each(function() {
            var this_id = $(this).parents('tr:first').attr('id');
            var this_product_id = $('.product_select_'+this_id).val();
            // if(product_id === this_product_id){
                var pending_status = $('.pending_'+this_id).val();
                if(pending_status == '0'){
                  var removed_product_id = this_product_id;
                  all_product_zero.push(removed_product_id);
                }
            // }
        });

       $.ajax({
                 type: "POST",
                 url: "<?php echo base_url(); ?>transaction/dc_entry/advice_based_product_number",
                 data: {
                    region_id   : region,
                    team_id     : team,
                    advice_id   : advice_id,
                    stock_completed_products : all_product_zero,
                  },
                 cache: true,
                 async: false,
                 success: function(data){
                    $('.product_select_'+id).empty();
                    $('.product_select_'+id).append(data);
                 }
               });
  }

  function advice_selection_process(){
    var advice_val = Array.from($('.dc_advice_multi_select').val());
        remark_pack = [];
        if(advice_val.length === 0){
          collect_all_remarks('');
        }
       for (var i = 0; i <= advice_val.length-1; i++) {
         var selected = $('.dc_advice_multi_select').find('option[value="'+advice_val[i]+'"]').data('foo');
         collect_all_remarks(selected);
       }
  }

  function collect_all_remarks(data){
       remark_pack.push(data); 
       $('.advice_remarks').val(remark_pack);
  }

  function customer_based_advice_select(){
    var region    = $('.my_region').val();
    var team      = $('.team').val();
    var customer  = $('.customer_selection').val();

     $.ajax({
               type: "POST",
               url: "<?php echo base_url(); ?>transaction/dc_entry/dc_fileter_advice_list",
               data: {
                  region_id: region,
                  teaam_id: team,
                  customer_id: customer,
                },
               cache: true,
               async: false,
               success: function(data){
                // alert(data);
                $('.dc_advice_multi_select').empty();
                $('.dc_advice_multi_select').append(data);
               }
             });
  }

  function team_based_prefix_data(){
    $.ajax({
             type: "POST",
             url: "<?php echo base_url(); ?>transaction/Dc_entry/get_dc_prefix_number",
             data: {region_id: $( "#s2_demo1" ).val(),team_id: $(".team").val()},
             // dataType:'json',
             cache: true,
             async: false,
             success: function(data){
                // alert(data);   
               $('#Dc_no').val('');
               $('#Dc_no').val(data);     
             }
           });
  }

  function minimum_one_row_must_validation(){
    var total_rows = $('.root').length;
    // alert(total_rows);
    if(total_rows === 0){
      $('.sub_but').prop('disabled',true);
    }else{
      $('.sub_but').prop('disabled',false);      
    }
  }

  function region_based_team(){
      $.ajax({
             type: "POST",
             url: "<?php echo base_url(); ?>transaction/Dc_entry/regionbased_team",
             data: {region_id: $( "#s2_demo1" ).val()},
             // dataType:'json',
             cache: true,
             async: false,
             success: function(data){
               //alert(data);   
               $('.team').empty();  
               $('.team').append(data);       
             }
           });
  }

  function region_based_customer(){
      $.ajax({
             type: "POST",
             url: "<?php echo base_url(); ?>transaction/Dc_entry/regionbased_customer",
             data: {
              region_id: $( "#s2_demo1" ).val(),
              team_id: $(".team").val(),
            },
             // dataType:'json',
             cache: true,
             async: false,
             success: function(data){
               //alert(data);   
               $('.customer_name').empty();  
               $('.customer_name').append(data);       
             }
           });
  }

  function range_quantity_dc_action(id){

    var selected_stock = $('.batch_select_'+id).find('option[value="'+$('.batch_select_'+id).val()+'"]').data('stock');

    var avail_advice_qty = $('.advice_quantity_'+id).val();

    if(avail_advice_qty > selected_stock){
        var value = $('.advice_quantity_exact_'+id).val();
      if ((value !== '') && (value.indexOf('.') === -1)) {
          $('.advice_quantity_exact_'+id).val(Math.max(Math.min(value, $('.stock_'+id).val()), -$('.stock_'+id).val()));
      }
    }else{

      var value = $('.advice_quantity_exact_'+id).val();
      if ((value !== '') && (value.indexOf('.') === -1)) {
          $('.advice_quantity_exact_'+id).val(Math.max(Math.min(value, $('.advice_quantity_'+id).val()), -$('.advice_quantity_'+id).val()));
      }

    }


      
  }

// function advice_range(id){
//     var value = $('.advice_quantity_exact_'+id).val();
//       if ((value !== '') && (value.indexOf('.') === -1)) {
//           $('.advice_quantity_exact_'+id).val(Math.max(Math.min(value, $('.advice_range_quantity_'+id).val()), -$('.advice_range_quantity_'+id).val()));
//       }
// }

// function stock_range(id){
//     var value = $('.advice_quantity_exact_'+id).val();
//       if ((value !== '') && (value.indexOf('.') === -1)) {
//           $('.advice_quantity_exact_'+id).val(Math.max(Math.min(value, $('.stock_'+id).val()), -$('.stock_'+id).val()));
//       }
// }


  function bottom_total(){
    var stock = 0;
        $(".stock").each(function() {
            var value = $(this).val();
            if(!isNaN(value)) {
                stock += parseFloat(value);
            }
             $(".total_stock_qty").text(stock.toFixed(2));
             $(".total_stock_qty").val(stock.toFixed(2) );
        });
    var advice = 0;
        $(".advice_static").each(function() {
            var value = $(this).val();
            if(!isNaN(value)) {
                advice += parseFloat(value);
            }
             $(".total_advice_qty").text(advice.toFixed(2));
             $(".total_advice_qty").val(advice.toFixed(2) );
        }); 
    var total = 0;
        $(".total_static").each(function() {
            var value = $(this).val();
            if(!isNaN(value)) {
                total += parseFloat(value);
            }
             $(".total_value_t").text(total.toFixed(2));
             $(".total_value_t").val(total.toFixed(2) );
        });   
    var batch_static = [];
         $(".batch_static").each(function() {
            var value = $(this).val();
            if(!isNaN(value)) {
                batch_static.push(value);
            }
             $(".batch_filter").val(batch_static);
        });     
  }

  function product_filteration(){
                $(".pending_product_filter").val('');
                $(".vanished_product_filter").val('');    
    var product_static = [];
         $(".product_static").each(function() {
            var value = $(this).val();
            if(!isNaN(value) && value.length != 0) {
                product_static.push(value);            
                var id = $(this).parents('tr:first').attr('id');      
                var pending_status = $('.pending_'+id).val();
                if(pending_status === '1'){
                  $(".pending_product_filter").val(product_static);
                  $(".pending_product_quantity").val(product_static);                  
                }
                if(pending_status === '0'){
                 $(".vanished_product_filter").val(product_static);
                }
            }

        }); 
  }



function add_new_row_box(count){

$("#dat_tbl").append(
''
+'<tr id="'+count+'" class="root">'
+'<td> '
+'<div class="form-group">'
+'<select class="form-control need m_select_search properties_type_static properties_type_select_'+count+'" required=""  name="prop_details_'+count+'[properties_type]" style="width: 100%;">'
+'<option value>Select Properties Type </option>'
+'<?php if (!empty($property_type)) { foreach ($property_type as $type) {?>'
+'<option value="<?php echo ucfirst($type['prop_type_id']);?>" <?php echo ($type['prop_type_id'] == 0) ? 'selected' : '';?>><?php echo ucfirst($type['prop_type_name']);?></option><?php } } ?>'
+'</select>'
+'</div>'
+'</td>'
+'<td>'
+'<div class="form-group">'
+'<div class="input-group mb-3">'
+'<div class="input-group-prepend">  '
+'<input type="text"  placeholder="Unit" class="form-control unit need unit_'+count+'" name="prop_details_'+count+'[unit]">'
+'</div>'
+'</div>'
+'</td>'
+'<td>'
+'<div class="form-group">'
+'<div class="input-group mb-3">'
+'<div class="input-group-prepend">'
+'<input type="text"  placeholder="Square Meter" class="form-control square_meter square_meter_'+count+' only_number need" name="prop_details_'+count+'[square_meter]">'
+'</div>'
+'</div>'
+'</td>'
+'<td> '
+'<div class="form-group">'
+'<select class="form-control need  property_status_static property_status_select_'+count+'" required=""  name="prop_details_'+count+'[property_status]" style="width: 100%;">'
+'<option value>Select Status </option>'
+'<option value="1"> Sold </option>'
+'<option value="2"> Rental </option>'
+'</select>'
+'</div>'
+'</td>'
+''
+'<td>'
+'<button class="btn btn-danger close_x" type="button" style="padding: 4px;" >'
+'<i class="zmdi zmdi-close" style="color: white;" ></i>'
+'</button>'
+'</td>'
+'</tr>'
    );

    $(".m_select_search").select2();
              $('.root').each(function(){
                  var this_id = $(this).attr('id');
                  if(this_id != count){
                    $("#"+this_id).find('input').attr('readonly', 'readonly');
                    $("#"+this_id).find('.select2-selection').addClass('stop_pointing');
                  }
              });             

  }

  $('.btn-success').click(function(e) {
        var flg = '';
        var isValid = true;
        $('.need').each(function() {
            if ($.trim($(this).val()) == '') {
                isValid = false;
                $(this).addClass('need_validation_error');
                $(this).parents('.input-group').find('.select2-container').addClass('need_validation_error');
                $(this).parents('.input-group').find('.multiselect').addClass('need_validation_error');
                 flg = 1;
            }
            else {
                $(this).removeClass('need_validation_error');
                $(this).parents('.input-group').find('.select2-selection').removeClass('need_validation_error');
                $(this).parents('.input-group').find('.multiselect').removeClass('need_validation_error');

                 flg = 0;
            }
            
        }); 
            if (isValid == false){ 
                e.preventDefault();   
              }

              if(flg === 0){
                  //$( "#customer_order_data" ).submit();
               }
    });


  $('#properties_dt').find('*').on('click ', function(e){
var flg = '';
        var isValid = true;
        $('.need').each(function() {
            if ($.trim($(this).val()) == '') {
                isValid = false;
            }
            else {
                $(this).removeClass('need_validation_error');
                $(this).parents('.input-group').find('.select2-selection').removeClass('need_validation_error');
                $(this).parents('.input-group').find('.multiselect').removeClass('need_validation_error');
            }            
        }); 
            if (isValid == false){ 
                e.preventDefault();   
              }
});

  </script>