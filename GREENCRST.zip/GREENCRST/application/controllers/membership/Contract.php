<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Contract extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('member/Membership_model');
        $this->load->model('member/Contract_model');
    }

	public function index()
	{
    	$template['page']            ='contract/contract';
        
        $this->load->view('template',$template);
	}

public function get_contract_details()
        {
        $mobile = $this->input->post("mobile");  

        $this->load->model('member/Contract_model');
        $template['contract'] =  $this->Contract_model->get_contract_details($mobile);
        $this->load->view('contract/ajax_contract',$template);
    }

    public function change_payment_status()
        {
        $Membership_ID = $this->input->post("Membership_ID");  
        $Member_payment_ID = $this->input->post("Member_payment_ID"); 
        $result =  $this->Contract_model->change_payment_status($Membership_ID,$Member_payment_ID);
        echo $result;
    }

        public function change_payment_status1()
        {
        $Membership_ID = $this->input->post("Membership_ID");  
        $Member_payment_ID = $this->input->post("Member_payment_ID"); 
        $result =  $this->Contract_model->change_payment_status1($Membership_ID,$Member_payment_ID);
        echo $result;
    }

    public function get_payments_details()
        {
        $Membership_ID = $this->input->post("Membership_ID");  
        $Contract_ID = $this->input->post("Contract_ID");  
        $this->load->model('member/Contract_model');
        $template['payments'] =  $this->Contract_model->get_payments_details($Membership_ID,$Contract_ID);
        $this->load->view('contract/ajax_contract',$template);
    }

    
    public function get_documentation_details()
        {
        $Membership_ID = $this->input->post("Membership_ID");  
        $Contract_ID = $this->input->post("Contract_ID");  
        $this->load->model('member/Contract_model');
        $template['payments2'] =  $this->Contract_model->get_document_details($Membership_ID,$Contract_ID);
        // var_dump($template['payments2']);die();
        $this->load->view('contract/ajax_contract',$template);
    }
    
    



}
