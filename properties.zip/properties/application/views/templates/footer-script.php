<!-- END CONTENT WRAPPER -->
		<!-- ================== GLOBAL VENDOR SCRIPTS ==================-->
		<script src="<?php echo base_url(); ?>assets/vendor/modernizr/modernizr.custom.js"></script>
		<!-- <script src="<?php echo base_url(); ?>assets/vendor/jquery/dist/jquery.min.js"></script> -->
		<script src="<?php echo base_url(); ?>assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- 		<script src="<?php echo base_url(); ?>assets/vendor/js-storage/js.storage.js"></script> -->
		<script src="<?php echo base_url(); ?>assets/vendor/js-cookie/src/js.cookie.js"></script>
		<!-- <script src="<?php echo base_url(); ?>assets/vendor/pace/pace.js"></script> -->
	<!-- 	<script src="<?php echo base_url(); ?>assets/vendor/metismenu/dist/metisMenu.js"></script> -->
	<!-- 	<script src="<?php echo base_url(); ?>assets/vendor/switchery-npm/index.js"></script> -->
		<script src="<?php echo base_url(); ?>assets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
		<!-- ================== PAGE LEVEL VENDOR SCRIPTS ==================-->
<!-- 		<script src="<?php echo base_url(); ?>assets/vendor/countup.js/dist/countUp.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/vendor/chart.js/dist/Chart.bundle.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/vendor/flot/jquery.flot.js"></script> -->
		<script src="<?php echo base_url(); ?>assets/vendor/jquery.flot.tooltip/js/jquery.flot.tooltip.min.js"></script>
<!-- 		<script src="<?php echo base_url(); ?>assets/vendor/flot/jquery.flot.resize.js"></script>
		<script src="<?php echo base_url(); ?>assets/vendor/flot/jquery.flot.time.js"></script> -->
<!-- 		<script src="<?php echo base_url(); ?>assets/vendor/flot.curvedlines/curvedLines.js"></script> -->
		<!-- <script src="<?php echo base_url(); ?>assets/vendor/datatables.net/js/jquery.dataTables.js"></script> -->
		<!-- <script src="<?php echo base_url(); ?>assets/vendor/datatables.net-bs4/js/dataTables.bootstrap4.js"></script> -->

		<!-- ================== PAGE LEVEL SCRIPTS ==================-->
	<!-- 	<script src="<?php echo base_url(); ?>assets/js/components/countUp-init.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/cards/counter-group.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/cards/recent-transactions.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/cards/monthly-budget.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/cards/users-chart.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/cards/bounce-rate-chart.js"></script> -->
		<!-- <script src="<?php echo base_url(); ?>assets/js/cards/session-duration-chart.js"></script> -->
		<script src="<?php echo base_url(); ?>assets/js/validator/validator.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
<!-- 		<script src="<?php echo base_url(); ?>assets/js/print/jspdf.min.js"></script> -->
	<!-- 	<script src="<?php echo base_url(); ?>assets/js/print/printThis.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/print/jspdf.plugin.autotable.js"></script> -->
		<!-- ================== PAGE LEVEL COMPONENT SCRIPTS ==================-->
		<!-- <script src="<?php echo base_url(); ?>assets/js/components/datatables-init.js"></script> -->
				<!-- ================== PAGE LEVEL VENDOR SCRIPTS ==================-->
	    <!-- <script src="<?php echo base_url(); ?>assets/vendor/moment/min/moment.min.js"></script> -->
<!-- 		<script src="<?php echo base_url(); ?>assets/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/vendor/bootstrap-daterangepicker/daterangepicker.js"></script> -->
		<script src="<?php echo base_url(); ?>assets/vendor/sweetalert2/dist/sweetalert2.min.js"></script>
				<!-- ================== PAGE LEVEL APP SCRIPTS ==================-->
	<!-- 	<script src="<?php echo base_url(); ?>assets/js/components/bootstrap-datepicker-init.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/components/bootstrap-date-range-picker-init.js"></script> -->

		<script src="<?php echo base_url(); ?>assets/vendor/select2/select2.min.js"></script>
				<!-- ================== GLOBAL APP SCRIPTS ==================-->
	<!-- 	<script src="<?php echo base_url(); ?>assets/js/global/app.js"></script> -->
		<script src="<?php echo base_url(); ?>assets/js/components/select2-init.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/components/sweetalert2.js"></script>

		<script src="<?php echo base_url(); ?>assets/select2/js/select2.js"></script>	
		<script src="<?php echo base_url(); ?>assets/select2/js/select2.min.js"></script>	
	<!-- 	<script src="<?php echo base_url(); ?>assets/js/country.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/notify/toastr.min.js"></script> -->
<!-- 		<script src="<?php echo base_url(); ?>assets/js/multiselect/bootstrap-multiselect.js"></script> -->
	<!-- 	<script src="<?php echo base_url(); ?>assets/js/table2excel.js"></script> -->

<!-- 		<script src="<?php echo base_url(); ?>assets/js/components/fullcalendar-init.js"></script> -->
<!-- 		<script src="<?php echo base_url(); ?>assets/vendor/fullcalendar/dist/fullcalendar.min.js"></script> -->
<!-- 		<script src="<?php echo base_url(); ?>assets/vendor/jquery-mask/jquery.mask.min.js"></script> -->
	<!-- 	<script src="<?php echo base_url(); ?>assets/js/components/jquery-mask-init.js"></script> -->
	<!-- 	<script src="../../../../../cdnjs.cloudflare.com/ajax/libs/pikaday/1.6.1/pikaday.min.js"></script>
		<script src="../../../../../cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.10.0/jquery.timepicker.min.js"></script> -->

		<!-- <script src="<?php echo base_url(); ?>assets/js/iEdit.js"></script> -->



		<!-- <script src="<?php echo base_url(); ?>assets/js/autocomplete/jquery.typeahead.js"></script> -->
		<!-- <script src="<?php echo base_url(); ?>assets/toggle/bootstrap-toggle.min.js"></script> -->
		<!-- <script src="<?php echo base_url(); ?>assets/js/jquery-ui-1.8.2.custom.min.js"></script> -->
		<!-- <script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script> -->
		

		<script>
				// var h1 = document.getElementsByTagName('h1')[0],
				//     start = document.getElementById('start'),
				//     stop = document.getElementById('stop'),
				//     clear = document.getElementById('clear'),
				//     seconds = 0, minutes = 0, hours = 0,
				//     t;

				// function add() {
				//     seconds++;
				//     if (seconds >= 60) {
				//         seconds = 0;
				//         minutes++;
				//         if (minutes >= 60) {
				//             minutes = 0;
				//             hours++;
				//         }
				//     }
				//     var time_da = (hours ? (hours > 9 ? hours : "0" + hours) : "00") + ":" + (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds);
				//     if(time_da == "0<?php echo $this->session->userdata('session_time'); ?>:00:00"){
				//     	//alert(<?php echo $this->session->userdata('session_time'); ?>);
				//     	 window.location ="<?php echo base_url();?>login/logout";
				//     }
				//     h1.textContent = time_da;

				//     timer();
				// }
				// function timer() {
				//     t = setTimeout(add, 1000);
				// }
				// timer();


				// /* Start button */
				// start.onclick = timer;

				// /* Stop button */
				// stop.onclick = function() {
				//     clearTimeout(t);
				// }

				// /* Clear button */
				// clear.onclick = function() {
				//     h1.textContent = "00:00:00";
				//     seconds = 0; minutes = 0; hours = 0;
				// }

		</script>
		
		