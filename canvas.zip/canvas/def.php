<!DOCTYPE html>
<html>
<head>
	<title>Editable Frame</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
<!--     <link rel="stylesheet" href="./css/addimagedialog_less_min.css">
    <link rel="stylesheet" href="./css/all.css"> -->
    <link rel="stylesheet" href="./css/bootstrap.css">
    <link rel="stylesheet" href="./css/jquery-ui.css">
<!--     <link rel="stylesheet" href="./css/modaldialog_min.css">
    <link rel="stylesheet" href="./css/query.modaldialog_min.css">
    <link rel="stylesheet" href="./css/responsive.css">
    <link rel="stylesheet" href="./css/sceneanimation_less_min.css">
    <link rel="stylesheet" href="./css/selectableimagedialog_less_min.css">
	<link rel="stylesheet" href="./css/standardeditor.css">
    <link rel="publisher" href="https://plus.google.com/117366687437440561467"></link> -->

<link rel="shortcut icon" href="https://www.vistaprint.in/sf/_langid-36/_hc-0000081d/_/vp/images/vp-site/common/icons/favicon.ico" />

<link rel="apple-touch-icon" sizes="152x152" href="https://www.vistaprint.in/vp/images/vp-site/common/logo/vistaprint-favorites-76-76-2014-2x.png"/>
<link rel="apple-touch-icon" sizes="120x120" href="https://www.vistaprint.in/vp/images/vp-site/common/logo/vistaprint-favorites-60-60-2014-2x.png"/>
<link rel="apple-touch-icon" sizes="76x76" href="https://www.vistaprint.in/vp/images/vp-site/common/logo/vistaprint-favorites-76-76-2014.png"/>
<link rel="apple-touch-icon" sizes="60x60" href="https://www.vistaprint.in/vp/images/vp-site/common/logo/vistaprint-favorites-60-60-2014.png"/>





<script type="text/javascript">
var utag_data = {
    PfIds : ["SKU604008"],
    DocIds : [""],
    ComboIds : [""],
    BacksideComboIds : [""],
    MerchProductIds : ["MP-238365"],
    MpIdsWithComboId : ["MP-238365CMB0"],
    OrderStep : "Design Selected",
    ServerEventNames : ["DesignSelected"],
    DesignPath : "Template",
    DesignTemplateId : "_SKU604008",
    GenTrack : "ANY:SCT:T",
    AbsolutePath : "/studio.aspx/vp/ns/livepreview.caspx",
    UserAgent : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36",
    ServerName : "www.vistaprint.in",
    SessionId : "5440495942",
    SubsessionId : "5485003605",
    VisitorId : "198575232984",
    PppId : "1275686",
    GlobalOptInStatus : "Global_Opt-In",
    Locale : "IN",
    Language : "en-in",
    Currency : "INR",
    PppPartnerId : "Google Organic Search",
    CampaignId : "22931",
    Attribution : {},
    SessionCipherName : "",
    SessionProtocolVersion : "",
    ProductCategory : "PIMProducts",
    PppChannel : "OrgSearchNonBranded",
    ActiveFeatureValues : ["28883","27741","29965","30217","30187","30064","30193","29941","30073","30146","30149","30181","30184"],
    IsCustomerCare : "False",
    IsRetail : "False",
    OrdersCount : "0",
    ShopperId : "",
    VisitorStatus : "False",
    VATState : "True",
    SCReportSuiteId : "vispri.vprt.prd",
    OperatingSystem : "Windows",
    ActualDeviceUIType : "Desktop",
    RequestedDeviceUIType : "Desktop",
    ResolvedDeviceUIType : "Desktop",
    PageHasMobileVersion : "False",
    GeoCountry : "IN",
    GeoRegion : "TN",
    GeoState : "TN",
    GeoCity : "Coimbatore",
    GeoPostalCode : "641015",
    MostRecentBreadcrumbName : "Personalised Mugs",
    PageName : "Wraparound Mug - 15oz - solid white:Studio",
    PageNameExtension : "",
    PageSection : "Studio",
    PageStage : "Design",
    NewPageNameInformation : "Wraparound Mug - 15oz - solid white:Studio,Design,Studio",
    IsNewPageNamingSchemeEnabled : "True",
    PageNameIds : "11:3:11:1407735:19447:-1:-1:-1:-1:-1:-1:-1:SKU604008:2740008:0"
};
</script>


        
        
    


<link rel="preload" href="https://www.vistaprint.in/sf/_langid-1/_hc-9e6f9df0/_/vp/fonts/MarkWeb-Bold_modified.woff" as="font" crossorigin />
<link rel="preload" href="https://www.vistaprint.in/sf/_langid-1/_hc-9e6f9df0/_/vp/fonts/MarkWeb-Light_modified.woff" as="font" crossorigin />
<style type="text/css">
@font-face { font-family: MarkPro; src: url("/sf/_langid-1/_hc-9e6f9df0/_/vp/fonts/MarkWeb-Bold_modified.woff") format("woff"); font-weight: bold; }
@font-face { font-family: MarkPro; src: url("/sf/_langid-1/_hc-9e6f9df0/_/vp/fonts/MarkWeb-Light_modified.woff") format("woff");  }
</style>
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/css.caspx?m=1&i=1&2x=0&langid=36&hc=21364cf4&dyn=1&d=%2fvp%2fcss%2fthirdparty%2fskinnyjs%2fjquery.modaldialog_min.css%2c%2fvp%2fcss%2fthirdparty%2fskinnyjs%2fjquery.modaldialog.skins_less_min.css%2c%2fvp%2fcss%2fthirdparty%2fskinnyjs%2fjquery.modaldialog.buttons_less_min.css" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-dba62b49/_/vp/css/pkg/vp.uilibrary/controls/modaldialog_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://studio4client.cdn.vpsvc.com/master/358/css/standardeditor.css" />
<link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-502ab301/_/vp/css/areas/customercare/servicecenter/studiocarecallout_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-360a7174/_/vp/css/sales/documents/previewing/sceneanimation_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-b144bb31/_/vp/css/sales/studio/controls/imagerepository_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-c91f5db1/_/vp/css/pkg/vp.uilibrary/controls/ui-library-basic.vistaprint_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-545672f9/_/vp/css/pkg/vp.uilibrary/controls/rangeslider_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-7005a882/_/vp/css/upload/dialogs/addimagedialog_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-38640c44/_/vp/css/upload/dialogs/selectableimagedialog_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-e37eff69/_/vp/css/thirdparty/skinnyjs/jquery.richtooltip_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-3373cc4c/_/vp/css/pkg/vp.uilibrary/controls/richtooltip_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-df48789b/_/vp/css/upload/upload_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-7b5c4dc1/_/vp/css/upload/error_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-ee2562c4/_/vp/css/upload/progress_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-012bd974/_/vp/css/upload/dialogs/previouslyuploadedimages_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-99e234d6/_/vp/css/sales/images/myimages_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-24264fb0/_/vp/css/pkg/vp.uilibrary/controls/textbutton.vistaprint_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-ea951748/_/vp/css/controls/paginator_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-82c69de3/_/vp/css/sales/images/libraryimages_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-c846a88d/_/vp/css/upload/dialogs/thirdpartyimages_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-cec135ea/_/vp/css/common/responsive-global.vistaprint_less_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/sf/_langid-36/_hc-3cb10487/_/vp/css/pkg/vp.uilibrary/common/responsive-grid_min.css?inline=1&dyn=1" />
<link rel="stylesheet" type="text/css" href="https://www.vistaprint.in/css.caspx?m=1&i=1&2x=0&langid=36&hc=1084c6fd&dyn=1&d=%2fvp%2fcss%2fAreas%2fRoot%2fHeader%2fheader_less_min.css%2c%2fvp%2fcss%2fareas%2froot%2ffooter%2ffooter_less_min.css%2c%2fvp%2fcss%2fjquery%2fvpextensions%2fjquery-menu_min.css%2c%2fvp%2fcss%2fjquery%2fvpextensions%2fmenu-skins%2fjquery-menu-taxonomy_min.css" />
<link rel="stylesheet" type="text/css" href="https://ui-library.cdn.vpsvc.com/css/controls/responsive-image_min.css" />
<link rel="stylesheet" type="text/css" href="https://cms.cdn.vpsvc.com/vistacore/css/Navigation/Meganavigator_scss-hc31b502e2c0f688ce08580d695128fe95.css" />
<link rel="stylesheet" type="text/css" href="https://cms.cdn.vpsvc.com/vistacore/css/Navigation/GlobalNavigation_scss-hca5d4792f56ffe9196d02b67c79f1411b.css" />
<link rel="stylesheet" type="text/css" href="https://cms.cdn.vpsvc.com/vistacore/css/Navigation/MobileMeganav_scss-hc13cd0415adcb571fe71daae28ee1568a.css" />
<script type="text/javascript">
window.NREUM||(NREUM={}),__nr_require=function(t,e,n){function r(n){if(!e[n]){var o=e[n]={exports:{}};t[n][0].call(o.exports,function(e){var o=t[n][1][e];return r(o||e)},o,o.exports)}return e[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<n.length;o++)r(n[o]);return r}({1:[function(t,e,n){function r(t){try{s.console&&console.log(t)}catch(e){}}var o,i=t("ee"),a=t(21),s={};try{o=localStorage.getItem("__nr_flags").split(","),console&&"function"==typeof console.log&&(s.console=!0,o.indexOf("dev")!==-1&&(s.dev=!0),o.indexOf("nr_dev")!==-1&&(s.nrDev=!0))}catch(c){}s.nrDev&&i.on("internal-error",function(t){r(t.stack)}),s.dev&&i.on("fn-err",function(t,e,n){r(n.stack)}),s.dev&&(r("NR AGENT IN DEVELOPMENT MODE"),r("flags: "+a(s,function(t,e){return t}).join(", ")))},{}],2:[function(t,e,n){function r(t,e,n,r,s){try{l?l-=1:o(s||new UncaughtException(t,e,n),!0)}catch(f){try{i("ierr",[f,c.now(),!0])}catch(d){}}return"function"==typeof u&&u.apply(this,a(arguments))}function UncaughtException(t,e,n){this.message=t||"Uncaught error with no additional information",this.sourceURL=e,this.line=n}function o(t,e){var n=e?null:c.now();i("err",[t,n])}var i=t("handle"),a=t(22),s=t("ee"),c=t("loader"),f=t("gos"),u=window.onerror,d=!1,p="nr@seenError",l=0;c.features.err=!0,t(1),window.onerror=r;try{throw new Error}catch(h){"stack"in h&&(t(13),t(12),"addEventListener"in window&&t(6),c.xhrWrappable&&t(14),d=!0)}s.on("fn-start",function(t,e,n){d&&(l+=1)}),s.on("fn-err",function(t,e,n){d&&!n[p]&&(f(n,p,function(){return!0}),this.thrown=!0,o(n))}),s.on("fn-end",function(){d&&!this.thrown&&l>0&&(l-=1)}),s.on("internal-error",function(t){i("ierr",[t,c.now(),!0])})},{}],3:[function(t,e,n){t("loader").features.ins=!0},{}],4:[function(t,e,n){function r(){M++,N=y.hash,this[u]=g.now()}function o(){M--,y.hash!==N&&i(0,!0);var t=g.now();this[h]=~~this[h]+t-this[u],this[d]=t}function i(t,e){E.emit("newURL",[""+y,e])}function a(t,e){t.on(e,function(){this[e]=g.now()})}var s="-start",c="-end",f="-body",u="fn"+s,d="fn"+c,p="cb"+s,l="cb"+c,h="jsTime",m="fetch",v="addEventListener",w=window,y=w.location,g=t("loader");if(w[v]&&g.xhrWrappable){var b=t(10),x=t(11),E=t(8),O=t(6),P=t(13),R=t(7),T=t(14),L=t(9),j=t("ee"),S=j.get("tracer");t(15),g.features.spa=!0;var N,M=0;j.on(u,r),j.on(p,r),j.on(d,o),j.on(l,o),j.buffer([u,d,"xhr-done","xhr-resolved"]),O.buffer([u]),P.buffer(["setTimeout"+c,"clearTimeout"+s,u]),T.buffer([u,"new-xhr","send-xhr"+s]),R.buffer([m+s,m+"-done",m+f+s,m+f+c]),E.buffer(["newURL"]),b.buffer([u]),x.buffer(["propagate",p,l,"executor-err","resolve"+s]),S.buffer([u,"no-"+u]),L.buffer(["new-jsonp","cb-start","jsonp-error","jsonp-end"]),a(T,"send-xhr"+s),a(j,"xhr-resolved"),a(j,"xhr-done"),a(R,m+s),a(R,m+"-done"),a(L,"new-jsonp"),a(L,"jsonp-end"),a(L,"cb-start"),E.on("pushState-end",i),E.on("replaceState-end",i),w[v]("hashchange",i,!0),w[v]("load",i,!0),w[v]("popstate",function(){i(0,M>1)},!0)}},{}],5:[function(t,e,n){function r(t){}if(window.performance&&window.performance.timing&&window.performance.getEntriesByType){var o=t("ee"),i=t("handle"),a=t(13),s=t(12),c="learResourceTimings",f="addEventListener",u="resourcetimingbufferfull",d="bstResource",p="resource",l="-start",h="-end",m="fn"+l,v="fn"+h,w="bstTimer",y="pushState",g=t("loader");g.features.stn=!0,t(8);var b=NREUM.o.EV;o.on(m,function(t,e){var n=t[0];n instanceof b&&(this.bstStart=g.now())}),o.on(v,function(t,e){var n=t[0];n instanceof b&&i("bst",[n,e,this.bstStart,g.now()])}),a.on(m,function(t,e,n){this.bstStart=g.now(),this.bstType=n}),a.on(v,function(t,e){i(w,[e,this.bstStart,g.now(),this.bstType])}),s.on(m,function(){this.bstStart=g.now()}),s.on(v,function(t,e){i(w,[e,this.bstStart,g.now(),"requestAnimationFrame"])}),o.on(y+l,function(t){this.time=g.now(),this.startPath=location.pathname+location.hash}),o.on(y+h,function(t){i("bstHist",[location.pathname+location.hash,this.startPath,this.time])}),f in window.performance&&(window.performance["c"+c]?window.performance[f](u,function(t){i(d,[window.performance.getEntriesByType(p)]),window.performance["c"+c]()},!1):window.performance[f]("webkit"+u,function(t){i(d,[window.performance.getEntriesByType(p)]),window.performance["webkitC"+c]()},!1)),document[f]("scroll",r,{passive:!0}),document[f]("keypress",r,!1),document[f]("click",r,!1)}},{}],6:[function(t,e,n){function r(t){for(var e=t;e&&!e.hasOwnProperty(u);)e=Object.getPrototypeOf(e);e&&o(e)}function o(t){s.inPlace(t,[u,d],"-",i)}function i(t,e){return t[1]}var a=t("ee").get("events"),s=t(24)(a,!0),c=t("gos"),f=XMLHttpRequest,u="addEventListener",d="removeEventListener";e.exports=a,"getPrototypeOf"in Object?(r(document),r(window),r(f.prototype)):f.prototype.hasOwnProperty(u)&&(o(window),o(f.prototype)),a.on(u+"-start",function(t,e){var n=t[1],r=c(n,"nr@wrapped",function(){function t(){if("function"==typeof n.handleEvent)return n.handleEvent.apply(n,arguments)}var e={object:t,"function":n}[typeof n];return e?s(e,"fn-",null,e.name||"anonymous"):n});this.wrapped=t[1]=r}),a.on(d+"-start",function(t){t[1]=this.wrapped||t[1]})},{}],7:[function(t,e,n){function r(t,e,n){var r=t[e];"function"==typeof r&&(t[e]=function(){var t=r.apply(this,arguments);return o.emit(n+"start",arguments,t),t.then(function(e){return o.emit(n+"end",[null,e],t),e},function(e){throw o.emit(n+"end",[e],t),e})})}var o=t("ee").get("fetch"),i=t(21);e.exports=o;var a=window,s="fetch-",c=s+"body-",f=["arrayBuffer","blob","json","text","formData"],u=a.Request,d=a.Response,p=a.fetch,l="prototype";u&&d&&p&&(i(f,function(t,e){r(u[l],e,c),r(d[l],e,c)}),r(a,"fetch",s),o.on(s+"end",function(t,e){var n=this;if(e){var r=e.headers.get("content-length");null!==r&&(n.rxSize=r),o.emit(s+"done",[null,e],n)}else o.emit(s+"done",[t],n)}))},{}],8:[function(t,e,n){var r=t("ee").get("history"),o=t(24)(r);e.exports=r,o.inPlace(window.history,["pushState","replaceState"],"-")},{}],9:[function(t,e,n){function r(t){function e(){c.emit("jsonp-end",[],p),t.removeEventListener("load",e,!1),t.removeEventListener("error",n,!1)}function n(){c.emit("jsonp-error",[],p),c.emit("jsonp-end",[],p),t.removeEventListener("load",e,!1),t.removeEventListener("error",n,!1)}var r=t&&"string"==typeof t.nodeName&&"script"===t.nodeName.toLowerCase();if(r){var o="function"==typeof t.addEventListener;if(o){var a=i(t.src);if(a){var u=s(a),d="function"==typeof u.parent[u.key];if(d){var p={};f.inPlace(u.parent,[u.key],"cb-",p),t.addEventListener("load",e,!1),t.addEventListener("error",n,!1),c.emit("new-jsonp",[t.src],p)}}}}}function o(){return"addEventListener"in window}function i(t){var e=t.match(u);return e?e[1]:null}function a(t,e){var n=t.match(p),r=n[1],o=n[3];return o?a(o,e[r]):e[r]}function s(t){var e=t.match(d);return e&&e.length>=3?{key:e[2],parent:a(e[1],window)}:{key:t,parent:window}}var c=t("ee").get("jsonp"),f=t(24)(c);if(e.exports=c,o()){var u=/[?&](?:callback|cb)=([^&#]+)/,d=/(.*)\.([^.]+)/,p=/^(\w+)(\.|$)(.*)$/,l=["appendChild","insertBefore","replaceChild"];f.inPlace(HTMLElement.prototype,l,"dom-"),f.inPlace(HTMLHeadElement.prototype,l,"dom-"),f.inPlace(HTMLBodyElement.prototype,l,"dom-"),c.on("dom-start",function(t){r(t[0])})}},{}],10:[function(t,e,n){var r=t("ee").get("mutation"),o=t(24)(r),i=NREUM.o.MO;e.exports=r,i&&(window.MutationObserver=function(t){return this instanceof i?new i(o(t,"fn-")):i.apply(this,arguments)},MutationObserver.prototype=i.prototype)},{}],11:[function(t,e,n){function r(t){var e=a.context(),n=s(t,"executor-",e),r=new f(n);return a.context(r).getCtx=function(){return e},a.emit("new-promise",[r,e],e),r}function o(t,e){return e}var i=t(24),a=t("ee").get("promise"),s=i(a),c=t(21),f=NREUM.o.PR;e.exports=a,f&&(window.Promise=r,["all","race"].forEach(function(t){var e=f[t];f[t]=function(n){function r(t){return function(){a.emit("propagate",[null,!o],i),o=o||!t}}var o=!1;c(n,function(e,n){Promise.resolve(n).then(r("all"===t),r(!1))});var i=e.apply(f,arguments),s=f.resolve(i);return s}}),["resolve","reject"].forEach(function(t){var e=f[t];f[t]=function(t){var n=e.apply(f,arguments);return t!==n&&a.emit("propagate",[t,!0],n),n}}),f.prototype["catch"]=function(t){return this.then(null,t)},f.prototype=Object.create(f.prototype,{constructor:{value:r}}),c(Object.getOwnPropertyNames(f),function(t,e){try{r[e]=f[e]}catch(n){}}),a.on("executor-start",function(t){t[0]=s(t[0],"resolve-",this),t[1]=s(t[1],"resolve-",this)}),a.on("executor-err",function(t,e,n){t[1](n)}),s.inPlace(f.prototype,["then"],"then-",o),a.on("then-start",function(t,e){this.promise=e,t[0]=s(t[0],"cb-",this),t[1]=s(t[1],"cb-",this)}),a.on("then-end",function(t,e,n){this.nextPromise=n;var r=this.promise;a.emit("propagate",[r,!0],n)}),a.on("cb-end",function(t,e,n){a.emit("propagate",[n,!0],this.nextPromise)}),a.on("propagate",function(t,e,n){this.getCtx&&!e||(this.getCtx=function(){if(t instanceof Promise)var e=a.context(t);return e&&e.getCtx?e.getCtx():this})}),r.toString=function(){return""+f})},{}],12:[function(t,e,n){var r=t("ee").get("raf"),o=t(24)(r),i="equestAnimationFrame";e.exports=r,o.inPlace(window,["r"+i,"mozR"+i,"webkitR"+i,"msR"+i],"raf-"),r.on("raf-start",function(t){t[0]=o(t[0],"fn-")})},{}],13:[function(t,e,n){function r(t,e,n){t[0]=a(t[0],"fn-",null,n)}function o(t,e,n){this.method=n,this.timerDuration=isNaN(t[1])?0:+t[1],t[0]=a(t[0],"fn-",this,n)}var i=t("ee").get("timer"),a=t(24)(i),s="setTimeout",c="setInterval",f="clearTimeout",u="-start",d="-";e.exports=i,a.inPlace(window,[s,"setImmediate"],s+d),a.inPlace(window,[c],c+d),a.inPlace(window,[f,"clearImmediate"],f+d),i.on(c+u,r),i.on(s+u,o)},{}],14:[function(t,e,n){function r(t,e){d.inPlace(e,["onreadystatechange"],"fn-",s)}function o(){var t=this,e=u.context(t);t.readyState>3&&!e.resolved&&(e.resolved=!0,u.emit("xhr-resolved",[],t)),d.inPlace(t,y,"fn-",s)}function i(t){g.push(t),h&&(x?x.then(a):v?v(a):(E=-E,O.data=E))}function a(){for(var t=0;t<g.length;t++)r([],g[t]);g.length&&(g=[])}function s(t,e){return e}function c(t,e){for(var n in t)e[n]=t[n];return e}t(6);var f=t("ee"),u=f.get("xhr"),d=t(24)(u),p=NREUM.o,l=p.XHR,h=p.MO,m=p.PR,v=p.SI,w="readystatechange",y=["onload","onerror","onabort","onloadstart","onloadend","onprogress","ontimeout"],g=[];e.exports=u;var b=window.XMLHttpRequest=function(t){var e=new l(t);try{u.emit("new-xhr",[e],e),e.addEventListener(w,o,!1)}catch(n){try{u.emit("internal-error",[n])}catch(r){}}return e};if(c(l,b),b.prototype=l.prototype,d.inPlace(b.prototype,["open","send"],"-xhr-",s),u.on("send-xhr-start",function(t,e){r(t,e),i(e)}),u.on("open-xhr-start",r),h){var x=m&&m.resolve();if(!v&&!m){var E=1,O=document.createTextNode(E);new h(a).observe(O,{characterData:!0})}}else f.on("fn-end",function(t){t[0]&&t[0].type===w||a()})},{}],15:[function(t,e,n){function r(t){var e=this.params,n=this.metrics;if(!this.ended){this.ended=!0;for(var r=0;r<d;r++)t.removeEventListener(u[r],this.listener,!1);if(!e.aborted){if(n.duration=a.now()-this.startTime,4===t.readyState){e.status=t.status;var i=o(t,this.lastSize);if(i&&(n.rxSize=i),this.sameOrigin){var c=t.getResponseHeader("X-NewRelic-App-Data");c&&(e.cat=c.split(", ").pop())}}else e.status=0;n.cbTime=this.cbTime,f.emit("xhr-done",[t],t),s("xhr",[e,n,this.startTime])}}}function o(t,e){var n=t.responseType;if("json"===n&&null!==e)return e;var r="arraybuffer"===n||"blob"===n||"json"===n?t.response:t.responseText;return h(r)}function i(t,e){var n=c(e),r=t.params;r.host=n.hostname+":"+n.port,r.pathname=n.pathname,t.sameOrigin=n.sameOrigin}var a=t("loader");if(a.xhrWrappable){var s=t("handle"),c=t(16),f=t("ee"),u=["load","error","abort","timeout"],d=u.length,p=t("id"),l=t(19),h=t(18),m=window.XMLHttpRequest;a.features.xhr=!0,t(14),f.on("new-xhr",function(t){var e=this;e.totalCbs=0,e.called=0,e.cbTime=0,e.end=r,e.ended=!1,e.xhrGuids={},e.lastSize=null,l&&(l>34||l<10)||window.opera||t.addEventListener("progress",function(t){e.lastSize=t.loaded},!1)}),f.on("open-xhr-start",function(t){this.params={method:t[0]},i(this,t[1]),this.metrics={}}),f.on("open-xhr-end",function(t,e){"loader_config"in NREUM&&"xpid"in NREUM.loader_config&&this.sameOrigin&&e.setRequestHeader("X-NewRelic-ID",NREUM.loader_config.xpid)}),f.on("send-xhr-start",function(t,e){var n=this.metrics,r=t[0],o=this;if(n&&r){var i=h(r);i&&(n.txSize=i)}this.startTime=a.now(),this.listener=function(t){try{"abort"===t.type&&(o.params.aborted=!0),("load"!==t.type||o.called===o.totalCbs&&(o.onloadCalled||"function"!=typeof e.onload))&&o.end(e)}catch(n){try{f.emit("internal-error",[n])}catch(r){}}};for(var s=0;s<d;s++)e.addEventListener(u[s],this.listener,!1)}),f.on("xhr-cb-time",function(t,e,n){this.cbTime+=t,e?this.onloadCalled=!0:this.called+=1,this.called!==this.totalCbs||!this.onloadCalled&&"function"==typeof n.onload||this.end(n)}),f.on("xhr-load-added",function(t,e){var n=""+p(t)+!!e;this.xhrGuids&&!this.xhrGuids[n]&&(this.xhrGuids[n]=!0,this.totalCbs+=1)}),f.on("xhr-load-removed",function(t,e){var n=""+p(t)+!!e;this.xhrGuids&&this.xhrGuids[n]&&(delete this.xhrGuids[n],this.totalCbs-=1)}),f.on("addEventListener-end",function(t,e){e instanceof m&&"load"===t[0]&&f.emit("xhr-load-added",[t[1],t[2]],e)}),f.on("removeEventListener-end",function(t,e){e instanceof m&&"load"===t[0]&&f.emit("xhr-load-removed",[t[1],t[2]],e)}),f.on("fn-start",function(t,e,n){e instanceof m&&("onload"===n&&(this.onload=!0),("load"===(t[0]&&t[0].type)||this.onload)&&(this.xhrCbStart=a.now()))}),f.on("fn-end",function(t,e){this.xhrCbStart&&f.emit("xhr-cb-time",[a.now()-this.xhrCbStart,this.onload,e],e)})}},{}],16:[function(t,e,n){e.exports=function(t){var e=document.createElement("a"),n=window.location,r={};e.href=t,r.port=e.port;var o=e.href.split("://");!r.port&&o[1]&&(r.port=o[1].split("/")[0].split("@").pop().split(":")[1]),r.port&&"0"!==r.port||(r.port="https"===o[0]?"443":"80"),r.hostname=e.hostname||n.hostname,r.pathname=e.pathname,r.protocol=o[0],"/"!==r.pathname.charAt(0)&&(r.pathname="/"+r.pathname);var i=!e.protocol||":"===e.protocol||e.protocol===n.protocol,a=e.hostname===document.domain&&e.port===n.port;return r.sameOrigin=i&&(!e.hostname||a),r}},{}],17:[function(t,e,n){function r(){}function o(t,e,n){return function(){return i(t,[f.now()].concat(s(arguments)),e?null:this,n),e?void 0:this}}var i=t("handle"),a=t(21),s=t(22),c=t("ee").get("tracer"),f=t("loader"),u=NREUM;"undefined"==typeof window.newrelic&&(newrelic=u);var d=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],p="api-",l=p+"ixn-";a(d,function(t,e){u[e]=o(p+e,!0,"api")}),u.addPageAction=o(p+"addPageAction",!0),u.setCurrentRouteName=o(p+"routeName",!0),e.exports=newrelic,u.interaction=function(){return(new r).get()};var h=r.prototype={createTracer:function(t,e){var n={},r=this,o="function"==typeof e;return i(l+"tracer",[f.now(),t,n],r),function(){if(c.emit((o?"":"no-")+"fn-start",[f.now(),r,o],n),o)try{return e.apply(this,arguments)}catch(t){throw c.emit("fn-err",[arguments,this,t],n),t}finally{c.emit("fn-end",[f.now()],n)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(t,e){h[e]=o(l+e)}),newrelic.noticeError=function(t,e){"string"==typeof t&&(t=new Error(t)),i("err",[t,f.now(),!1,e])}},{}],18:[function(t,e,n){e.exports=function(t){if("string"==typeof t&&t.length)return t.length;if("object"==typeof t){if("undefined"!=typeof ArrayBuffer&&t instanceof ArrayBuffer&&t.byteLength)return t.byteLength;if("undefined"!=typeof Blob&&t instanceof Blob&&t.size)return t.size;if(!("undefined"!=typeof FormData&&t instanceof FormData))try{return JSON.stringify(t).length}catch(e){return}}}},{}],19:[function(t,e,n){var r=0,o=navigator.userAgent.match(/Firefox[\/\s](\d+\.\d+)/);o&&(r=+o[1]),e.exports=r},{}],20:[function(t,e,n){function r(t,e){if(!o)return!1;if(t!==o)return!1;if(!e)return!0;if(!i)return!1;for(var n=i.split("."),r=e.split("."),a=0;a<r.length;a++)if(r[a]!==n[a])return!1;return!0}var o=null,i=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var s=navigator.userAgent,c=s.match(a);c&&s.indexOf("Chrome")===-1&&s.indexOf("Chromium")===-1&&(o="Safari",i=c[1])}e.exports={agent:o,version:i,match:r}},{}],21:[function(t,e,n){function r(t,e){var n=[],r="",i=0;for(r in t)o.call(t,r)&&(n[i]=e(r,t[r]),i+=1);return n}var o=Object.prototype.hasOwnProperty;e.exports=r},{}],22:[function(t,e,n){function r(t,e,n){e||(e=0),"undefined"==typeof n&&(n=t?t.length:0);for(var r=-1,o=n-e||0,i=Array(o<0?0:o);++r<o;)i[r]=t[e+r];return i}e.exports=r},{}],23:[function(t,e,n){e.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],24:[function(t,e,n){function r(t){return!(t&&t instanceof Function&&t.apply&&!t[a])}var o=t("ee"),i=t(22),a="nr@original",s=Object.prototype.hasOwnProperty,c=!1;e.exports=function(t,e){function n(t,e,n,o){function nrWrapper(){var r,a,s,c;try{a=this,r=i(arguments),s="function"==typeof n?n(r,a):n||{}}catch(f){p([f,"",[r,a,o],s])}u(e+"start",[r,a,o],s);try{return c=t.apply(a,r)}catch(d){throw u(e+"err",[r,a,d],s),d}finally{u(e+"end",[r,a,c],s)}}return r(t)?t:(e||(e=""),nrWrapper[a]=t,d(t,nrWrapper),nrWrapper)}function f(t,e,o,i){o||(o="");var a,s,c,f="-"===o.charAt(0);for(c=0;c<e.length;c++)s=e[c],a=t[s],r(a)||(t[s]=n(a,f?s+o:o,i,s))}function u(n,r,o){if(!c||e){var i=c;c=!0;try{t.emit(n,r,o,e)}catch(a){p([a,n,r,o])}c=i}}function d(t,e){if(Object.defineProperty&&Object.keys)try{var n=Object.keys(t);return n.forEach(function(n){Object.defineProperty(e,n,{get:function(){return t[n]},set:function(e){return t[n]=e,e}})}),e}catch(r){p([r])}for(var o in t)s.call(t,o)&&(e[o]=t[o]);return e}function p(e){try{t.emit("internal-error",e)}catch(n){}}return t||(t=o),n.inPlace=f,n.flag=a,n}},{}],ee:[function(t,e,n){function r(){}function o(t){function e(t){return t&&t instanceof r?t:t?c(t,s,i):i()}function n(n,r,o,i){if(!p.aborted||i){t&&t(n,r,o);for(var a=e(o),s=m(n),c=s.length,f=0;f<c;f++)s[f].apply(a,r);var d=u[g[n]];return d&&d.push([b,n,r,a]),a}}function l(t,e){y[t]=m(t).concat(e)}function h(t,e){var n=y[t];if(n)for(var r=0;r<n.length;r++)n[r]===e&&n.splice(r,1)}function m(t){return y[t]||[]}function v(t){return d[t]=d[t]||o(n)}function w(t,e){f(t,function(t,n){e=e||"feature",g[n]=e,e in u||(u[e]=[])})}var y={},g={},b={on:l,addEventListener:l,removeEventListener:h,emit:n,get:v,listeners:m,context:e,buffer:w,abort:a,aborted:!1};return b}function i(){return new r}function a(){(u.api||u.feature)&&(p.aborted=!0,u=p.backlog={})}var s="nr@context",c=t("gos"),f=t(21),u={},d={},p=e.exports=o();p.backlog=u},{}],gos:[function(t,e,n){function r(t,e,n){if(o.call(t,e))return t[e];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(t,e,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return t[e]=r,r}var o=Object.prototype.hasOwnProperty;e.exports=r},{}],handle:[function(t,e,n){function r(t,e,n,r){o.buffer([t],r),o.emit(t,e,n)}var o=t("ee").get("handle");e.exports=r,r.ee=o},{}],id:[function(t,e,n){function r(t){var e=typeof t;return!t||"object"!==e&&"function"!==e?-1:t===window?0:a(t,i,function(){return o++})}var o=1,i="nr@id",a=t("gos");e.exports=r},{}],loader:[function(t,e,n){function r(){if(!E++){var t=x.info=NREUM.info,e=l.getElementsByTagName("script")[0];if(setTimeout(u.abort,3e4),!(t&&t.licenseKey&&t.applicationID&&e))return u.abort();f(g,function(e,n){t[e]||(t[e]=n)}),c("mark",["onload",a()+x.offset],null,"api");var n=l.createElement("script");n.src="https://"+t.agent,e.parentNode.insertBefore(n,e)}}function o(){"complete"===l.readyState&&i()}function i(){c("mark",["domContent",a()+x.offset],null,"api")}function a(){return O.exists&&performance.now?Math.round(performance.now()):(s=Math.max((new Date).getTime(),s))-x.offset}var s=(new Date).getTime(),c=t("handle"),f=t(21),u=t("ee"),d=t(20),p=window,l=p.document,h="addEventListener",m="attachEvent",v=p.XMLHttpRequest,w=v&&v.prototype;NREUM.o={ST:setTimeout,SI:p.setImmediate,CT:clearTimeout,XHR:v,REQ:p.Request,EV:p.Event,PR:p.Promise,MO:p.MutationObserver};var y=""+location,g={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-spa-1118.min.js"},b=v&&w&&w[h]&&!/CriOS/.test(navigator.userAgent),x=e.exports={offset:s,now:a,origin:y,features:{},xhrWrappable:b,userAgent:d};t(17),l[h]?(l[h]("DOMContentLoaded",i,!1),p[h]("load",r,!1)):(l[m]("onreadystatechange",o),p[m]("onload",r)),c("mark",["firstbyte",s],null,"api");var E=0,O=t(23)},{}]},{},["loader",2,15,5,3,4]);
</script>
<script type="text/javascript">
NREUM.info = {beacon: "bam.nr-data.net",errorBeacon: "bam.nr-data.net",licenseKey: "496abe3d21",applicationID: "13279578",sa: 1};
</script>
<script type="text/javascript">
var _rollbarConfig = {"accessToken":"0395d8ba4e444e1794cd0969aff19a3e","captureUncaught":true,"captureUnhandledRejections":true,"payload":{"environment":"prd","person":{"id":"5440495942"},"client":{"javascript":{"source_map_enabled":true,"code_version":null}},"vp":{"version":"40.0","language":"In","locale":"In","studio_mode":"Studio4 - Monolith"},"branch":null}};!function(r){function e(n){if(o[n])return o[n].exports;var t=o[n]={exports:{},id:n,loaded:!1};return r[n].call(t.exports,t,t.exports,e),t.loaded=!0,t.exports}var o={};return e.m=r,e.c=o,e.p="",e(0)}([function(r,e,o){"use strict";var n=o(1),t=o(4);_rollbarConfig=_rollbarConfig||{},_rollbarConfig.rollbarJsUrl=_rollbarConfig.rollbarJsUrl||"/sf/_hc-93d34cb9/_/vp/JS-Lib/ThirdParty/rollbar/rollbar_min.js",_rollbarConfig.async=void 0===_rollbarConfig.async||_rollbarConfig.async;var a=n.setupShim(window,_rollbarConfig),l=t(_rollbarConfig);window.rollbar=n.Rollbar,a.loadFull(window,document,!_rollbarConfig.async,_rollbarConfig,l)},function(r,e,o){"use strict";function n(r){return function(){try{return r.apply(this,arguments)}catch(r){try{console.error("[Rollbar]: Internal error",r)}catch(r){}}}}function t(r,e){this.options=r,this._rollbarOldOnError=null;var o=s++;this.shimId=function(){return o},"undefined"!=typeof window&&window._rollbarShims&&(window._rollbarShims[o]={handler:e,messages:[]})}function a(r,e){if(r){var o=e.globalAlias||"Rollbar";if("object"==typeof r[o])return r[o];r._rollbarShims={},r._rollbarWrappedError=null;var t=new p(e);return n(function(){e.captureUncaught&&(t._rollbarOldOnError=r.onerror,i.captureUncaughtExceptions(r,t,!0),i.wrapGlobals(r,t,!0)),e.captureUnhandledRejections&&i.captureUnhandledRejections(r,t,!0);var n=e.autoInstrument;return e.enabled!==!1&&(void 0===n||n===!0||"object"==typeof n&&n.network)&&r.addEventListener&&(r.addEventListener("load",t.captureLoad.bind(t)),r.addEventListener("DOMContentLoaded",t.captureDomContentLoaded.bind(t))),r[o]=t,t})()}}function l(r){return n(function(){var e=this,o=Array.prototype.slice.call(arguments,0),n={shim:e,method:r,args:o,ts:new Date};window._rollbarShims[this.shimId()].messages.push(n)})}var i=o(2),s=0,d=o(3),c=function(r,e){return new t(r,e)},p=function(r){return new d(c,r)};t.prototype.loadFull=function(r,e,o,t,a){var l=function(){var e;if(void 0===r._rollbarDidLoad){e=new Error("rollbar.js did not load");for(var o,n,t,l,i=0;o=r._rollbarShims[i++];)for(o=o.messages||[];n=o.shift();)for(t=n.args||[],i=0;i<t.length;++i)if(l=t[i],"function"==typeof l){l(e);break}}"function"==typeof a&&a(e)},i=!1,s=e.createElement("script"),d=e.getElementsByTagName("script")[0],c=d.parentNode;s.crossOrigin="",s.src=t.rollbarJsUrl,o||(s.async=!0),s.onload=s.onreadystatechange=n(function(){if(!(i||this.readyState&&"loaded"!==this.readyState&&"complete"!==this.readyState)){s.onload=s.onreadystatechange=null;try{c.removeChild(s)}catch(r){}i=!0,l()}}),c.insertBefore(s,d)},t.prototype.wrap=function(r,e,o){try{var n;if(n="function"==typeof e?e:function(){return e||{}},"function"!=typeof r)return r;if(r._isWrap)return r;if(!r._rollbar_wrapped&&(r._rollbar_wrapped=function(){o&&"function"==typeof o&&o.apply(this,arguments);try{return r.apply(this,arguments)}catch(o){var e=o;throw e&&("string"==typeof e&&(e=new String(e)),e._rollbarContext=n()||{},e._rollbarContext._wrappedSource=r.toString(),window._rollbarWrappedError=e),e}},r._rollbar_wrapped._isWrap=!0,r.hasOwnProperty))for(var t in r)r.hasOwnProperty(t)&&(r._rollbar_wrapped[t]=r[t]);return r._rollbar_wrapped}catch(e){return r}};for(var u="log,debug,info,warn,warning,error,critical,global,configure,handleUncaughtException,handleUnhandledRejection,captureEvent,captureDomContentLoaded,captureLoad".split(","),f=0;f<u.length;++f)t.prototype[u[f]]=l(u[f]);r.exports={setupShim:a,Rollbar:p}},function(r,e){"use strict";function o(r,e,o){if(r){var t;if("function"==typeof e._rollbarOldOnError)t=e._rollbarOldOnError;else if(r.onerror){for(t=r.onerror;t._rollbarOldOnError;)t=t._rollbarOldOnError;e._rollbarOldOnError=t}var a=function(){var o=Array.prototype.slice.call(arguments,0);n(r,e,t,o)};o&&(a._rollbarOldOnError=t),r.onerror=a}}function n(r,e,o,n){r._rollbarWrappedError&&(n[4]||(n[4]=r._rollbarWrappedError),n[5]||(n[5]=r._rollbarWrappedError._rollbarContext),r._rollbarWrappedError=null),e.handleUncaughtException.apply(e,n),o&&o.apply(r,n)}function t(r,e,o){if(r){"function"==typeof r._rollbarURH&&r._rollbarURH.belongsToShim&&r.removeEventListener("unhandledrejection",r._rollbarURH);var n=function(r){var o,n,t;try{o=r.reason}catch(r){o=void 0}try{n=r.promise}catch(r){n="[unhandledrejection] error getting `promise` from event"}try{t=r.detail,!o&&t&&(o=t.reason,n=t.promise)}catch(r){t="[unhandledrejection] error getting `detail` from event"}o||(o="[unhandledrejection] error getting `reason` from event"),e&&e.handleUnhandledRejection&&e.handleUnhandledRejection(o,n)};n.belongsToShim=o,r._rollbarURH=n,r.addEventListener("unhandledrejection",n)}}function a(r,e,o){if(r){var n,t,a="EventTarget,Window,Node,ApplicationCache,AudioTrackList,ChannelMergerNode,CryptoOperation,EventSource,FileReader,HTMLUnknownElement,IDBDatabase,IDBRequest,IDBTransaction,KeyOperation,MediaController,MessagePort,ModalWindow,Notification,SVGElementInstance,Screen,TextTrack,TextTrackCue,TextTrackList,WebSocket,WebSocketWorker,Worker,XMLHttpRequest,XMLHttpRequestEventTarget,XMLHttpRequestUpload".split(",");for(n=0;n<a.length;++n)t=a[n],r[t]&&r[t].prototype&&l(e,r[t].prototype,o)}}function l(r,e,o){if(e.hasOwnProperty&&e.hasOwnProperty("addEventListener")){for(var n=e.addEventListener;n._rollbarOldAdd&&n.belongsToShim;)n=n._rollbarOldAdd;var t=function(e,o,t){n.call(this,e,r.wrap(o),t)};t._rollbarOldAdd=n,t.belongsToShim=o,e.addEventListener=t;for(var a=e.removeEventListener;a._rollbarOldRemove&&a.belongsToShim;)a=a._rollbarOldRemove;var l=function(r,e,o){a.call(this,r,e&&e._rollbar_wrapped||e,o)};l._rollbarOldRemove=a,l.belongsToShim=o,e.removeEventListener=l}}r.exports={captureUncaughtExceptions:o,captureUnhandledRejections:t,wrapGlobals:a}},function(r,e){"use strict";function o(r,e){this.impl=r(e,this),this.options=e,n(o.prototype)}function n(r){for(var e=function(r){return function(){var e=Array.prototype.slice.call(arguments,0);if(this.impl[r])return this.impl[r].apply(this.impl,e)}},o="log,debug,info,warn,warning,error,critical,global,configure,handleUncaughtException,handleUnhandledRejection,_createItem,wrap,loadFull,shimId,captureEvent,captureDomContentLoaded,captureLoad".split(","),n=0;n<o.length;n++)r[o[n]]=e(o[n])}o.prototype._swapAndProcessMessages=function(r,e){this.impl=r(this.options);for(var o,n,t;o=e.shift();)n=o.method,t=o.args,this[n]&&"function"==typeof this[n]&&("captureDomContentLoaded"===n||"captureLoad"===n?this[n].apply(this,[t[0],o.ts]):this[n].apply(this,t));return this},r.exports=o},function(r,e){"use strict";r.exports=function(r){return function(e){if(!e&&!window._rollbarInitialized){r=r||{};for(var o,n,t=r.globalAlias||"Rollbar",a=window.rollbar,l=function(r){return new a(r)},i=0;o=window._rollbarShims[i++];)n||(n=o.handler),o.handler._swapAndProcessMessages(l,o.messages);window[t]=n,window._rollbarInitialized=!0}}}}]);
</script>
<script type="text/javascript">
try {
window.vpSiteVersion="40.0";
window.languageId=36;
window.imageHost='';
window._cookieDomain='.vistaprint.in';
window._vp_page_guid = 'eb3f4f1a-7bcd-4cb9-9315-5199c2c9fe35';
window._vp_session_id = 5440495942;
var VP_CLIENT_EVENT_TYPE_Unknown = 0;
var VP_CLIENT_EVENT_TYPE_Begin = 1;
var VP_CLIENT_EVENT_TYPE_Load = 2;
var VP_CLIENT_EVENT_TYPE_Unload = 3;
var VP_CLIENT_EVENT_TYPE_Error = 4;
var VP_CLIENT_EVENT_TYPE_DomLoad = 5;
var VP_CLIENT_EVENT_TYPE_LandingPageLoad = 6;
var VP_CLIENT_EVENT_TYPE_LandingPageLoadServer = 7;

window._vp_log_client_errors = true;
} catch (ex) {}
window._browserData = {className: "Webkit", classVersion: { major: 537.36, minor: 0.0 }, name: "GoogleChrome", version: { major: 75.0, minor: 3770.142 }, operatingSystem: "Windows", operatingSystemVersion: { major: 10.0, minor: 0.0 }, isMobile: false, isSmallMobile: false, isTablet: false, supportsPng: true, supportsInlineImages: true, isIeCompatMode: false, ieCompatModeRealVersion: 0};

</script>
<script type="text/javascript" src="/sf/_hc-8651c9a5/_/vp/JS-Lib/common/bootstrapper_min.js"></script>
<script type="text/javascript">
try {

       function setConfirmRedirect(locale, lang) {
            jQuery('a[name=HubPageRedirectMessageModalOk]').attr('href', '/EnterprisePartner/HubPage/GoToLocale?locale='+locale+'&langid='+lang); 
            return true;
        }
    ;
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
window._sessionCacheToken = "wXzYelxDYiN0uX7_3mfgJQ";
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }


</script>


</head>
<body>
<div class="canvases">

<div class="canvas-container " style="position: relative; display: block; height: 430px; width: 954px;">
    <div id="canvas_div" class="canvas" style="top: 0px; left: 0px; width: 954px; height: 430px;"><div class="underlay canvas-element-wrapper"><img class="product-underlay" id="d0-1-product-underlay" crossorigin="anonymous" src="./image/livepreview.jpg" style="top: 0px; left: 0px; width: 954px; height: 430px;"></div><div class="items canvas-element-wrapper"><img class="item ui-resizable" id="d0-1-backgroundImage" crossorigin="anonymous" style="left: 0px; top: 0px; width: 954px; height: 430px; z-index: 1;" src="./image/studio.png"><img class="item ui-resizable" id="d0-1-vpls_img_2" crossorigin="anonymous" style="left: 0px; top: 0px; width: 953px; height: 429px; z-index: 2;" src="./image/preview.png"><img class="item ui-resizable" id="d0-1-vpls_img_1" crossorigin="anonymous" style="left: 56px; top: 56px; width: 287px; height: 318px; z-index: 3;" src="./image/preview_img.png"><img class="item" id="d0-1-vpls_shape_3" crossorigin="anonymous" style="left: 399px; top: 125px; z-index: 4; visibility: visible;" src="./image/studio_txt.png"><img class="item" id="d0-1-vpls_shape_4" crossorigin="anonymous" style="left: 399px; top: 235px; z-index: 5;" src="./image/studio_txt.png"><img class="item" id="d0-1-item_99" crossorigin="anonymous" src="./image/studio_txt.png" style="left: 404px; top: 304px; z-index: 6; display: inline-block; visibility: visible;"></div><div class="decorations canvas-element-wrapper"><div class="decoration not-customer-modifiable ui-resizable" id="d0-1-backgroundImage-decoration" style="top: 0px; left: 0px; width: 954px; height: 430px; z-index: 1;"><div class="studio-live-selection-box"></div></div><div class="decoration locked selected" id="d0-1-vpls_img_2-decoration" style="top: 0px; left: 0px; width: 953px; height: 429px; z-index: 2;"><div class="studio-live-selection-box"></div></div><div class="decoration locked" id="d0-1-vpls_img_1-decoration" style="top: 56px; left: 56px; width: 286px; height: 317px; z-index: 3;"><div class="studio-live-selection-box"></div></div><div class="decoration ui-resizable" id="d0-1-vpls_shape_3-decoration" style="top: 125px; left: 399px; width: 413px; height: 92px; z-index: 4;"><div class="studio-live-selection-box"></div></div><div class="decoration ui-resizable" id="d0-1-vpls_shape_4-decoration" style="top: 235px; left: 399px; width: 506px; height: 32px; z-index: 5;"><div class="studio-live-selection-box"></div></div><div class="decoration ui-resizable horizontal" id="d0-1-item_99-decoration" style="top: 293px; left: 394px; width: 455px; height: 66px; z-index: 6;"><div class="studio-live-selection-box"></div></div></div><div class="overlay canvas-element-wrapper"><div class="safety-margin" id="safety-margin" style="display: block;"><div class="safety-margin-line-fg" style="top: 8px; left: 8px; width: 1px; height: 414px;"></div><div class="safety-margin-line-fg" style="top: 8px; left: 8px; width: 938px; height: 1px;"></div><div class="safety-margin-line-fg" style="top: 8px; left: 946px; width: 1px; height: 414px;"></div><div class="safety-margin-line-fg" style="top: 422px; left: 8px; width: 938px; height: 1px;"></div><div class="safety-margin-line-bg" style="top: 8px; left: 8px; width: 1px; height: 414px;"></div><div class="safety-margin-line-bg" style="top: 8px; left: 8px; width: 938px; height: 1px;"></div><div class="safety-margin-line-bg" style="top: 8px; left: 946px; width: 1px; height: 414px;"></div><div class="safety-margin-line-bg" style="top: 422px; left: 8px; width: 938px; height: 1px;"></div><div class="safety-line-callout">
    <div class="header-text" style="left: 5px; top: -24px;">Safety Line</div>
    <div class="pointer-line-bg" style="left: 38px; width: 1px; height: 8px; top: 0px;"></div>
    <div class="pointer-line-fg" style="left: 38px; width: 1px; height: 8px; top: 0px;"></div>
    <div class="pointer-circle" style="left: 35px; top: 5px;"></div>
<div class="safety-line-callout">
    <div class="header-text" style="left: 5px; top: -24px;">Safety Line</div>
    <div class="pointer-line-bg" style="left: 38px; width: 1px; height: 8px; top: 0px;"></div>
    <div class="pointer-line-fg" style="left: 38px; width: 1px; height: 8px; top: 0px;"></div>
    <div class="pointer-circle" style="left: 35px; top: 5px;"></div>
</div>

<div class="safety-line-message" style="left: 5px; top: -3px;">
    <div>Anything outside of the safety line may be trimmed off in the printing process</div>
        <a href="javascript://" class="more-details">More print tips</a>
</div></div>

<div class="safety-line-message" style="left: 5px; top: -3px;">
    <div>Anything outside of the safety line may be trimmed off in the printing process</div>
        <a href="javascript://" class="more-details">More print tips</a>
</div></div><div class="grid-overlay" style="display: none;"><div class="grid-line section-line" style="top: 215.037px; left: 0px; width: 954px; height: 2px;"></div><div class="grid-line section-line" style="top: 215.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line section-line" style="top: 215.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 195.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 235.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 175.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 255.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 155.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 275.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 135.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 295.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line section-line" style="top: 115.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line section-line" style="top: 315.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 95.0374px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 335.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 75.0374px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 355.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 55.0374px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 375.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 35.0374px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line" style="top: 395.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line section-line" style="top: 15.0374px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line section-line" style="top: 415.037px; left: 0px; width: 954px; height: 1px;"></div><div class="grid-line section-line" style="top: 0px; left: 477px; width: 2px; height: 430.075px;"></div><div class="grid-line section-line" style="top: 0px; left: 477px; width: 1px; height: 430.075px;"></div><div class="grid-line section-line" style="top: 0px; left: 477px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 457px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 497px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 437px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 517px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 417px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 537px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 397px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 557px; width: 1px; height: 430.075px;"></div><div class="grid-line section-line" style="top: 0px; left: 377px; width: 1px; height: 430.075px;"></div><div class="grid-line section-line" style="top: 0px; left: 577px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 357px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 597px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 337px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 617px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 317px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 637px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 297px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 657px; width: 1px; height: 430.075px;"></div><div class="grid-line section-line" style="top: 0px; left: 277px; width: 1px; height: 430.075px;"></div><div class="grid-line section-line" style="top: 0px; left: 677px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 257px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 697px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 237px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 717px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 217px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 737px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 197px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 757px; width: 1px; height: 430.075px;"></div><div class="grid-line section-line" style="top: 0px; left: 177px; width: 1px; height: 430.075px;"></div><div class="grid-line section-line" style="top: 0px; left: 777px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 157px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 797px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 137px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 817px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 117px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 837px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 97px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 857px; width: 1px; height: 430.075px;"></div><div class="grid-line section-line" style="top: 0px; left: 77px; width: 1px; height: 430.075px;"></div><div class="grid-line section-line" style="top: 0px; left: 877px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 57px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 897px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 37px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 917px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 17px; width: 1px; height: 430.075px;"></div><div class="grid-line" style="top: 0px; left: 937px; width: 1px; height: 430.075px;"></div></div></div><div class="handles canvas-element-wrapper" style="width: 954px; height: 430px;"><div class="handle ui-selectable ui-draggable ui-resizable selected" id="d0-1-vpls_img_2-handle" style="top: 0px; left: 0px; width: 953px; height: 429px;"><div class="handle-target" unselectable="on"></div></div><div class="handle ui-selectable ui-draggable ui-resizable" id="d0-1-vpls_img_1-handle" style="top: 56px; left: 56px; width: 286px; height: 317px;"><div class="handle-target" unselectable="on"></div></div><div class="handle force-high-zindex ui-selectable ui-draggable ui-resizable" id="d0-1-vpls_shape_3-handle" style="top: 125px; left: 399px; width: 413px; height: 92px; visibility: visible;"><div class="handle-target" unselectable="on"></div><div class="ui-resizable-handle ui-resizable-nw" data-handle="nw"></div><div class="ui-resizable-handle ui-resizable-ne" data-handle="ne"></div><div class="ui-resizable-handle ui-resizable-sw" data-handle="sw"></div><div class="ui-resizable-handle ui-resizable-se" data-handle="se"></div></div><div class="handle force-high-zindex ui-selectable ui-draggable ui-resizable" id="d0-1-vpls_shape_4-handle" style="top: 235px; left: 399px; width: 506px; height: 32px;"><div class="handle-target" unselectable="on"></div><div class="ui-resizable-handle ui-resizable-nw" data-handle="nw"></div><div class="ui-resizable-handle ui-resizable-ne" data-handle="ne"></div><div class="ui-resizable-handle ui-resizable-sw" data-handle="sw"></div><div class="ui-resizable-handle ui-resizable-se" data-handle="se"></div></div><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAAAAACH5BAEBAAAALAAAAAABAAEAAAICRAEAOw==" usemap="#d0-1-map" class="handle-image" hidefocus="true" unselectable="true"><map name="d0-1-map"><area id="d0-1-item_99-area" shape="rect" coords="404,304,806,348" href="#d0-1-item_99"><area id="d0-1-vpls_shape_4-area" shape="poly" coords="399,235,605.4276266350827,235,605.4276266350827,266.5599735937044,399,266.5599735937044" href="#d0-1-vpls_shape_4" tabindex="2"><area id="d0-1-vpls_shape_3-area" shape="poly" coords="399,145.55563695802138,812.2873904972901,145.55563695802138,812.2873904972901,196.73515945815944,399,196.73515945815944" href="#d0-1-vpls_shape_3" tabindex="1"><area id="d0-1-vpls_img_1-area" shape="rect" coords="56,56,342,373" href="#d0-1-vpls_img_1" tabindex="3"><area id="d0-1-vpls_img_2-area" shape="rect" coords="0,0,953,429" href="#d0-1-vpls_img_2" tabindex="4"><area shape="rect" class="canvas-handle-area" coords="0,0,954,430" id="d0-1-area"></map><div class="handle force-high-zindex ui-selectable ui-draggable ui-resizable horizontal" id="d0-1-item_99-handle" style="top: 293px; left: 394px; width: 455px; height: 66px; display: inline-block; visibility: visible;"><div class="handle-target" unselectable="on"></div><div class="ui-resizable-handle ui-resizable-e" data-handle="e"></div><div class="ui-resizable-handle ui-resizable-w" data-handle="w"></div></div></div></div>

    
    
    <div class="zoom-slider">
        <div class="zoom-out"><a href="javascript:void(0)" class="textbutton textbutton-round"> <span class="textbutton-icon textbutton-icon-minus"></span> </a></div>
        <div class="slider-container"> <span class="irs js-irs-2"><span class="irs"><span class="irs-line" tabindex="-1"><span class="irs-line-left"></span><span class="irs-line-mid"></span><span class="irs-line-right"></span></span><span class="irs-min" style="">0</span><span class="irs-max" style="">100</span><span class="irs-from" style="visibility: hidden;">0</span><span class="irs-to" style="visibility: hidden;">0</span><span class="irs-single">0</span></span><span class="irs-grid"></span><span class="irs-bar"></span><span class="irs-bar-edge"></span><span class="irs-shadow shadow-single"></span><span class="irs-slider single"></span></span><input type="range" class="range-slider irs-hidden-input" min="0" max="100" value="60" step="5" readonly=""> </div>
        <div class="zoom-in"><a href="javascript:void(0)" class="textbutton textbutton-round"> <span class="textbutton-icon textbutton-icon-plus"></span> </a></div>
    </div>
</div> 
</div>


<div class="contextual-toolbar-container" style="bottom: 733px; left: 535px;">
<div class="item-contextual-toolbar contextual-toolbar toolbar above tool-group" style="display: none; visibility: visible;">

    <div class="expanded-tool-container" style="display: none; width: 511px;">
        <div class="resizable-bar"><div class="resizable-icon"></div></div>
        <a href="#" class="textbutton textbutton-round close-button">
            <span class="textbutton-icon textbutton-icon-delete"></span>
        </a>
    </div>
<div class="button-row tool-group" style="width: 511px;">
    <div class="slidable-button-row" style="transform: translateX(0px); width: 511px;"><div class="tool-group-wrapper" style="width: 511px;"><div class="buttons-with-separator tool-group" style="display: none;"><div class="toolbar-button item-ungroup-button ungroup-button">
<div class="toolbar-button-inner item-ungroup-button ungroup-button-inner">
    <span class="toolbar-button-icon"></span>
    <span class="toolbar-button-caption">Ungroup</span>
</div>

</div><div class="toolbar-button item-group-button group-button">
<div class="toolbar-button-inner item-group-button group-button-inner">
    <span class="toolbar-button-icon"></span>
    <span class="toolbar-button-caption">Group</span>
</div>

</div></div><div class="buttons-with-separator tool-group" style="display: none;"><div unselectable="on" class="premium-finishes-toggle-tool">
    <span class="toggle-label"></span>
    <fieldset class="buttonbar">
            <input name="premium-finishes-toggle-tool" type="radio" id="premium-finishes-toggle-tool-0" value="1"> 
            <label for="premium-finishes-toggle-tool-0">On</label> 
            <input name="premium-finishes-toggle-tool" type="radio" id="premium-finishes-toggle-tool-1" value="0"> 
            <label for="premium-finishes-toggle-tool-1">Off</label> 
    </fieldset>
</div></div><div class="buttons-with-separator tool-group" style="display: none;"><div unselectable="on" class="toolbar-button table-style-picker" style="display: none;">
    <div class="expanded-tool table-style-picker-expanded-tool" style="display: none;">
        <div class="table-style-picker-previews tool-content">
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="1"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="2"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="3"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="4"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="5"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="6"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="7"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="8"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="9"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="10"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="11"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="12"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="13"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="14"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="15"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="16"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="17"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="18"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="19"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="20"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="21"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="22"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="23"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="24"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="25"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="26"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="27"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="28"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="29"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="30"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="31"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="32"></span>
                <span class="table-style" unselectable="on"><img class="table-style-preview" data-style-id="33"></span>
        </div>
    </div>
<span class="table-style-picker-label">Table design</span></div><div unselectable="on" class="toolbar-button with-separator background-color-picker">
    <div class="expanded-tool categorized-expanded-tool background-color-picker-expanded-tool">
    </div>
<div class="color-picker-shadow"></div><span class="color-picker-label">Table colour</span></div><div class="toolbar-button insert-column-before">Add Column <br> to the Left</div><div class="toolbar-button insert-column-after">Add Column <br> to the Right</div><div class="toolbar-button insert-row-before">Add Row <br> Above</div><div class="toolbar-button insert-row-after">Add Row <br> Below</div><div class="toolbar-button align-column-left"></div><div class="toolbar-button align-column-center"></div><div class="toolbar-button align-column-right"></div><div class="toolbar-button delete-column"></div><div class="toolbar-button delete-row"></div></div><div class="with-separator tool-group-little" style="display: none;"><div class="font-family-tool" style="" title="Font">
    <div unselectable="on" class="font-family-display-name"><img src="./image/clearpixel.gif" style="background-image: url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1160px" unselectable="on">
</div>
    
    <div class="expanded-tool categorized-expanded-tool font-family-expanded-tool" style="display:none;">
        <div class="tool-content">
            
            
            <div class="font-list recently-used-font-list">
                    <div class="tool-select-option font-option" data-font-family-name="Futura Bk BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1160px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
            </div>
            
            
            <div class="font-list all-fonts-font-list">

                    <div class="tool-select-option font-option" data-font-family-name="Abel">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px 0px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Adamina">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -20px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Adelle">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -40px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Alex Brush">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -60px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Amazone BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -80px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="AnnabelleJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -100px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Antic Slab">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -120px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Apertura Web">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -140px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Archivo Narrow">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -160px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Arial">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -180px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Armitage">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -200px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Athelas Rg">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -220px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Balloon Bd BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -240px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="BankGothic Md BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -260px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Baskerville BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -280px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="BatangChe">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -300px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="BeignetJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -320px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Benchnine">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -340px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="BernhardMod BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -360px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Bevan">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -380px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="BookmanJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -400px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="BoxerScriptJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -420px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Bree">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -440px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Bree Serif">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -460px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="BrushScript BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -480px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="BuenaParkJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -500px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Buenard">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -520px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="CabernetJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -540px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Calla Web Titling">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -560px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="CapitalPoster">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -580px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Carrois Gothic">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -600px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Catamaran">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -620px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Caveat">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -640px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Comic Sans MS">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -660px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="ComicPro JY">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -680px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="CopprplGoth BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -700px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Coquette">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -720px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="CornerStoreJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -740px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Courier New">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -760px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Crete">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -780px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Cuisine">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -800px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Damion">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -820px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="DandelionJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -840px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="De Soto">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -860px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="De Soto Engraved">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -880px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="DebonairJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -900px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Didact Gothic">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -920px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="DomCasual BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -940px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Dotum">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -960px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="DotumChe">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -980px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Eb Garamond">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1000px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="EloquentJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1020px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="EmpyreanJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1040px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="English157 BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1060px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Euphoria Script">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1080px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="FangSong_GB2312">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1100px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="FenwayParkJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1120px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Fjalla One">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1140px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Futura Bk BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1160px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="FZShuTi">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1180px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="FZYaoTi">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1200px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Georgia">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1220px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Gochi Hand">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1240px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="GoldenStateJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1260px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="GoudyOlSt BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1280px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Grand Hotel">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1300px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Grandma">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1320px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Gruppo">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1340px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Gulim">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1360px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="GulimChe">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1380px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Gungsuh">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1400px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="GungsuhChe">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1420px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Handlee">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1440px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="HellenicWideJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1460px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Hind">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1480px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="HolidayTimesJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1500px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="HooliganJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1520px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="HucklebuckJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1540px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Humanst521 BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1560px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Impact">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1580px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Integrity JY Lining 2">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1600px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="JohnAndrewJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1620px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="KaiTi_GB2312">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1640px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Kandal">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1660px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Kandal Black">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1680px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Kennedy Sm Caps Book GD">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1700px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="KonTikiEnchantedJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1720px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="LFT Etica">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1740px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="LiSu">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1760px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Lobster Two">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1780px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="LuxRoyaleJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1800px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Mallanna">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1820px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="MaryHelenJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1840px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Melanie BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1860px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="MingLiU">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1880px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Missy BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1900px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="MisterEarl BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1920px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Mostra Nuova">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1940px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="MS Gothic">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1960px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="MS Mincho">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1980px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="MS PGothic">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2000px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="MS PMincho">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2020px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Nixie One">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2040px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="NSimSun">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2060px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Open Sans">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2080px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Parisienne">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2100px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Petit Formal Script">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2120px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Pill Web 300mg">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2140px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="PMingLiU">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2160px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Poiret One">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2180px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Politica">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2200px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Poppins">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2220px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Proxima Nova Black">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2240px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Proxima Nova Rg">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2260px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Quattrocento">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2280px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Quicksand">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2300px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Raleway">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2320px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="RandolphJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2340px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Refrigerator Deluxe">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2360px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Roboto Slab">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2380px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Roger">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2400px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Ronnia Cond">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2420px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Roundhand BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2440px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Sacramento">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2460px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Sail">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2480px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Satisfy">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2500px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="ScriptoramaJF Hostess">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2520px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="SimHei">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2540px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="SimSun">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2560px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Slabo 27Px">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2580px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Sofia">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2600px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="SouthlandJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2620px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="STCaiyun">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2640px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Stencil BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2660px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="StephanieMarieJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2680px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Stint Ultra Expanded">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2700px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="STXihei">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2720px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="STXingkai">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2740px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="STXinwei">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2760px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="STZhongsong">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2780px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Suranna">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2800px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Swis721 BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2820px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Tahoma">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2840px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Times New Roman">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2860px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Trebuchet MS">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2880px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="VAGRounded BT">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2900px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="ValentinaJoyJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2920px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="VarsityScriptJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2940px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Verdana">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2960px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="WesleyJF">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2980px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Wingdings">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -3000px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
                    <div class="tool-select-option font-option" data-font-family-name="Zag">
                            <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -3020px;" unselectable="on">
                        <div class="overflow-gradient"></div>
                    </div>
            </div>
            
            
                <div class="font-list bold-font-list">
                        <div class="tool-select-option font-option" data-font-family-name="Bevan">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -380px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="CabernetJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -540px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Crete">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -780px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="EloquentJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1020px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Fjalla One">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1140px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="HucklebuckJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1540px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Impact">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1580px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Kandal Black">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1680px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Proxima Nova Black">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2240px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="RandolphJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2340px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Stencil BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2660px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="VAGRounded BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2900px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                </div>
                <div class="font-list classic-font-list">
                        <div class="tool-select-option font-option" data-font-family-name="Adamina">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -20px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Adelle">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -40px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Antic Slab">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -120px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Arial">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -180px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Athelas Rg">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -220px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Baskerville BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -280px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="BernhardMod BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -360px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="BookmanJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -400px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Buenard">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -520px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Calla Web Titling">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -560px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="CopprplGoth BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -700px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Courier New">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -760px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="De Soto">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -860px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="De Soto Engraved">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -880px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Eb Garamond">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1000px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="EmpyreanJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1040px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Georgia">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1220px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="GoudyOlSt BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1280px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Kandal">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1660px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Kennedy Sm Caps Book GD">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1700px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Nixie One">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2040px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Quattrocento">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2280px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Roboto Slab">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2380px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Slabo 27Px">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2580px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Suranna">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2800px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Times New Roman">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2860px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                </div>
                <div class="font-list fun-font-list">
                        <div class="tool-select-option font-option" data-font-family-name="Balloon Bd BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -240px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Bree Serif">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -460px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Caveat">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -640px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Comic Sans MS">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -660px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="ComicPro JY">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -680px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="CornerStoreJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -740px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="DandelionJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -840px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="DomCasual BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -940px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Gochi Hand">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1240px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="GoldenStateJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1260px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Grand Hotel">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1300px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Grandma">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1320px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Handlee">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1440px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="HolidayTimesJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1500px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Lobster Two">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1780px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Melanie BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1860px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Missy BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1900px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="MisterEarl BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1920px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Poiret One">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2180px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Roger">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2400px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Sail">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2480px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Sofia">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2600px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                </div>
                <div class="font-list international-font-list">
                        <div class="tool-select-option font-option" data-font-family-name="BatangChe">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -300px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Dotum">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -960px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="DotumChe">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -980px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="FangSong_GB2312">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1100px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="FZShuTi">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1180px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="FZYaoTi">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1200px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Gulim">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1360px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="GulimChe">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1380px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Gungsuh">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1400px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="GungsuhChe">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1420px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Hind">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1480px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="KaiTi_GB2312">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1640px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="LiSu">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1760px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="MingLiU">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1880px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="MS Gothic">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1960px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="MS Mincho">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1980px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="MS PGothic">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2000px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="MS PMincho">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2020px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="NSimSun">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2060px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="PMingLiU">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2160px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Poppins">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2220px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="SimHei">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2540px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="SimSun">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2560px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="STCaiyun">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2640px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="STXihei">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2720px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="STXingkai">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2740px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="STXinwei">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2760px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="STZhongsong">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2780px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                </div>
                <div class="font-list modern-font-list">
                        <div class="tool-select-option font-option" data-font-family-name="Abel">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px 0px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Apertura Web">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -140px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Archivo Narrow">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -160px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Armitage">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -200px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="BankGothic Md BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -260px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Benchnine">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -340px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Bree">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -440px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="BuenaParkJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -500px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="CapitalPoster">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -580px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Carrois Gothic">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -600px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Catamaran">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -620px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Coquette">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -720px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Didact Gothic">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -920px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Futura Bk BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1160px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Gruppo">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1340px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="HellenicWideJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1460px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="HooliganJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1520px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Humanst521 BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1560px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Integrity JY Lining 2">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1600px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="JohnAndrewJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1620px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="KonTikiEnchantedJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1720px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="LFT Etica">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1740px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Mallanna">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1820px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Mostra Nuova">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1940px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Open Sans">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2080px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Pill Web 300mg">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2140px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Politica">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2200px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Proxima Nova Rg">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2260px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Quicksand">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2300px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Raleway">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2320px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Refrigerator Deluxe">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2360px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Ronnia Cond">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2420px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="SouthlandJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2620px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Stint Ultra Expanded">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2700px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Swis721 BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2820px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Tahoma">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2840px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Trebuchet MS">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2880px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Verdana">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2960px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="WesleyJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2980px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Zag">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -3020px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                </div>
                <div class="font-list script-font-list">
                        <div class="tool-select-option font-option" data-font-family-name="Alex Brush">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -60px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Amazone BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -80px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="AnnabelleJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -100px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="BeignetJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -320px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="BoxerScriptJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -420px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="BrushScript BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -480px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Cuisine">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -800px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Damion">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -820px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="DebonairJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -900px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="English157 BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1060px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Euphoria Script">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1080px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="FenwayParkJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1120px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="LuxRoyaleJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1800px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="MaryHelenJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -1840px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Parisienne">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2100px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Petit Formal Script">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2120px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Roundhand BT">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2440px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Sacramento">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2460px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="Satisfy">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2500px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="ScriptoramaJF Hostess">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2520px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="StephanieMarieJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2680px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="ValentinaJoyJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2920px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                        <div class="tool-select-option font-option" data-font-family-name="VarsityScriptJF">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -2940px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                </div>
                <div class="font-list symbols-font-list">
                        <div class="tool-select-option font-option" data-font-family-name="Wingdings">
                                <img class="font-image" src="./image/clearpixel.gif" style="background-image:url(./image/fontsprite.png); width: 250px; height: 20px; background-position: 0px -3000px;" unselectable="on">
                            <div class="overflow-gradient"></div>
                        </div>
                </div>
        </div>
        
        
        <div class="font-categories tool-category-headers">
            
            
            <div class="tool-category-header font-category">
                <a href="#" class="font-category-link" data-category-name="recently-used"> Recently Used (<span class="recently-used-font-count">1</span>)</a>
            </div>
                
            
            <div class="tool-category-header font-category">
                <a href="#" class="font-category-link" data-category-name="all-fonts"> All Fonts (152)</a>
            </div>
                
            
                <div class="tool-category-header font-category">
                    <a href="#" class="font-category-link" data-category-name="bold">Bold (12)</a>
                </div>
                <div class="tool-category-header font-category">
                    <a href="#" class="font-category-link" data-category-name="classic">Classic (26)</a>
                </div>
                <div class="tool-category-header font-category">
                    <a href="#" class="font-category-link" data-category-name="fun">Fun (22)</a>
                </div>
                <div class="tool-category-header font-category">
                    <a href="#" class="font-category-link" data-category-name="international">International (28)</a>
                </div>
                <div class="tool-category-header font-category">
                    <a href="#" class="font-category-link" data-category-name="modern">Modern (40)</a>
                </div>
                <div class="tool-category-header font-category">
                    <a href="#" class="font-category-link" data-category-name="script">Script (23)</a>
                </div>
                <div class="tool-category-header font-category">
                    <a href="#" class="font-category-link" data-category-name="symbols">Symbols (1)</a>
                </div>
        </div>
    </div>
</div><div class="font-size-tool" style="display: none;">
    <div class="font-size-display"></div>

    <div class="expanded-tool font-size-slider-expanded-tool" style="display: none;">
        <div class="font-size-tools">
            <div class="title">Choose font size:
            <div class="font-size-input-container">
                <button class="textbutton textbutton-skin-secondary textbutton-round font-size-minus-button">
                    <span class="textbutton-icon textbutton-icon-minus"></span>
                </button>
                <div class="font-size-input">
                    <input type="text" data-max="2000" data-min="0" autocomplete="off" value="" name="fontSize" class="font-size-text-input stylized-input">
                </div>
                <button class="textbutton textbutton-skin-secondary textbutton-round font-size-plus-button">
                    <span class="textbutton-icon textbutton-icon-plus"></span>
                </button>
            </div>
            <div class="font-size-slider-container">
                <input class="font-size-range-slider range-slider" type="range" id="fontSizeSlider" value="" min="18" max="1000" step="1">
            </div>
        </div>
    </div>
</div></div></div><div class="buttons-with-separator tool-group" style="display: none;"><div class="toolbar-button font-size-adjustment increase-font-size" title="Increase Size"></div><div class="toolbar-button font-size-adjustment decrease-font-size" title="Decrease Size"></div><div unselectable="on" class="toolbar-button word-art-curve-tool" style="" title="Curve Text">
    <div class="expanded-tool word-art-curve-expanded-tool" style="display: none; height: 50px;">
        <div class="tool-content">
                <div class="word-art-curve sharpConvex" data-curve-command="sharpConvex" unselectable="on"> </div>
                <div class="word-art-curve convex" data-curve-command="convex" unselectable="on"> </div>
                <div class="word-art-curve straight" data-curve-command="straight" unselectable="on"> </div>
                <div class="word-art-curve concave" data-curve-command="concave" unselectable="on"> </div>
                <div class="word-art-curve sharpConcave" data-curve-command="sharpConcave" unselectable="on"> </div>
        </div>
    </div>
</div><div unselectable="on" class="toolbar-button with-separator font-color-picker color-picker" title="Colour">
    <div class="expanded-tool categorized-expanded-tool font-color-picker color-picker-expanded-tool">
    </div>
<div class="color-picker-shadow"></div><span class="color-picker-label">Font colour</span></div></div><div class="buttons-with-separator tool-group" style="display: none;"><div class="toolbar-button bold button-disabled" title="Bold"></div><div class="toolbar-button italic" title="Italic"></div><div class="toolbar-button underline" style="display: none;"></div></div><div class="buttons-with-separator tool-group" style="display: none;"><div class="toolbar-button leftjustify"></div><div class="toolbar-button centerjustify"></div><div class="toolbar-button rightjustify"></div></div><div class="buttons-with-separator tool-group" style="display: none;"><div class="toolbar-button orderedlist" style="display: none;"></div><div class="toolbar-button unorderedlist" style="display: none;"></div><div unselectable="on" class="toolbar-button special-characters-tool" style="" title="Special Character">
    <div class="expanded-tool special-characters-expanded-tool" style="display: none;">
        <div class="special-characters-picker tool-content">
                <span class="special-character" unselectable="on">‚</span>
                <span class="special-character" unselectable="on">ƒ</span>
                <span class="special-character" unselectable="on">„</span>
                <span class="special-character" unselectable="on">…</span>
                <span class="special-character" unselectable="on">†</span>
                <span class="special-character" unselectable="on">‡</span>
                <span class="special-character" unselectable="on">ˆ</span>
                <span class="special-character" unselectable="on">‰</span>
                <span class="special-character" unselectable="on">Š</span>
                <span class="special-character" unselectable="on">‹</span>
                <span class="special-character" unselectable="on">Œ</span>
                <span class="special-character" unselectable="on">‘</span>
                <span class="special-character" unselectable="on">’</span>
                <span class="special-character" unselectable="on">“</span>
                <span class="special-character" unselectable="on">”</span>
                <span class="special-character" unselectable="on">•</span>
                <span class="special-character" unselectable="on">–</span>
                <span class="special-character" unselectable="on">—</span>
                <span class="special-character" unselectable="on">˜</span>
                <span class="special-character" unselectable="on">™</span>
                <span class="special-character" unselectable="on">š</span>
                <span class="special-character" unselectable="on">›</span>
                <span class="special-character" unselectable="on">œ</span>
                <span class="special-character" unselectable="on">Ÿ</span>
                <span class="special-character" unselectable="on">¡</span>
                <span class="special-character" unselectable="on">¢</span>
                <span class="special-character" unselectable="on">£</span>
                <span class="special-character" unselectable="on">¤</span>
                <span class="special-character" unselectable="on">¥</span>
                <span class="special-character" unselectable="on">¦</span>
                <span class="special-character" unselectable="on">§</span>
                <span class="special-character" unselectable="on">¨</span>
                <span class="special-character" unselectable="on">©</span>
                <span class="special-character" unselectable="on">ª</span>
                <span class="special-character" unselectable="on">«</span>
                <span class="special-character" unselectable="on">¬</span>
                <span class="special-character" unselectable="on">®</span>
                <span class="special-character" unselectable="on">¯</span>
                <span class="special-character" unselectable="on">°</span>
                <span class="special-character" unselectable="on">±</span>
                <span class="special-character" unselectable="on">²</span>
                <span class="special-character" unselectable="on">³</span>
                <span class="special-character" unselectable="on">´</span>
                <span class="special-character" unselectable="on">¶</span>
                <span class="special-character" unselectable="on">·</span>
                <span class="special-character" unselectable="on">¸</span>
                <span class="special-character" unselectable="on">¹</span>
                <span class="special-character" unselectable="on">º</span>
                <span class="special-character" unselectable="on">»</span>
                <span class="special-character" unselectable="on">¼</span>
                <span class="special-character" unselectable="on">½</span>
                <span class="special-character" unselectable="on">¾</span>
                <span class="special-character" unselectable="on">¿</span>
                <span class="special-character" unselectable="on">À</span>
                <span class="special-character" unselectable="on">Á</span>
                <span class="special-character" unselectable="on">Â</span>
                <span class="special-character" unselectable="on">Ã</span>
                <span class="special-character" unselectable="on">Ä</span>
                <span class="special-character" unselectable="on">Å</span>
                <span class="special-character" unselectable="on">Æ</span>
                <span class="special-character" unselectable="on">Ç</span>
                <span class="special-character" unselectable="on">È</span>
                <span class="special-character" unselectable="on">É</span>
                <span class="special-character" unselectable="on">Ê</span>
                <span class="special-character" unselectable="on">Ë</span>
                <span class="special-character" unselectable="on">Ì</span>
                <span class="special-character" unselectable="on">Í</span>
                <span class="special-character" unselectable="on">Î</span>
                <span class="special-character" unselectable="on">Ï</span>
                <span class="special-character" unselectable="on">Ð</span>
                <span class="special-character" unselectable="on">Ñ</span>
                <span class="special-character" unselectable="on">Ò</span>
                <span class="special-character" unselectable="on">Ó</span>
                <span class="special-character" unselectable="on">Ô</span>
                <span class="special-character" unselectable="on">Õ</span>
                <span class="special-character" unselectable="on">Ö</span>
                <span class="special-character" unselectable="on">×</span>
                <span class="special-character" unselectable="on">Ø</span>
                <span class="special-character" unselectable="on">Ù</span>
                <span class="special-character" unselectable="on">Ú</span>
                <span class="special-character" unselectable="on">Û</span>
                <span class="special-character" unselectable="on">Ü</span>
                <span class="special-character" unselectable="on">Ý</span>
                <span class="special-character" unselectable="on">Þ</span>
                <span class="special-character" unselectable="on">ß</span>
                <span class="special-character" unselectable="on">à</span>
                <span class="special-character" unselectable="on">á</span>
                <span class="special-character" unselectable="on">â</span>
                <span class="special-character" unselectable="on">ã</span>
                <span class="special-character" unselectable="on">ä</span>
                <span class="special-character" unselectable="on">å</span>
                <span class="special-character" unselectable="on">æ</span>
                <span class="special-character" unselectable="on">ç</span>
                <span class="special-character" unselectable="on">è</span>
                <span class="special-character" unselectable="on">é</span>
                <span class="special-character" unselectable="on">ê</span>
                <span class="special-character" unselectable="on">ë</span>
                <span class="special-character" unselectable="on">ì</span>
                <span class="special-character" unselectable="on">í</span>
                <span class="special-character" unselectable="on">î</span>
                <span class="special-character" unselectable="on">ï</span>
                <span class="special-character" unselectable="on">ð</span>
                <span class="special-character" unselectable="on">ñ</span>
                <span class="special-character" unselectable="on">ò</span>
                <span class="special-character" unselectable="on">ó</span>
                <span class="special-character" unselectable="on">ô</span>
                <span class="special-character" unselectable="on">õ</span>
                <span class="special-character" unselectable="on">ö</span>
                <span class="special-character" unselectable="on">÷</span>
                <span class="special-character" unselectable="on">ø</span>
                <span class="special-character" unselectable="on">ù</span>
                <span class="special-character" unselectable="on">ú</span>
                <span class="special-character" unselectable="on">û</span>
                <span class="special-character" unselectable="on">ü</span>
                <span class="special-character" unselectable="on">ý</span>
                <span class="special-character" unselectable="on">þ</span>
                <span class="special-character" unselectable="on">ÿ</span>
                <span class="special-character" unselectable="on">€</span>
                <span class="special-character" unselectable="on">!</span>
                <span class="special-character" unselectable="on">"</span>
                <span class="special-character" unselectable="on">#</span>
                <span class="special-character" unselectable="on">$</span>
                <span class="special-character" unselectable="on">%</span>
                <span class="special-character" unselectable="on">&amp;</span>
                <span class="special-character" unselectable="on">'</span>
                <span class="special-character" unselectable="on">(</span>
                <span class="special-character" unselectable="on">)</span>
                <span class="special-character" unselectable="on">*</span>
                <span class="special-character" unselectable="on">+</span>
                <span class="special-character" unselectable="on">,</span>
                <span class="special-character" unselectable="on">-</span>
                <span class="special-character" unselectable="on">.</span>
                <span class="special-character" unselectable="on">/</span>
                <span class="special-character" unselectable="on">0</span>
                <span class="special-character" unselectable="on">1</span>
                <span class="special-character" unselectable="on">2</span>
                <span class="special-character" unselectable="on">3</span>
                <span class="special-character" unselectable="on">4</span>
                <span class="special-character" unselectable="on">5</span>
                <span class="special-character" unselectable="on">6</span>
                <span class="special-character" unselectable="on">7</span>
                <span class="special-character" unselectable="on">8</span>
                <span class="special-character" unselectable="on">9</span>
                <span class="special-character" unselectable="on">:</span>
                <span class="special-character" unselectable="on">;</span>
                <span class="special-character" unselectable="on">&lt;</span>
                <span class="special-character" unselectable="on">=</span>
                <span class="special-character" unselectable="on">&gt;</span>
                <span class="special-character" unselectable="on">?</span>
                <span class="special-character" unselectable="on">@</span>
                <span class="special-character" unselectable="on">A</span>
                <span class="special-character" unselectable="on">B</span>
                <span class="special-character" unselectable="on">C</span>
                <span class="special-character" unselectable="on">D</span>
                <span class="special-character" unselectable="on">E</span>
                <span class="special-character" unselectable="on">F</span>
                <span class="special-character" unselectable="on">G</span>
                <span class="special-character" unselectable="on">H</span>
                <span class="special-character" unselectable="on">I</span>
                <span class="special-character" unselectable="on">J</span>
                <span class="special-character" unselectable="on">K</span>
                <span class="special-character" unselectable="on">L</span>
                <span class="special-character" unselectable="on">M</span>
                <span class="special-character" unselectable="on">N</span>
                <span class="special-character" unselectable="on">O</span>
                <span class="special-character" unselectable="on">P</span>
                <span class="special-character" unselectable="on">Q</span>
                <span class="special-character" unselectable="on">R</span>
                <span class="special-character" unselectable="on">S</span>
                <span class="special-character" unselectable="on">T</span>
                <span class="special-character" unselectable="on">U</span>
                <span class="special-character" unselectable="on">V</span>
                <span class="special-character" unselectable="on">W</span>
                <span class="special-character" unselectable="on">X</span>
                <span class="special-character" unselectable="on">Y</span>
                <span class="special-character" unselectable="on">Z</span>
                <span class="special-character" unselectable="on">[</span>
                <span class="special-character" unselectable="on">\</span>
                <span class="special-character" unselectable="on">]</span>
                <span class="special-character" unselectable="on">^</span>
                <span class="special-character" unselectable="on">_</span>
                <span class="special-character" unselectable="on">`</span>
                <span class="special-character" unselectable="on">a</span>
                <span class="special-character" unselectable="on">b</span>
                <span class="special-character" unselectable="on">c</span>
                <span class="special-character" unselectable="on">d</span>
                <span class="special-character" unselectable="on">e</span>
                <span class="special-character" unselectable="on">f</span>
                <span class="special-character" unselectable="on">g</span>
                <span class="special-character" unselectable="on">h</span>
                <span class="special-character" unselectable="on">i</span>
                <span class="special-character" unselectable="on">j</span>
                <span class="special-character" unselectable="on">k</span>
                <span class="special-character" unselectable="on">l</span>
                <span class="special-character" unselectable="on">m</span>
                <span class="special-character" unselectable="on">n</span>
                <span class="special-character" unselectable="on">o</span>
                <span class="special-character" unselectable="on">p</span>
                <span class="special-character" unselectable="on">q</span>
                <span class="special-character" unselectable="on">r</span>
                <span class="special-character" unselectable="on">s</span>
                <span class="special-character" unselectable="on">t</span>
                <span class="special-character" unselectable="on">u</span>
                <span class="special-character" unselectable="on">v</span>
                <span class="special-character" unselectable="on">w</span>
                <span class="special-character" unselectable="on">x</span>
                <span class="special-character" unselectable="on">y</span>
                <span class="special-character" unselectable="on">z</span>
                <span class="special-character" unselectable="on">{</span>
                <span class="special-character" unselectable="on">|</span>
                <span class="special-character" unselectable="on">}</span>
                <span class="special-character" unselectable="on">~</span>
                <span class="special-character" unselectable="on">₩</span>
                <span class="special-character" unselectable="on"> </span>
        </div>
    </div>
</div></div><div class="buttons-with-separator tool-group" style=""><div unselectable="on" class="toggle-lock toolbar-button">
    <div unselectable="on" class="locked" title="Move / Resize">
        Move / Resize
    </div>
    <div unselectable="on" class="unlocked" title="Lock in Place" style="display: none;">
        Lock
    </div>
</div><div class="toolbar-button crop" title="Crop / Rotate">Crop / Rotate</div><div class="toolbar-button change-image-tool add-image" style="display: none;">
    <div unselectable="on" class=" change-image-tool"></div>
    <span class="toolbar-button-caption">Add Image</span>
    
    <div class="expanded-tool change-image-expanded-tool" style="display:none;">
        <div class="tool-content">
            <div class="change-image-tool-content">
                <div class="upload-breadcrumbs breadcrumbs"><span data-category-name="default">home</span></div>
                <div class="upload-buttons">
<div class="upload-tool-group">

    <a href="/vp/ns/propath/UploadResources.aspx?pfid=SKU604008" target="UploadResources" class="upload-resources-link">
        View upload specs and templates
    </a>



    <div class="upload-tool-group-add-image">
<div class="upload-tool more-options-tool upload-tool-addimagedialog" data-category-name="addimagedialog">
    <div class="more-options-tool-button upload-tool-button ">
        <div class="more-options-tool-button-caption">My Computer</div>
    </div>


</div>

<div class="upload-tool more-options-tool upload-tool-previousdialog" data-category-name="previousdialog">
    <div class="more-options-tool-button upload-tool-button ">
        <div class="more-options-tool-button-caption">Previous Uploads</div>
    </div>


</div>

<div class="upload-tool more-options-tool upload-tool-libraryImageDialog" data-category-name="libraryImageDialog">
    <div class="more-options-tool-button upload-tool-button ">
        <div class="more-options-tool-button-caption">Image Library</div>
    </div>


</div>

<div class="upload-tool more-options-tool upload-tool-thirdpartydialog_facebook" data-category-name="thirdpartydialog_facebook">
    <div class="more-options-tool-button upload-tool-button ">
        <div class="more-options-tool-button-caption">Facebook</div>
    </div>


</div>

    </div>


    <div class="uploaded-resources-legal-disclaimer text-size-6"> Please ensure you have the right to use any image you upload </div>
</div>

                </div>
                <div class="upload-container">

                </div>

            </div>
        </div>
    </div>
</div><div class="toolbar-button change-image-tool replace-image" style="" title="Replace">
    <div unselectable="on" class=" change-image-tool"></div>
    <span class="toolbar-button-caption">Replace</span>
    
    <div class="expanded-tool change-image-expanded-tool" style="display:none;">
        <div class="tool-content">
            <div class="change-image-tool-content">
                <div class="upload-breadcrumbs breadcrumbs"><span data-category-name="default">home</span></div>
                <div class="upload-buttons">
<div class="upload-tool-group">

    <a href="/vp/ns/propath/UploadResources.aspx?pfid=SKU604008" target="UploadResources" class="upload-resources-link">
        View upload specs and templates
    </a>



    <div class="upload-tool-group-replace-image">
<div class="upload-tool more-options-tool upload-tool-addimagedialog" data-category-name="addimagedialog">
    <div class="more-options-tool-button upload-tool-button ">
        <div class="more-options-tool-button-caption">My Computer</div>
    </div>


</div>

<div class="upload-tool more-options-tool upload-tool-previousdialog" data-category-name="previousdialog">
    <div class="more-options-tool-button upload-tool-button ">
        <div class="more-options-tool-button-caption">Previous Uploads</div>
    </div>


</div>

<div class="upload-tool more-options-tool upload-tool-libraryImageDialog" data-category-name="libraryImageDialog">
    <div class="more-options-tool-button upload-tool-button ">
        <div class="more-options-tool-button-caption">Image Library</div>
    </div>


</div>

<div class="upload-tool more-options-tool upload-tool-thirdpartydialog_facebook" data-category-name="thirdpartydialog_facebook">
    <div class="more-options-tool-button upload-tool-button ">
        <div class="more-options-tool-button-caption">Facebook</div>
    </div>


</div>

    </div>


    <div class="uploaded-resources-legal-disclaimer text-size-6"> Please ensure you have the right to use any image you upload </div>
</div>

                </div>
                <div class="upload-container">

                </div>

            </div>
        </div>
    </div>
</div><div unselectable="on" class="toggle-background-knockout toolbar-button" style="display: none;">
    <div unselectable="on" class="remove" title="Remove Background">
        Remove Background
    </div>
    <div unselectable="on" class="replace" title="Add Background">
        Add Background
    </div>
</div><div unselectable="on" class="toggle-crispify toolbar-button" style="display: none;">
    <div unselectable="on" class="crispify" title="Sharpen">
        Sharpen
    </div>
    <div unselectable="on" class="uncrispify" title="Unsharpen">
        Unsharpen
    </div>
</div><div unselectable="on" class="toolbar-button with-separator image-color-picker-tool" style="display: none;">
    <div class="expanded-tool categorized-expanded-tool image-color-picker-tool-expanded-tool">
    </div>
<div class="color-picker-shadow"></div><span class="color-picker-label">Colour</span></div><div unselectable="on" class="toolbar-button with-separator image-color-picker-tool" title="Colour">
    <div class="expanded-tool categorized-expanded-tool image-color-picker-tool-expanded-tool">
    </div>
<div class="color-picker-shadow"></div><span class="color-picker-label">Colour</span></div></div><div class="buttons-with-separator tool-group" style="display: none;"><div unselectable="on" class="toolbar-button with-separator shape-fill-tool">
    <div class="expanded-tool categorized-expanded-tool shape-fill-tool-expanded-tool">
    </div>
<span>Fill</span></div><div unselectable="on" class="toolbar-button with-separator shape-stroke-tool">
    <div class="expanded-tool categorized-expanded-tool shape-stroke-tool-expanded-tool">
    </div>
<span>Stroke</span></div><div unselectable="on" class="toolbar-button with-separator shape-corners-tool corners" style="display:none;">
    <div class="expanded-tool shape-corners-expanded-tool" style="display:none;">
        <div class="tool-content">
            <label for="cornerradius" class="text-large">Corner Radius</label>
            <input type="text" class="stylized-input" size="3" name="cornerradius">
        </div>
    </div>
<span>Corners</span></div><div unselectable="on" class="toolbar-button with-separator shape-rotation-tool rotate" style="display: none;">
    <div class="expanded-tool shape-rotation-expanded-tool" style="display:none;">
        <div class="tool-content">
            <label for="rotation" class="text-large">Enter Rotation:</label>
            <input type="text" class="stylized-input" size="3" name="rotation">
            <label class="text-large">degrees</label>
        </div>
    </div>
<span>Rotation</span></div><div unselectable="on" class="toolbar-button with-separator edit-starburst-tool" style="display: none;">
    <div class="expanded-tool edit-starburst-expanded-tool" style="display:none;">
        <div class="tool-content">
            <div class="starburst-shape-editor">
                <h5>Number of points</h5>
                <div class="input-wrapper">
                    <div class="slider">
                        <span class="irs js-irs-3"><span class="irs" style=""><span class="irs-line" tabindex="-1"><span class="irs-line-left"></span><span class="irs-line-mid"></span><span class="irs-line-right"></span></span><span class="irs-min" style="">2</span><span class="irs-max" style="">50</span><span class="irs-from" style="visibility: hidden;">0</span><span class="irs-to" style="visibility: hidden;">0</span><span class="irs-single">0</span></span><span class="irs-grid"></span><span class="irs-bar"></span><span class="irs-bar-edge"></span><span class="irs-shadow shadow-single"></span><span class="irs-slider single" style=""></span></span><input type="range" class="number-of-points-slider range-slider irs-hidden-input" min="2" max="50" value="9" readonly="">
                    </div>
                    <input type="text" class="number-of-points-input stylized-input" size="3" value="9" name="numberofpoints">
                </div>
                <h5>Height of points</h5>
                <div class="input-wrapper">
                    <div class="slider">
                        <span class="irs js-irs-4"><span class="irs" style=""><span class="irs-line" tabindex="-1"><span class="irs-line-left"></span><span class="irs-line-mid"></span><span class="irs-line-right"></span></span><span class="irs-min" style="">1</span><span class="irs-max" style="">100</span><span class="irs-from" style="visibility: hidden;">0</span><span class="irs-to" style="visibility: hidden;">0</span><span class="irs-single">0</span></span><span class="irs-grid"></span><span class="irs-bar"></span><span class="irs-bar-edge"></span><span class="irs-shadow shadow-single"></span><span class="irs-slider single" style=""></span></span><input type="range" class="height-of-points-slider range-slider irs-hidden-input" min="1" max="100" value="60" readonly="">
                    </div>
                    <input type="text" class="height-of-points-input stylized-input" size="3" value="60" name="heightofpoints">
                </div>
            </div>
        </div>
    </div>
<span>Edit</span></div></div><div class="buttons-with-separator tool-group"><div class="toolbar-button duplicate" title="Duplicate"><span>Duplicate</span></div><div unselectable="on" class="toolbar-button arrange-tool" style="" title="Arrange">
    <span></span>
    <div class="expanded-tool arrange-expanded-tool" style="display: none;">
        <div class="arrange-button bring-to-front">
            <div class="arrange-button-icon"></div>
            <span class="arrange-button-text text-large">Bring to Front</span>
        </div>
        <div class="arrange-button send-to-back">
            <div class="arrange-button-icon"></div>
            <span class="arrange-button-text text-large">Send to Back</span>
        </div>
        <div class="arrange-button bring-forward">
            <div class="arrange-button-icon"></div>
            <span class="arrange-button-text text-large">Bring Forward</span>
        </div>
        <div class="arrange-button send-backward">
            <div class="arrange-button-icon"></div>
            <span class="arrange-button-text text-large">Send Backward</span>
        </div>
    </div>
<span>Arrange</span></div><div class="toolbar-button rotate" style="display: none;" title="Rotate"><span>Rotate</span></div></div><div class="toolbar-button client-side-delete"><span>Delete</span></div></div></div>
</div><div class="editor-row" style="width: 511px;">
    <div class="text-editor-wrapper stylized-contenteditable-wrapper" style="display: none;"></div><div class="text-editor-wrapper stylized-contenteditable-wrapper" style="display: none;" data-purpose="companyname"><input type="text" class="editable-field" tabindex="1"></div></div></div>

<div class="group-contextual-toolbar contextual-toolbar toolbar above big tool-group" style="display: none;">

    <div class="expanded-tool-container">
        <div class="resizable-bar"><div class="resizable-icon"></div></div>
        <a href="#" class="textbutton textbutton-round close-button">
            <span class="textbutton-icon textbutton-icon-delete"></span>
        </a>
    </div>
<div class="button-row tool-group">
    <div class="slidable-button-row">
        <div class="buttons-with-separator tool-group"><div class="buttons-with-separator tool-group"><div class="toolbar-button group-ungroup-button ungroup-button">
<div class="toolbar-button-inner group-ungroup-button ungroup-button-inner">
    <span class="toolbar-button-icon"></span>
    <span class="toolbar-button-caption">Ungroup</span>
</div>

</div><div class="toolbar-button group-group-button group-button">
<div class="toolbar-button-inner group-group-button group-button-inner">
    <span class="toolbar-button-icon"></span>
    <span class="toolbar-button-caption">Group</span>
</div>

</div></div><div class="toolbar-button duplicate"><span>Duplicate</span></div><div class="toolbar-button client-side-delete"></div></div>
    </div>
</div></div>

    </div>

    <button class="btn btn-success" type="button" id="click_canas">preview</button>

 <div class="card" id="apend_div">
    

  </div>
   
</body>
<script src="https://code.jquery.com/jquery.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"  ></script>
        <script src="html2canvas.js"  ></script>
        <script src="html2canvas.min.js"  ></script>
        <script src="html2canvas.esm.js"  ></script>
        <script src="canvas2image.js"  ></script>

<script type="text/javascript">
            $(document).on('click', '#click_canas', function(e) {
                var elm=$('#canvas_div').get(0);
                var lebar = '600';
                var tinggi  = '400';
                var type = 'png';
                var filename = 'htmltocanvas';
                alert();
                html2canvas(document.querySelector("#canvas_div")).then(canvas => {
                    // document.body.appendChild(canvas);

                    var canWidth=canvas.width;
                    var canHeight=canvas.height;
                    var img = Canvas2Image.convertToImage(canvas,canWidth,canHeight);
                    console.log(img.src);
                    alert(img.src);
                    // $('#preview').empty();
                    // alert(1);
                    // $('#preview').after(img);
                    get_preview(img);

                    // Canvas2Image.saveAsImage(canvas,lebar,tinggi,type,filename);
                })
            });
        </script>

<script type="text/javascript">
          
function get_preview(img){
    alert('in');
        var canvas = document.createElement('canvas'),
        ctx = canvas.getContext('2d'),
        parts = [];
        // img = new Image();

    
    img.onload = split_4;
    function split_4() {
      
      var w2 = img.width / 3,
          h2 = img.height/1.8;
          // alert(w2);
      for(var i=0; i<3; i++) {
        var x = (-w2*i) % (w2*3),
            y = (h2*0)<=h2 ? 0 : -h2 ;
            console.log(x,y);
        canvas.width = w2;
        canvas.height = h2;
        ctx.drawImage(this, x, y, w2*3, h2*1);
        parts.push( canvas.toDataURL() );
        // for test div
        var slicedImage = document.createElement('img')
        slicedImage.src = parts[i];
        var div = document.getElementById('test');
        // div.appendChild( slicedImage );
      }
      console.log(parts);

          $.ajax({
                  type: "POST",
                  url: "./apend_image.php",
                  data: {data: parts},
                  cache: true,
                  async: false,
                  dataType:'html',
                  success: function(data){
                   // alert(data);
                  // result = data;
                  $('#apend_div').empty().append(data);
                  }
                  });
    }
    // img.src=document.getElementById("canvasimg").getAttribute('src');
             }
        </script>
<!-- <script src="./js/bootstrap.min.js"  ></script> -->
<!-- <script src="./js/bootstrap.js"  ></script> -->

<!-- <script src="./js/bootstrapper_min.js"  ></script>
<script src="./js/history.adapter.jquery_min.js"  ></script>
<script src="./js/image_min.js"  ></script>
<script src="./js/jquery-1.12.4.js"  ></script>
<script src="./js/jquery-ui.js"  ></script>
<script src="./js/jquery.customEvent_min.js"  ></script>
<script src="./js/jquery.hostIframe_min.js"  ></script>
<script src="./js/jquery.hoverDelay_min.js"  ></script>
<script src="./js/jquery.imageSize_min.js"  ></script>
<script src="./js/jquery.modalDialog_min.js"  ></script>
<script src="./js/jquery.richTooltip_min.js"  ></script>
<script src="./js/jquery.textbutton_min.js"  ></script>
<script src="./js/responsive-image_min.js"  ></script>
<script src="./js/SceneAnimation_min.js"  ></script>
<script src="./js/vp.widget.selectableitems_min.js"  ></script> -->
<script type="text/javascript">
    (function() {



        window.docJson = {"finishPreference":null,"enterprisePartnerTemplateId":0,"documentOptions":[],"colorOverrideRgb":"","hasText":false,"hasPlaceholder":false,"hasUpload":false,"persistenceData":"","module":"models/document","name":"","id":"0","canvases":[{"templateDescriptor":"_SKU604008","height":535.7,"width":1188.3,"items":[],"id":"1","module":"models/canvas","viewed":false,"pageNumber":1,"colorization":1,"languageId":36,"serializedColorOverride":null,"substrateColorId":null,"substrateThreadColorRgb":"#3B3B3B","substrateReferenceThreadId":"mcp0020","finishes":[]}]};
        window.docViewModelJson = {"canvasViewModels":[{"productDpi":0,"name":"Front Side","previewUrl":null,"isFullUpload":false,"id":"d0-1","module":"viewmodels/canvasviewmodel","active":true,"hidden":false,"zoomFactor":0.57225402883799836,"itemViewModels":[],"chromes":[{"viewType":5,"type":1,"module":"viewmodels/productunderlayviewmodel","height":535.7,"width":1188.3,"left":0.0,"top":0.0},{"type":0,"module":"viewmodels/safetymarginviewmodel","safeAreaList":[{"top":10.204724409448819,"height":515.33858267716528,"width":1167.8740157480315,"left":10.204724409448819}]},{"type":0,"module":"viewmodels/gridoverlayviewmodel","height":535.7,"width":1188.3,"left":0.0,"top":0.0}]}],"id":"d0"};
        window.stateJson = {"isUserLoggedIn":false,"localeId":"In"};
    })();
</script>





        <script>
            window.configSetup = {
                "editorType" : "Standard",
                "configEndpoint" : "studio4/editor/studioconfig"
            }
        </script>

 <noscript><div id="noscript-warning">Please enable <a href="/vp/errjscript.aspx">JavaScript</a>.</div></noscript>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-caf7fd3e/_/vp/js-lib/ThirdParty/json2_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-0159801f/_/vp/JS-Lib/jquery/jquery-current_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-3f5f9797/_/vp/JS-Lib/jquery/jquery-noConflict_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-c3c5ade9/_/vp/JS-Lib/common/vp.instrumentation_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-a8948fbf/_/vp/JS-Lib/common_generated_dd/browsers_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-bfe6be54/_/vp/JS-Lib/common/core/vp.browser_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-62ae1255/_/vp/JS-Lib/ThirdParty/skinnyjs/date-parse_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-40f64310/_/vp/JS-Lib/ThirdParty/skinnyjs/jquery.cookies_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-77f7d2f8/_/vp/JS-Lib/ThirdParty/skinnyjs/jquery.msAjax_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-dd41a6c4/_/vp/JS-Lib/ThirdParty/skinnyjs/jquery.ns_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-244b83c3/_/vp/JS-Lib/ThirdParty/skinnyjs/jquery.imageSize_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-e1dc3a10/_/vp/JS-Lib/ThirdParty/skinnyjs/jquery.delimitedString_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-1f6a6323/_/vp/JS-Lib/ThirdParty/skinnyjs/jquery.querystring_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-dedcaa90/_/vp/JS-Lib/ThirdParty/skinnyjs/jquery.url_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-5216df36/_/vp/JS-Lib/ThirdParty/skinnyjs/jquery.isVisibleKeyCode_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-793bb033/_/vp/JS-Lib/ThirdParty/skinnyjs/jquery.css_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-9ec7293f/_/vp/JS-Lib/ThirdParty/skinnyjs/pointy_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-a71d651e/_/vp/JS-Lib/ThirdParty/skinnyjs/pointy.gestures_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-95f35c69/_/vp/JS-Lib/ThirdParty/lodash/lodash.compat_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-351c4e50/_/vp/JS-Lib/ThirdParty/backbone/underscore-extensions_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-15f1734a/_/vp/JS-Lib/ThirdParty/backbone/backbone_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-2f60dd10/_/vp/JS-Lib/ThirdParty/backbone/backbone-extensions_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-10ae73c8/_/vp/JS-Lib/ThirdParty/backbone/backbone.queryparams_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-fb034c67/_/vp/JS-Lib/ThirdParty/iscroll4_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-9e7c1c00/_/vp/JS-Lib/ThirdParty/amplify/amplify.store_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-1d3e2bc4/_/vp/JS-Lib/common/core/vp.ui.afterLoad_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-8384ad4c/_/vp/JS-Lib/common/vp.spot_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-b6cd41f3/_/vp/JS-Lib/common/vp.logger_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-8f78e4f6/_/vp/JS-Lib/Sales/Controls/MobileCookies_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-9a8a1600/_/vp/JS-Lib/jQuery/plugins/jquery.XDomainRequest_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-472039c6/_/vp/JS-Lib/jQuery/vpextensions/jquery.orientation_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-aedea3ca/_/vp/JS-Lib/jquery/vpextensions/jquery.ajaxErrorHandler_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-ce9c469f/_/vp/JS-Lib/controls/responsive-image_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-f2ae0cb7/_/vp/js-lib/ThirdParty/skinnyjs/jquery.customEvent_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-22472918/_/vp/js-lib/ThirdParty/skinnyjs/jquery.clientRect_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-e54ba554/_/vp/js-lib/ThirdParty/skinnyjs/jquery.hostIframe_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-233adc33/_/vp/js-lib/ThirdParty/skinnyjs/jquery.disableEvent_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-03ebd94b/_/vp/js-lib/ThirdParty/skinnyjs/jquery.proxyAll_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-99daf599/_/vp/js-lib/ThirdParty/skinnyjs/jquery.partialLoad_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-b16b23de/_/vp/js-lib/thirdparty/skinnyjs/jquery.postMessage_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-be866b2c/_/vp/js-lib/ThirdParty/skinnyjs/jquery.modalDialog_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-07263fab/_/vp/js-lib/pkg/vp.uilibrary/controls/jquery.modalDialog.chromeScrollFix_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-8fcd0418/_/vp/js-lib/jquery/plugins/history/history.adapter.jquery_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-e1f54af6/_/vp/js-lib/jquery/plugins/history/history.html4_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-325e6ed8/_/vp/js-lib/jquery/plugins/history/history_min.js"></script>
<script type="text/javascript">
try {
jQuery.modalDialog.enableHistory();
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }

</script>
<script type="text/javascript" src="https://cdn.dst.vistaprint.io/Chat/ChatPlugin/Prod/chat.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-326194d1/_/vp/JS-Lib/Sales/Documents/Previewing/SceneAnimation_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-43518877/_/vp/js-lib/pkg/vp.uilibrary/controls/ui-library-basic_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-a705a1cd/_/vp/js-lib/pkg/vp.uilibrary/controls/rangeslider_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-bcb79bf2/_/vp/js-lib/studio/editor/docitem_type_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-6b23f9b9/_/vp/js-lib/common/vp.debug_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-b61ab616/_/vp/JS-Lib/common/vp.crossdomain_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-56a1c564/_/vp/JS-Lib/common/vp.servermanager_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-0c063a22/_/vp/JS-Lib/image/image_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-abc272ff/_/vp/JS-Lib/image/search_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-19ddc755/_/vp/JS-Lib/swfobject/swfobject_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-2382823b/_/vp/JS-Lib/uploads/vp.upload.queue_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-746a490f/_/vp/JS-Lib/uploads/generated_dd/upload-constants_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-aa5a1daf/_/vp/JS-Lib/uploads/vp.upload_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-984bda72/_/vp/JS-Lib/uploads/vp.upload.upload_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-84b7bf65/_/vp/JS-Lib/uploads/vp.upload.progress_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-36a7a9af/_/vp/JS-Lib/uploads/vp.upload.error_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-2a43ae5b/_/vp/JS-Lib/uploads/vp.upload.manager_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-970785b9/_/vp/JS-Lib/uploads/vp.upload.tracking_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-0a758700/_/vp/JS-Lib/uploads/thirdpartyauthorization_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-f4046efa/_/vp/JS-Lib/uploads/repository/vp.upload.repositorymodel_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-b92dba68/_/vp/JS-Lib/uploads/repository/vp.upload.repositoryview_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-a83ef295/_/vp/JS-Lib/uploads/repository/vp.upload.repositoryentryview_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-048b5d64/_/vp/JS-Lib/jQuery/plugins/jquery.dragToSelect_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-ba6b4ac9/_/vp/JS-Lib/common/vp.widget.selectableitems_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-569b7269/_/vp/JS-Lib/Sales/Images/MyImages_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-6ebb2232/_/vp/JS-Lib/Sales/Images/Album_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-4ede2903/_/vp/js-lib/jQuery/vpextensions/jquery.textbutton_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-fcde6d41/_/vp/JS-Lib/uploads/dialogs/dialogbase_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-22bdb35a/_/vp/JS-Lib/uploads/dialogs/mycomputeruploadsdialog_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-e903871b/_/vp/JS-Lib/uploads/dialogs/imageuploader_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-4b452540/_/vp/JS-Lib/uploads/dialogs/selectableimagedialog_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-6bdca4bb/_/vp/JS-Lib/uploads/dialogs/previousimagesdialog_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-fd3040ac/_/vp/JS-Lib/uploads/dialogs/thirdpartydialog_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-79db808b/_/vp/JS-Lib/uploads/dialogs/libraryImageDialog_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-da25381f/_/vp/js-lib/thirdparty/skinnyjs/jquery.calcRestrainedPos_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-14661624/_/vp/js-lib/thirdparty/skinnyjs/jquery.hoverDelay_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-7ba64472/_/vp/JS-Lib/ThirdParty/skinnyjs/jquery.richTooltip_min.js"></script>
<script type="text/javascript">
try {
vp.upload.serverGuid = 'a84f6c93295a48bc88e0d6e1a6581f2d';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.postUrls = ["https://uploads.documents.cimpress.io/upload/process.aspx","https://uploads.documents.cimpress.io/upload/process.aspx","https://www.vistaprint.in/upload/ProcessImageUpload.aspx"];
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.postUrlsImageMask = ["https://uploads.documents.cimpress.io","https://uploads.documents.cimpress.io"];
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.trackUrls = ["https://imagewnd.vistaprint.com/upload/progresstracker.aspx","https://imageven.vistaprint.com/upload/progresstracker.aspx","https://www.vistaprint.in/upload/UploadImageProgressTracker.aspx"];
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.pullUrls = ["https://uploads.documents.cimpress.io/upload/process.aspx","https://uploads.documents.cimpress.io/upload/process.aspx"];
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.logUrl = 'https://www.vistaprint.in/vp/ns/upload/UploadLog.aspx';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.partnerFetchUrl = 'https://www.vistaprint.in/partners/imagetransfer/fetch.aspx';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.errorCodes = {"109":1080964,"108":1080966,"103":1376052,"102":1080962,"100":1376052,"111":2202483,"110":2170337,"105":1080963,"104":1080934,"2":2396333,"1":1080967,"301":1080967,"202":1376075,"215":1136712,"401":1080967,"302":1080967,"213":1990617,"203":1376075,"209":1116270,"204":1376075,"201":1376075,"210":1080991,"211":1139838,"212":1376075,"205":1376075,"214":1200073,"107":1080965,"216":1136936,"402":1080967,"403":1080967,"106":1310994};
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.errorData = {"1376075":{"queryString":"&error=0&eec=1376075&eep=","headerText":"Processing Error","resolutionTexts":["We cannot read this file. Please make sure your file is compatible with our image processing system. We support many file formats including graphics files from Adobe Photoshop CS5, Adobe Illustrator CS5, and Adobe Acrobat 8.","For maximum upload reliability, save your file as a PDF (version 1.4 or lower) and upload it again."],"subheaderText":"We're sorry, but we were unable to process your file."},"2170337":{"queryString":"&error=0&eec=2170337&eep=","headerText":"Corel Not Supported","resolutionTexts":["<b>To save a Corel file as a PDF</b>\r\n<ol>\r\n<li>Open the file you want to upload.</li>\r\n<li>Click the <b>File</b> menu and then click \"Publish to PDF.\"</li>\r\n<li>Click \"Settings\" on the bottom of the dialog box.</li>\r\n<li>Click the \"Advanced\" tab and under \"Color Management,\" mark \"Output all objects as: CMYK\"</li>\r\n<li>Then, click the \"Objects\" tab and select either \"Embed fonts in document\" OR \"Export all text as curves.\"</li>\r\n<li>Click \"OK\" and then click \"Save\" to create your PDF.</li>\r\n</ol>"],"subheaderText":"We currently do not support Corel uploads, but you can easily convert your file to a PDF for upload."},"1116270":{"queryString":"&error=0&eec=1116270&eep=","headerText":"Blank Stamp or Finish Mask","resolutionTexts":["The stamp or finish mask you have uploaded consists entirely of white or light colours. If you ordered this uploaded image, you would get a blank stamp, or a document without a finish. Please fix your image so that it is a black and white image, where black areas denote the regions that should be stamped or have finish applied."],"subheaderText":"We’re sorry, but we were unable to process your file."},"2396333":{"queryString":"&error=0&eec=2396333&eep=","headerText":"Temporary Error","resolutionTexts":["Our website is currently experiencing a technical error. We are actively working to resolve the issue, so please try to upload your file again at a later time. You can still use your previously uploaded images. We apologize for the inconvenience."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1310994":{"queryString":"&error=0&eec=1310994&eep=","headerText":"Bad File Path","resolutionTexts":["The file path you entered seems to be invalid. Please make sure you have provided a full path to your file, including an extension and a directory. You may also press the \"Browse\" or \"Choose file\" button and find the file by browsing your hard drive directly."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1990617":{"queryString":"&error=0&eec=1990617&eep=","headerText":"Old Illustrator File","resolutionTexts":["Your Adobe Illustrator file has a version we cannot recognise. Please save this file in a more recent Illustrator format, such as Illustrator CS or later.","For maximum upload reliability, save your file as a PDF (version 1.4 or lower) and upload it again."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1200073":{"queryString":"&error=0&eec=1200073&eep=","headerText":"MP3 Upload Error","resolutionTexts":["Please confirm that it is a valid MP3, or try a different file."],"subheaderText":"The audio file you have uploaded cannot be processed."},"1139838":{"queryString":"&error=0&eec=1139838&eep=","headerText":"Unembedded Font","resolutionTexts":["The uploaded document contains unembedded fonts. Either we do not recognise these fonts, or the fonts are protected and we cannot embed them. Please make sure all fonts are embedded, or else convert text in the document to outlines."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1080962":{"queryString":"&error=0&eec=1080962&eep=","headerText":"File Format Error","resolutionTexts":["Please review our list of acceptable file formats, verify that your file has the correct file extension and re-upload.","If it does not have it already, try naming your file using the three letter extension for the file type. For example: .jpg, .psd, .pdf, etc."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1080963":{"queryString":"&error=0&eec=1080963&eep=","headerText":"File Too Large","resolutionTexts":["The maximum file size we accept is 38 MB. Please reduce the size of your file. For maximum upload reliability, you may try to save your file as a PDF (version 1.4 or lower), and upload it again."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1376052":{"queryString":"&error=0&eec=1376052&eep=","headerText":"File Transfer Error","resolutionTexts":["The Internet connection may have been lost. Retry your file upload.","Close other applications that are using an Internet connection, which may help your upload speed."],"subheaderText":"We're sorry, but we were unable to receive your file."},"1080966":{"queryString":"&error=0&eec=1080966&eep=","headerText":"No Document Fields","resolutionTexts":["The document you have selected has no text fields on it. You will therefore be unable to apply data to this document. Please go back and select another document as the template."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1080967":{"queryString":"&error=0&eec=1080967&eep=","headerText":"General Error","resolutionTexts":["Please make sure your file is compatible with our image processing system. We support many types of graphics files, including files from the following applications:\r\n<ul>\r\n<li>Adobe Photoshop CS</li>\r\n<li>Adobe Illustrator CS</li>\r\n<li>Adobe Acrobat 6</li>\r\n</ul>\r\nIf you are using a newer version of these applications, please save your file so that it is readable by earlier versions.","For maximum upload reliability, you may try to save your file as a PDF (version 1.4 or lower), and upload it again."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1080964":{"queryString":"&error=0&eec=1080964&eep=","headerText":"Too Many Data Rows","resolutionTexts":["You may put up to 20 documents in your cart using the spreadsheet tool. Adding together the documents already in your cart and the data rows you uploaded, you've exceeded this limit. If you require more documents, please place a separate order."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1080965":{"queryString":"&error=0&eec=1080965&eep=","headerText":"General Data Error","resolutionTexts":["We had a problem reading the data from your spreadsheet or applying it to your document. Please ensure that you have uploaded a correctly formatted .CSV file, without any empty rows."],"subheaderText":"We’re sorry, but we were unable to process your file."},"2202483":{"queryString":"&error=0&eec=2202483&eep=","headerText":"File Format Error","resolutionTexts":["",""],"subheaderText":"We do not currently support images in this format. Please avoid uploading PDF images. Save your images as JPEG, GIF, or PNG before uploading."},"1080991":{"queryString":"&error=0&eec=1080991&eep=","headerText":"Encryption Error","resolutionTexts":["Your uploaded file is encrypted or password protected. Please remove your file security measures and upload again."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1136712":{"queryString":"&error=0&eec=1136712&eep=","headerText":"Document Upload Error","resolutionTexts":["Please try a different file."],"subheaderText":"The uploaded document contains a virus."},"1080934":{"queryString":"&error=0&eec=1080934&eep=","headerText":"Bad File / Upload","resolutionTexts":["Your upload was not successful. Possibly the file did not transfer correctly, the uploaded file has no content, or the uploaded file is corrupt. Please verify that you can open your file on your computer and try again."],"subheaderText":"We’re sorry, but we were unable to process your file."},"1136936":{"queryString":"&error=0&eec=1136936&eep=","headerText":"Document Upload Error","resolutionTexts":["Please try again later."],"subheaderText":"Sorry, we cannot currently process uploaded documents."}};
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.resultErrorGeneral = {"error":{"code":100}};
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.resultErrorNoFile = {"error":{"code":104}};
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.resultErrorTooLarge = {"error":{"code":105}};
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.resultErrorBadPath = {"error":{"code":106}};
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.resultErrorFileFormat = {"error":{"code":102}};
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.maxFileSize = 39999500;
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.errorSuggestedSolutions = 'Suggested Solutions';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.errorDialogTitle = 'Upload error';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.fieldBlankWarning = 'Please select a file to upload.';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.dialogTitleProgress = 'Upload in progress';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.dialogTitleMyImages = 'Use a previously uploaded image';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.dialogTitleImageLibrary = 'Search our image library';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.dialogTitleCropImage = 'Crop Image';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.uploadsMcpTenantName = 'vbu';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.clientsidePreview = true;
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.configurationMap['uploadConfiguration-singleImageDialog'] = {"postQS":"&path=32&storeorig=0","pathId":32,"canUseImageServices":true};
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.errorTemplateId = 'divUploadErrorArea';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.progressTemplateIds[3] = 'divUploadProgressBar';
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }

</script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-554ffc77/_/vp/JS-Lib/studio/vp.studio.draggableimage_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-1f17dda1/_/vp/js-lib/Areas/Account/SignIn/SignInDialog_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-a7a1a25e/_/vp/JS-Lib/Sales/Studio/LoginManager_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-f327a15f/_/vp/js-lib/common/vp.widget.paginator_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-2cf1feb5/_/vp/JS-Lib/Sales/Images/LibraryImages_min.js"></script>
<script type="text/javascript">
try {
vp.upload.configurationMap['uploadConfiguration-multiImageDialog'] = {"postQS":"&path=4&storeorig=0","pathId":4,"canUseImageServices":true};
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }
try {
vp.upload.configurationMap['uploadConfiguration-logoBackgroundKnockout'] = {"postQS":"&path=13&storeorig=0","pathId":13,"canUseImageServices":true};
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }

</script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-05e8f33b/_/vp/js-lib/thirdparty/handlebars/handlebars_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-863556f8/_/vp/js-lib/common/vp.color_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-25fa4126/_/vp/js-lib/common/core/vp.widget.loadingbox_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-40e97e97/_/vp/js-lib/thirdparty/artejs/rangy.debug_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-9914b7b3/_/vp/js-lib/thirdparty/artejs/arte.debug_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-6487629d/_/vp/js-lib/thirdparty/fastclick/fastclick_min.js"></script>
<script type="text/javascript" src="https://assets.hatchery.vistaprint.com/js/photobridge.js?crossorigin=1" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://studio4client.cdn.vpsvc.com/master/358/standard-studio-webpack-bundle.js.gz?crossorigin=1" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-4359ba9d/_/vp/JS-Lib/customercare/ChatContactUs_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-8029a743/_/vp/js-lib/areas/root/header/SiteSearch_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-be4aa9e8/_/vp/js-lib/areas/root/Shared/HtmlCache_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-e42cd12e/_/vp/JS-Lib/Areas/Root/Header/Header_min.js"></script>
<script type="text/javascript">
try {
initHeader(false);
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }

</script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-b20243c1/_/vp/js-lib/ThirdParty/skinnyjs/jquery.menu_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-b4d3103d/_/vp/js-lib/jquery/vpextensions/menu-skins/jquery-menu-none_min.js"></script>
<script type="text/javascript" src="https://cms.cdn.vpsvc.com/vistacore/js/Common/ns_min-hc927c5571e43be883b84f4b02e071d235.js" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cms.cdn.vpsvc.com/vistacore/js/Navigation/GlobalNavigation_min-hcfff3a293bce38b4485ef77008209f309.js" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cms.cdn.vpsvc.com/vistacore/js/Navigation/Meganavigator_min-hcc7de459c5a0074c571c649adfef8ee34.js" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cms.cdn.vpsvc.com/vistacore/js/Navigation/MobileMeganavigator_min-hcf202d0ce73cb027e2412960bbac233ca.js" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-af8b58d6/_/vp/JS-Lib/Sales/Navigation/Footer_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-ae163e94/_/vp/JS-Lib/Sales/Web/Sessions/vp.pageVisitCounter_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-e6ef7022/_/vp/js-lib/tagmanagement/TealiumManager_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-15dcf220/_/vp/js-lib/tagmanagement/PageManager_min.js"></script>
<script type="text/javascript" src="https://www.vistaprint.in/sf/_hc-e02e1e4c/_/vp/JS-Lib/common/vp_newrelic_min.js?xo=1" crossorigin="anonymous"></script>
<script type="text/javascript">
try {
function BodyOnLoad_OnDOMReady() {
new vp.upload.dialogs.SingleImageUploader('singleImageDialog');
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').dialogReplaceableContentNode = 'singleImageDialog_contentnode';
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').putInModalDialog('Add Images From...', 670);
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').modalDialogName = 'singleImageDialog_proxydialog';
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').dialogNames = ["addimagedialog","previousdialog","libraryImageDialog","thirdpartydialog_facebook"];
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').parameters = {"showLogos":true,"sUploadPath":"SinglePhoto","sRepositoryCalloutText":"Drag and Drop Images Here","createQuickMask":false,"bIsSignedIn":false,"showUploads":true,"showFolders":false,"sHostName":"//vistaprint.in","hostName":"","pfid":""};
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').dialogParameters['addimagedialog'] = {};
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').dialogParameters['previousdialog'] = {};
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').dialogParameters['libraryImageDialog'] = {};
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').dialogParameters['thirdpartydialog_facebook'] = {"maxImageHeight":90,"maxImageWidth":90,"sAlbumsText":"Albums","imagesPerPage":8};
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').constructorList.push("function(proxy) { return new vp.upload.dialogs.MyComputerUploadsDialog('addimagedialog', proxy); }");
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').constructorList.push("function(proxy) { return new vp.upload.dialogs.PreviouslyUploadedImagesDialog('previousdialog', proxy); }");
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').constructorList.push("function(proxy) { return new vp.upload.dialogs.LibraryImageDialog('libraryImageDialog', proxy); }");
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').constructorList.push("function(proxy) { return new vp.upload.dialogs.ThirdPartyDialog('thirdpartydialog_facebook', proxy, 'Facebook', 'http://www.vistaprint.com/vp/ns/thirdpartyauthorization.aspx?auth_url=http%3a%2f%2fen-gb.facebook.com%2fv2.2%2fdialog%2foauth%3fclient_id%3d324573781338%26redirect_uri%3dhttps%253a%252f%252fwww.vistaprint.com%252fvp%252fns%252fthirdpartyauthorization.aspx%253fprovider%253dfacebook%26scope%3duser_photos&return_url=http%3a%2f%2fwww.vistaprint.in%2fvp%2fns%2fthirdpartyauthorization.aspx', 'True' ); }");
vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').createDialogs();


    vp.images.bUserLoggedIn = false;
    vp.images.MyImagesUploadsBySession = true;
    
    vp.images.MyImagesMap['singleImageDialog-previousdialog'] = new vp.images.MyImages(
        'singleImageDialog-previousdialogMyImages_MyImagesRoot',
        vp.images.isUserLoggedIn,
        function (r) { vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').getDialog('previousdialog').selectImages(r); },
        6,
        false,
        8,
        null,
        vp.upload.dialogs.loginFromPreviouslyUploadedImagesDialog,
        true,
        'default',
        function (a,b) { vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').getDialog('previousdialog').createImage(a,b); });

    vp.images.ui = { 
        imageUrls: { 
            folder: 'https://www.vistaprint.in/sf/_hc-000004e1/_langid-36/_/vp/images/b09/common/misc-images/folder.png', 
            checkUsedPhoto: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAABsElEQVQ4y7WVv0rEQBDGczkihniVpBErK99AfAFBxSKljY1YyoFFEO4QfAIfQfxTKWJ1jailpT6CRSKCHGcRDcRLbt0v7IQQN5uoZODjcpuZX3ZnZnc17ae1uNpcBpfJZZXIFD5tEaM0nYCu6875vr8XhuFdkiRDJgzPGMM7+OQ+oKugU1wdz/O6HDBiFQYf+CJGxOpSqOM4s0EQXFLgc/DKDp5O2PKgy+YvNlPhGWN4R4YYxBbhLbGUDkHHk5j1H4+Zdb7BjNNVqfAOPvEkodm/iZkblHMk38SSCOrcH5YC81q52WdRMs5mLtJiCqZmoAiUU8yiLjSMoxT4lcRZzkVBMWvNRIUpp6rly6D4XbvtZTkHS8xas9A+GERRfgvFf4wjNh3jLNHnmkV9iornizN9tl4LCiGW+jwF27Y9Q8lHO8Fp4WqLvUcf6fIWr7croRBiyUrBS4PdzOnlc8h2Ho6UUCm4LBU93h1FK4NKU6EqXh6ugpYVT9lugFdBESNrt8oNgmKqWrAvVlbcIH/e0hB8ESPb0v86hAiK2OIh1Nix2ehB3+jVpLxMsUOhupfpNz8s4CngIAhOAAAAAElFTkSuQmCC'
        } 
    };


vp.widget.PaginatorOld.initAll();
vp.widget.PaginatorOld.initAll();


    vp.images.LibraryImagesMap['singleImageDialog-libraryImageDialog'] = new vp.images.LibraryImages(
        'singleImageDialog-libraryImageDialogLibraryImages_LibraryImagesRoot',
        function (r) { vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').chooseImages(r); },
        8,
        49,        
        false,
        function (a,b) { vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').getDialog('libraryImageDialog').createImage(a,b); },
        'default');


vp.widget.PaginatorOld.initAll();
vp.widget.PaginatorOld.initAll();
vp.widget.PaginatorOld.initAll();
new vp.upload.dialogs.MultiImageUploader('multiImageDialog');
vp.upload.AggregateProgressBar = new vp.upload.AggregateProgress('divAggregateProgressContainer');
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').dialogReplaceableContentNode = 'multiImageDialog_contentnode';
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').dialogNames = ["addimagedialog","previousdialog","libraryImageDialog","thirdpartydialog_facebook"];
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').parameters = {"showLogos":true,"sUploadPath":"MultiPhoto","sRepositoryCalloutText":"Drag and Drop Images Here","maxImageCountWarning":"The maximum number of images allowed is -1. Please remove some images before adding more.","createQuickMask":false,"maxImageCount":-1,"bIsSignedIn":false,"showUploads":true,"showFolders":false,"sHostName":"//vistaprint.in","hostName":"","pfid":""};
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').dialogParameters['addimagedialog'] = {};
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').dialogParameters['previousdialog'] = {};
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').dialogParameters['libraryImageDialog'] = {};
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').dialogParameters['thirdpartydialog_facebook'] = {"maxImageHeight":90,"maxImageWidth":90,"sAlbumsText":"Albums","imagesPerPage":8};
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').constructorList.push("function(proxy) { return new vp.upload.dialogs.MyComputerUploadsDialog('addimagedialog', proxy); }");
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').constructorList.push("function(proxy) { return new vp.upload.dialogs.PreviouslyUploadedImagesDialog('previousdialog', proxy); }");
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').constructorList.push("function(proxy) { return new vp.upload.dialogs.LibraryImageDialog('libraryImageDialog', proxy); }");
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').constructorList.push("function(proxy) { return new vp.upload.dialogs.ThirdPartyDialog('thirdpartydialog_facebook', proxy, 'Facebook', 'http://www.vistaprint.com/vp/ns/thirdpartyauthorization.aspx?auth_url=http%3a%2f%2fen-gb.facebook.com%2fv2.2%2fdialog%2foauth%3fclient_id%3d324573781338%26redirect_uri%3dhttps%253a%252f%252fwww.vistaprint.com%252fvp%252fns%252fthirdpartyauthorization.aspx%253fprovider%253dfacebook%26scope%3duser_photos&return_url=http%3a%2f%2fwww.vistaprint.in%2fvp%2fns%2fthirdpartyauthorization.aspx', 'True' ); }");
vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').createDialogs();


    vp.images.bUserLoggedIn = false;
    vp.images.MyImagesUploadsBySession = true;
    
    vp.images.MyImagesMap['multiImageDialog-previousdialog'] = new vp.images.MyImages(
        'multiImageDialog-previousdialogMyImages_MyImagesRoot',
        vp.images.isUserLoggedIn,
        function (r) { vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').getDialog('previousdialog').selectImages(r); },
        6,
        true,
        8,
        null,
        vp.upload.dialogs.loginFromPreviouslyUploadedImagesDialog,
        true,
        'default',
        function (a,b) { vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').getDialog('previousdialog').createImage(a,b); });

    vp.images.ui = { 
        imageUrls: { 
            folder: 'https://www.vistaprint.in/sf/_hc-000004e1/_langid-36/_/vp/images/b09/common/misc-images/folder.png', 
            checkUsedPhoto: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAABsElEQVQ4y7WVv0rEQBDGczkihniVpBErK99AfAFBxSKljY1YyoFFEO4QfAIfQfxTKWJ1jailpT6CRSKCHGcRDcRLbt0v7IQQN5uoZODjcpuZX3ZnZnc17ae1uNpcBpfJZZXIFD5tEaM0nYCu6875vr8XhuFdkiRDJgzPGMM7+OQ+oKugU1wdz/O6HDBiFQYf+CJGxOpSqOM4s0EQXFLgc/DKDp5O2PKgy+YvNlPhGWN4R4YYxBbhLbGUDkHHk5j1H4+Zdb7BjNNVqfAOPvEkodm/iZkblHMk38SSCOrcH5YC81q52WdRMs5mLtJiCqZmoAiUU8yiLjSMoxT4lcRZzkVBMWvNRIUpp6rly6D4XbvtZTkHS8xas9A+GERRfgvFf4wjNh3jLNHnmkV9iornizN9tl4LCiGW+jwF27Y9Q8lHO8Fp4WqLvUcf6fIWr7croRBiyUrBS4PdzOnlc8h2Ho6UUCm4LBU93h1FK4NKU6EqXh6ugpYVT9lugFdBESNrt8oNgmKqWrAvVlbcIH/e0hB8ESPb0v86hAiK2OIh1Nix2ehB3+jVpLxMsUOhupfpNz8s4CngIAhOAAAAAElFTkSuQmCC'
        } 
    };


vp.widget.PaginatorOld.initAll();
vp.widget.PaginatorOld.initAll();


    vp.images.LibraryImagesMap['multiImageDialog-libraryImageDialog'] = new vp.images.LibraryImages(
        'multiImageDialog-libraryImageDialogLibraryImages_LibraryImagesRoot',
        function (r) { vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').chooseImages(r); },
        8,
        49,        
        true,
        function (a,b) { vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').getDialog('libraryImageDialog').createImage(a,b); },
        'default');


vp.widget.PaginatorOld.initAll();
vp.widget.PaginatorOld.initAll();
vp.widget.PaginatorOld.initAll();
(function($){$('.sites-bar-link').on('click', function() {var trackingTarget = $(this).attr('data-tracking-target'); if(trackingTarget){vp.spot.track(trackingTarget);}});})(window.jQuery);
jQuery('.country-current').dropDownMenu({'skin': 'none'});
jQuery('.header-link-menu:has(.menu-panel)').dropDownMenu({'skin': 'none', 'linksWithSubmenusEnabled': true});
if (vp && vp.pageVisitCounter) {vp.pageVisitCounter.MAX_PAGE_VISITS = 32767;};
if (vp && vp.pageVisitCounter) {vp.pageVisitCounter.recordVisit();};
}
jQuery(document).ready(BodyOnLoad_OnDOMReady);
function BodyOnLoad() {
$('#addimagedialog-tab-singleImageDialog').click(function() { vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').goTo('addimagedialog'); });
$('#previousdialog-tab-singleImageDialog').click(function() { vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').goTo('previousdialog'); });
$('#libraryImageDialog-tab-singleImageDialog').click(function() { vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').goTo('libraryImageDialog'); });
$('#thirdpartydialog_facebook-tab-singleImageDialog').click(function() { vp.upload.dialogs.imageuploaderbase.getProxy('singleImageDialog').goTo('thirdpartydialog_facebook'); });
$('#addimagedialog-tab-multiImageDialog').click(function() { vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').goTo('addimagedialog'); });
$('#previousdialog-tab-multiImageDialog').click(function() { vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').goTo('previousdialog'); });
$('#libraryImageDialog-tab-multiImageDialog').click(function() { vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').goTo('libraryImageDialog'); });
$('#thirdpartydialog_facebook-tab-multiImageDialog').click(function() { vp.upload.dialogs.imageuploaderbase.getProxy('multiImageDialog').goTo('thirdpartydialog_facebook'); });
vp.tagmanager.TealiumManager.load('OnloadAsync', '//tags.cdn.vpsvc.com/utag/vprt/prf-main/prod/utag.js', true);
vp.tagmanager.PageManager.load();
$('link[media="non-critical-css"]').each(function(){$(this).removeAttr('media');});
$('#critical-css').remove();
}
jQuery(window).load(BodyOnLoad);
vp.bootstrap.finish();
}
 catch (jsEx) { vp.bootstrap.logException(jsEx); }

</script>

</html>