<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Users_model extends CI_Model {

    private $user_type_table = 'gc_user_types';
    private $user_permission_table = 'gc_user_type_permissions';
    private $user_modules_table = 'gc_user_modules';
    private $user_sections_table = 'gc_user_sections';
    private $gc_users_table = 'gc_users';




    function insert_user_type($data) {

        $modify['Module_name']="User Type";
                $modify['Data']=$data['user_type_name'];
                $modify['Action']="1";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);
                $data['Created_by']         =$this->session->userdata('UserId');
                $data['company_id']         =$this->session->userdata('CompanyId');
        if ($this->db->insert($this->user_type_table, $data)) {
            $insert_id = $this->db->insert_id();
            $this->session->set_flashdata('users_success', 'Added');
            return $insert_id;
        }
        return FALSE;
    }

    public function get_prefix()
    {
        $this->db->select("gc_prefix_setting" . '.user_prefix');
        $query = $this->db->get("gc_prefix_setting");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function insert_user_permission($data) {
        if ($this->db->insert($this->user_permission_table, $data)) {
            $sal_id = $this->db->insert_id();
            return true;
        }
        return false;
    }

    function update_user_type($data, $id) {

        $modify['Module_name']="User Type";
                $modify['Data']=$data['user_type_name'];
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);
                $data['Updated_by']=$this->session->userdata('UserId');
        $data['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', $id);
        if ($this->db->update($this->user_type_table, $data)) {
            $this->session->set_flashdata('users_success', 'Updated');
            return TRUE;
        }
        return FALSE;
    }

    
    function get_check_otp($id,$otp) {

        $this->db->select('*');
        $this->db->where('user_id',$id);            
        $this->db->where('mail_otp',$otp);
        $query = $this->db->get('gc_users');         
        if ($query->num_rows() > 0) {
            return  1;
        }
        return 0;
    }


    public function delete($table_name,$id)
    {
        $this->db->select('user_type_id');$this->db->from('gc_user_type_permissions');$this->db->where('user_type_id', $id);
        $this->db->where('user_type_id.company_id', $this->session->userdata('CompanyId'));
        $user_type_query = $this->db->get();
        $this->db->select('user_type_id');$this->db->from('gc_users');$this->db->where('user_type_id', $id);
        $this->db->where('user_type_id.company_id', $this->session->userdata('CompanyId'));        
        $user_type_id = $this->db->get();
        $user_type_query = $user_type_query->row_array();
        $user_type_id = $user_type_id->row_array();
        if ($user_type_query > 0 || $user_type_id > 0) {
            echo "Duplicate";
            $this->session->set_flashdata('duplicate', 'Already Used in Some Page');
        }else{
if($table_name=="gc_users"){ $title="Users";}elseif($table_name=="gc_user_types"){$title="User Type";}
            $this->db->where('id', $id);
            $query = $this->db->get($table_name);
            $get['data']=$query->result_array();
            if($table_name=="gc_users"){ $value=$get['data'][0]['firstname'];}elseif($table_name=="gc_user_types"){ $value= $get['data'][0]['user_type_name'];}
                $modify['Module_name']=$title;
                $modify['Data']=$value;
                $modify['Action']="3";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);
                $data['Deleted_by']=$this->session->userdata('UserId');
            $data['status'] ="3";
            $this->db->where('id', $id);
            if ($this->db->update($table_name, $data)) {           
                $this->session->set_flashdata('users_success', 'Deleted');            
                $this->session->set_flashdata('user_success', 'Deleted');            
                return TRUE;
            }
            return FALSE;   
        }    
    }
    function get_all_user_types() {
        $this->db->select($this->user_type_table . '.*');
        $this->db->where('company_id', $this->session->userdata('CompanyId'));
        $this->db->where('status!=', 3);
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
    
    function get_all_user_types_multi($id) {
        $this->db->select($this->user_type_table . '.*');
        $this->db->where('company_id', $this->session->userdata('CompanyId'));        
        $this->db->where('status!=', 3);
        $id = explode(",", $id); 

        $this->db->where_in('id', $id);
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }


    function get_all_country() {
        $this->db->select('id,country_name');
        $this->db->where('status!=', 3);
        $query = $this->db->get('gc_countries');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }


    function get_all_payment_mode() {
        $this->db->select('Payment_mode,ID');
        $this->db->where('status!=', 3);
        $this->db->where_not_in('ID',[19,1]);
        $query = $this->db->get('gc_payment_mode');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

        function get_all_user_types_active() {
        $this->db->select($this->user_type_table . '.*');
        $this->db->where('company_id', $this->session->userdata('CompanyId'));        
        $this->db->where('status', 1);
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

public function samp()
{
   return 10;
}
    function get_user_details($id) {

        $this->db->select('member.*,country.country_name,users.og_password,users.username');
        $this->db->from('gc_membership as member');
       $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
       $this->db->join('gc_countries as country', 'country.id = address.country', 'left');
       $this->db->join('gc_users as users', 'users.user_id = member.Membership_ID', 'left');
        $this->db->where('member.Membership_ID', $id);
        $this->db->where('users.user_type_id', 3);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    function get_all_users() {
        $this->db->select($this->gc_users_table . '.*');
        $this->db->where('company_id', $this->session->userdata('CompanyId'));
        $this->db->where('status!=', 3);
        $query = $this->db->get($this->gc_users_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function reset_passcode($id) {
        $this->db->select('member.Membership_ID,member.Email');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_users as users', 'users.user_id = member.Membership_ID', 'left');
        $this->db->where('member.Membership_code', $id);
        $this->db->where('users.user_type_id', 3);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    // function get_all_users_export($id) {
    //     $this->db->select($this->gc_users_table . '.*');

    //     $id = explode(",", $id); 

    //     $this->db->where_in('id', $id);

    //     $query = $this->db->get($this->gc_users_table);
    //     if ($query->num_rows() > 0) {
    //         return $query->result_array();
    //     }
    //     return NULL;
    // }


    function get_user_by_id($user_id) {
       
        $this->db->select($this->gc_users_table . '.*');
        $this->db->where('company_id', $this->session->userdata('CompanyId'));
        $this->db->where('id', $user_id);
        $query = $this->db->get($this->gc_users_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
       
    }

    function get_user_member_by_id($user_id) {
       
        $this->db->select('*');
        // $this->db->where('company_id', $this->session->userdata('CompanyId'));
        $this->db->where('Membership_ID', $user_id);
        $query = $this->db->get('gc_membership');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
       
    }

    // function get_all_users_export($id) {
       
    // $this->db->select($this->gc_users_table . '.*');
    
    // $id = explode(",", $id); 

    // $this->db->where_in('id', $id);
    //     $query = $this->db->get($this->gc_users_table);
    //     if ($query->num_rows() > 0) {
    //         return $query->result_array();
    //     }
    //     return NULL;
       
    // }

    function get_user_desp($user_id) {
       
$this->db->select($this->user_type_table . '.description');
$this->db->where('company_id', $this->session->userdata('CompanyId'));
 $this->db->where('id', $user_id);
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
       
    }

    function get_user_type_by_id($id) {
        $this->db->select($this->user_type_table . '.*');
        $this->db->where($this->user_type_table .'.company_id', $this->session->userdata('CompanyId'));
        $this->db->where($this->user_type_table .'.id', $id);
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function get_all_user_sections_with_modules() {
        $this->db->select($this->user_modules_table . '.*');
        $query = $this->db->get($this->user_modules_table);
        $modules = $query->result_array();
        $user_section_arr = array();
        if (!empty($modules)) {
            foreach ($modules as $module) {
                $sections = $this->get_user_sections_by_module_id($module['id']);
                $user_section_arr[$module['id']] = $module;
                $user_section_arr[$module['id']]['sections'] = $sections;
            }
        }
        return $user_section_arr;
    }   

    function get_user_sections_by_module_id($id) {
        $this->db->select('tab_1.id,tab_1.user_section_name,,tab_1.user_section_key,acc_view,acc_add,acc_edit,acc_delete');
        $this->db->join($this->user_modules_table . ' AS tab_2', 'tab_2.id = tab_1.module_id', 'LEFT');
        $this->db->where('tab_1.module_id', $id);
        $this->db->where('tab_1.status', 1);
        $query = $this->db->get($this->user_sections_table . ' AS tab_1');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function get_user_permissions_by_type($user_type_id) {
        $this->db->select('tab_1.*');
        $this->db->where('tab_1.user_type_id', $user_type_id);
        $query = $this->db->get($this->user_permission_table . ' AS tab_1');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
        function get_financial_year() {
        $this->db->select('*');
        $this->db->where('Status',1);
        $query = $this->db->get('gc_financial_yr_table');
        if ($query->num_rows() > 0) {
            return  $query->row();
        }
        return NULL;
    }
    
    function get_session_time() {
        $this->db->select('*');
        // $this->db->where('Status',1);
        $query = $this->db->get('gc_signout_setting');
        if ($query->num_rows() > 0) {
            return  $query->row();
        }
        return NULL;
    }

    function get_user_permissions_by_type_1($user_type_id) {
        // $this->db->select('tab_1.*');
        // $this->db->where('tab_1.user_type_id', $user_type_id);
        $query = $this->db->query("SELECT user_type_id,module_id FROM `gc_user_type_permissions` WHERE user_type_id='{$user_type_id}' group by `module_id` ");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
    function delete_user_permission_by_type($type) {
        $this->db->where('user_type_id', $type);
        if ($this->db->delete($this->user_permission_table)) {
            if ($this->db->affected_rows() > 0) {
                return true;
            }
        }
        return false;
    }


    function get_increment_code() {
        $entry_number = $this->db->count_all_results($this->gc_users_table)+1;

        return $entry_number;
    }

    function insert_user($data) {
        $modify['Module_name']="Users";
                $modify['Data']=$data['firstname'];
                $modify['Action']="1";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);
                $data['Created_by']=$this->session->userdata('UserId');
        $data['og_password'] = $data['password'];
        $data['password'] = md5($data['password']);

        if ($this->db->insert($this->gc_users_table, $data)) {
            $user_id = $this->db->insert_id();
            $this->session->set_flashdata('user_success', 'Added');
            return $user_id;
        }
        return FALSE;
    }

        function update_user($data, $user_id,$image_data) {
           
        if (empty($data['password'])) {
            unset($data['password']);
        } else {
            $data['og_password'] = $data['password'];
            $data['password'] = md5($data['password']);
        }
        $modify['Module_name']="Users";
                $modify['Data']=$data['firstname'];
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);
                $data['Updated_by']=$this->session->userdata('UserId');
        $data['updated_date'] = date('Y-m-d H:i:s');
        $data['profile_image'] = $image_data;
        $this->db->where('id', $user_id);
        if ($this->db->update($this->gc_users_table, $data)) {
            return TRUE;
        }
        return FALSE;
    }

   
   
   function delete_checkbox($id){
   $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 3;    
   
           $this->db->where('id', $id);
           if ($this->db->update('gc_users', $data)) {
               $this->session->set_flashdata('user_success', 'Deleted');
               return TRUE;
          }
       
           return FALSE;                
        }
   
   
   function active_all_checkbox($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 1;    
   
           $this->db->where('id', $id);
           if ($this->db->update('gc_users', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
   function deactivate_all_checkbox($id){
   
         $data['updated_date'] = date('Y-m-d H:i:s');
         $data['status']         = 2;
   
           $this->db->where('id', $id);
           if ($this->db->update('gc_users', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
   
   
   function delete_checkbox1($id){
   // $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status'] = 3;    
   
           $this->db->where('id', $id);
           $this->db->where('user_mode', 2);
           if ($this->db->update('gc_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Deleted');
               return TRUE;
          }
       
           return FALSE;                
        }
   
   
   function active_all_checkbox1($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 1;    
   
           $this->db->where('id', $id);
           if ($this->db->update('gc_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
    function active_all_checkbox11($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 2;    
   
           $this->db->where('id', $id);
           if ($this->db->update('gc_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }

       function get_all_users1() {
        $this->db->select('users.*,user_type.user_type_name,countries.country_name,states.state_name,cities.city_name,company.CompanyName,branch.type_name')->from('gc_users as users');
        $this->db->join('gc_user_types as user_type', 'user_type.id = users.user_type_id', 'left');
        $this->db->join('gc_countries as countries', 'countries.id = users.country_id', 'left');
        $this->db->join('gc_states as states', 'states.id = users.state_id', 'left');
        $this->db->join('gc_cities as cities', 'cities.id = users.city_id', 'left');
        $this->db->join('gc_company_table as company', 'company.CompanyID = users.company_id', 'left');
         $this->db->join('gc_hub_branch as branch', 'branch.id = users.branch_id', 'left');
        $this->db->where('users.status!=', 3);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
   
   function get_all_users_multi($id) {
        $this->db->select('users.*,user_type.user_type_name,countries.country_name,states.state_name,cities.city_name,company.CompanyName,branch.type_name')->from('gc_users as users');
        $this->db->join('gc_user_types as user_type', 'user_type.id = users.user_type_id', 'left');
        $this->db->join('gc_countries as countries', 'countries.id = users.country_id', 'left');
        $this->db->join('gc_states as states', 'states.id = users.state_id', 'left');
        $this->db->join('gc_cities as cities', 'cities.id = users.city_id', 'left');
        $this->db->join('gc_company_table as company', 'company.CompanyID = users.company_id', 'left');
        $this->db->join('gc_hub_branch as branch', 'branch.id = users.branch_id', 'left');
        $this->db->where('users.status!=', 3);
        $id = explode(",", $id); 

        $this->db->where_in('users.id', $id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
   
    // get Batch details
    public function get_level_earning($userid) {

        $this->db->select('sum(history.Amount) as Credit_sum');
        $this->db->from('gc_member_commission_details as history');
        $this->db->where('history.Membership_ID', $userid);
        $this->db->where('history.Status', 1);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_binary_earning($userid) {

        $this->db->select('Own_BV,Left_BV,Right_BV');
        $this->db->from('gc_bv_values');
        $this->db->where('Membership_ID', $userid);
        $this->db->where('Status', 1);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

        
        // if ($opencart->insert('oc_customer', $reg)) {
        //      $opencart->insert_id();
        // } 
    public function get_all_orders($id)
    {

    // $opencart = $this->load->database('opencart', TRUE);
    // $opencart->select('order.*,total.quantity,status.name as status_name');
    // $opencart->join('oc_customer as customer', 'customer.customer_id = order.customer_id', 'left');
    // $opencart->join('oc_order_product as total', 'total.order_id = order.order_id', 'left');
    // $opencart->join('oc_order_history as history', 'history.order_id = order.order_id', 'left');
    // $opencart->join('oc_order_status as status', 'status.order_status_id = history.order_status_id', 'left');
    // $opencart->where('customer.Member_id', $id);
    // $opencart->group_by('total.order_id');
    // $query = $opencart->get('oc_order as order');
    // if ($query->num_rows() > 0) {
    //     return  $query->result_array();
    // }
    // return NULL;
    }


 public function get_left_right_members_bv($Membership_ID){
$final_left_tree="";
$final_right_tree="";
            $this->db->select('Child_ID,Position_type');
            $this->db->where_in('Parent_ID',$Membership_ID);
            $this->db->order_by('Position_type');
            $query_bin = $this->db->get('gc_binary_member_relation');
            if($query_bin->num_rows() > 0){  // Query_bin numrows if start
                $member_binary=$query_bin->result_array();
                // var_dump($member_binary);
                if($query_bin->num_rows()==2){ // Query_bin numrows1 if start 
                    
                    // foreach($member_binary as $bin){
                    //     if($bin['Position_type']==1){

                    //     }
                    // }
                    if($member_binary[0]['Position_type']==1){
                        $left_tree=$member_binary[0]['Child_ID'];
                        $right_tree=$member_binary[1]['Child_ID'];
                         }else{
                            $left_tree=$member_binary[1]['Child_ID'];
                            $right_tree=$member_binary[0]['Child_ID'];
                         }
                     
                } // Query_bin numrows1 else start 
                else{ // Query_bin numrows1 if end 
                    if($member_binary[0]['Position_type']==1){
                        $left_tree=$member_binary[0]['Child_ID'];
                        $right_tree='';
                         }else{
                            $left_tree='';
                            $right_tree=$member_binary[0]['Child_ID'];
                        }
                } // Query_bin numrows1 else end

                // *** Left Tree Members start *** //
                if(!empty($left_tree)){
                $final_left_tree=[$left_tree];
                $left_parent_id=[$left_tree];

                            $left_limit=1;
                            for($i=1;$i<=10000;$i++){ // left for start  
                            // for($i=1;$i<=$left_limit;$i++){  
                                $this->db->select('Child_ID');
                                $this->db->where_in('Parent_ID',$left_parent_id);
                                // $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
                                $left_query = $this->db->get('gc_binary_member_relation');
                                if($left_query->num_rows() > 0){
                                    foreach($left_query->result_array() as $key => $val){
                                        $left_parent_id[$key]=$val['Child_ID'];
                                        array_push($final_left_tree,$val['Child_ID']);
                                    }
                                    //print_r($left_parent_id);echo '<br>';
                                        //$left_limit++;
                                }
                
                            } // left for end
                            // var_dump($final_left_tree);die();

                             // *** Left Tree Members commision getting start *** //
                            $this->db->select('sum(Total_B_V) as Left_bv');
                            $this->db->where('Date >=',date('Y-m-01'));
                            $this->db->where('Date <=',date('Y-m-t'));
                            $this->db->where_in('Membership_ID',$final_left_tree);
                            $left_com_query=$this->db->get('gc_binary_transaction_details');
                            $left_com=$left_com_query->result_array();
                            if(!empty($left_com[0]['Left_bv'])){
                               $left_binary_commission=$left_com[0]['Left_bv']; 
                           }else{
                                $left_binary_commission=0;
                           }
                            
                             // *** Left Tree Members commision getting end *** //
                }else{
                    $left_binary_commission=0;
                }
                // *** Left Tree Members end *** //

                // *** Right Tree Members start *** //
                if(!empty($right_tree)){
                $final_right_tree=[$right_tree];
                $right_parent_id=[$right_tree];

                            $right_limit=1;
                            for($j=1;$j<=1000;$j++){ // right for start
                            // for($j=1;$j<=$right_limit;$j++){
                                $this->db->select('Child_ID');
                                $this->db->where_in('Parent_ID',$right_parent_id);
                                // $this->db->order_by("Binary_relation_ID", "DESC")->limit(1);
                                $right_query = $this->db->get('gc_binary_member_relation');
                                if($right_query->num_rows() > 0){
                                    foreach($right_query->result_array() as $key => $val){
                                        $right_parent_id[$key]=$val['Child_ID'];
                                        array_push($final_right_tree,$val['Child_ID']);
                                    }
                                    //print_r($parent_id);echo '<br>';
                                        //$right_limit++;
                                }
                
                            } // right for end

                              // *** right Tree Members commision getting start *** //
                            $this->db->select('sum(Total_B_V) as Right_bv');
                            $this->db->where('Date >=',date('Y-m-01'));
                            $this->db->where('Date <=',date('Y-m-t'));
                            $this->db->where_in('Membership_ID',$final_right_tree);
                            $right_com_query=$this->db->get('gc_binary_transaction_details');
                            $right_com=$right_com_query->result_array();
                            if(!empty($right_com[0]['Right_bv'])){
                               $right_binary_commission=$right_com[0]['Right_bv']; 
                           }else{
                                $right_binary_commission=0;
                           }
                             // *** right Tree Members commision getting end *** //
                }              


              }

              $final_array=array('left_bv' => $final_left_tree,
                                 'right_bv' => $final_right_tree);

                return $final_array;
}



 public function getall_orders($id) {

        $this->db->select('order.*,member.First_name,member.Last_name,member.Membership_code,member.Mobile,sum(detail.Total_B_V) as BV');
        $this->db->from('gc_binary_transaction as order');
        $this->db->join('gc_binary_transaction_details as detail', 'detail.Transaction_ID = order.Transaction_ID', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = order.Membership_ID', 'left');
        $this->db->where('order.Status',1);
        $this->db->where('order.Membership_ID',$id);
        $this->db->group_by('detail.Transaction_ID');
        $this->db->order_by("order.Transaction_ID", "DESC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    public function get_all_orders_by($id)
    {

    $opencart = $this->load->database('opencart', TRUE);
    $opencart->select('order.*,total.quantity,product.meta_title,manufacture.name as manu_name,products.price as perprice,ordertotal.*,history.order_status_id as history_orderstatus,history.comment as history_comment,history.date_added as history_date,status.name as status_name');
    $opencart->join('oc_customer as customer', 'customer.customer_id = order.customer_id', 'left');
    $opencart->join('oc_order_product as total', 'total.order_id = order.order_id', 'left');

    $opencart->join('oc_product_description as product', 'product.product_id = total.product_id', 'left');

    $opencart->join('oc_product as products', 'products.product_id = product.product_id', 'left');

    $opencart->join('oc_manufacturer as manufacture', 'manufacture.manufacturer_id = products.manufacturer_id', 'left');

    $opencart->join('oc_order_total as ordertotal', 'ordertotal.order_id = order.order_id', 'left');

    $opencart->join('oc_order_history as history', 'history.order_id = order.order_id', 'left');

    $opencart->join('oc_order_status as status', 'status.order_status_id = history.order_status_id', 'left');


    $opencart->where('order.order_id', $id);
    $opencart->group_by('ordertotal.order_id');
    $query = $opencart->get('oc_order as order');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

  function get_all_ordershistory_by($id) {

    $opencart = $this->load->database('opencart', TRUE);
    $opencart->select('history.*,status.name as status_name');
    $opencart->where('order_id',$id);
    $opencart->join('oc_order_status as status', 'status.order_status_id = history.order_status_id', 'left');
    $query = $opencart->get('oc_order_history as history');
    if ($query->num_rows() > 0) {
        return  $query->result_array();
    }
    return NULL;
    }

  function get_all_orderstotal_by($id) {

        $opencart = $this->load->database('opencart', TRUE);
        $opencart->select('total.*');
        $opencart->where('order_id',$id);
        $query = $opencart->get('oc_order_total as total');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    public function duplicate_check($data,$table_name,$colum){

        $this->db->select('*');
        $this->db->from($table_name);
        $this->db->where($colum, $data);
        // $this->db->where('Status!=', 3);
        $query = $this->db->get();
        if ($query->num_rows() > 0) { 
            return 1;
        }else{
            return 0;
        }     
    }

    public function duplicate_check_return_id($country,$city,$table_name,$colum){

        $this->db->select('id');
        $this->db->from($table_name);
        $this->db->where($colum, $city);
        $this->db->where('country_id', $country);
        $query = $this->db->get()->row();
        if (!empty($query)) { 
            return $query->id;
        }else{
            return 0;
        }     
    }

    public function get_country_code($id)
    {
        $this->db->select('country_code');
        $this->db->from('gc_countries');
        $this->db->where('id', $id);
        $this->db->where('status', 1);
        $query = $this->db->get()->row();
        if (!empty($query)) { 
            return $query->country_code;
        }   
    }

}
