<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lease_model extends CI_Model {

	public function get_lease($lease=NULL) {
	    $this->db->select('lease.*,area.area_name,customer.customer_name,details.*,SUM(details.category_value) as detail_total,SUM(lease.area_total) as lease_total');
	    $this->db->from('prop_lease as lease');
	    $this->db->join('prop_lease_details as details','details.lease_id = lease.lease_id','left');
	    $this->db->join('prop_area as area','area.area_id = lease.area_id','left');
	    $this->db->join('prop_customer as customer','customer.customer_id = lease.customer_id','left');
	    $this->db->where('lease.status!=',3);
	    $this->db->group_by('details.lease_id');
	    if (!empty($lease)) {
	    	$this->db->where('lease.lease_id',$lease);
	    }
	    $query = $this->db->get();        
	    if ($query->num_rows() > 0) {
	        return $query->result_array();
	    }
	    return NULL;
	}

	public function get_lease_by($id) {
	    $this->db->select('*');
	    $this->db->from('prop_lease');
	    $this->db->where('lease_id', $id);
	    $query = $this->db->get();        
	    if ($query->num_rows() > 0) {
	        return $query->result_array();
	    }
	    return NULL;
	}

	public function get_lease_detail_by($id) {
	    $this->db->select('*');
	    $this->db->from('prop_lease_details');
	    $this->db->where('lease_id', $id);
	    $query = $this->db->get();        
	    if ($query->num_rows() > 0) {
	        return $query->result_array();
	    }
	    return NULL;
	}
	
	public function get_customer() {
	    $this->db->select('*');
	    $this->db->from('prop_customer');
	    $this->db->where('status!=',3);
	    $query = $this->db->get();        
	    if ($query->num_rows() > 0) {
	        return $query->result_array();
	    }
	    return NULL;
	}

	public function get_area() {
	    $this->db->select('*');
	    $this->db->from('prop_area');
	    $this->db->where('status!=',3);
	    $query = $this->db->get();        
	    if ($query->num_rows() > 0) {
	        return $query->result_array();
	    }
	    return NULL;
	}

    function get_area_by_areaid($id) {
        $this->db->select('area_sqm,area_rent');
        $this->db->where('area_id',$id);				
        $this->db->where('status',1);
        $query = $this->db->get('prop_area');			
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

	public function get_lease_excel_report($start,$end,$area,$customer) {
		
	    $this->db->select('lease.*,area.area_name,customer.customer_name,details.*,SUM(details.category_value) as detail_total,SUM(lease.area_total) as lease_total');
	    $this->db->from('prop_lease as lease');
	    $this->db->join('prop_lease_details as details','details.lease_id = lease.lease_id','left');
	    $this->db->join('prop_area as area','area.area_id = lease.area_id','left');
	    $this->db->join('prop_customer as customer','customer.customer_id = lease.customer_id','left');
	    $this->db->where('lease.status!=',3);
	    $this->db->group_by('details.lease_id');

	    if (!empty($start)) {
	    	$this->db->where('DATE(lease.start_date)>=',date('Y-m-d',strtotime($start)));
	    }
	    if (!empty($end)) {
	    	$this->db->where('DATE(lease.end_date)<=',date('Y-m-d',strtotime($end)));
	    }
	    if (!empty($area)) {
	    	$this->db->where('lease.area_id',$area);
	    }
	    if (!empty($customer)) {
	    	$this->db->where('lease.customer_id',$customer);
	    }

	    $query = $this->db->get();        
	    if ($query->num_rows() > 0) {
	        return $query->result_array();
	    }
	    return NULL;
	}

	public function get_lease_expiry_excel_report($start,$end,$area,$customer) {
		
	    $this->db->select('lease.*,area.area_name,customer.customer_name,details.*,SUM(details.category_value) as detail_total,SUM(lease.area_total) as lease_total');
	    $this->db->from('prop_lease as lease');
	    $this->db->join('prop_lease_details as details','details.lease_id = lease.lease_id','left');
	    $this->db->join('prop_area as area','area.area_id = lease.area_id','left');
	    $this->db->join('prop_customer as customer','customer.customer_id = lease.customer_id','left');
	    $this->db->where('lease.status!=',3);
	    $this->db->group_by('details.lease_id');

	    if (!empty($start)) {
	    	$this->db->where('DATE(lease.end_date)>=',date('Y-m-d',strtotime($start)));
	    }
	    if (!empty($end)) {
	    	$this->db->where('DATE(lease.end_date)<=',date('Y-m-d',strtotime($end)));
	    }
	    if (!empty($area)) {
	    	$this->db->where('lease.area_id',$area);
	    }
	    if (!empty($customer)) {
	    	$this->db->where('lease.customer_id',$customer);
	    }

	    $query = $this->db->get();        
	    if ($query->num_rows() > 0) {
	        return $query->result_array();
	    }
	    return NULL;
	}

	public function get_lease_report() {
		extract($_POST);	
		
	    $this->db->select('lease.*,area.area_name,customer.customer_name,details.*,SUM(details.category_value) as detail_total');
	    $this->db->from('prop_lease as lease');
	    $this->db->join('prop_lease_details as details','details.lease_id = lease.lease_id','left');
	    $this->db->join('prop_area as area','area.area_id = lease.area_id','left');
	    $this->db->join('prop_customer as customer','customer.customer_id = lease.customer_id','left');
	    $this->db->where('lease.status!=',3);
	    $this->db->group_by('details.lease_id');

	    if (!empty($start)) {
	    	$this->db->where('DATE(lease.start_date)>=',date('Y-m-d',strtotime($start)));
	    }
	    if (!empty($end)) {
	    	$this->db->where('DATE(lease.end_date)<=',date('Y-m-d',strtotime($end)));
	    }

	    
	    if (!empty($tenant_origin)) {
	    	$this->db->where('lease.tenant_origin',$tenant_origin);
	    }

	    if (!empty($area)) {
	    	$this->db->where('lease.area_id',$area);
	    }
	    if (!empty($customer)) {
	    	$this->db->where('lease.customer_id',$customer);
	    }
	    $query = $this->db->get();        
	    if ($query->num_rows() > 0) {
	        return $query->result_array();
	    }
	    return NULL;
	}

	public function get_lease_expiry_report() {
		extract($_POST);	
		
	    $this->db->select('lease.*,area.area_name,customer.customer_name,details.*,SUM(details.category_value) as detail_total');
	    $this->db->from('prop_lease as lease');
	    $this->db->join('prop_lease_details as details','details.lease_id = lease.lease_id','left');
	    $this->db->join('prop_area as area','area.area_id = lease.area_id','left');
	    $this->db->join('prop_customer as customer','customer.customer_id = lease.customer_id','left');
	    $this->db->where('lease.status!=',3);
	    $this->db->group_by('details.lease_id');

	    if (!empty($start)) {
	    	$this->db->where('DATE(lease.end_date)>=',date('Y-m-d',strtotime($start)));
	    }
	    if (!empty($end)) {
	    	$this->db->where('DATE(lease.end_date)<=',date('Y-m-d',strtotime($end)));
	    }
	    if (!empty($area)) {
	    	$this->db->where('lease.area_id',$area);
	    }
	    if (!empty($customer)) {
	    	$this->db->where('lease.customer_id',$customer);
	    }
	    $query = $this->db->get();        
	    if ($query->num_rows() > 0) {
	        return $query->result_array();
	    }
	    return NULL;
	}
}
