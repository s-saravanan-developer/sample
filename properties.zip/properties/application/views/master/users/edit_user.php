<div class="content-wrapper">
   <div class="content">
      <header class="page-header">
         <div class="d-flex align-items-center">
            <div class="mr-auto">
               <h1 class="separator">Edit User</h1>
               <nav class="breadcrumb-wrapper" aria-label="breadcrumb">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="index.html"><i class="icon dripicons-home"></i></a></li>
                     <li class="breadcrumb-item"><a href="javascript:void(0)">Master</a></li>
                     <li class="breadcrumb-item active" aria-current="page">Manage User / Edit User</li>
                  </ol>
               </nav>
            </div>
            <ul class="actions top-right">
               <li class="dropdown">
                  <a href="javascript:void(0)" class="btn btn-fab" data-toggle="dropdown" aria-expanded="false">
                  <i class="la la-ellipsis-h"></i>
                  </a>
                  <div class="dropdown-menu dropdown-icon-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(40px, 40px, 0px); top: 0px; left: 0px; will-change: transform;">
                     <div class="dropdown-header">
                        Quick Actions
                     </div>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-clockwise"></i> Refresh
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-gear"></i> Manage User Types
                     </a>
                     <a href="#" class="dropdown-item">
                     <i class="icon dripicons-help"></i> Support
                     </a>
                  </div>
               </li>
            </ul>
         </div>
      </header>
      <section class="page-content container-fluid">
         
         <div class="row">
            <div class="col">
               <div class="card" style="overflow-x: scroll;">
                  <h5 class="card-header">User Information</h5>
                  <form method="post" action="<?php echo base_url();?>master/users/user_edit" class="form-horizontal" data-toggle="validator" role="form" novalidate="true"  enctype="multipart/form-data">
                     <input type="hidden" name="id" id="id" class="user_id" value="<?php echo $users[0]['user_id']; ?>">
                     <div class="card-body">
                        <div class="form-body">
                           <div class="row">                              
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">User Code </label>
                                    <!-- <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-dns  zmdi-hc-fw"></i></span>
                                       </div> -->
                                       <input type="text" class="form-control" placeholder="User Id" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="user_code" readonly="" value="<?php echo $users[0]['user_code']; ?>">
                                   
                                 </div>
                              </div>

                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Company </label> <span class="text-danger">*</span>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control multiselect" multiple="" id="company_id_edit"  name="company_id[]" required="">
                                       <!-- <option >Select Company</option> -->
                                    <?php
                                    if (!empty($companies)) {
                                        foreach ($companies as $company) {
                                            ?>
                                            <option value="<?php echo $company['company_id']; ?>" <?php echo ($company['company_id'] == 0) ? 'selected' : ''; ?>><?php echo ucfirst($company['company_name']); ?>
                                            </option>
                                            <?php
                                        }
                                    }
                                    ?>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Name</label> <span class="text-danger">*</span>       
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-account zmdi-hc-fw"></i></span>
                                       </div>                                      
                                       <input type="text" class="form-control" placeholder="Name" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="firstname" required="" value="<?php echo $users[0]['firstname']; ?>" maxlength="50">
                                    </div>
                                 </div>
                              </div>
                              
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label">DOB</label>
                                    <div class="input-group">
                                       <span class="input-group-addon action">
                                       <i class="icon dripicons-calendar"></i>
                                       </span>
                                       <input type="text" class="form-control date helper-datepicker" placeholder="dd/mm/yyyy" name="dob" id="tbDate" value="<?php echo $users[0]['dob']; ?>">
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Email Address</label>
                                    <div class="input-group mb-3">
                                       <div class="input-group-append">
                                          <span class="input-group-text" id="basic-addon2"><i class="zmdi zmdi-email zmdi-hc-fw"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Enter Email Address" aria-label="Icon Left" aria-describedby="basic-addon2" name="email" value="<?php echo $users[0]['email']; ?>">
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Mobile Number</label> <span class="text-danger">*</span>
                                    <div class="input-group mb-3">
                                       <div class="input-group-append">
                                          <span class="input-group-text" id="basic-addon2"><i class="zmdi zmdi-smartphone-iphone zmdi-hc-fw"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Enter Mobile Number" aria-label="Icon Left" aria-describedby="basic-addon2" name="mobile" required="" value="<?php echo $users[0]['mobile']; ?>" onkeypress="return isNumber(event)">
                                    </div>
                                 </div>
                              </div>
                              
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Phone Number</label>
                                    <div class="input-group mb-3">
                                       <div class="input-group-append">
                                          <span class="input-group-text" id="basic-addon2"><i class="zmdi zmdi-phone zmdi-hc-fw"></i></span>
                                       </div>
                                       <input type="text" class="form-control" maxlength="11" placeholder="Enter Phone Number" aria-label="Icon Left" aria-describedby="basic-addon2" name="phone" value="<?php echo $users[0]['phone']; ?>" onkeypress="return isNumber(event)">                           
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Address Line 1</label> <span class="text-danger">*</span>
                                     <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-card zmdi-hc-fw"></i></span>
                                       </div>
                                    <input type="text" class="form-control" id="exampleFormControlTextarea1" placeholder="Enter Address Line 1" rows="3" name="address1" required="" value="<?php echo $users[0]['address1']; ?>">
                                    <div class="invalid-feedback">
                                       Please choose a Address Line.
                                    </div>
                                 </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Address Line 2</label>
                                     <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-card zmdi-hc-fw"></i></span>
                                       </div>
                                    <input type="text" class="form-control" id="exampleFormControlTextarea1" placeholder="Enter Address Line 2" rows="3" name="address2" required="" value="<?php echo $users[0]['address2']; ?>">
                                 </div>
                              </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Country</label> <span class="text-danger">*</span>
                                     <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control company_country" id="country_id" name="country_id" required="">
                                       <option value="">Select Country</option>
                                    <option value="">Select Country</option>
                                    <?php
                                    if (!empty($countries)) {
                                        foreach ($countries as $country) {
                                            ?>
                                            <option value="<?php echo $country['id']; ?>" <?php echo ($country['id'] == $users[0]['country_id']) ? 'selected' : ''; ?>><?php echo ucfirst($country['country_name']); ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                    </select>
</div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">State</label> <span class="text-danger">*</span>
                                     <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control company_state" id="state_id" name="state_id" required="">
                                       <option value="">Select State</option>
                                   <?php
                                    if (!empty($states)) {
                                        foreach ($states as $state) {
                                            ?>
                                            <option value="<?php echo $state['id']; ?>" <?php echo ($state['id'] == $users[0]['state_id']) ? 'selected' : ''; ?>><?php echo ucfirst($state['state_name']); ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                    </select>
                                 </div>
                                 </div>
                              </div>

                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">City</label> <span class="text-danger">*</span>
                                     <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text " id="basic-icon-addon1"><i class="zmdi zmdi-pin-drop zmdi-hc-fw"></i></span>
                                       </div>
                                    <select class="form-control company_city" id="city_id" name="city_id" required="">
                                        <option value="">Select City</option>
                                    <?php
                                    if (!empty($cities)) {
                                        foreach ($cities as $city) {
                                            ?>
                                            <option value="<?php echo $city['id']; ?>" <?php echo ($city['id'] == $users[0]['city_id']) ? 'selected' : ''; ?>><?php echo ucfirst($city['city_name']); ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                              
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Pincode</label> <span class="text-danger">*</span>
                                    <div class="input-group mb-3">
                                       <div class="input-group-prepend">
                                          <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-pin zmdi-hc-fw"></i></span>
                                       </div>
                                       <input type="text" class="form-control" placeholder="Enter Pincode" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="pincode" required="" value="<?php echo $users[0]['pincode']; ?>" onkeypress="return isNumber(event)">
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">Profile Picture</label>
                                    <span class="">
                                       <input type="file" id="profile_image" class="form-control" name="profile">
                                       <input type="hidden" name="old_file_name" value="<?php echo $users[0]['profile']; ?>">
                                    </span>
                                 </div>
                              </div>
                              <div class="col-md-4" >
                                        <a href="javascript:void(0);" style="margin-left: -55px;">
                                          <?php if($users[0]['profile'] != NULL) { ?>
                                          <img id="imagePreview" src="<?php echo base_url(); ?>attachments/users_image/<?php echo $users[0]['profile']; ?>" style="width: 60px; height: 60px; border: 2px #ccc solid;margin-top:0px;margin-left:55px;;margin-top:10px; " alt="User profile picture" default_src="<?php echo base_url(); ?>attachments/users_image/default_profile_image.png">
                                          <?php }else{ ?>
                                          <img id="imagePreview" src="<?php echo base_url(); ?>attachments/users_image/default_profile_image.png" style="width: 60px; height: 60px; border: 2px #ccc solid;margin-top:0px;margin-left:55px;;margin-top:10px; " alt="User profile picture" default_src="<?php echo base_url(); ?>attachments/users_image/default_profile_image.png">
                                          <?php } ?>
                                       </a>
                              </div>
                              
                           </div>
                           <div class="row">
                              <h5 class="card-header">User Credential
                                 </h5>
                              <div class="col-12">
                                
                                 <div class="row">
                                    <div class="col-md-4">
                                       <div class="form-group">
                                          <label class="col-form-label-lg control-label" for="largeInput">User Name</label>
                                          <div class="input-group mb-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-account zmdi-hc-fw"></i></span>
                                             </div>
                                             <input type="text" class="form-control check_dataedit" placeholder="User Name" aria-label="Icon Left" aria-describedby="basic-icon-addon1" onkeyup="duplicate_checkedit()" name="username" value="<?php echo $users[0]['username']; ?>">
                                          </div>
                                          <div class="text-center duplicate-occuredit no-display">
                                           <code>This Username Is Already Used</code>
                                        </div>
                                       </div>
                                    </div>
                                    <div class="col-md-4">
                                       <div class="form-group">
                                          <label class="col-form-label-lg control-label" for="largeInput">Password</label>
                                          <div class="input-group mb-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-lock zmdi-hc-fw"></i></span>
                                             </div>
                                             <input type="password" data-minlength="6" class="form-control" id="inputPasswordform" placeholder="Password" aria-label="Icon Left" aria-describedby="basic-icon-addon1" name="password"  > 
                                             
                                          </div>
                                          <span class="text-danger text-center" style="font-size: 12px; padding-left: 9px; padding-top: 10px;">   <strong>(Leave as empty, if you do not change password)</strong></span>
                                       </div>
                                    </div>
                                    <div class="col-md-4">
                                       <div class="form-group">
                                          <label class="col-form-label-lg control-label" for="largeInput">Re-Password</label>
                                          <div class="input-group mb-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-lock zmdi-hc-fw"></i></span>
                                             </div>
                                             <input type="password" class="form-control" id="inputPasswordConfirm" data-match="#inputPasswordform" data-match-error="Whoops, these don't match" placeholder="Re-Password" aria-describedby="basic-icon-addon1" > <br>
                                          </div>
                                          <div class="help-block with-errors"></div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <h5 class="card-header">User Role Information
                              </h5>
                           <div class="col-md-12">
                             
                              <div class="row">
                              <div class="col-md-4">
                                 <div class="form-group">
                                    <label class="col-form-label-lg control-label" for="largeInput">User Type</label> <span class="text-danger">*</span>
                                     <div class="input-group mb-3">
                                             <div class="input-group-prepend">
                                                <span class="input-group-text" id="basic-icon-addon1"><i class="zmdi zmdi-account zmdi-hc-fw"></i></span>
                                             </div>
                                    <select class="form-control" id="user_type_id" name="user_type_id" onchange="view_desp()" required="">
                                       <option value="">Select User Type</option>
                          <?php if (!empty($user_types)) {foreach ($user_types as $type) {?>
                          <option value="<?php echo $type['user_type_id']; ?>" <?php if($type['user_type_id']==$users[0]['user_type_id']) echo 'selected';?>><?php echo ucfirst($type['user_type_name']); ?></option>
                          <?php } } ?>
                                    </select>
                                 </div>
                                 </div>
                              </div>
                              <div class="col-md-4" id="description_view" style="display:none;">
                               <div class="form-group">
                                  <label for="exampleFormControlTextarea1">Description <span style="color:red">*</span></label></label>
                                  <textarea class="form-control" id="description" placeholder="Enter Description" name="user_type[description]" rows="3"></textarea>
                               </div>
                              </div>
                            </div>
                           </div>
                        </div>
                     </div>
                 
                  <div class="card-footer bg-light">                  
                     <button class="btn btn-success" type="submit" id="edituser">Update</button>
                     <a href="<?php echo base_url();?>master/users/user" class="btn btn-accent">Cancel</a>
                  </div>

               </div>
               </form>
            </div>
         </div>
   </div>
   </section>
</div>
</div>
</div>


<script>

$(function() {
  // var company = JSON.parse("[" + '<?php echo $users[0]['company_id']; ?>' + "]");
  var name = [];
  $.map(name, function (x) {
    return $('.multiselect').append("<option>" + x + "</option>");
  });
  
  $('.multiselect')
    .multiselect({
      allSelectedText: 'All',
      maxHeight: 200,
      includeSelectAllOption: true
    })
    .multiselect('deselectAll', false)
    .multiselect('updateButtonText');


    // $('.multiselect').val(company).trigger('change').multiSelect("refresh");;

var company = '<?php echo $users[0]['company_id']; ?>';

var valArr = company.split(",");

$.each(company.split(","), function(i,e){
  // alert(e);
    $(".multiselect").find(":checkbox[value='"+e+"']").attr("checked","checked");
    $(".multiselect option[value='" + e + "']").prop("selected", true);
    $(".multiselect").multiSelect("refresh");
});
// alert(valArr[0]);
// i = 0, size = valArr.length;
// for(i; i < size; i++){
//   $(".multiselect").find(":checkbox[value='"+valArr[i]+"']").attr("checked","checked");
//   $(".multiselect option[value='" + valArr[i] + "']").attr("selected", 1);
//   $(".multiselect").multiselect("refresh");
// }

});
$(document).on('change', '.multiselect', function(e) {
  // alert(); 


  // alert($(this).val());
});
   $(document).ready(function() {
    $('#company_id_edit').change(function(){
      alert($(this).val());
   //    $(this).val(2).trigger('change');
    });
    });

      // $('.branch_id_select').val(<?php //echo $users[0]['branch_id']; ?>);
      // $('#company_id_edit').select2();
      // var company = JSON.parse("[" + '<?php echo $users[0]['company_id']; ?>' + "]");
      // $('#company_id_edit').select2().val(company).trigger('change');

   // });



   function view_desp(){
      id = $('#user_type_id').val();
      var data_string="id="+id;
      console.log(data_string);
        $.ajax({   
          url: "<?php echo base_url(); ?>master/Users/get_desp",
          async: false,
          type: "POST",    
          data: data_string, 
          dataType: "json", 
          success: function(data) { 
                
         if(data!=null){
            $("#description_view").show();
            $("#description").val(data[0]['description']);
            }
            else{
                 $("#description_view").hide();
                 $("#description").val("");
               }
      
    }
    });
   }

      function duplicate_checkedit() {
        // alert("hi");
      var id = $('.user_id').val();
      var check_data = $('.check_dataedit').val();
      // alert(check_data);
      var result = '';
         $.ajax({
           type: "POST",
           url: "<?php echo base_url(); ?>master/location/duplicate_checkedit",
           data: {data: check_data,table_name: 'mpro_users',colum: 'username',id:id},
           cache: true,
           async: false,
           success: function(data){
            
            result = data;
           }
         });
         if(result == 1){
            $('.duplicate-occuredit').removeClass('no-display');
            
            $('#edituser').attr( "disabled","disabled");
            return false;
        }else{
            $('.duplicate-occuredit').addClass('no-display');
            $('#edituser').removeAttr( "disabled", );
            return true;
        }
         
   }
</script>


<script type="text/javascript">
  
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>