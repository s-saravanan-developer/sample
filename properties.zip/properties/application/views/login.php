<!DOCTYPE html>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Property</title>
    <link rel="icon" type="image/jpg" href="" />
    <!-- Global stylesheets -->

    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/login/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/login/styles.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/login/colors.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/login/components.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/login/core.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/layouts/vertical/themes/theme-a.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- /global stylesheets -->
</head>
<body class="login-container bg-slate-800">
    <!-- Page container -->
    <div class="page-container">
        <!-- Page content -->
        <div class="page-content">
            <!-- Main content -->
            <div class="content-wrapper">
                <style type="text/css">
                    .material-icons {
                        font-family: 'Material Icons';
                        font-weight: normal;
                        font-style: normal;
                        font-size: 24px;
                        /* Preferred icon size */
                        display: inline-block;
                        line-height: 1;
                        text-transform: none;
                        letter-spacing: normal;
                        word-wrap: normal;
                        white-space: nowrap;
                        direction: ltr;

                        /* Support for all WebKit browsers. */
                        -webkit-font-smoothing: antialiased;
                        /* Support for Safari and Chrome. */
                        text-rendering: optimizeLegibility;

                        /* Support for Firefox. */
                        -moz-osx-font-smoothing: grayscale;

                        /* Support for IE. */
                        font-feature-settings: 'liga';
                    }

                    .error_msg {
                        font-size: 14px;
                        border-color: rgba(208, 101, 101, 0.9);
                        font-family: inherit;
                        font-size: 14px;
                        -webkit-box-sizing: border-box;
                        -moz-box-sizing: border-box;
                        box-sizing: border-box;
                    }

                    .qt-loader.qt-loader-mini:before, .qt-loader:before {
                        content: '';
                        top: 57%;
                        background: 0 0;
                        margin-top: -.6rem;
                        opacity: .75;
                        left: 0;
                        box-sizing: border-box;
                    }
                    .qt-loader {
                        position: relative;
                        z-index: 999;
                    }
                    .qt-loader:before {
                        width: 30px;
                        height: 30px;
                        border-radius: 50%;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                        position: absolute;
                        animation: clockwise .5s linear infinite;
                    }
                    .qt-loader.qt-loader-mini:before {
                        width: 14px;
                        height: 14px;
                        border: 2px solid #FFF;
                        border-radius: 50%;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                        position: absolute;
                        -webkit-animation: clockwise .5s linear infinite;
                        animation: clockwise .5s linear infinite;
                    }
                    .qt-loader.qt-loader-left:before {
                        right: auto;
                        left: 0;
                        margin-left: 13px;
                    }
                    .qt-loader.qt-loader-right {
                        padding-right: 40px;
                    }
                    .qt-loader.qt-loader-right:before {
                        left: auto;
                        right: 0;
                        margin-right: 13px;
                    }
                    .qt-loader.qt-loader-secondary:before {
                        border: 2px solid #788db4;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                    }
                    .qt-loader.qt-loader-success:before {
                        border: 2px solid #2fbfa0;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                    }
                    .qt-loader:hover.qt-loader-success:before {
                        border: 2px solid #fff;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                    }
                    .qt-loader.qt-loader-danger:before {
                        border: 2px solid #ff5c75;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                    }
                    .qt-loader:hover.qt-loader-danger:before {
                        border: 2px solid #fff;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                    }
                    .qt-loader.qt-loader-info:before {
                        border: 2px solid #399AF2;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                    }
                    .qt-loader:hover.qt-loader-info:before, .qt-loader:hover.qt-loader-secondary:before {
                        border: 2px solid #fff;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                    }
                    .qt-loader.qt-loader-warning:before {
                        border: 2px solid #FFCE67;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                    }
                    .qt-loader:hover.qt-loader-warning:before {
                        border: 2px solid #fff;
                        border-left-color: transparent;
                        border-bottom-color: transparent;
                    }
                    .qt-loader.qt-loader-center {
                        position: absolute;
                        left: 50%;
                        top: 50%}
                        @-webkit-keyframes clockwise {
                            0% {
                                -webkit-transform: rotate(0);
                                transform: rotate(0);
                            }
                            100% {
                                -webkit-transform: rotate(360deg);
                                transform: rotate(360deg);
                            }
                        }
                        @keyframes clockwise {
                            0% {
                                -webkit-transform: rotate(0);
                                transform: rotate(0);
                            }
                            100% {
                                -webkit-transform: rotate(360deg);
                                transform: rotate(360deg);
                            }
                        }
                        @-webkit-keyframes donut-rotate {
                            0%, 100% {
                                -webkit-transform: rotate(0);
                                transform: rotate(0);
                            }
                            .p-l-40, .qt-loader.qt-loader-left {
                                padding-left: 40px!important;
                            }
                            .btn-block-ui:before, .qt-loader:before {
                                border: 2px solid #FFF;
                                -webkit-animation: clockwise .5s linear infinite;
                            }
                            50% {
                                -webkit-transform: rotate(-140deg);
                                transform: rotate(-140deg);
                            }
                        }
                        @keyframes donut-rotate {
                            0%, 100% {
                                -webkit-transform: rotate(0);
                                transform: rotate(0);
                            }
                            50% {
                                -webkit-transform: rotate(-140deg);
                                transform: rotate(-140deg);
                            }
                        }

                        .p {
                            color: red;
                        }

                        .powered_by_text {
                            text-align: center;
                        }

                        .powered_link:hover,
                        .powered_link:visited {
                            color: #84c3e0;
                        }

                        .text-muted{
                            color: #999999;
                        } 
                        .while-hoverable{
                            color: #4885ed;
                        }

                    </style>
                    <!-- Content area -->
                    <div class="content">
                        <!-- Advanced login -->
                        <form class="sign-in-form login_div" name="login_form" id="login_form" action="Login/validate" method="post">
                            <div class="panel panel-body login-form log-bor" style="background: #f7f7f7">
                                <div class="text-center">

                                   <!--  <div class="icon-object border-warning-400 text-warning-400"><img src="<?php echo base_url(); ?>assets/img/logo.jpg" alt="" height="120"></i>
                                    </div> -->
                                    <h2>Property</h2>
                                    <!--  <h1 class="thin">Medical Probook</h1>-->
                                    <h5 class="content-group-lg" style="margin-top:0px">Login to your account <small class="display-block">Enter your credentials</small></h5>
                                </div>
                                <span id="form_err_demo" class="badge badge-danger" style="font-size: 15px;margin-bottom: 15px"></span>
                                <div class="form-group has-feedback has-feedback-left">
                                    <input type="text" name="username" id="user" class="login_input form-control required" placeholder="Username" autofocus="" />
                                    <div class="form-control-feedback">
                                        <i class="material-icons text-muted" style="padding-top: 8px; font-size: 18px;">person</i>
                                    </div>
                                </div>

                                <div class="form-group has-feedback has-feedback-left">
                                    <input type="password" name="password" id="pwd" class="login_input form-control required" placeholder="Password" />
                                    <div class="form-control-feedback">
                                     <i class="material-icons text-muted" href="<?php echo base_url(); ?>/user1.png" style="padding-top: 8px; font-size: 18px;">lock</i>
                                 </div>
                             </div>
                             <span id="form_err" style="color:red;"></span>
                             <div class="form-group">
                               <button class="btn btn-success  btn-floating btn-lg btn-block" id="login_btn" type="button">Sign In</button>                               
                           </div>
                           <div class="powered_by_text">
                            <span style="display: block;">&copy; <?php echo date('Y'); ?> @Prop, All rights reserved.</span> <!--Powered by <a href="<?php echo base_url(); ?>/#" target="_blank" style="color: #4885ed">MEQUALS</a>-->
                        </div>
                    </div>
                </form>
            </div>                
        </div>
    </div>
</div>

</body>
</html>

<script src="<?php echo base_url(); ?>assets/vendor/jquery/dist/jquery.min.js"></script>
<script type="text/javascript">
    $("#login_btn").click(function(){ 
        $('#login_btn').addClass('qt-loader qt-loader-mini qt-loader-right');   
        var username = $('#user').val();
        var password = $('#pwd').val();
        var data_string="username="+username+"&password="+password;

        $.ajax({   
          url: "<?php echo base_url(); ?>login/validate",
          async: false,
          type: "POST", 	
          data: data_string, 
          dataType: "json", 
          success: function(data) {          
              if(data['value']==1){
                $('#login_btn').removeClass('qt-loader qt-loader-mini qt-loader-right');  
                $(".form-group").addClass("has-error");
                $("#form_err").empty().prepend("Username or Password Incorrect!");       
            }else{

                if(data['value']==2){
                $('#login_btn').removeClass('qt-loader qt-loader-mini qt-loader-right');  
                $("#form_err_demo").empty().prepend("Demo Session Expired..Please Contract");       
            }else{
                $(".form-group").removeClass("has-error");
                window.location.href=data['value'];
            }
        } 
    }
    }); 
    });

    var input = document.getElementById("pwd");
    input.addEventListener("keyup", function(event) {
       event.preventDefault();
       if (event.keyCode === 13) {
           document.getElementById("login_btn").click();
       }
   });

</script>
