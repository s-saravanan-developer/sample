<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Ecommerce_model extends CI_Model { 

    function getall_bank() {

        $this->db->select('*');
        $this->db->where('Status',1);
        $this->db->order_by("ID", "DESC");
        $query = $this->db->get('gc_bank');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

 public function getall_orders() {

        $this->db->select('order.*,member.First_name,member.Last_name,member.Membership_code,member.Mobile,sum(detail.Total_B_V) as BV');
        $this->db->from('gc_binary_transaction as order');
        $this->db->join('gc_binary_transaction_details as detail', 'detail.Transaction_ID = order.Transaction_ID', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = order.Membership_ID', 'left');
        $this->db->where('order.Status',1);
        $this->db->where('order.Created_date>=',date('Y-m-d'));
        $this->db->group_by('detail.Transaction_ID');
        $this->db->order_by("order.Transaction_ID", "DESC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

 public function get_order_member_details($mobile,$s_date,$e_date) {

        $this->db->select('order.*,member.First_name,member.Last_name,member.Membership_code,member.Mobile,sum(detail.Total_B_V) as BV');
        $this->db->from('gc_binary_transaction as order');
        $this->db->join('gc_binary_transaction_details as detail', 'detail.Transaction_ID = order.Transaction_ID', 'left');
        $this->db->join('gc_membership as member', 'member.Membership_ID = order.Membership_ID', 'left');
        $this->db->where('order.Status',1);
        $this->db->order_by("order.Transaction_ID", "DESC");
        if(!empty($mobile)){
           $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where); 
        }
        
        if(!empty($s_date)){
            if(date('Y-m-d',strtotime($s_date))>=date('Y-m-d')){
                $e_date='';
            }
            $this->db->where('order.Created_date >=',date('Y-m-d',strtotime($s_date)));
        }

        if(!empty($e_date)){
            $this->db->where('order.Created_date <=',date('Y-m-d',strtotime($e_date)));
        }
        
        $this->db->group_by('detail.Transaction_ID');

        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }
    

public function getall_order_details_by_id($Transaction_ID){
    $this->db->select('details.*,order.Order_no,order.Created_date');
    $this->db->from('gc_binary_transaction_details as details');
    $this->db->join('gc_binary_transaction as order', 'order.Transaction_ID = details.Transaction_ID', 'left');
    $this->db->where("details.Transaction_ID",$Transaction_ID);
    $this->db->where("order.Status",1);
    $this->db->group_by("details.Transaction_detail_ID");
    $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;


}


function getall_members($status,$status1) {

        $this->db->select('member.*,contract.*,payments.*,nominees.*,member.Status as Member_status,contract.Status as Cont_status,address.*,type.Membership_type,topup.Franchise,bank.Status as Bank_status,payments.Payment_status,bank.*,bank.Bank_ID as Bank_Bank_ID,gc_bank.Bank_name');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_payments as payments', 'payments.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_nominees as nominees', 'nominees.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_id', 'left');
        $this->db->join('gc_member_banks as bank', 'bank.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_bank as gc_bank', 'gc_bank.ID = bank.Bank_ID', 'left');
        $this->db->join('gc_member_documents as documents', 'documents.Membership_ID = member.Membership_ID', 'left');

        // $this->db->join('gc_member_documents as document', 'document.Membership_ID = member.Membership_ID', 'left');
        $this->db->group_by("member.Membership_ID");
        if($status!=1){
        $this->db->where("member.Status",$status);}
        if($status1==10 || $status1==11){
            if($status1==10){
                $this->db->where("bank.Status",5);
            }elseif($status1==11){
                $this->db->where("documents.Status",5);
            }
        }
        $this->db->group_by("payments.Membership_ID");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


public function update_document_status($data,$Membership_ID) {
    $id=$data['Document_ID'];
    unset($data['Document_ID']);
        $this->db->where('Document_ID',$id);
        $this->db->update('gc_member_documents',$data);

        $data1['Status']=4;
        $this->db->where('Membership_ID',$Membership_ID);
        if($this->db->update('gc_membership',$data1)){
            return 1;
            }else{
                return 0;
            }
    }


}



