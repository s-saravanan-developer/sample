		Adding

				$modify['Module_name']="City";
				$modify['Data']=$cityarea_data['area_name'];
				$modify['Action']="1";
				$modify['Created_by']=$this->session->userdata('UserId');
				$this->db->insert('mpro_modification_history', $modify);


		Update

				$modify['Module_name']="State";
				$modify['Data']=$cityarea_data_edit['area_name'];
				$modify['Action']="2";
				$modify['Created_by']=$this->session->userdata('UserId');
				$this->db->insert('mpro_modification_history', $modify);
				

		Delete

				$this->db->where('id', $id);
				$query = $this->db->get('mpro_countries');
				$get['data']=$query->result_array();
				$modify['Module_name']="Country";
				$modify['Data']=$get['data'][0]['country_name'];
				$modify['Action']="3";
				$modify['Created_by']=$this->session->userdata('UserId');
				$this->db->insert('mpro_modification_history', $modify);
				