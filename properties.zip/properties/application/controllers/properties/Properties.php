<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Properties extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('properties/Properties_model');
    }

	public function index()
	{
    	$template['page']='properties/properties';
      $template['teble_name']='prop_properties';
      $template['properties'] =  $this->Properties_model->getall_properties();
      // $template['weeks']  =  $this->Properties_model->get_weeks();
      $this->load->view('template',$template);
	}

  public function add(){
    $template['page']='properties/add_properties';
    $template['companies']=$this->Properties_model->getall_companies_active();
    $this->load->view('template',$template);
  }

  public function edit(){
    $template['page']='properties/edit_properties';
    $id = decrypt($this->input->get('id'));
    $template['companies']=$this->Properties_model->getall_companies_active();
    $template['properties']=$this->Properties_model->get_properties_by_id($id);
    // var_dump($template['properties']);die();
    $this->load->view('template',$template);
  }

    public function adding()
    {
        
        $prop_data = $this->input->post('properties');

        $increment1=(substr($this->db->select('properties_code')->order_by('properties_id','desc')->limit(1)->get('prop_properties')->row('properties_code'),11))+1;
        $prop_data['properties_code']='PROP/1/PRO-'.sprintf("%'.06d", $increment1);
        $prop_data['created_by']=$this->session->userdata('id');
        // $prop_data['company_id']=$this->session->userdata('company_id');
        $this->Properties_model->inserting_properties($prop_data);
        $this->session->set_flashdata('country_success', 'Added');
        redirect('properties/Properties');
    }


    public function editing()
    {
        $id=$this->input->post('properties_id');
        $prop_data = $this->input->post('properties');
        $this->Properties_model->updating_properties($prop_data,$id);

        $this->session->set_flashdata('country_success', 'Updated');
        redirect('properties/Properties');
    }

    public function sub_properties(){
      $template['page']='properties/sub_properties';
      $template['teble_name']='prop_sub_properties';
      // $template['properties'] =  $this->Properties_model->getall_properties();
      $template['properties'] =  $this->Properties_model->getall_sub_properties();
      // $template['weeks']  =  $this->Properties_model->get_weeks();
      $this->load->view('template',$template);
    }


  public function sub_add(){
    $template['page']='properties/add_sub_properties';
    $template['companies']=$this->Properties_model->getall_companies_active();
    $template['property_type']=$this->Properties_model->getall_property_types_active();
    $this->load->view('template',$template);
  }

  public function sub_edit(){
    $id = decrypt($this->input->get('id'));
    // die($id);
    $template['page']='properties/edit_sub_properties';
    $template['companies']=$this->Properties_model->getall_companies_active();
    $template['property_type']=$this->Properties_model->getall_property_types_active();
    $template['properties']=$this->Properties_model->get_sub_properties_by_id($id);
    $this->load->view('template',$template);
  }

    public function sub_adding()
    {
        
        $prop_data = $this->input->post('properties');
        $prop_data['created_by']=$this->session->userdata('id');
        // $prop_data['company_id']=$this->session->userdata('company_id');
        $sub_property_id=$this->Properties_model->inserting_sub_properties($prop_data);
        $count = $this->input->post('details_count');
        $count_data=explode(',',$count);
        foreach ($count_data as $key => $val) {
          $properties_details['prop_details_'.$val] = $this->input->post('prop_details_'.$val);
          $properties_details['prop_details_'.$val]['sub_property_id']=$sub_property_id;
          $properties_details['prop_details_'.$val]['properties']=$prop_data['properties'];
          $properties_details['prop_details_'.$val]['phase']=$prop_data['phase'];
          $Inserted_id1   =   $this->Properties_model->inserting_sub_properties_details($properties_details['prop_details_'.$val]);
        }

        $this->session->set_flashdata('sub_properties_success', 'Added');
        redirect('properties/Properties/sub_properties');
    }


    public function sub_editing()
    {
        $id        = $this->input->post('sub_property_id');
        $prop_data = $this->input->post('properties');
        // var_dump($prop_data);die();
        $this->Properties_model->updating_sub_properties($prop_data,$id);

         $count = $this->input->post('details_count');
         $count_data=explode(',',$count);
         // var_dump($count_data);
        foreach ($count_data as $key => $val) {
          $properties_details['prop_details_'.$val] = $this->input->post('prop_details_'.$val);
          $properties_details['prop_details_'.$val]['sub_property_id']=$id;
          $properties_details['prop_details_'.$val]['company_id']=$prop_data['company_id'];
          $properties_details['prop_details_'.$val]['properties']=$prop_data['properties'];
          $properties_details['prop_details_'.$val]['phase']=$prop_data['phase'];
          $Inserted_id1   =   $this->Properties_model->updating_sub_properties_details($properties_details['prop_details_'.$val]);
        }
        // echo '<pre>';
        // print_r($properties_details);die();
        $this->session->set_flashdata('country_success', 'Updated');
        redirect('properties/Properties/sub_properties');
    }

    public function get_company_based_properties(){
      $company_id=$this->input->post('company');
      $prop=$this->Properties_model->get_company_based_properties($company_id);

        if(!empty($prop)){
        echo '<option value="">Select Property</option>';             
        foreach ($prop as $value) {

             echo '<option value="'.$value['properties_id'].'">'.$value['properties_name'].'</option>';
        }}else{
            echo 0;            
        } 

    }

    public function delete()
    {
        $id=decrypt($this->input->post('delete_id'));

        $data = array('Status' => 3);
        
        $this->db->where('properties_id',$id);
        $this->db->update('prop_properties',$data);

        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('properties/Properties');
    }

        public function check1() {
        $data['page'] = 'import';
        $data['title'] = 'Import XLSX | TechArise';
        $this->load->view('sampleselect', $data);
    }

       public function check() {
        $data['page'] = 'import';
        $data['title'] = 'Import XLSX | TechArise';
        $this->load->view('import/index', $data);
    }



    
    public function checkbox_action(){
                 $id = ( explode( ',', $this->input->get_post('id') ));             
                 $status = $this->input->get_post('status');             
                 foreach ($id as  $value) {
                                  // $this->Users_model->delete_checkbox($value);
                                  $data['updated_date'] = date('Y-m-d H:i:s');
                                  $data['status']         = $status;    
                              // var_dump($data);die();
                                  $this->db->where('prop_type_id', $value);

                        if ($this->db->update('prop_properties_types', $data)) {
                            $this->session->set_flashdata('user_success', 'Deleted');
                            return TRUE;
                  }
                 }
        }
    
        // public function active_all_checkbox(){
        //          $id = ( explode( ',', $this->input->get_post('id') ));             
        //          foreach ($id as  $value) {
        //              $this->Users_model->active_all_checkbox($value);
        //          }
        // }
    
        // public function deactivate_all_checkbox(){
        //          $id = ( explode( ',', $this->input->get_post('id') ));             
        //          foreach ($id as  $value) {
        //              $this->Users_model->deactivate_all_checkbox($value);
        //          }
        // }
    


    
        // public function delete_checkbox1(){
        //          $id = ( explode( ',', $this->input->get_post('id') ));        

        //          foreach ($id as  $value) {
        //              $this->Users_model->delete_checkbox1($value);
        //          }
        // }
    
        // public function active_all_checkbox1(){
        //          $id = ( explode( ',', $this->input->get_post('id') ));             
        //          foreach ($id as  $value) {
        //              $this->Users_model->active_all_checkbox1($value);
        //          }
        // }
    
        //  public function active_all_checkbox11(){
        //          $id = ( explode( ',', $this->input->get_post('id') ));  
                            
        //          foreach ($id as  $value) {
        //              $this->Users_model->active_all_checkbox11($value);
        //          }
        // }
    


   
   
   function active_all_checkbox($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 1;    
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_users', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
   function deactivate_all_checkbox($id){
   
         $data['updated_date'] = date('Y-m-d H:i:s');
         $data['status']         = 2;
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_users', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
   
   
   function delete_checkbox1($id){
   // $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status'] = 3;    
   
           $this->db->where('user_id', $id);
           $this->db->where('user_mode', 2);
           if ($this->db->update('prop_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Deleted');
               return TRUE;
          }
       
           return FALSE;                
        }
   
   
   function active_all_checkbox1($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 1;    
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
    function active_all_checkbox11($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 2;    
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }



}
