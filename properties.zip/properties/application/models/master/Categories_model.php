<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories_model extends CI_Model {

		
	private $categories 			= 'prop_categories';

	public function get_all_categories()
	{
		$this->db->select($this->categories . '.*');
        $this->db->where('company_id', $this->session->userdata('company_id'));
		$this->db->where('status!=',3);
        $query = $this->db->get($this->categories);
        if ($query->num_rows() > 0) {
        	$category_base = $query->result_array(); 
            foreach ($category_base as $key => $value) {
                
                if(isset($delete_status)){ 
                    $category_base[$key]['delete_status'] = 1; 
                }
                else{ 
                    $category_base[$key]['delete_status'] = 0;
                }    
            }
            return $category_base;
        }
        return NULL;
	}

	public function get_all_categories_multi_export($id)
	{
		$this->db->select($this->categories . '.*');
		$id = explode(",", $id); 
        $this->db->where('company_id', $this->session->userdata('company_id'));

        $this->db->where_in('id', $id);
        $query = $this->db->get($this->categories);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}

	public function get_all_categories1()
	{
		$this->db->select($this->categories . '.*');
        $this->db->where('company_id', $this->session->userdata('company_id'));
		$this->db->where('status',1);
        $query = $this->db->get($this->categories);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
	}
	/**
	 * Countrty data Add 
	 */
	public function adding_category($category)
	{
				$modify['module_name']="Category";
				$modify['data']=$category['category_name'];
				$modify['action']="1";
				$modify['created_by']=$this->session->userdata('id');
				$this->db->insert('prop_modification_history', $modify);
				$category['created_by']=$this->session->userdata('id');
				$category['company_id']=$this->session->userdata('company_id');
		if ($this->db->insert('prop_categories', $category)) {
            $this->session->set_flashdata('categor_success', 'Added');
			return TRUE;
		}
		return FALSE;		
	}

	/**
	 * Countrty data Edit 
	 */
	public function editing_category($category_data,$id)
	{
				$modify['module_name']="Category";
				$modify['data']=$category_data['category_name'];
				$modify['action']="2";
				$modify['created_by']=$this->session->userdata('id');
				$this->db->insert('prop_modification_history', $modify);
				$category_data['updated_by']=$this->session->userdata('id');
		$category_data['updated_date'] = date('Y-m-d H:i:s');
		$this->db->where('id', $id);
		if ($this->db->update('prop_categories', $category_data)) {
            $this->session->set_flashdata('categor_success', 'Updated');
			return TRUE;
		}
		return FALSE;		
	}




}

/* End of file Location_model.php */
/* Location: ./application/models/master/Location_model.php */