                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                if(!window.__td){window.__MT=100;window.__ti=0;window.__td=[];window.__td.length=window.__MT;window.__noTrace=false;}(function $vpfn_A6P00sV1eysf7TuX1EkjRg1$1($,vp,undefined)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}

vp.sceneAnimation=function $vpfn_7f9hJve1AHoYeMSZWuXvEw4$24(elementId,jsonCfg)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var me=this;

this.$element=$(elementId);
this.frameIndex=0;
this.position=0;
this.direction=1;
this.animating=false;
this.height=this.$element.height();

$.extend(this,jsonCfg);

this.frameCount=this.timings.length;

if(this.enableMouseControl===true)
{
this.$element.on('mousemove',$.proxy(this.mouseAnimate,this));
this.$element.on('mouseleave',$.proxy(this.mouseLeave,this));
}

this.$element.find('.play-overlay a').on('click',$.proxy(this.playClicked,this));

this.loadImage();
};

vp.sceneAnimation.prototype.loadImage=function $vpfn_3ec6L3_bjlbjnZdIVM70_A30$44()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
var me=this;
var image=new Image;

this.$image=$(image);
this.$image.addClass('scene-animation-sprite');

image.onload=function $vpfn_zv58irGlR8_ldA8HsZ25Fg38$23()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
me.imageLoadCompleted();
};
image.src=this.url;
};

vp.sceneAnimation.prototype.imageLoadCompleted=function $vpfn_ZGeebYam7I2pmzpPVbaZTA45$53()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
this.$element.append(this.$image);

this.adjustSize();

if(this.autoplay===true)
{
this.$element.find('.loading-overlay').fadeOut(250);
this.animating=true;
this.timer=setTimeout($.proxy(this.animateStart,this),0);
}
else
{
this.$element.find('.loading-overlay').hide();
this.$element.find('.play-overlay').show();
}
};

vp.sceneAnimation.prototype.animateStart=function $vpfn_IORzkLSA9ZuL74k9ZNRN8Q64$47()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
vp.spot.trackWithQueryString('SceneAnimation_Play',this.trackingData);
this.animate();
};

vp.sceneAnimation.prototype.animate=function $vpfn_oip83tyFBpsBOT5a0HjpHw70$42()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
this.$image.css('top','-'+this.position+'px');

if(this.frameIndex===this.frameCount)
{
if(this.oscillate===true)
{
this.frameIndex=this.frameIndex-2;
this.direction=-1;
}
else
{
this.frameIndex=0;

if(this.loop===false)
{
this.animating=false;
this.showPlayOverlay();
}
}
}
if(this.frameIndex===-1)
{
this.frameIndex=1;
this.direction=1;

if(this.loop===false)
{
this.animating=false;
this.showPlayOverlay();
}
}

this.position=this.frameIndex*this.height;

this.frameIndex+=this.direction;

if(this.animating===true)
{
this.timer=setTimeout($.proxy(this.animate,this),this.timings[this.frameIndex]);
}

};

vp.sceneAnimation.prototype.playClicked=function $vpfn_XnVi7v75vSGuGvCQKeYkGQ115$46(event)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
event.preventDefault();

this.$element.find('.play-overlay').hide();
this.animating=true;
this.timer=setTimeout($.proxy(this.animateStart,this),0);
};

vp.sceneAnimation.prototype.showPlayOverlay=function $vpfn_S3CxQ8jtsvYLpO$Z76EIiA124$50()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
this.$element.find('.play-overlay').show();
};

vp.sceneAnimation.prototype.mouseAnimate=function $vpfn_RJPYBr3qL4bfHZpRe83SIQ129$47(event)
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
if(this.timer)
{
clearTimeout(this.timer);
this.timer=null;
}

if(this.animating===false)
{
return;
}

this.paused=true;

var xPos=event.clientX-this.$element.offset().left;
this.frameIndex=Math.round((xPos/this.$element.width())*(this.frameCount-1));

this.position=this.frameIndex*this.height;
this.$image.css('top','-'+this.position+'px');
};

vp.sceneAnimation.prototype.mouseLeave=function $vpfn_jiwKSdm7TNzJjIG1M4treQ151$45()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
if(this.paused===false){return;}

if(this.animating===true)
{
this.paused=false;
this.timer=setTimeout($.proxy(this.animate,this),0);
}
};

vp.sceneAnimation.prototype.adjustSize=function $vpfn_tezRYLzLT2MRS8DQTgfUtQ162$45()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
this.$image.width(this.$element.width());
this.$image.height(this.$element.height()*this.frameCount);
};

vp.sceneAnimation.initAll=function $vpfn_3O0lnkh2$QCZhGTsGVCNHQ168$32()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
$('div[data-scene-animation-config]').each(function $vpfn_A6P00sV1eysf7TuX1EkjRg170$51()
{if(!window.__noTrace){__td[__ti]=arguments;__ti=__ti>=__MT?0:__ti+1;}
new vp.sceneAnimation(this,$(this).data('scene-animation-config'));
});
};

})(window.jQuery,window.vp);


$(vp.sceneAnimation.initAll);

