<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Membership extends CI_Controller {

	public function __construct() {
        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Master_model');
    }

	public function index()
	{
    	$template['page']='membership/viewmembership';
        $this->load->view('template',$template);
	}

    public function Membershiptype()
    {
        $template['page']='master/membershiptype/viewmembershiptype';
        $template['payout'] =  $this->Master_model->getall_membershiptype();
        $this->load->view('template',$template);
    }

    public function Membership_requesttype()
    {
        $template['page']='master/membershiptype/viewmembership_reqtype';
        $template['payout'] =  $this->Master_model->getall_membership_reqtype();
        $this->load->view('template',$template);
    }

    public function withdraw()
    {
        $template['page']='master/membershiptype/viewwithdraw';
        $template['payout'] =  $this->Master_model->getall_withdraw();
        $this->load->view('template',$template);
    }

    public function add_membershiptype()
    {
        extract($_POST);

        $data = array('Membership_type' => $Membership_type,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->insert('gc_membershiptype',$data);
        $this->session->set_flashdata('success', 'Added');
        redirect('master/Membership/Membershiptype');
    }

    public function add_withdraw()
    {
        extract($_POST);

        $data = array('Withdraw_type' => $Withdraw_type,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->insert('gc_withdraw',$data);
        $this->session->set_flashdata('payout_success', 'Added');
        redirect('master/Membership/withdraw');
    }

    public function add_membership_requesttype()
    {
        extract($_POST);

        $data = array('Membership_reqtype' => $Membership_reqtype,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->insert('gc_membership_reqtype',$data);
        $this->session->set_flashdata('payout_success', 'Added');
        redirect('master/Membership/Membership_requesttype');
    }

    public function edit_membership_requesttype()
    {
        extract($_POST);

        $data = array('Membership_reqtype' => $Membership_reqtype,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->where('ID',$ID);
        $this->db->update('gc_membership_reqtype',$data);
        $this->session->set_flashdata('payout_success', 'Updated');
        redirect('master/Membership/Membership_requesttype');
    }

    public function edit_membershiptype()
    {
        extract($_POST);

        $data = array('Membership_type' => $Membership_type,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->where('ID',$ID);
        $this->db->update('gc_membershiptype',$data);
        $this->session->set_flashdata('success', 'Updated');
        redirect('master/Membership/Membershiptype');
    }

    public function edit_withdraw()
    {
        extract($_POST);

        $data = array('Withdraw_type' => $Withdraw_type,
                      'Alias_name' => $Alias_name,
                      'Description' => $Description,  
                      'Status' => $Status
                     );
        $this->db->where('ID',$ID);
        $this->db->update('gc_withdraw',$data);
        $this->session->set_flashdata('payout_success', 'Updated');
        redirect('master/Membership/withdraw');
    }

    public function delete_membershiptype($id)
    
    {

        $data = array('Status' => 3);

        $this->db->where('ID',$id);
        $this->db->update('gc_membershiptype',$data);
        
        $this->db->where('Member_type',$id);
        $this->db->delete('gc_tree_color_setting');


        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Membership/Membershiptype');
    }

    public function delete_withdraw($id)
    {

        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_withdraw',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Membership/withdraw');
    }

    public function delete_membership_requesttype($id)
    {

        $data = array('Status' => 3);
        
        $this->db->where('ID',$id);
        $this->db->update('gc_membership_reqtype',$data);
        $this->session->set_flashdata('duplicate', 'Deleted Succesfully');
        redirect('master/Membership/Membership_requesttype');
    }
}
