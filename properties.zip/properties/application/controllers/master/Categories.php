<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories extends CI_Controller {

	public function __construct() {
        parent::__construct();
        if ($this->session->userdata('is_logged_in') == '') {            
            redirect('login');
            session_destroy();
        }
        $this->load->model('master/Categories_model');
        $this->load->model('master/Location_model');
        $this->load->model('master/Upload_model');
        // $this->load->model('Common_model');
    }

	public function index()
	{		
		$template['table_name'] 	=	"prop_categories";
		$template['category'] 	=	$this->Categories_model->get_all_categories();
		$template['page']		=	'master/categories/categories';
        $this->load->view('template',$template);
	}

	/**
	 * Common Funtion To Delete Or Status Update To 3 
	 * @return [type] [description]
	 */



	public function category_add()
	{
		$this->db->trans_start();
		$category = $this->input->post('category');
		$this->Categories_model->adding_category($category);
		$this->db->trans_complete();
		if ($this->db->trans_status() === FALSE)
		{
		    $this->session->set_flashdata('categor_error', 'error');
		}
		redirect('master/Categories');
	}

	public function category_edit()
	{
		$this->db->trans_start();
		$id = $this->input->post('category_id');
		$category_edit = $this->input->post('category_edit');
		$this->Categories_model->editing_category($category_edit,$id);
		$this->db->trans_complete();
		if ($this->db->trans_status() === FALSE)
		{
		    $this->session->set_flashdata('categor_error', 'error');
		}
		redirect('master/Categories');
	}

	public function delete()
	{
		// $url 			= $this->input->post('url');	
		$id 			= $this->input->post('delete_id');
		// $field_name 	= $this->input->post('check_data');
		// $table_name = $this->input->post('table_name'); $table_name = strtolower($table_name);
		// $this->Categories_model->delete($table_name,$id,$field_name);
		// 
		$data = array('Status' => 3);
        
        $this->db->where('id',$id);
        $this->db->update('prop_categories',$data);
		$this->session->set_flashdata('product_success', 'Deleted');
		redirect('master/Categories');
	}


}

?>