<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Contract_model extends CI_Model { 

    function getall_bank() {

        $this->db->select('*');
        $this->db->where('Status',1);
        $this->db->order_by("ID", "DESC");
        $query = $this->db->get('gc_bank');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }



    function change_payment_status($Membership_ID,$Member_payment_ID) {
        $this->db->select('Contract_ID');
        $this->db->from('gc_member_payments');
        $this->db->where('Member_payment_ID',$Member_payment_ID);
        $query=$this->db->get();
        $payment=$query->result_array();
        $contract_id=$payment[0]['Contract_ID'];


    $data['Payment_status']=6;
        $this->db->where('Member_payment_ID',$Member_payment_ID);
        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->update('gc_member_payments',$data);

        $pays_val=$this->get_pays_records1($Membership_ID,$contract_id);

            $status_flag=[];
              $a=0;  if(!empty($pays_val)){foreach($pays_val as $py_t){
            $py_t['Payment_status'];
                                                 
            if($py_t['Payment_status'] == 5){
                  array_push($status_flag,1);
                  }else{
                  array_push($status_flag,0);
                  }
                  $a++;
          } } 
                if(array_sum($status_flag)==0){
                //echo 'insetrt';
                //$set_pay_date=$this->get_previous_date(date('Y-m-d'));
                $data_member['Payment_status_date']=date('Y-m-d');
                $data_member['Payment_status']=6;
                //var_dump($data_member);
                $this->db->where('Contract_ID',$contract_id);
                $this->db->update('gc_member_franchisee_contract',$data_member);
            }else{
                //echo 'aagadhu';die();
            }
        $data1['Status']=4;
        $this->db->where('Membership_ID',$Membership_ID);
        if($this->db->update('gc_membership',$data1)){
            return 1;}else{
                return 0;
            }
        }

    function change_payment_status1($Membership_ID,$Member_payment_ID) {
        $this->db->select('Contract_ID');
        $this->db->from('gc_member_payments');
        $this->db->where('Member_payment_ID',$Member_payment_ID);
        $query=$this->db->get();
        $payment=$query->result_array();
        $contract_id=$payment[0]['Contract_ID'];

         


    $data['Payment_status']=6;
        $this->db->where('Member_payment_ID',$Member_payment_ID);
        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->update('gc_member_payments',$data);

        $pays_val=$this->get_pays_records1($Membership_ID,$contract_id);

            $status_flag=[];
              $a=0;  if(!empty($pays_val)){foreach($pays_val as $py_t){
            $py_t['Payment_status'];
                                                 
            if($py_t['Payment_status'] == 5){
                  array_push($status_flag,1);
                  }else{
                  array_push($status_flag,0);
                  }
                  $a++;
          } } 
                if(array_sum($status_flag)==0){
                //echo 'insetrt';
                //$set_pay_date=$this->get_previous_date(date('Y-m-d'));
                    $this->db->select('topup.Validity,Value,Return,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
        $this->db->from('gc_member_topup as topup');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');

        $this->db->where('contract.Contract_ID',$contract_id);
        $this->db->where('contract.Membership_ID',$Membership_ID);
        $query = $this->db->get();
        $contract=$query->result_array();
        if(!empty($contract)){
            $month=$contract[0]['Validity'];
            $Amount=$contract[0]['Value'];
            $Return=$contract[0]['Return'];
            if($contract[0]['Payout_status']==2){
                $payout_id=$contract[0]['New_payout_ID'];
            }else{
                $payout_id=$contract[0]['Old_payout_ID'];
            }
        }else{
            $month=0;
            $Amount=0;
            $Return=0;
        }
// Transaction Insert Start        
        $transaction=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $Membership_ID, 
                            'Contract_ID' => $contract_id, 
                            'Transaction_type' => 1,
                            'Transaction_date' => date('Y-m-d'), 
                            'Remarks' => '', 
                            'Created_by' => $this->session->userdata('UserId') 
                        );
        $this->db->insert('gc_transaction',$transaction);
        $transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
        $Comission_amount=$Amount*$Return/100;
        $transaction_detail=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $Membership_ID, 
                            'Contract_ID' => $contract_id,
                            'Member_level_detail_ID' => NULL, 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 1, 
                            'Payout_ID' => $payout_id,
                            'Amount' => $Comission_amount, 
                            'Commision' => $Return,
                            'Remarks' => '' 
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail);
// Transaction Detail (Top-up) Insert End   

// Transaction History (Debit) Insert start 
$history_data=array(
                 'Company_id'               => $this->session->userdata('CompanyId'),
                 'Branch_id'                => $this->session->userdata('CompanyId'), 
                 'Membership_ID' => $Membership_ID,
                 'Contract_ID'   => $contract_id,
                 'Payout_ID' => $payout_id,
                 'Date'  => date('Y-m-d'),
                 'History_for'   => ' Topup Amount of  '.$Amount,
                 'Credit_amount' => 0,
                 'Debit_amount' => $Amount,
                  );
            $this->db->insert('gc_transaction_history',$history_data);  

// Transaction History (Debit) Insert End  

// Transaction Details (Direct&Push-up) Insert Start
        $this->db->select('Reference_ID');
        $this->db->from('gc_membership');
        $this->db->where('Membership_ID',$Membership_ID);
        $query = $this->db->get();
        $membership=$query->result_array();


$ref_ID="";$level_insert_id="";
        for($i=1;$i<=9;$i++){ 
            if($i==1){
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$membership[0]['Reference_ID']);
            //$this->db->where('contract.Contract_status',6);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            //var_dump($binary);
            $crnt_lvl=$binary[0]['Current_level'];
            //if($crnt_lvl<=$i){
            $level['Level_ID']=$i;
            //}
            //else{
               //$level['Level_ID']=$crnt_lvl;
            //}
            $ref_ID=$binary[0]['Reference_ID'];
            //echo $binary[0]['Contract_ID'];
            $this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
            $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
            //$this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();


                        $Comission_amount1=$Amount*$level_details[0]['Return']/100;
            $this->db->select('Payout_type');
            $this->db->from('gc_level');
            $this->db->where('ID',$level['Level_ID']);
            $query_lvl= $this->db->get();
            if($query_lvl->num_rows() > 0) {
            $level_payout=$query_lvl->result_array();
            $payout_id1=$level_payout[0]['Payout_type'];
            }else{
                if($level_details[0]['Payout_status']==2){
                $payout_id1=$level_details[0]['New_payout_ID'];
                }else{
                $payout_id1=$level_details[0]['Old_payout_ID'];
                        }
                    }
// Transaction Details Insert start 
$transaction_detail1=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $binary[0]['Membership_ID'], 
                            'Contract_ID' => $binary[0]['Contract_ID'],
                            'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 2,
                            'Payout_ID' => $payout_id1, 
                            'Amount' => $Comission_amount1, 
                            'Commision' => $level_details[0]['Return'],
                            'Remarks' => '' 
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start


        }
    }
    else{
            $this->db->select('*');
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$ref_ID);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            $crnt_lvl=$binary[0]['Current_level'];
            $level['Level_ID']=$i;
           //  if($crnt_lvl<=$i){
            
           //  }
           //  else{
           //     $level['Level_ID']=$crnt_lvl;
           // }
            $ref_ID=$binary[0]['Reference_ID'];

            $this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
            $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
            //$this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();
            //var_dump($level_details);
                        $Comission_amount1=$level_details[0]['Value']*$level_details[0]['Return']/100;
                        $this->db->select('Payout_type');
            $this->db->from('gc_level');
            $this->db->where('ID',$level['Level_ID']);
            $query_lvl= $this->db->get();
            if($query_lvl->num_rows() > 0) {
            $level_payout=$query_lvl->result_array();
            $payout_id1=$level_payout[0]['Payout_type'];
            }else{
                        if($level_details[0]['Payout_status']==2){
                        $payout_id1=$level_details[0]['New_payout_ID'];
                        }else{
                        $payout_id1=$level_details[0]['Old_payout_ID'];
                        }
                    }
// Transaction Details Insert start 
$transaction_detail1=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $binary[0]['Membership_ID'], 
                            'Contract_ID' => $binary[0]['Contract_ID'],
                            'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 3,
                            'Payout_ID' => $payout_id1, 
                            'Amount' => $Comission_amount1, 
                            'Commision' => $level_details[0]['Return'],
                            'Remarks' => ''  
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
// Transaction Details (Direct&Push-up) Insert End        

                }

            }
        }

        $data1['Start_date']=date('Y-m-d');
        $data1['End_date']=date('Y-m-d', strtotime('+'.$month.'months'));
        $data1['Contract_status']=6;
        $data1['Contract_status_date']=date('Y-m-d');
        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->where('Contract_ID',$contract_id);
        $this->db->update('gc_member_franchisee_contract',$data1);

                $data_member['Payment_status_date']=date('Y-m-d');
                $data_member['Payment_status']=6;
                //var_dump($data_member);
                $this->db->where('Contract_ID',$contract_id);
                $this->db->update('gc_member_franchisee_contract',$data_member);
            }else{
                //echo 'aagadhu';die();
            }
        $data6['Status']=4;
        $this->db->where('Membership_ID',$Membership_ID);
        if($this->db->update('gc_membership',$data6)){
            return 1;}else{
                return 0;
            }
        }        

        public function activ(){
            $this->db->select('topup.Validity,Value,Return,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
        $this->db->from('gc_member_topup as topup');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Topup_id = topup.ID', 'left');

        $this->db->where('contract.Contract_ID',$Contract_ID);
        $this->db->where('contract.Membership_ID',$Membership_ID);
        $query = $this->db->get();
        $contract=$query->result_array();
        if(!empty($contract)){
            $month=$contract[0]['Validity'];
            $Amount=$contract[0]['Value'];
            $Return=$contract[0]['Return'];
            if($contract[0]['Payout_status']==2){
                $payout_id=$contract[0]['New_payout_ID'];
            }else{
                $payout_id=$contract[0]['Old_payout_ID'];
            }
        }else{
            $month=0;
            $Amount=0;
            $Return=0;
        }
// Transaction Insert Start        
        $transaction=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $Membership_ID, 
                            'Contract_ID' => $Contract_ID, 
                            'Transaction_type' => 1,
                            'Transaction_date' => date('Y-m-d'), 
                            'Remarks' => '', 
                            'Created_by' => $this->session->userdata('UserId') 
                        );
        $this->db->insert('gc_transaction',$transaction);
        $transaction_id=$this->db->insert_id();
// Transaction Insert End
// Transaction Detail (Top-up) Insert Start        
        $Comission_amount=$Amount*$Return/100;
        $transaction_detail=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $Membership_ID, 
                            'Contract_ID' => $Contract_ID,
                            'Member_level_detail_ID' => NULL, 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 1, 
                            'Payout_ID' => $payout_id,
                            'Amount' => $Comission_amount, 
                            'Commision' => $Return,
                            'Remarks' => '' 
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail);
// Transaction Detail (Top-up) Insert End   

// Transaction History (Debit) Insert start 
$history_data=array(
                 'Company_id'               => $this->session->userdata('CompanyId'),
                 'Branch_id'                => $this->session->userdata('CompanyId'), 
                 'Membership_ID' => $Membership_ID,
                 'Contract_ID'   => $Contract_ID,
                 'Payout_ID' => $payout_id,
                 'Date'  => date('Y-m-d'),
                 'History_for'   => ' Topup Amount of  '.$Amount,
                 'Credit_amount' => 0,
                 'Debit_amount' => $Amount,
                  );
            $this->db->insert('gc_transaction_history',$history_data);  

// Transaction History (Debit) Insert End  

// Transaction Details (Direct&Push-up) Insert Start
        $this->db->select('Reference_ID');
        $this->db->from('gc_membership');
        $this->db->where('Membership_ID',$Membership_ID);
        $query = $this->db->get();
        $membership=$query->result_array();


$ref_ID="";$level_insert_id="";
        for($i=1;$i<=9;$i++){ 
            if($i==1){
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$membership[0]['Reference_ID']);
            //$this->db->where('contract.Contract_status',6);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            var_dump($binary);die();
            $crnt_lvl=$binary[0]['Current_level'];
            //if($crnt_lvl<=$i){
            $level['Level_ID']=$i;
            //}
            //else{
               //$level['Level_ID']=$crnt_lvl;
            //}
            $ref_ID=$binary[0]['Reference_ID'];

            $this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
            $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$membership[0]['Reference_ID']);
            //$this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();


                        $Comission_amount1=$Amount*$level_details[0]['Return']/100;
            $this->db->select('Payout_type');
            $this->db->from('gc_level');
            $this->db->where('ID',$level['Level_ID']);
            $query_lvl= $this->db->get();
            if($query_lvl->num_rows() > 0) {
            $level_payout=$query_lvl->result_array();
            $payout_id1=$level_payout[0]['Payout_type'];
            }else{
                if($level_details[0]['Payout_status']==2){
                $payout_id1=$level_details[0]['New_payout_ID'];
                }else{
                $payout_id1=$level_details[0]['Old_payout_ID'];
                        }
                    }
// Transaction Details Insert start 
$transaction_detail1=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $binary[0]['Membership_ID'], 
                            'Contract_ID' => $binary[0]['Contract_ID'],
                            'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 2,
                            'Payout_ID' => $payout_id1, 
                            'Amount' => $Comission_amount1, 
                            'Commision' => $level_details[0]['Return'],
                            'Remarks' => '' 
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start


        }
    }
    else{
            $this->db->select('*');
            $this->db->select('member.Membership_ID,member.Reference_ID,member.Current_level,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_membership as member');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
            $this->db->where('member.Membership_ID',$ref_ID);
            $query= $this->db->get();
            if($query->num_rows() > 0) {
            $binary=$query->result_array();
            var_dump($binary);die();
            $crnt_lvl=$binary[0]['Current_level'];
            $level['Level_ID']=$i;
           //  if($crnt_lvl<=$i){
            
           //  }
           //  else{
           //     $level['Level_ID']=$crnt_lvl;
           // }
            $ref_ID=$binary[0]['Reference_ID'];

            $this->db->select('level.Member_level_detail_ID,topup.Validity,topup.Value,lvl.Return,contract.Contract_ID,contract.Old_payout_ID,contract.New_payout_ID,contract.Payout_status');
            $this->db->from('gc_member_level_details as level');
            $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID ='.$binary[0]['Contract_ID'], 'left');
            $this->db->join('gc_member_topup as topup', 'topup.ID =contract.Topup_id', 'left');
            $this->db->join('gc_level as lvl', 'lvl.ID ='.$level['Level_ID'], 'left');
            $this->db->where('level.Child_ID',$Membership_ID);
            $this->db->where('level.Membership_ID',$binary[0]['Membership_ID']);
            //$this->db->where('level.Level_ID',$level['Level_ID']);
            $query= $this->db->get();
            $level_details=$query->result_array();
                        $Comission_amount1=$level_details[0]['Value']*$level_details[0]['Return']/100;
                        $this->db->select('Payout_type');
            $this->db->from('gc_level');
            $this->db->where('ID',$level['Level_ID']);
            $query_lvl= $this->db->get();
            if($query_lvl->num_rows() > 0) {
            $level_payout=$query_lvl->result_array();
            $payout_id1=$level_payout[0]['Payout_type'];
            }else{
                        if($level_details[0]['Payout_status']==2){
                        $payout_id1=$level_details[0]['New_payout_ID'];
                        }else{
                        $payout_id1=$level_details[0]['Old_payout_ID'];
                        }
                    }
// Transaction Details Insert start 
$transaction_detail1=array(
                            'Company_id' => $this->session->userdata('CompanyId'),
                            'Branch_id' => $this->session->userdata('CompanyId'), 
                            'Membership_ID' => $binary[0]['Membership_ID'], 
                            'Contract_ID' => $binary[0]['Contract_ID'],
                            'Member_level_detail_ID' => $level_details[0]['Member_level_detail_ID'], 
                            'Transaction_ID' => $transaction_id, 
                            'Commision_type' => 3,
                            'Payout_ID' => $payout_id1, 
                            'Amount' => $Comission_amount1, 
                            'Commision' => $level_details[0]['Return'],
                            'Remarks' => ''  
                        );
        $this->db->insert('gc_transaction_details',$transaction_detail1);
// Transaction Details Insert start
// Transaction Details (Direct&Push-up) Insert End        

                }

            }
        }

        $data1['Start_date']=date('Y-m-d');
        $data1['End_date']=date('Y-m-d', strtotime('+'.$month.'months'));
        $data1['Contract_status']=6;
        $data1['Contract_status_date']=date('Y-m-d');
        $this->db->where('Membership_ID',$Membership_ID);
        $this->db->where('Contract_ID',$Contract_ID);
        if($this->db->update('gc_member_franchisee_contract',$data1)){
            return 1;
        }else{
            return 0;
        }
        }

            public function get_previous_date($cur_date){

    $this->db->select('Weeks');
        $this->db->where('Status',1);
        $this->db->where('ID',1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            $days=$query->result_array();
            $week_days=explode(',',$days[0]['Weeks']);
            //var_dump($week_days);
$date=new DateTime();
$year=date('Y');
$date->setDate($year, 01, 01);
$dt = $date->format('Y-m-d');
$day=date('l', strtotime($dt));
$search =date('N', strtotime($day));

$arr = [];
$arr2 = [];

for ($i=0 ;$i < count($week_days); $i++) {

    if($week_days[$i] == $search){
        $arr[$i] = $week_days[$i];
        $search = $week_days[$i] + 1;
    }else{
        $arr2[$i] = $week_days[$i];
    }
}

$action = array_merge($arr,$arr2);
$days = array(
     '1' => 'Monday',
     '2' => 'Tuesday',
     '3' => 'Wednesday',
     '4' => 'Thursday',
     '5' => 'Friday',
     '6' => 'Saturday',
     '7' => 'Sunday'
 );
$final_dt=[];

foreach($action as $da){
if (array_key_exists($da,$days))
  {
  array_push($final_dt,$days[$da]);
  }

}

//var_dump($final_dt);
$final_dates=[];
for($i=1; $i<=52; $i++){
        foreach($final_dt as $newval){
        //date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))).'<br>';
        array_push($final_dates,date("Y-m-d", strtotime('+'.$i.$newval ,strtotime($dt))));
        }
    }
   $cur_date=date("Y-m-d", strtotime($cur_date));
    
    //var_dump($final_dates);
    foreach($final_dates as $key=> $fin){
if($cur_date==$fin){
    $keyval= $key-1;
    return  $final_dates[$keyval];
}else{
    $keyval=$key;
    $final_dates[$keyval];
}
    }
    //echo $serch_date=$final_dates[$keyval];
}

    }

public function get_pays_records($id) {

        $this->db->select('*');
        $this->db->where('Membership_ID',$id);
        $query = $this->db->get('gc_member_payments');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    
    }

public function get_pays_records1($id,$contract_id) {

        $this->db->select('*');
        $this->db->where('Membership_ID',$id);
        $this->db->where('Contract_ID',$contract_id);
        $query = $this->db->get('gc_member_payments');
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    
    }
   
   

       function get_today_contracts($date) {

        $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Photo,member.Mobile,contract.*,type.Membership_type as Membership_name,topup.Franchise,payout.Payout_type,topup.Value,topup.Validity,topup.Return,banks.Status as bank_status,contract.Start_date,contract.End_date');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = contract.Payout_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
        $this->db->join('gc_member_banks as banks', 'banks.Member_bank_ID = member.Membership_ID', 'left');
        // $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        // $this->db->where($where);
        $this->db->where('contract.Date',$date);
        $this->db->where('contract.Invest_type',2);
        // $this->db->where('Membership_ID',$mobile);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function get_contract_details($mobile) {

        $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Photo,member.Mobile,contract.*,type.Membership_type as Membership_name,topup.Franchise,payout.Payout_type,topup.Value,topup.Validity,topup.Return,banks.Status as bank_status,contract.Start_date,contract.End_date');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = contract.Old_payout_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
        $this->db->join('gc_member_banks as banks', 'banks.Member_bank_ID = member.Membership_ID', 'left');
        $where = '(member.Membership_code="'.$mobile.'" or member.Mobile = "'.$mobile.'")';
        $this->db->where($where);
        // $this->db->where('Membership_ID',$mobile);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function get_payments_details($Membership_ID,$Contract_ID) {

         $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Membership_code,payments.*,contract.Contract_ref_no,mode.Payment_mode,bank.Bank_name');
        $this->db->from('gc_member_payments as payments');
        $this->db->join('gc_membership as member', 'member.Membership_ID = payments.Membership_ID', 'left');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Contract_ID = payments.Contract_ID', 'left');
        $this->db->join('gc_payment_mode as mode', 'mode.ID = payments.Payment_type_ID', 'left');
        $this->db->join('gc_bank as bank', 'bank.ID = payments.Bank_ID', 'left');
        $this->db->where('payments.Membership_ID',$Membership_ID);
        $this->db->where('payments.Contract_ID',$Contract_ID);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }


    function get_document_details($mobile) {

        $this->db->select('member.Membership_ID,member.First_name,member.Last_name,member.Gender,member.Membership_code,member.Photo,member.Mobile,contract.*,type.Membership_type as Membership_name,topup.Franchise,payout.Payout_type,topup.Value,topup.Validity,topup.Return,banks.Status as bank_status,contract.Start_date,contract.End_date,aggrement.Delivery_mode,aggrement.Referer_name,aggrement.Agreement_ID,aggrement.Status as agreementstatus,aggrement.Courier_name');
        $this->db->from('gc_membership as member');
        $this->db->join('gc_member_franchisee_contract as contract', 'contract.Membership_ID = member.Membership_ID', 'left');
        $this->db->join('gc_member_topup as topup', 'topup.ID = contract.Topup_ID', 'left');
        $this->db->join('gc_payout_type as payout', 'payout.id = contract.Old_payout_ID', 'left');
        $this->db->join('gc_membershiptype as type', 'type.ID = contract.Membership_type', 'left');
        $this->db->join('gc_member_banks as banks', 'banks.Member_bank_ID = member.Membership_ID', 'left');

        $this->db->join('gc_member_agreement as aggrement', 'aggrement.Membership_ID = member.Membership_ID', 'left');
        
        $this->db->where('member.Membership_ID',$mobile);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

}



