<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Order extends CI_Controller {

	public function __construct() {

        parent::__construct();

        if ($this->session->userdata('is_logged_in') == '') {
            redirect('login');
            session_destroy();

        }
        $this->load->model('master/Users_model');
    }

	public function index()
	{
        $id = $this->session->userdata('UserCode');
        $template['orderstatus']  =   $this->Users_model->get_all_orders($id);
        $template['order']  =   $this->Users_model->getall_orders($id);
		$template['page']='order/view_order';
        $this->load->view('template',$template);
		
	}

    public function view_details()
    {
        $txtdcp = rawurldecode($this->encrypt->decode($_GET['val']));
        $template['order']  =   $this->Users_model->get_all_orders_by($txtdcp);
        $template['orderhistory']  =   $this->Users_model->get_all_ordershistory_by($txtdcp);
        $template['ordertotal']  =   $this->Users_model->get_all_orderstotal_by($txtdcp);
        // $template['orderstatus']  =   $this->Users_model->get_order_status();
        $template['page']='order/view_order_details';
        // var_dump($template['ordertotal']);die();
        $this->load->view('template',$template);

    }


}
