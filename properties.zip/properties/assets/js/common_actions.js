$(document).ready(function () {
$('.grand_all').click(function () {
        

            if ($(".grand_all").prop('checked') == true) {
              
                $('input.allow_access,input.column_all').prop('checked', true);
            } else { 
                $('input.allow_access,input.column_all').prop('checked',false);
                

            }
        });


   
    $(document).ready(function () {
        $('.column_all').click(function () {
            if ($(this).prop('checked') == true) {
                $(this).closest('tr').find('input.allow_access').prop('checked', true);
            } else {
                $(this).closest('tr').find('input.allow_access').prop('checked',false);
            }

            total_checkbox = Number($('input[type=checkbox].allow_access,input[type=checkbox].column_all').length);
            checked_checkbox = Number($('input[type=checkbox].allow_access:checked,input[type=checkbox].column_all:checked').length);
            if (total_checkbox == checked_checkbox) {
                $('input.grand_all').prop('checked', true);
            } else {
                $('input.grand_all').prop('checked',false);
            }
        });
    });




