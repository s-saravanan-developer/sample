<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Users_model extends CI_Model {

    private $user_type_table        = 'prop_user_types';
    private $user_permission_table  = 'prop_user_type_permissions';
    private $user_modules_table     = 'prop_user_modules';
    private $user_sections_table    = 'prop_user_sections';
    private $prop_users_table         = 'prop_users';




    function insert_user_type($data) {

        $modify['module_name']  ="User Type";
        $modify['data']         =$data['user_type_name'];
        $modify['action']       ="1";
        $modify['created_by']   =$this->session->userdata('id');
        $this->db->insert('prop_modification_history', $modify);

        $data['created_by']     =$this->session->userdata('id');
        $data['company_id']     =$this->session->userdata('company_id');

        if ($this->db->insert($this->user_type_table, $data)) {
            $insert_id = $this->db->insert_id();
            $this->session->set_flashdata('users_success', 'Added');
            return $insert_id;
        }
        return FALSE;
    }

    public function getall_bankactive()
    {
        $this->db->select('banks.*,membership.First_name,bank.Bank_name,membership.Membership_code,membership.Membership_ID');
        $this->db->from('prop_member_banks as banks');
        $this->db->join('prop_membership as membership', 'membership.Membership_ID = banks.Membership_ID', 'left');
        $this->db->join('prop_bank as bank', 'bank.ID = banks.Bank_ID', 'left');
        $this->db->where('banks.updated_date =', date('Y-m-d'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function getall_bankactiveby($date)
    {
        $this->db->select('banks.*,membership.First_name,bank.Bank_name,membership.Membership_ID');
        $this->db->from('prop_member_banks as banks');
        $this->db->join('prop_membership as membership', 'membership.Membership_ID = banks.Membership_ID', 'left');
        $this->db->join('prop_bank as bank', 'bank.ID = banks.Bank_ID', 'left');
        $this->db->where('banks.updated_date =', date('Y-m-d',strtotime($date)));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_prefix()
    {
        $this->db->select("prop_prefix_setting.customer_prefix");
        $this->db->where('company_id',$this->session->userdata('company_id'));
        $query = $this->db->get("prop_prefix_setting");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function insert_user_permission($data) {
        if ($this->db->insert($this->user_permission_table, $data)) {
            $sal_id = $this->db->insert_id();
            return true;
        }
        return false;
    }

    function get_check_otp($id,$otp) {

        $this->db->select('*');
        $this->db->where('user_id',$id);            
        $this->db->where('mail_otp',$otp);
        $query = $this->db->get('prop_users');         
        if ($query->num_rows() > 0) {
            return  1;
        }
        return 0;
    }
    function get_user_details($id) {

        $this->db->select('member.*,country.country_name');
        $this->db->from('prop_membership as member');
       $this->db->join('prop_member_address as address', 'address.Membership_ID = member.Membership_ID', 'left');
       $this->db->join('prop_countries as country', 'country.id = address.country', 'left');
        $this->db->where('member.Membership_ID', $id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return  $query->result_array();
        }
        return NULL;
    }

    function update_user_type($data, $id) {

        $modify['module_name']="User Type";
                $modify['data']=$data['user_type_name'];
                $modify['action']="2";
                $modify['created_by']=$this->session->userdata('id');
                $this->db->insert('prop_modification_history', $modify);
                $data['updated_by']=$this->session->userdata('id');
        $data['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('user_type_id', $id);
        if ($this->db->update($this->user_type_table, $data)) {
            $this->session->set_flashdata('users_success', 'Updated');
            return TRUE;
        }
        return FALSE;
    }

    public function delete($table_name,$id)
    {
        // var_dump($id);
        // $this->db->select('user_type_id');$this->db->from('prop_user_type_permissions');$this->db->where('user_type_id', $id);
        // $this->db->where('company_id', $this->session->userdata('company_id'));
        // $user_type_query = $this->db->get();

        $this->db->select('user_type_id');$this->db->from('prop_users');$this->db->where('user_type_id', $id);
        $this->db->where('company_id', $this->session->userdata('company_id'));        
        $user_type_id = $this->db->get();

        // $user_type_query = $user_type_query->row_array();
        $user_type_id = $user_type_id->row_array();
        if ( $user_type_id > 0) {
        // if ($user_type_query > 0 || $user_type_id > 0) {
            echo "Duplicate";
            $this->session->set_flashdata('duplicate', 'Already Used in Some Page');
        }else{
if($table_name=="prop_users"){ $title="Users"; $where='user_id';}elseif($table_name=="prop_user_types"){$title="User Type"; $where='user_type_id';}

            $this->db->where($where, $id);
            $query = $this->db->get($table_name);
            $get['data']=$query->result_array();
            if($table_name=="prop_users"){ $value=$get['data'][0]['firstname'];}elseif($table_name=="prop_user_types"){ $value= $get['data'][0]['user_type_name'];}
                $modify['module_name']=$title;
                $modify['data']=$value;
                $modify['action']="3";
                $modify['created_by']=$this->session->userdata('id');
                $this->db->insert('prop_modification_history', $modify);
                $data['Deleted_by']=$this->session->userdata('id');
            $data['status'] ="3";
            $this->db->where($where, $id);
            if ($this->db->update($table_name, $data)) {           
                $this->session->set_flashdata('users_success', 'Deleted');            
                $this->session->set_flashdata('user_success', 'Deleted');            
                return TRUE;
            }
            return FALSE;   
        }    
    }
    function get_all_user_types() {
        $user=[1,3];
        $this->db->select($this->user_type_table . '.*');
        $this->db->where('company_id', $this->session->userdata('company_id'));
        $this->db->where('status!=', 3);
        if ($this->session->userdata('user_type_id')==5) {
           $this->db->where_not_in('user_type_id', $user);
        }
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
    
    function get_all_user_types_user() {
        $this->db->select($this->user_type_table . '.*');
        $this->db->where('company_id', $this->session->userdata('company_id'));
        $this->db->where('status!=', 3);
        $this->db->where('user_type_id!=', 3);
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function get_all_user_types_multi($id) {
        $this->db->select($this->user_type_table . '.*');
        $this->db->where('company_id', $this->session->userdata('company_id'));        
        $this->db->where('status!=', 3);
        $id = explode(",", $id); 

        $this->db->where_in('user_type_id', $id);
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function get_all_user_types_active() {
        $this->db->select($this->user_type_table . '.*');
        $this->db->where('company_id', $this->session->userdata('company_id'));        
        $this->db->where('status', 1);
        if ($this->session->userdata('user_type_id')==5) {
           $this->db->where('user_type_id!=', 1);
        }
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function get_all_user_types_active_user() {
        $user=[1,3];
        $this->db->select($this->user_type_table . '.*');
        $this->db->where('company_id', $this->session->userdata('company_id'));        
        $this->db->where('status', 1);
        // $this->db->where_not_in('user_type_id', $user);
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }


    function get_all_companies() {
        $user=[1,3];
        $this->db->select('company_id,company_name');
        // $this->db->where('company_id', $this->session->userdata('company_id'));        
        $this->db->where('status', 1);
        // $this->db->where_not_in('user_type_id', $user);
        $query = $this->db->get('prop_company_table');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    

    function get_all_users() {
        $this->db->select($this->prop_users_table . '.*');
        // $this->db->where('company_id', $this->session->userdata('company_id'));
        $this->db->where('user_type_id!=', 3);
        $this->db->where('status!=', 3);
        if ($this->session->userdata('user_type_id')==5) {
           $this->db->where('user_id!=', 1);
        }
        $query = $this->db->get($this->prop_users_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }


    // function get_all_users_export($id) {
    //     $this->db->select($this->prop_users_table . '.*');

    //     $id = explode(",", $id); 

    //     $this->db->where_in('id', $id);

    //     $query = $this->db->get($this->prop_users_table);
    //     if ($query->num_rows() > 0) {
    //         return $query->result_array();
    //     }
    //     return NULL;
    // }


    function get_user_by_id($user_id) {
       
        $this->db->select($this->prop_users_table . '.*');
        // $this->db->where('company_id', $this->session->userdata('company_id'));
        $this->db->where('user_id', $user_id);
        $query = $this->db->get($this->prop_users_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
       
    }

    // function get_all_users_export($id) {
       
    // $this->db->select($this->prop_users_table . '.*');
    
    // $id = explode(",", $id); 

    // $this->db->where_in('id', $id);
    //     $query = $this->db->get($this->prop_users_table);
    //     if ($query->num_rows() > 0) {
    //         return $query->result_array();
    //     }
    //     return NULL;
       
    // }

    function get_user_desp($user_id) {
       
$this->db->select($this->user_type_table . '.description');
$this->db->where('company_id', $this->session->userdata('company_id'));
 $this->db->where('user_type_id', $user_id);
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
       
    }

    function get_user_type_by_id($id) {
        $this->db->select($this->user_type_table . '.*');
        $this->db->where($this->user_type_table .'.company_id', $this->session->userdata('company_id'));
        $this->db->where($this->user_type_table .'.user_type_id', $id);
        $query = $this->db->get($this->user_type_table);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function get_all_user_sections_with_modules() {
        $this->db->select($this->user_modules_table . '.*');
        $query = $this->db->get($this->user_modules_table);
        $modules = $query->result_array();
        $user_section_arr = array();
        if (!empty($modules)) {
            foreach ($modules as $module) {
                $sections = $this->get_user_sections_by_module_id($module['id']);
                $user_section_arr[$module['id']] = $module;
                $user_section_arr[$module['id']]['sections'] = $sections;
            }
        }
        return $user_section_arr;
    }   

    function get_user_sections_by_module_id($id) {
        $this->db->select('tab_1.id,tab_1.user_section_name,,tab_1.user_section_key,acc_view,acc_add,acc_edit,acc_delete');
        $this->db->join($this->user_modules_table . ' AS tab_2', 'tab_2.id = tab_1.module_id', 'LEFT');
        $this->db->where('tab_1.module_id', $id);
        $this->db->where('tab_1.status', 1);
        $query = $this->db->get($this->user_sections_table . ' AS tab_1');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    function get_user_permissions_by_type($user_type_id) {
        $this->db->select('tab_1.*');
        $this->db->where('tab_1.user_type_id', $user_type_id);
        $query = $this->db->get($this->user_permission_table . ' AS tab_1');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
        function get_financial_year() {
        $this->db->select('*');
        $this->db->where('Status',1);
        $query = $this->db->get('prop_financial_yr_table');
        if ($query->num_rows() > 0) {
            return  $query->row();
        }
        return NULL;
    }
    
    function get_session_time() {
        $this->db->select('*');
        // $this->db->where('Status',1);
        $query = $this->db->get('prop_signout_setting');
        if ($query->num_rows() > 0) {
            return  $query->row();
        }
        return NULL;
    }

    function get_user_permissions_by_type_1($user_type_id) {
        // $this->db->select('tab_1.*');
        // $this->db->where('tab_1.user_type_id', $user_type_id);
        $query = $this->db->query("SELECT user_type_id,module_id FROM `prop_user_type_permissions` WHERE user_type_id='{$user_type_id}' group by `module_id` ");
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
    function delete_user_permission_by_type($type) {
        $this->db->where('user_type_id', $type);
        if ($this->db->delete($this->user_permission_table)) {
            if ($this->db->affected_rows() > 0) {
                return true;
            }
        }
        return false;
    }


    function get_increment_code() {
        $entry_number = $this->db->count_all_results($this->prop_users_table)+1;

        return $entry_number;
    }

    function insert_user($data) {
        $modify['module_name']="Users";
                $modify['data']=$data['firstname'];
                $modify['action']="1";
                $modify['created_by']=$this->session->userdata('id');
                $this->db->insert('prop_modification_history', $modify);
                $data['created_by']=$this->session->userdata('id');
                $data['og_password'] = $data['password'];
                $data['password'] = md5($data['password']);
                // var_dump($data);die();
        if ($this->db->insert($this->prop_users_table, $data)) {
            $user_id = $this->db->insert_id();
            $this->session->set_flashdata('user_success', 'Added');
            return $user_id;
        }else{
            return FALSE;
        }
        
    }

        function update_user($data, $user_id,$image_data) {
           
        if (empty($data['password'])) {
            unset($data['password']);
        } else {
            $data['og_password'] = $data['password'];
            $data['password'] = md5($data['password']);
        }
        $modify['module_name']="Users";
                $modify['data']=$data['firstname'];
                $modify['action']="2";
                $modify['created_by']=$this->session->userdata('id');
                $this->db->insert('prop_modification_history', $modify);
                $data['updated_by']=$this->session->userdata('id');
        $data['updated_date'] = date('Y-m-d H:i:s');
        $data['profile'] = $image_data;

        // var_dump($data);die();
        $this->db->where('user_id', $user_id);
        if ($this->db->update($this->prop_users_table, $data)) {
            return TRUE;
        }
        return FALSE;
    }

   
   
   function delete_checkbox($id){
   $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 3;    
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_users', $data)) {
               $this->session->set_flashdata('user_success', 'Deleted');
               return TRUE;
          }
       
           return FALSE;                
        }
   
   
   function active_all_checkbox($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 1;    
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_users', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
   function deactivate_all_checkbox($id){
   
         $data['updated_date'] = date('Y-m-d H:i:s');
         $data['status']         = 2;
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_users', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
   
   
   function delete_checkbox1($id){
   // $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status'] = 3;    
   
           $this->db->where('user_id', $id);
           $this->db->where('user_mode', 2);
           if ($this->db->update('prop_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Deleted');
               return TRUE;
          }
       
           return FALSE;                
        }
   
   
   function active_all_checkbox1($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 1;    
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }
   
    function active_all_checkbox11($id){
         
                $data['updated_date'] = date('Y-m-d H:i:s');
                 $data['status']         = 2;    
   
           $this->db->where('user_id', $id);
           if ($this->db->update('prop_user_types', $data)) {
               $this->session->set_flashdata('user_success', 'Updated');
               return TRUE;
           }
           return FALSE;  
   }

       function get_all_users1() {
        $this->db->select('users.*,user_type.user_type_name,countries.country_name,states.state_name,cities.city_name')->from('prop_users as users');
        $this->db->join('prop_user_types as user_type', 'user_type.id = users.user_type_id', 'left');
        $this->db->join('prop_countries as countries', 'countries.id = users.country_id', 'left');
        $this->db->join('prop_states as states', 'states.id = users.state_id', 'left');
        $this->db->join('prop_cities as cities', 'cities.id = users.city_id', 'left');
        // $this->db->join('prop_company_table as company', 'company.company_id = users.company_id', 'left');
         // $this->db->join('prop_hub_branch as branch', 'branch.id = users.branch_id', 'left');
        $this->db->where('users.status!=', 3);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
   
   function get_all_users_multi($id) {
        $this->db->select('users.*,user_type.user_type_name,countries.country_name,states.state_name,cities.city_name')->from('prop_users as users');
        $this->db->join('prop_user_types as user_type', 'user_type.id = users.user_type_id', 'left');
        $this->db->join('prop_countries as countries', 'countries.id = users.country_id', 'left');
        $this->db->join('prop_states as states', 'states.id = users.state_id', 'left');
        $this->db->join('prop_cities as cities', 'cities.id = users.city_id', 'left');
        // $this->db->join('prop_company_table as company', 'company.company_id = users.company_id', 'left');
        // $this->db->join('prop_hub_branch as branch', 'branch.id = users.branch_id', 'left');
        $this->db->where('users.status!=', 3);
        $id = explode(",", $id); 

        $this->db->where_in('users.user_id', $id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
   
}