<?php if($_POST['type']=='get_lease_report'){if(!empty($lease)){ ?>

  <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/datatables.net-bs4/css/dataTables.bootstrap4.css"> -->
  <!-- <script src="<?php echo base_url(); ?>assets/js/components/datatables-init.js"></script> -->


  <table class="table table-striped table-bordered table-responsive tablescript_data">
    <thead>
     <tr>
      <th class="text-center" style="width: 2%">S.No</th>
      <th class="text-center" style="width: 20%">Tenant.Name</th>
      <th class="text-center" style="width: 20%">Tenant.Origin</th>
      <th class="text-center" style="width: 20%">Tenant.Type</th>
      <th class="text-center" style="width: 20%">Lease.Type</th>
      <th class="text-center" style="width: 10%">Area</th>
      <th class="text-center" style="width: 10%">Current.Area.Sqm</th>
      <th class="text-center" style="width: 10%">Rate.per.Sqm</th>
      <th class="text-center" style="width: 10%">Total.Area.Rent</th>
      <th class="text-center" style="width: 10%">Lease.Period</th>
      <th class="text-center" style="width: 10%">Management.Fees</th>
      <th class="text-center" style="width: 10%">Parking.Fees</th>
      <th class="text-center" style="width: 10%">Air.Condition.Fees</th>
      <th class="text-center" style="width: 10%">Escalation.Fees</th>
      <th class="text-center" style="width: 10%">Initail.Lease.Commencement</th>
      <th class="text-center" style="width: 10%">Final.Lease.Commencement</th>
      <th class="text-center" style="width: 10%">Total.Lease.Amount</th>
      <th class="text-center" style="width: 5%">Status</th>                            
    </tr>
  </thead>
  <tbody>

   <?php  $maintain_total= $parking_total= $aircondition_total= $escalation_total =$amount_total=0;
   if (!empty($lease)) {$s = 1; foreach ($lease as $list) {?>
     <tr>
      <td ><?php echo $s; ?></td>
      <td class="text-left" style="color: #db3236; font-size: large"><?php echo ucfirst($list['customer_name']); ?></td>
      <td class="text-center"><?php echo strtoupper($list['tenant_origin']); ?></td>

      <td class="text-center"><?php echo strtoupper($list['tenant_type']); ?></td>

      <td class="text-center"><?php echo strtoupper($list['lease_type']); ?></td>

      <td class="text-center"><?php echo strtoupper($list['area_name']); ?></td>

      <td class="text-center"><?php echo strtoupper($list['area_sqm']); ?></td>

      <td class="text-right"><i class="la la-rupee"></i> <?php echo strtoupper($list['area_rent']); ?></td>

      <td class="text-right"><i class="la la-rupee"></i> <?php echo strtoupper($list['area_total']); ?></td>

      <td class="text-center"><?php echo strtoupper($list['lease_tenure']); ?> Years</td>

      <?php $maintain= $parking= $aircondition= $escalation=0;
      $lease_detail    =   $this->Lease_model->get_lease_detail_by($list['lease_id']); 

      foreach ($lease_detail as $key => $value) {

       if ($value['category_type']=='MAINTENANCE') {$maintain=$value['category_value']; $maintain_total+=$value['category_value'];}

       if ($value['category_type']=='PARKING') {$parking=$value['category_value']; $parking_total+=$value['category_value'];}

       if ($value['category_type']=='AIRCONDITION') {$aircondition=$value['category_value']; $aircondition_total+=$value['category_value'];}

       if ($value['category_type']=='ESCALATION') {$escalation=$value['category_value'];$escalation_total+=$value['category_value']; }

     } ?>


     <td class="text-right"><i class="la la-rupee"></i> <?php echo number_format($maintain,2); ?></td>

     <td class="text-right"><i class="la la-rupee"></i> <?php echo number_format($parking,2); ?></td>

     <td class="text-right"><i class="la la-rupee"></i> <?php echo number_format($aircondition,2); ?></td>

     <td class="text-right"><i class="la la-rupee"></i> <?php echo number_format($escalation,2); ?></td>

     <td class="text-center"><?php echo date('d-m-Y',strtotime($list['start_date'])); ?></td>

     <td class="text-center"><?php echo date('d-m-Y',strtotime($list['end_date'])); ?></td>

     <td class="text-right" style="color: #db3236; font-size: large"><i class="la la-rupee"></i> <?php echo number_format($list['area_total']+$list['detail_total'],2); $amount_total+=$list['area_total']+$list['detail_total'];?></td>
     <td>

      <span class="badge badge-danger">Expired </span>
  </td>
</tr>
<?php $s++; } } ?>
<tr>
  <td colspan="10"></td>
  <td class="text-right" style="font-size: large;color: #1e5598"><?php echo number_format($maintain_total,2); ?></td>
  <td class="text-right" style="font-size: large;color: #1e5598"><?php echo number_format($parking_total,2); ?></td>
  <td class="text-right" style="font-size: large;color: #1e5598"><?php echo number_format($aircondition_total,2); ?></td>
  <td class="text-right" style="font-size: large;color: #1e5598"><?php echo number_format($escalation_total,2); ?></td>
  <td></td>
  <td></td>
  <td class="text-right" style="font-size: large;color: #1e5598;"><?php echo number_format($amount_total,2); ?></td>
  <td></td>
</tr>
</tbody>
</table>

<?php }else{ ?>
  <table  class="table table-striped table-bordered table-responsive tablescript_data">
    <thead>
     <tr>
      <th class="text-center" style="width: 2%">S.No</th>
      <th class="text-center" style="width: 20%">Tenant.Name</th>
      <th class="text-center" style="width: 20%">Tenant.Origin</th>
      <th class="text-center" style="width: 20%">Tenant.Type</th>
      <th class="text-center" style="width: 20%">Lease.Type</th>
      <th class="text-center" style="width: 10%">Area</th>
      <th class="text-center" style="width: 10%">Current.Area.Sqm</th>
      <th class="text-center" style="width: 10%">Rate.per.Sqm</th>
      <th class="text-center" style="width: 10%">Total.Area.Rent</th>
      <th class="text-center" style="width: 10%">Lease.Period</th>
      <th class="text-center" style="width: 10%">Management.Fees</th>
      <th class="text-center" style="width: 10%">Parking.Fees</th>
      <th class="text-center" style="width: 10%">Air.Condition.Fees</th>
      <th class="text-center" style="width: 10%">Escalation.Fees</th>
      <th class="text-center" style="width: 10%">Initail.Lease.Commencement</th>
      <th class="text-center" style="width: 10%">Final.Lease.Commencement</th>
      <th class="text-center" style="width: 10%">Total.Lease.Amount</th>
      <th class="text-center" style="width: 5%">Status</th>                            
    </tr>
  </thead>
</table>

<?php }} ?>

<script>
  $(document).ready(function(){
   $('.tablescript_data').dataTable();
 });
</script>