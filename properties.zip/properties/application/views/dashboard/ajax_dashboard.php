<?php if($_POST['type']=='get_bank_details'){if(!empty($active_bank)){ ?>


<table id="bs4-table" class="table table-striped table-bordered table table-responsive" style="width:100%" >
<thead>
   <tr>
    <th class="text-center" style="width: 2%">
         <input type="checkbox" name="checkbox" class="checkbox" id="select_all" /> 
     </th>
      <th style="width: 5%">Name</th>                                   
      <th style="width: 5%">Bank</th>                         
      <th style="width: 5%">AC Holder</th>                             
      <th style="width: 5%">AC Number</th>                           
      <th style="width: 5%">Branch</th>                             
      <th style="width: 5%">IFSC</th>                             
      <th style="width: 5%">Status</th>                             
      <th style="width: 5%">Action</th>  
   </tr>
</thead>
<tbody>
   <?php if (!empty($active_bank)) {$s = 1; foreach ($active_bank as $list) {?>
   <tr>
     <td class="text-center">
      <?php if ($list['Status'] != 6) {?>
      <input type="checkbox" name="checkbox" class="checkbox boxischecked" value="<?php echo ucfirst($list['Member_bank_ID']); ?>"  />
      <?php }else{ ?>
        <input type="checkbox" class="disabled" value="<?php echo ucfirst($list['Member_bank_ID']); ?>"  />
      <?php } ?>
    </td>
      <td class="s_no"><?php echo ucfirst($list['First_name']); ?></td>
      <td class="s_no"><?php echo ucfirst($list['Bank_name']); ?></td>
      <td class="s_no"><?php echo ucfirst($list['Account_holder']); ?></td>
      <td class="s_no"><?php echo ucfirst($list['Account_no']); ?></td>
      <td class="s_no"><?php echo ucfirst($list['Branch']); ?></td>
      <td class="s_no"><?php echo ucfirst($list['IFSC']); ?></td>
      
      
      <td class="text-center"><span class="badge badge-<?php echo ($list['Status'] == 6) ? 'success' : 'danger'; ?>"><?php echo ($list['Status'] == 6) ? 'Active' : 'In-Active'; ?></span>
      </td>

     <td class="text-center"> 
      <?php if ($list['Status'] != 6) {?>
      <a href="" onclick="activate_bank('<?php echo $list['Member_bank_ID']; ?>','<?php echo $list['Membership_ID']; ?>')" class="btn btn-success btn-sm" data-toggle="modal" data-target="#activatemodel" ><i class="zmdi zmdi-check zmdi-hc-fw" style="color:  white;" data-toggle="tooltip" data-placement="top" data-original-title="Activate"></i></a>  
      <?php }else{ ?>
        <a href=""class="btn btn-success btn-sm disabled"  ><i class="zmdi zmdi-check zmdi-hc-fw" style="color:  white;" data-toggle="tooltip" data-placement="top" data-original-title="Activate"></i></a>  
      <?php } ?>
      </td>
   </tr>
   <?php $s++; } } ?>



</tbody>
</table>


 <script>

    $(document).ready(function(){
     $('#bs4-table').DataTable();
    });

    $(document).ready(function(){

    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
        
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });

    });
        $('.delbtn').prop('disabled', true);
        $('.checkbox').change(function(){
        $('.delbtn').prop('disabled', $('.checkbox:checked').length == 0);
    })


    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;

            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });

</script>


<?php }else{ ?>


<table id="bs4-table1" class="table table-striped table-bordered table table-responsive" style="width:100%" >
  <thead>
   <tr>
    <th class="text-center" style="width: 2%">
         <input type="checkbox" name="checkbox" class="checkbox" id="select_all" /> 
     </th>
      <th style="width: 5%">Name</th>                                   
      <th style="width: 5%">Bank</th>                         
      <th style="width: 5%">AC Holder</th>                             
      <th style="width: 5%">AC Number</th>                           
      <th style="width: 5%">Branch</th>                             
      <th style="width: 5%">IFSC</th>                             
      <th style="width: 5%">Status</th>                             
      <th style="width: 5%">Action</th>  
   </tr>
  </thead>
  <tbody></tbody>
</table>
<script>

  $(document).ready(function(){
   $('#bs4-table1').DataTable();
  });

  $(document).ready(function(){
    $('.card-header').on('click', function() {
      $('.block-el').show();
    });
  });

</script>

<?php }} ?>
