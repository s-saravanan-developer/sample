<?php
header('Content-type: application/octet-stream');
header('Content-Disposition: attachment; filename=Lease Report-' . date('d-m-Y') . '.xls');
header('Pragma: no-cache');
header('Expires: 0');
?>

<style type="text/css">
    table { border:1px #dfdfdf solid; border-collapse:collapse; }
    table th,td { border:1px #dfdfdf solid; text-align:center; }
</style>
<table  class="table table-striped table-bordered table-responsive tablescript">
    <thead>
     <tr>
      <th>S.No</th>
      <th>Tenant.Name</th>
      <th>Tenant.Origin</th>
      <th>Tenant.Type</th>
      <th>Lease.Type</th>
      <th>Area</th>
      <th>Current.Area.Sqm</th>
      <th>Rate.per.Sqm</th>
      <th>Total.Area.Rent</th>
      <th>Lease.Period</th>
      <th>Management.Fees</th>
      <th>Parking.Fees</th>
      <th>Air.Condition.Fees</th>
      <th>Escalation.Fees</th>
      <th>Initail.Lease.Commencement</th>
      <th>Final.Lease.Commencement</th>
      <th>Total.Lease.Amount</th>
      <th>Status</th>                          
    </tr>
  </thead>
  <tbody>
 
   <?php  $maintain_total= $parking_total= $aircondition_total= $escalation_total =$amount_total=0;
   if (!empty($lease)) {$s = 1; foreach ($lease as $list) {?>
     <tr>
      <td ><?php echo $s; ?></td>
      <td class="text-center" style="color: #db3236; font-size: large"><?php echo ucfirst($list['customer_name']); ?></td>
      <td class="text-center"><?php echo strtoupper($list['tenant_origin']); ?></td>

      <td class="text-center"><?php echo strtoupper($list['tenant_type']); ?></td>

      <td class="text-center"><?php echo strtoupper($list['lease_type']); ?></td>

      <td class="text-center"><?php echo strtoupper($list['area_name']); ?></td>

      <td class="text-center"><?php echo strtoupper($list['area_sqm']); ?></td>

      <td class="text-right"><i class="la la-rupee"></i> <?php echo strtoupper($list['area_rent']); ?></td>

      <td class="text-right"><i class="la la-rupee"></i> <?php echo strtoupper($list['area_total']); ?></td>

      <td class="text-center"><?php echo strtoupper($list['lease_tenure']); ?> Years</td>


        <?php $maintain= $parking= $aircondition= $escalation=0;
         $lease_detail    =   $this->Lease_model->get_lease_detail_by($list['lease_id']); 
        foreach ($lease_detail as $key => $value) {
       
         if ($value['category_type']=='MAINTENANCE') {$maintain=$value['category_value']; $maintain_total+=$value['category_value'];}
         if ($value['category_type']=='PARKING') {$parking=$value['category_value']; $parking_total+=$value['category_value'];}
         if ($value['category_type']=='AIRCONDITION') {$aircondition=$value['category_value']; $aircondition_total+=$value['category_value'];}
         if ($value['category_type']=='ESCALATION') {$escalation=$value['category_value'];$escalation_total+=$value['category_value']; }
        } ?>

      <td class="text-right"><?php echo number_format($maintain,2); ?></td>

      <td class="text-right"><?php echo number_format($parking,2); ?></td>

      <td class="text-right"><?php echo number_format($aircondition,2); ?></td>

      <td class="text-right"><?php echo number_format($escalation,2); ?></td>

      <td class="text-center"><?php echo date('d-m-Y',strtotime($list['start_date'])); ?></td>

      <td class="text-center"><?php echo date('d-m-Y',strtotime($list['end_date'])); ?></td>

      <td class="text-right" style="color: #db3236; font-size: large"><i class="la la-rupee"></i> <?php echo number_format($list['area_total']+$list['detail_total'],2); $amount_total+=$list['area_total']+$list['detail_total'];?></td>
      <td>
        <?php if (date('Y-m-d')>=$list['end_date']) { ?>
          <span class="badge badge-<?php echo ($list['status'] == 1) ? 'success' : 'danger'; ?>"><?php echo ($list['status'] == 1) ? 'Active' : 'In-Active'; ?>
          </span>
        <?php }else{ ?>
          <span class="badge badge-danger">Expired </span>
        <?php } ?>
       
    </td>
  </tr>
  <?php $s++; } } ?>
  <tr>
    <td colspan="10"></td>
    <td style="color: #1e5598"><?php echo number_format($maintain_total,2); ?></td>
    <td style="color: #1e5598"><?php echo number_format($parking_total,2); ?></td>
    <td style="color: #1e5598"><?php echo number_format($aircondition_total,2); ?></td>
    <td style="color: #1e5598"><?php echo number_format($escalation_total,2); ?></td>
    <td></td>
    <td></td>
    <td style="font-size: large;color: #1e5598;"><?php echo number_format($amount_total,2); ?></td>
    <td></td>
  </tr>
</tbody>
</table>
