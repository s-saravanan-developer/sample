<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Company_model extends CI_Model {

    private $gc_company = 'gc_company_table';   

    public function get_all_company() {
        $this->db->select('company.*,country.country_name,state.state_name,city.city_name');
        $this->db->from('gc_company_table as company');
        $this->db->join('gc_cities as city', 'city.id = company.CityID', 'left');
        $this->db->join('gc_states as state', 'state.id = company.StateID', 'left');
        $this->db->join('gc_countries as country', 'country.id = company.Country', 'left');
        $this->db->where('company.CompanyStatus!=',3);
        //$this->db->where('company.CompanyID', $this->session->userdata('CompanyId'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
                $company_base = $query->result_array(); 
                foreach ($company_base as $key => $value) {
                    $delete_status = $this->check_delete_status($value['CompanyID']);
                    if(isset($delete_status)){ 
                        $company_base[$key]['delete_status'] = 1; 
                    }
                    else{ 
                        $company_base[$key]['delete_status'] = 0;
                    }    
                }
            return $company_base;
        }
        return NULL;
    }

    public function check_delete_status($company_id){
        $this->db->select('company.CompanyID');
        $this->db->from('gc_company_table as company');        
        $this->db->join('gc_hub_branch as region','region.company_id = company.CompanyID','left');
        $this->db->where('region.company_id',$company_id);
        $this->db->where('company.CompanyID', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_edit_company_data($id)
    {
        $this->db->select('*');     
        $this->db->from('gc_company_table');
        $this->db->where('CompanyID', $id);
        //$this->db->where('CompanyID', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

        public function get_all_company_data()
    {
        $this->db->select('*');     
        $this->db->from('gc_company_table');
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

   /**
     * Company Data Add 
     */
    public function insert_company($adding_company_data)
    {
        $modify['Module_name']="Company";
                $modify['Data']=$adding_company_data['CompanyName'];
                $modify['Action']="1";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);

        $adding_company_data['Created_by']=$this->session->userdata('UserId');
        // $adding_company_data['financial_yr_id']=$this->session->userdata('Financial_yr_id');
        if ($this->db->insert('gc_company_table', $adding_company_data)) {
            $this->session->set_flashdata('category_success', 'Added');
            return $this->db->insert_id();
        }
        return FALSE;       
    }

    function insert_branch($data) {
        if ($this->db->insert('gc_hub_branch', $data)) {
            $Branch_id = $this->db->insert_id();
            $this->session->set_flashdata('user_success', 'Added');
            return $Branch_id;
        }
        return FALSE;
    }
    /**
     * Company Data Add 
     */
    public function edit_company($editing_company_data,$id,$image_data)
    {
        $modify['Module_name']="Company";
                $modify['Data']=$editing_company_data['CompanyName'];
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);

            $editing_company_data['Updated_by']=$this->session->userdata('UserId');
        $editing_company_data['updatedon'] = date('Y-m-d H:i:s');
        $editing_company_data['CompanyLogo'] = $image_data;
        $this->db->where('CompanyID', $id);
        if ($this->db->update('gc_company_table', $editing_company_data)) {
            return TRUE;
        }
        return FALSE;       
    }


    /**
     * Branch Data Edit 
     */
    public function edit_branch($editing_branch_data,$id)
    {
        $editing_company_data['Updated_by']=$this->session->userdata('UserId');
        $editing_company_data['Updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('Company_id', $id);
        if ($this->db->update(' gc_hub_branch', $editing_branch_data)) {
            return TRUE;
        }
        return FALSE;       
    }
    

    /**
     * Company Data Edit 
     */
    public function editing_customer_group($adding_customer_group_data_edit,$id)
    {
        $Company_data_edit['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', $id);
        if ($this->db->update('gc_customer_group', $adding_customer_group_data_edit)) {
            return TRUE;
        }
        return FALSE;       
    }


    /**
     * Comman Model To Delete or update the Data
     * @param  [type] $table_name [description]
     * @param  [type] $id         [description]
     * @return [type]             [description]
     */
    public function delete($table_name,$id)
    {
            $this->db->where('CompanyID', $id);
            $query = $this->db->get('gc_company_table');
            $get['data']=$query->result_array();
                $modify['Module_name']="Company";
                $modify['Data']=$get['data'][0]['CompanyName'];
                $modify['Action']="3";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);
                $data['Deleted_by']=$this->session->userdata('UserId');
        $data['CompanyStatus'] ="3";
        $this->db->where('CompanyID', $id);
        if ($this->db->update($table_name, $data)) {
            return TRUE;
           
        }
        return FALSE;  
        
    }

    // Prefix Get Data
    
    public function get_prefix_setting_data()
    {   $this->db->where('company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get('gc_prefix_setting');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function inserting_prefix_data($prefix_data)
    {
        $modify['Module_name']="Prefix Settings";
                $modify['Data']="Prefix Data";
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);

            $prefix_data['Updated_by']=$this->session->userdata('UserId');

        $prefix_data['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', 1);
        if ($this->db->update('gc_prefix_setting', $prefix_data)) {
            return TRUE;
        }
        return FALSE; 
    }

    public function get_transaction_prefix_data()
    {
        $query = $this->db->get('gc_transaction_prefix');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function inserting_transaction_prefix_data($transaction_data)
    {
                $modify['Module_name']="Transaction  Settings";
                $modify['Data']="Transaction";
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);

            $transaction_data['Updated_by']=$this->session->userdata('UserId');
        $transaction_data['updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', 1);
        if ($this->db->update('gc_transaction_prefix', $transaction_data)) {
            return TRUE;
        }
        return FALSE; 
    }


    // Get Prefix For Specific Id BRANCH
    public function get_prefix_setting_data_branch($id)
    {
        $this->db->where('branch_id',$id);
        $this->db->where('company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get('gc_prefix_setting');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function updating_branch_prefix($data,$id){

            $modify['Module_name']="Prefix  Settings";
                $modify['Data']="Branch Prefix";
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);

            $data['Updated_by']=$this->session->userdata('UserId');
        $this->db->where('branch_id', $id);
        if($this->db->update('gc_prefix_setting', $data)){
            return TRUE;
        }
        return false;
    }

    public function updating_transaction_prefix($data,$id){

        $modify['Module_name']="Transaction  Settings";
                $modify['Data']="Transaction Prefix";
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);

            $data['Updated_by']=$this->session->userdata('UserId');
        $this->db->where('branch_id', $id);
        if($this->db->update('gc_transaction_prefix', $data)){
            return TRUE;
        }
        return false;
    }

    public function get_transaction_prefix_data_branch($id)
    {
        $this->db->select('*,transaction.id as t_id');
        $this->db->from('gc_transaction_prefix_region as transaction');
        $this->db->join('gc_team_details as team', 'team.id = transaction.team_id', 'left');
        $this->db->where('transaction.region_id', $id);
        $this->db->where('transaction.common_based_prefix_status!=', 1);
        $this->db->where('transaction.team_based_prefix_status=', 1);
        $this->db->where('transaction.company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_transaction_prefix_common($id)
    {
        // $this->db->select('transaction.id,
        //     transaction.user_prefix,transaction.customer_prefix,transaction.employee_prefix,transaction.vendor_prefix,transaction.manufacture_prefix,
        //     transaction.grn,transaction.purchase_return,transaction.scheme,transaction.stock_transfer,
        //     transaction.close_book,transaction.close_date,transaction.allow_change,transaction.warning_days,
        //     transaction.drug_item_type,transaction.drug_price_type,transaction.so_tax,transaction.day_setting,
        //     transaction.dispatch_buff_date,transaction.ds_detail_team_id,
        //     transaction.dispatch_prefix,transaction.credit_prefix,transaction.debit_prefix'
        // );
        $this->db->select('*');
        $this->db->from('gc_transaction_prefix_region as transaction');
        $this->db->where('transaction.region_id', $id);
        $this->db->where('transaction.common_based_prefix_status', 1);
        $this->db->where('transaction.company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    public function get_transaction_prefix_advice($id)
    {
        $this->db->select('transaction.advice_qty,transaction.advice_gst');
        $this->db->from('gc_transaction_prefix_region as transaction');
        $this->db->where('transaction.region_id', $id);
        $this->db->where('transaction.common_based_prefix_status', 1);
        $this->db->where('transaction.company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    // Advanced Setting
    
    // Inserting
    public function tree_color_setting_insert($account_data)
    {
                $modify['Module_name']="Advanced Settings";
                $modify['Data']="Tree Color 
                Settings";
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);

                if($account_data['ID']==''){    
                    $account_data['Company_id']=$this->session->userdata('CompanyId');
                    $account_data['Branch_id']=$this->session->userdata('CompanyId');
                    $account_data['Created_by']=$this->session->userdata('UserId');
                    $account_data['Created_date'] = date('Y-m-d H:i:s');
                    $this->db->insert('gc_tree_color_setting', $account_data);
                }else{
                $account_data['Updated_by']=$this->session->userdata('UserId');
                $account_data['Updated_date'] = date('Y-m-d H:i:s');
                $this->db->where('ID', $account_data['ID']);
                $this->db->update('gc_tree_color_setting', $account_data);
            }
        
    }

        

    
        public function get_account_setting_data()
    {   
        $this->db->where('Company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get('gc_advanced_settings');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    // Viewing
    public function account_setting_view()
    {   $this->db->where('Company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get('gc_advanced_settings');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    // Inserting
    public function currency_setting_insert($currency_data)
    {
         $modify['Module_name']="Advanced Settings";
                $modify['Data']="Currency 
                Settings";
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);

$currency_data['Updated_by']=$this->session->userdata('UserId');
        $currency_data['Updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', 1);
        if ($this->db->update('gc_advanced_settings', $currency_data)) {
            return TRUE;
        }
        return FALSE; 
    }

    // Viewing
    public function date_num_setting_view()
    {   $this->db->where('Company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get('gc_advanced_settings');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    // Inserting
    public function date_num_setting_insert($date_num_data)
    {
         $modify['Module_name']="Advanced Settings";
                $modify['Data']="Date & Time 
                Settings";
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);
        //print_r($date_num_data); die();
                $date_num_data['Updated_by']=$this->session->userdata('UserId');
        $date_num_data['Updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', 1);
        if ($this->db->update('gc_advanced_settings', $date_num_data)) {
            return TRUE;
        }
        return FALSE; 
    }

    // Viewing
    public function currency_setting_view()
    {   $this->db->where('Company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get('gc_advanced_settings');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    // Inserting
    public function signout_setting_insert($signout_data)
    {
        $modify['Module_name']="Advanced Settings";
                $modify['Data']="Signout $ Account 
                Settings";
                $modify['Action']="2";
                $modify['Created_by']=$this->session->userdata('UserId');
                $this->db->insert('gc_modification_history', $modify);
        //print_r($date_num_data); die();
                $signout_data['Updated_by']=$this->session->userdata('UserId');
        $signout_data['Updated_date'] = date('Y-m-d H:i:s');
        $this->db->where('id', 1);
        if ($this->db->update('gc_advanced_settings', $signout_data)) {
            return TRUE;
        }
        return FALSE; 
    }

    // Viewing
    public function signout_setting_view()
    {   
        $this->db->where('Company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get('gc_advanced_settings');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
        public function tree_setting_view()
    {   
        $this->db->where('Company_id', $this->session->userdata('CompanyId'));
        $query = $this->db->get('gc_tree_color_setting');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
        public function levels_view()
    {   
        $this->db->where('Status', 1);
        $query = $this->db->get('gc_leveltype');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

        public function members_view()
    {   
        $this->db->where('Status', 1);
        $query = $this->db->get('gc_membershiptype');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }

    


    public function check_duplicate_function_company($name)
    {
        $this->db->select('company.CompanyName');
        $this->db->from('gc_company_table as company');
        $this->db->where('company.CompanyName', $name);
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return NULL;
    }
}